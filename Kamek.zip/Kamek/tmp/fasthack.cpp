//
// processed\../src/profile.cpp
//

#include <profile.h>
#include <game.h>


/* SPRITES */

SpriteData sprites[SpriteId::Num] = { 0 };

class SpritesSetter
{
public:
    SpritesSetter();
};

SpritesSetter::SpritesSetter()
{
    for (u32 i = 0; i < 483; i++)
        sprites[i] = originalSprites[i];
}

static SpritesSetter doSetSprites;

/* PROFILES */

Profile* profiles[ProfileId::Num] = { 0 };
extern "C" Profile** ObjectProfileList;

class ProfileSetter
{
public:
    ProfileSetter();
};

ProfileSetter::ProfileSetter()
{
    ObjectProfileList = &profiles[0];

    for (u32 i = 0; i < ORIGINAL_PROFILES; i++) {
        profiles[i] = originalProfiles[i];
    }
}

static ProfileSetter doSetProfiles;

void SetObjectProfileList()
{
    ObjectProfileList = &profiles[0];
}

/* SPRITE FILES */

extern "C" const char** spriteFiles[483];
const char** customSpriteFiles[SpriteId::Num - 483] = { 0 };

/* PROFILE NAMES*/

extern "C" const char* profileNames[ORIGINAL_PROFILES];
const char* customProfileNames[ProfileId::Num - ORIGINAL_PROFILES] = { 0 };

const char* GetProfileName(u32 profileId)
{
    if (profileId < ORIGINAL_PROFILES) {
        return profileNames[profileId];
    }

    return customProfileNames[profileId - ORIGINAL_PROFILES];
}

/* CUSTOM PROFILE CTOR */

Profile::Profile(dActor_c* (*buildFunc)(), u32 id, const SpriteData* spriteData, u16 executeOrderProfileId, u16 drawOrderProfileId, const char* name, const char** files, u32 flags) {
    this->buildFunc = buildFunc;
    this->executeOrderProfileId = executeOrderProfileId;
    this->drawOrderProfileId = drawOrderProfileId;
	this->flags = flags;

	u32 profileId;
	if (spriteData) {
		sprites[id] = *spriteData;
		if (id < 483) {
			spriteFiles[id] = files;
		} else {
			customSpriteFiles[id - 483] = files;
		}
		profileId = spriteData->profileId;
	}
	else {
		profileId = id;
	}
	
	profiles[profileId] = this;
	if (profileId < ORIGINAL_PROFILES) {
		profileNames[profileId] = name;
	}
	else {
		customProfileNames[profileId - ORIGINAL_PROFILES] = name;
	}
}
//
// processed\../src/apDebug.cpp
//

#include <game.h>

class APDebugDrawer : public m3d::proc_c {
	public:
		APDebugDrawer();

		bool amISetUp;
		mHeapAllocator_c allocator;

		void setMeUp();

		void drawMe();

		void drawOpa();
		void drawXlu();
};


static APDebugDrawer defaultInstance;
static bool enableDebugMode = false;

int APDebugDraw() {
	if (enableDebugMode)
		defaultInstance.drawMe();
	return 1;
}


APDebugDrawer::APDebugDrawer() {
	amISetUp = false;
}

void APDebugDrawer::setMeUp() {
	allocator.setup(GameHeaps[0], 0x20);
	setup(&allocator);
}

void APDebugDrawer::drawMe() {
	if (!amISetUp) {
		setMeUp();
		amISetUp = true;
	}

	scheduleForDrawing();
}

void APDebugDrawer::drawOpa() {
	drawXlu();
}
void APDebugDrawer::drawXlu() {
	GXClearVtxDesc();

	GXSetVtxDesc(GX_VA_POS, GX_DIRECT);
	GXSetVtxDesc(GX_VA_CLR0, GX_DIRECT);

	GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS, GX_POS_XYZ, GX_F32, 0);
	GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR0, GX_CLR_RGBA, GX_RGBA8, 0);

	GXSetNumIndStages(0);
	for (int i = 0; i < 0x10; i++)
		GXSetTevDirect(i);

	GXSetNumChans(1);
	GXSetChanCtrl(GX_COLOR0A0, GX_DISABLE, GX_SRC_REG, GX_SRC_VTX, GX_LIGHTNULL, GX_DF_NONE, GX_AF_NONE);
	GXSetChanAmbColor(GX_COLOR0A0, (GXColor){255,255,255,255});
	GXSetChanMatColor(GX_COLOR0A0, (GXColor){255,255,255,255});
	GXSetNumTexGens(0);

	GXSetNumTevStages(1);
	GXSetNumIndStages(0);

	GXSetTevSwapModeTable(GX_TEV_SWAP0, GX_CH_RED, GX_CH_GREEN, GX_CH_BLUE, GX_CH_ALPHA);

	GXSetTevOrder(GX_TEVSTAGE0, GX_TEXCOORDNULL, GX_TEXMAP_NULL, GX_COLOR0A0);
	GXSetTevOp(GX_TEVSTAGE0, GX_PASSCLR);
//	GXSetTevColorIn(GX_TEVSTAGE0, GX_CC_C1, GX_CC_C0, GX_CC_RASC, GX_CC_ZERO);
//	GXSetTevColorOp(GX_TEVSTAGE0, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_TRUE, GX_TEVPREV);
//	GXSetTevAlphaIn(GX_TEVSTAGE0, GX_CA_ZERO, GX_CA_A0, GX_CA_RASA, GX_CA_ZERO);
//	GXSetTevAlphaOp(GX_TEVSTAGE0, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_TRUE, GX_TEVPREV);

	GXSetZCompLoc(GX_FALSE);
	GXSetBlendMode(GX_BM_BLEND, GX_BL_SRCALPHA, GX_BL_INVSRCALPHA, GX_LO_SET);
	GXSetZMode(GX_TRUE, GX_ALWAYS, GX_FALSE);
	GXSetAlphaCompare(GX_ALWAYS, 0, GX_AOP_OR, GX_ALWAYS, 0);

	GXSetFog(GX_FOG_NONE, 0, 0, 0, 0, (GXColor){0,0,0,0});
	GXSetFogRangeAdj(GX_FALSE, 0, 0);

	GXSetCullMode(GX_CULL_NONE);

	GXSetDither(GX_TRUE);
	GXSetLineWidth(18, GX_TO_ZERO);

	GXSetTevColor(GX_TEVREG0, (GXColor){255,255,255,255});
	GXSetTevColor(GX_TEVREG1, (GXColor){0,0,0,255});

	nw4r::g3d::Camera cam(GetCameraByID(GetCurrentCameraID()));
	Mtx matrix;
	cam.GetCameraMtx(&matrix);
	GXLoadPosMtxImm(matrix, 0);
	GXSetCurrentMtx(0);

	ActivePhysics *ap = ActivePhysics::globalListHead;

	while (ap) {
//		if (ap->owner->name == PLAYER)
//			OSReport("Player has : DistToC=%f,%f DistToEdge=%f,%f Pos=%f,%f Scale=%f,%f\n",
//					ap->info.xDistToCenter, ap->info.yDistToCenter,
//					ap->info.xDistToEdge, ap->info.yDistToEdge,
//					ap->owner->pos.x, ap->owner->pos.y,
//					ap->owner->scale.x, ap->owner->scale.y);

		u32 uptr = (u32)ap;
		u8 r = (uptr>>16)&0xFF;
		u8 g = (uptr>>8)&0xFF;
		u8 b = uptr&0xFF;
		u8 a = 0xFF;

		GXBegin(GX_LINES, GX_VTXFMT0, 10);

		float centreX = ap->owner->pos.x + ap->info.xDistToCenter;
		float centreY = ap->owner->pos.y + ap->info.yDistToCenter;
		float edgeDistX = ap->info.xDistToEdge;
		float edgeDistY = ap->info.yDistToEdge;

		float tlX = centreX - edgeDistX, tlY = centreY + edgeDistY;
		float trX = centreX + edgeDistX, trY = centreY + edgeDistY;

		float blX = centreX - edgeDistX, blY = centreY - edgeDistY;
		float brX = centreX + edgeDistX, brY = centreY - edgeDistY;

		switch (ap->collisionCheckType) {
			case 2: // vert trapezoid
				tlY = centreY + ap->trpValue0;
				trY = centreY + ap->trpValue1;
				blY = centreY + ap->trpValue2;
				brY = centreY + ap->trpValue3;
				break;
			case 3: // horz trapezoid
				tlX = centreX + ap->trpValue0;
				trX = centreX + ap->trpValue1;
				blX = centreX + ap->trpValue2;
				brX = centreX + ap->trpValue3;
				break;
		}

		// Top
		GXPosition3f32(tlX, tlY, 9000.0f);
		GXColor4u8(r,g,b,a);
		GXPosition3f32(trX, trY, 9000.0f);
		GXColor4u8(r,g,b,a);

		// Left
		GXPosition3f32(tlX, tlY, 9000.0f);
		GXColor4u8(r,g,b,a);
		GXPosition3f32(blX, blY, 9000.0f);
		GXColor4u8(r,g,b,a);

		// Right
		GXPosition3f32(trX, trY, 9000.0f);
		GXColor4u8(r,g,b,a);
		GXPosition3f32(brX, brY, 9000.0f);
		GXColor4u8(r,g,b,a);

		// Bottom
		GXPosition3f32(blX, blY, 9000.0f);
		GXColor4u8(r,g,b,a);
		GXPosition3f32(brX, brY, 9000.0f);
		GXColor4u8(r,g,b,a);

		// Diagonal
		GXPosition3f32(trX, trY, 9000.0f);
		GXColor4u8(r,g,b,a);
		GXPosition3f32(blX, blY, 9000.0f);
		GXColor4u8(r,g,b,a);

		GXEnd();

		ap = ap->listPrev;
	}

	Physics *p = Physics::globalListHead;

	while (p) {
		u32 uptr = (u32)p;
		u8 r = (uptr>>16)&0xFF;
		u8 g = (uptr>>8)&0xFF;
		u8 b = uptr&0xFF;
		u8 a = 0xFF;

		GXBegin(GX_LINES, GX_VTXFMT0, 10);

		float tlX = p->unkArray[0].x;
		float tlY = p->unkArray[0].y;
		float trX = p->unkArray[3].x;
		float trY = p->unkArray[3].y;
		float blX = p->unkArray[1].x;
		float blY = p->unkArray[1].y;
		float brX = p->unkArray[2].x;
		float brY = p->unkArray[2].y;

		// Top
		GXPosition3f32(tlX, tlY, 9000.0f);
		GXColor4u8(r,g,b,a);
		GXPosition3f32(trX, trY, 9000.0f);
		GXColor4u8(r,g,b,a);

		// Left
		GXPosition3f32(tlX, tlY, 9000.0f);
		GXColor4u8(r,g,b,a);
		GXPosition3f32(blX, blY, 9000.0f);
		GXColor4u8(r,g,b,a);

		// Right
		GXPosition3f32(trX, trY, 9000.0f);
		GXColor4u8(r,g,b,a);
		GXPosition3f32(brX, brY, 9000.0f);
		GXColor4u8(r,g,b,a);

		// Bottom
		GXPosition3f32(blX, blY, 9000.0f);
		GXColor4u8(r,g,b,a);
		GXPosition3f32(brX, brY, 9000.0f);
		GXColor4u8(r,g,b,a);

		// Diagonal
		GXPosition3f32(trX, trY, 9000.0f);
		GXColor4u8(r,g,b,a);
		GXPosition3f32(blX, blY, 9000.0f);
		GXColor4u8(r,g,b,a);

		GXEnd();

		p = p->next;
	}


	// Basic Colliders
	BasicCollider *bc = BasicCollider::globalListHead;
	while (bc) {
		u32 uptr = (u32)bc;
		u8 r = (uptr>>16)&0xFF;
		u8 g = (uptr>>8)&0xFF;
		u8 b = uptr&0xFF;
		u8 a = 0xFF;

		switch (bc->type) {
			case 0: case 2:
				GXBegin(GX_LINES, GX_VTXFMT0, 2);
				GXPosition3f32(bc->leftX, bc->leftY, 9000.0f);
				GXColor4u8(r,g,b,a);
				GXPosition3f32(bc->rightX, bc->rightY, 9000.0f);
				GXColor4u8(r,g,b,a);
				GXEnd();
				break;
		}

		bc = bc->next;
	}


	// Now, the hardest one.. CollisionMgr_c!
	fBase_c *fb = 0;
	while ((fb = fBase_c::searchByBaseType(2, fb))) {
		u8 *testMe = ((u8*)fb) + 0x1EC;
		if (*((u32*)testMe) != 0x8030F6D0)
			continue;

		u32 uptr = (u32)fb;
		u8 r = u8((uptr>>16)&0xFF)+0x20;
		u8 g = u8((uptr>>8)&0xFF)-0x30;
		u8 b = u8(uptr&0xFF)+0x80;
		u8 a = 0xFF;

		dStageActor_c *ac = (dStageActor_c*)fb;

		sensorBase_s *sensors[4] = {
			ac->collMgr.pBelowInfo, ac->collMgr.pAboveInfo,
			ac->collMgr.pAdjacentInfo, ac->collMgr.pAdjacentInfo};

		for (int i = 0; i < 4; i++) {
			sensorBase_s *s = sensors[i];
			if (!s)
				continue;

			float mult = (i == 3) ? -1.0f : 1.0f;

			switch (s->flags & SENSOR_TYPE_MASK) {
				case SENSOR_POINT:
					GXBegin(GX_POINTS, GX_VTXFMT0, 1);
					GXPosition3f32(
							ac->pos.x + (mult * (s->asPoint()->x / 4096.0f)),
							ac->pos.y + (s->asPoint()->y / 4096.0f),
							8005.0f);
					GXColor4u8(r,g,b,a);
					GXEnd();
					break;
				case SENSOR_LINE:
					GXBegin(GX_LINES, GX_VTXFMT0, 2);
					if (i < 2) {
						GXPosition3f32(
								ac->pos.x + (s->asLine()->lineA / 4096.0f),
								ac->pos.y + (s->asLine()->distanceFromCenter / 4096.0f),
								8005.0f);
						GXColor4u8(r,g,b,a);
						GXPosition3f32(
								ac->pos.x + (s->asLine()->lineB / 4096.0f),
								ac->pos.y + (s->asLine()->distanceFromCenter / 4096.0f),
								8005.0f);
						GXColor4u8(r,g,b,a);
					} else {
						GXPosition3f32(
								ac->pos.x + (mult * (s->asLine()->distanceFromCenter / 4096.0f)),
								ac->pos.y + (s->asLine()->lineA / 4096.0f),
								8005.0f);
						GXColor4u8(r,g,b,a);
						GXPosition3f32(
								ac->pos.x + (mult * (s->asLine()->distanceFromCenter / 4096.0f)),
								ac->pos.y + (s->asLine()->lineB / 4096.0f),
								8005.0f);
						GXColor4u8(r,g,b,a);
					}
					GXEnd();
					break;
			}
		}
	}
}

//
// processed\../src/creditsMgr.cpp
//

#include <game.h>
#include <sfx.h>
#include <dCourse.h>
#include <stage.h>
#include <playeranim.h>
#include <newer.h>
#include <profile.h>

void *EGG__Heap__alloc(unsigned long size, int unk, void *heap);
void EGG__Heap__free(void *ptr, void *heap);

extern char CameraLockEnabled;
extern VEC2 CameraLockPosition;

extern char isLockPlayerRotation;
extern s16 lockedPlayerRotation;

extern bool NoMichaelBuble;

extern bool isNewerCredits;

mTexture_c efbTexture;
bool getNextEFB = false;
int thing = 0;

const char *CreditsFileList[] = {"CreditsBG", 0};

extern "C" void GXPixModeSync();
extern "C" void *MakeMarioEnterDemoMode();
extern "C" void *MakeMarioExitDemoMode();

struct FireworkInfo {
	const char *name;
	float xOffset, yOffset;
	int delay;
};

extern void *SoundRelatedClass;

extern u16 DanceValues_AnimSpeed; // 80427C2E
extern u8 DanceValues_DummyBlockAndGrass; // 8042A049
extern u8 DanceValues_Bahps; // 8042A04A
extern u8 DanceValues_CreditsControl; // 8042A04B

class dFlipbookRenderer_c : public m3d::proc_c {
	public:
		dFlipbookRenderer_c();
		~dFlipbookRenderer_c();

		mAllocator_c allocator;
		void drawOpa();
		void drawXlu();
		void execute();

		bool isEnabled;
		int flipFrame;

		int scheduledBG;

		char *tplBuffer[2];
		u32 tplBufferSize[2];
		GXTexObj bgTexObj[2];

		void loadNewBG(int bgID, bool isBackface);
};

struct danceInfo_s {
	u32 when;
	u8 animSpeed, dummyBlockFlag, bahpFlag, creditsFlag;
};

class dCreditsMgr_c : public dActorState_c {
	public:
		int onCreate();
		int onDelete();
		int onExecute();
		int onDraw();

		int currentPathID;

		bool isOutOfView() { return false; }
		Vec2 _vf70();

		dDvdLoader_c scriptLoader;
		const u8 *scriptPos;

		dFlipbookRenderer_c renderer;

		bool loadLayout();
		bool loadTitleLayout();
		bool layoutLoaded;
		bool titleLayoutLoaded;
		m2d::EmbedLayout_c layout;
		m2d::EmbedLayout_c titleLayout;

		bool titleLayoutVisible;

		int countdown;

		bool fireworks;
		int fireworksCountdown;
		int fwID;

		int fauxScrollFrame;
		float fauxScrollMinX, fauxScrollMaxX, fauxScrollY;

		VEC2 endingLockPositions[4];

		danceInfo_s *danceCommand;
		int danceTimer;

		nw4r::lyt::TextBox
			*Title, *TitleS,
			*Name, *NameS,
			*LeftName, *LeftNameS,
			*RightName, *RightNameS;
		nw4r::lyt::Pane
			*TitleContainer, *NamesContainer,
			*OneNameC, *TwoNamesC, *N_proportionC_00;

		void doAutoscroll(int pathID);
		void positionPlayers();

		void animComplete();

		void enableZoom();
		void disableZoom();
		void playerWinAnim();
		void playerLookUp();
		void theEnd();
		void exitStage();

		bool endingMode;
		bool canSkipCredits;

//		USING_STATES(dCreditsMgr_c);
//		DECLARE_STATE(Wait);
//		DECLARE_STATE(PlayLayoutAnim);
//		DECLARE_STATE(Flipping);

		static dActor_c *build();
		static dCreditsMgr_c *instance;
};
// CREATE_STATE(dCreditsMgr_c, Wait);
// CREATE_STATE(dCreditsMgr_c, PlayLayoutAnim);
// CREATE_STATE(dCreditsMgr_c, Flipping);

dCreditsMgr_c *dCreditsMgr_c::instance = 0;

dActor_c *dCreditsMgr_c::build() {
	void *buf = AllocFromGameHeap1(sizeof(dCreditsMgr_c));
	return new(buf) dCreditsMgr_c;
}

const SpriteData NewerCreditsSpriteData = {ProfileId::AC_NEWER_ENDING_MAIN, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile NewerCreditsProfile(&dCreditsMgr_c::build, SpriteId::AC_NEWER_ENDING_MAIN, &NewerCreditsSpriteData, ProfileId::AC_ENDING_MAIN, ProfileId::AC_BATTLE_KINOPIO, "AC_NEWER_ENDING_MAIN", CreditsFileList, 0x2);


int dCreditsMgr_c::onCreate() {
	NoMichaelBuble = true;

	instance = this;

	if (!loadLayout())
		return false;
	if (!loadTitleLayout())
		return false;

	if (!scriptLoader.load("/NewerStaffRoll.bin"))
		return false;

	scriptPos = (const u8*)scriptLoader.buffer;

	getNextEFB = true; // make sure we have a texture

	renderer.allocator.setup(GameHeaps[0], 0x20);
	bool result = renderer.setup(&renderer.allocator);

	renderer.loadNewBG(0, false);

	isNewerCredits = true;

	SaveBlock *save = GetSaveFile()->GetBlock(-1);
	canSkipCredits = save->isWorldDataFlag(8, 1);

	//acState.setState(&StateID_Wait);

	return true;
}

int dCreditsMgr_c::onDelete() {
	instance = 0;

	isLockPlayerRotation = false;

	CameraLockEnabled = false;
	isNewerCredits = false;

	scriptLoader.unload();
	return layout.free() && titleLayout.free();
}
extern "C" bool SpawnEffect(const char*, int, Vec*, S16Vec*, Vec*);
int dCreditsMgr_c::onExecute() {
	danceTimer++;
	if (danceCommand == 0)
		danceCommand = (danceInfo_s*)getResource("CreditsBG", "/Dance.bin");

	char *autoscrInfo = ((char*)dBgGm_c::instance) + 0x900AC;

	fauxScrollFrame++;
	if (fauxScrollFrame > 60)
		fauxScrollFrame = 60;
	float fsMult = (1.0f / 60.0f) * float(fauxScrollFrame);
	float interp = float(fauxScrollMinX) + ((fauxScrollMaxX - fauxScrollMinX) * fsMult);
	CameraLockPosition.x = interp;
	CameraLockPosition.y = fauxScrollY;

	if (endingMode) {
		for (int i = 0; i < 4; i++) {
			dAcPy_c *player;
			if ((player = dAcPy_c::findByID(i))) {
				if (!player->testFlag(0x24)) {
					player->setAnimePlayWithAnimID(0);
				}
				player->setFlag(0x24);
				player->rot.y = 0;
				player->speed.x = player->speed.y = player->speed.z = 0.0f;
				player->pos.x = endingLockPositions[i].x;
				player->pos.y = endingLockPositions[i].y;
			}
		}
	}

	if (fireworks) {
		fireworksCountdown--;
		if (fireworksCountdown <= 0) {
			static const FireworkInfo fwInfo[] = {
				{"Wm_ob_fireworks_g", 20.000000f, 49.000000f, 8}, // ends @ 8
				{"Wm_ob_fireworks_1up", 154.000000f, 80.000000f, 14}, // ends @ 22
				{"Wm_ob_fireworks_b", 168.000000f, 27.000000f, 33}, // ends @ 55
				{"Wm_ob_fireworks_1up", 416.000000f, 22.000000f, 33}, // ends @ 88
				{"Wm_ob_fireworks_y", 179.000000f, 11.000000f, 8}, // ends @ 96
				{"Wm_ob_fireworks_star", 9.000000f, 35.000000f, 25}, // ends @ 121
				{"Wm_ob_fireworks_y", 398.000000f, 29.000000f, 11}, // ends @ 132
				{"Wm_ob_fireworks_g", 127.000000f, 64.000000f, 21}, // ends @ 153
				{"Wm_ob_fireworks_star", 439.000000f, 66.000000f, 3}, // ends @ 156
				{"Wm_ob_fireworks_k", 320.000000f, 18.000000f, 31}, // ends @ 187
				{"Wm_ob_fireworks_p", 158.000000f, 47.000000f, 42}, // ends @ 229
				{"Wm_ob_fireworks_star", 127.000000f, 1.000000f, 29}, // ends @ 258
				{"Wm_ob_fireworks_k", 164.000000f, 50.000000f, 18}, // ends @ 276
				{"Wm_ob_fireworks_g", 365.000000f, 25.000000f, 39}, // ends @ 315
				{"Wm_ob_fireworks_k", 2.000000f, 78.000000f, 44}, // ends @ 359
				{"Wm_ob_fireworks_g", 309.000000f, 25.000000f, 42}, // ends @ 401
				{"Wm_ob_fireworks_star", 222.000000f, 78.000000f, 44}, // ends @ 445
				//{"Wm_ob_fireworks_y", 269.000000f, 23.000000f, 38}, // ends @ 483
				{0, 0.0f, 0.0f, 0},
			};

			fireworksCountdown = fwInfo[fwID].delay;
			float xOffs = fwInfo[fwID].xOffset;
			float yOffs = fwInfo[fwID].yOffset;
			VEC3 efPos = {10208.0f + xOffs, -304.0f - yOffs, pos.z + 200.0f};

			SpawnEffect(fwInfo[fwID].name, 0, &efPos, 0, 0);

			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_OBJ_GOAL_FIREWORKS, 1);

			fwID++;
			if (!fwInfo[fwID].name)
				fireworks = false;
		}
	}

	if (countdown > 0) {
		countdown--;
	} else if (!renderer.isEnabled) {
		if (!endingMode)
			isLockPlayerRotation = false;

		// Execute commands if we can
		bool exitInterpreter = false;
		while (scriptPos && !exitInterpreter) {
			int u16_top, u16_bottom;
			int whatAnim;
			u8 *staffCreditScore;
			nw4r::lyt::Pane *paneThing;

			const u8 *read = scriptPos;
			int cmdSize = *(read++);
			int cmdType = *(read++);

			scriptPos += cmdSize;

			switch (cmdType) {
				case 0: // Stop running script
					scriptPos = 0;
					exitInterpreter = true;
					break;

				case 1: // Delay
					u16_top = *(read++);
					u16_bottom = *(read++);
					countdown = (u16_top << 8) | u16_bottom;
					exitInterpreter = true;
					break;

				case 2: // Switch scene
					doAutoscroll(*(read++));
					break;

				case 3: // Switch scene and wait
					doAutoscroll(*(read++));
					exitInterpreter = true;
					break;

				case 4: // Show scores
					staffCreditScore = GetStaffCreditScore();
					staffCreditScore[0x279] = 1;
					if (!settings & 2) {
						// Hide the high score bit
						paneThing = *((nw4r::lyt::Pane**)(staffCreditScore + 0x274));
						paneThing->SetVisible(false);
					}
					OSReport("Staff Credit Score object is at %p, going to show it\n", staffCreditScore);
					break;

				case 5: // Show text
					layout.enableNonLoopAnim(0);
					break;
				case 6: // Hide text
					layout.enableNonLoopAnim(1);
					break;

				case 7: { // Set names. FUN!
					int titleLength = *(read++);
					int nameCount = *(read++);

					WriteAsciiToTextBox(Title, (const char*)read);
					WriteAsciiToTextBox(TitleS, (const char*)read);

					read += titleLength;

					WriteAsciiToTextBox(Name, (const char*)read);
					WriteAsciiToTextBox(NameS, (const char*)read);

					float calcHeight = 29.0f * nameCount;
					TitleContainer->trans.y = (calcHeight * 0.5f) + 3.0f;

					OneNameC->SetVisible(true);
					TwoNamesC->SetVisible(false);

					} break;

				case 8:
					titleLayoutVisible = true;
					break;
				case 9:
					titleLayoutVisible = false;
					break;
				case 10:
					whatAnim = *(read++);
					titleLayout.enableNonLoopAnim(whatAnim);
					break;

				case 11:
					endingMode = true;
					break;
				case 12:
					enableZoom();
					break;
				case 13:
					playerWinAnim();
					break;
				case 14:
					disableZoom();
					break;
				case 15:
					playerLookUp();
					break;
				case 16:
					theEnd();
					break;
				case 17:
					exitStage();
					exitInterpreter = true;
					break;
				case 18:
					GetTheEnd()->willHide = true;
					break;
				case 19:
					fireworks = true;
					fireworksCountdown = 25;
					break;
				case 20:
					fireworks = false;
					break;
			}
		}
	}

	if (Remocon_GetPressed(GetActiveRemocon()) & WPAD_PLUS && canSkipCredits) {
		exitStage();
	}

	layout.execAnimations();
	layout.update();

	titleLayout.execAnimations();
	titleLayout.update();

	//acState.execute();
	renderer.execute();

	return true;
}

int dCreditsMgr_c::onDraw() {
	renderer.scheduleForDrawing();
	layout.scheduleForDrawing();
	if (titleLayoutVisible)
		titleLayout.scheduleForDrawing();
	return true;
}


bool dCreditsMgr_c::loadLayout() {
	if (!layoutLoaded) {
		if (!layout.loadArc("StaffRoll.arc", false))
			return false;

		layout.build("StaffRoll.brlyt");

		static const char *brlanNames[] = {
			"StaffRoll_show.brlan",
			"StaffRoll_hide.brlan",
		};
		static const char *groupNames[] = {
			"TheOnlyGroup", "TheOnlyGroup"
		};

		layout.loadAnimations(brlanNames, 2);
		layout.loadGroups(groupNames, (int[2]){0, 1}, 2);
		layout.disableAllAnimations();
		layout.resetAnim(0);

		static const char *tbNames[] = {
			"Title", "TitleS",
			"Name", "NameS",
			"LeftName", "LeftNameS",
			"RightName", "RightNameS"
		};
		static const char *paneNames[] = {
			"TitleContainer", "NamesContainer",
			"OneNameC", "TwoNamesC",
		};

		layout.getTextBoxes(tbNames, &Title, 8);
		layout.getPanes(paneNames, &TitleContainer, 4);

		layoutLoaded = true;
	}
	return layoutLoaded;
}

bool dCreditsMgr_c::loadTitleLayout() {
	if (!titleLayoutLoaded) {
		if (!titleLayout.loadArc("StaffRollTitle.arc", false))
			return false;

		titleLayout.build("StaffRollTitle.brlyt");

		static const char *brlanNames[] = {
			"StaffRollTitle_appear1.brlan",
			"StaffRollTitle_appear2.brlan",
		};
		static const char *groupNames[] = {
			"TheOnlyGroup", "TheOnlyGroup"
		};

		titleLayout.loadAnimations(brlanNames, 2);
		titleLayout.loadGroups(groupNames, (int[2]){0, 1}, 2);
		titleLayout.disableAllAnimations();
		titleLayout.resetAnim(1);

		float propScale = 1.3f;
		if (!IsWideScreen())
			propScale *= 0.85f;

		N_proportionC_00 = titleLayout.findPaneByName("N_proportionC_00");
		N_proportionC_00->trans.y = -130.0f;
		N_proportionC_00->scale.x = propScale;
		N_proportionC_00->scale.y = propScale;

		titleLayoutLoaded = true;
	}
	return titleLayoutLoaded;
}

extern "C" dCourse_c::rail_s *GetRail(int id);

void dCreditsMgr_c::doAutoscroll(int pathID) {
	OSReport("Activating Autoscroll with path %d\n", pathID);

	getNextEFB = true;
	renderer.isEnabled = true;
	renderer.flipFrame = 0;
	renderer.scheduledBG = pathID;
	MakeMarioEnterDemoMode();

	char *autoscrInfo = ((char*)dBgGm_c::instance) + 0x900AC;
	*((u8*)(autoscrInfo + 0x14)) = pathID;
	*((u8*)(autoscrInfo + 0x15)) = 1; // unk11
	*((u8*)(autoscrInfo + 0x16)) = 0; // atEnd Related
	*((u8*)(autoscrInfo + 0x17)) = 2; // atEnd
	*((u8*)(autoscrInfo + 0x18)) = 0; // mode
	*((u8*)(autoscrInfo + 0x1A)) = 1; // isAutoscrolling
	*((u32*)(((char*)dBgGm_c::instance) + 0x900EC)) = 0; // node ID
	*((u32*)(((char*)dBgGm_c::instance) + 0x900F0)) = 0; // ?

	currentPathID = pathID;

	dCourse_c::rail_s *rail = GetRail(pathID);
	dCourse_c *course = dCourseFull_c::instance->get(GetAreaNum());

	dCourse_c::railNode_s *firstNode = &course->railNode[rail->startNode];
	dCourse_c::railNode_s *secondNode = &course->railNode[rail->startNode+1];

	fauxScrollFrame = 0;
	fauxScrollMinX = firstNode->xPos;
	fauxScrollMaxX = secondNode->xPos;
	fauxScrollY = -firstNode->yPos;

	CameraLockEnabled = 1;

	// set directions
	isLockPlayerRotation = true;
	lockedPlayerRotation = endingMode ? 0 : 0x3000;

	for (int i = 0; i < 4; i++) {
		dAcPy_c *player;
		if ((player = dAcPy_c::findByID(i))) {
			player->direction = 0;
			player->rot.y = 0x3000;
		}
	}
}

void dCreditsMgr_c::animComplete() {
	positionPlayers();
}


void dCreditsMgr_c::positionPlayers() {
	dCourse_c *course = dCourseFull_c::instance->get(GetAreaNum());
	dCourse_c::nextGoto_s *entrance = course->getNextGotoByID(currentPathID);

	float diff = endingMode ? 48.0f : 24.0f;
	float playerPositions[4];
	playerPositions[0] = entrance->xPos;
	playerPositions[1] = playerPositions[0] - diff;
	playerPositions[2] = playerPositions[0] + diff;
	playerPositions[3] = playerPositions[0] + diff + diff;

	// This is annoying
	dAcPy_c *players[4];
	for (int i = 0; i < 4; i++)
		players[i] = dAcPy_c::findByID(i);

	static const int crap[4] = {0,1,3,2};

	int whichPos = 0;
	for (int i = 0; i < 4; i++) {
		dAcPy_c *player = 0;
		// Find the player matching this ID
		for (int j = 0; j < 4; j++) {
			if (Player_ID[players[j]->settings & 0xF] == crap[i]) {
				player = players[j];
				break;
			}
		}

		if (player) {
			player->pos.x = playerPositions[whichPos];
			player->pos.y = -(entrance->yPos + 16);
			player->direction = 0;
			player->rot.y = 0x3000;
			player->speed.x = player->speed.y = player->speed.z = 0.0f;
			dPlayerModelHandler_c *pmh = (dPlayerModelHandler_c*)(((u32)player) + 0x2A60);
			pmh->mdlClass->startAnimation(0, 1.0f, 0.0f, 0.0f);
			whichPos++;

			u32 *pInactivityCounter = (u32*)(((u32)player) + 0x480);
			*pInactivityCounter = 177;

			endingLockPositions[i].x = player->pos.x;
			endingLockPositions[i].y = player->pos.y;
		}
	}
}


void dCreditsMgr_c::enableZoom() {
	BgGmBase::manualZoomEntry_s &zoom = dBgGm_c::instance->manualZooms[0];
	zoom.x1 = 10218.0f;
	zoom.x2 = 11000.0f;
	zoom.y1 = -200.0f;
	zoom.y2 = -600.0f;

	zoom.x1 = 1100.0f;
	zoom.x2 = 1300.0f;
	zoom.y1 = -400.0f;
	zoom.y2 = -550.0f;
	zoom.zoomLevel = 7;
	zoom.unkValue6 = 0;
	zoom.firstFlag = 0;
}
void dCreditsMgr_c::disableZoom() {
	BgGmBase::manualZoomEntry_s &zoom = dBgGm_c::instance->manualZooms[0];
	zoom.unkValue6 = 100;
}
void dCreditsMgr_c::playerWinAnim() {
	// who won?
	// First, get the amounts
	u8 *amountsU8 = GetStaffCreditScore() + 0x288;
	int *playerAmounts = (int*)(amountsU8);
	int maxSoFar = 0;

	for (int i = 0; i < 4; i++) {
		if (playerAmounts[i] > maxSoFar)
			maxSoFar = playerAmounts[i];
	}

	if (maxSoFar == 0)
		return;

	// did anyone win?
	for (int i = 0; i < 4; i++) {
		if (playerAmounts[i] == maxSoFar) {
			dAcPy_c *player = dAcPy_c::findByID(i);
			if (!player)
				continue;

			player->setAnimePlayWithAnimID(goal_puton_capA);
			player->setFlag(0x24);

			static const int vocs[4] = {
				SE_VOC_MA_CLEAR_NORMAL,
				SE_VOC_LU_CLEAR_NORMAL,
				SE_VOC_KO_CLEAR_NORMAL,
				SE_VOC_KO2_CLEAR_NORMAL
			};
			dPlayerModelHandler_c *pmh = (dPlayerModelHandler_c*)(((u32)player) + 0x2A60);
			int voc = vocs[pmh->mdlClass->player_id_2];
			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, voc, 1);

			int powerup = *((u32*)( 0x1090 + ((u8*)player) ));
			handle.SetPitch(powerup == 3 ? 1.5f : 1.0f);
		}
	}
}

void dCreditsMgr_c::playerLookUp() {
	_120 |= 8;
	lookAtMode = 2; // Higher maximum distance
}
void dCreditsMgr_c::theEnd() {
	GetTheEnd()->willShow = true;
}

extern "C" u32 CreateBootParam();
//updated to match vanilla maps + world 9 unlocks
void dCreditsMgr_c::exitStage() {
	if (settings & 1) {
		ExitStage(MOVIE, 3, EXIT_LEVEL, CIRCLE_WIPE);
	} else {
		ActivateWipe(CIRCLE_WIPE);
		if (canSkipCredits) { // game's been beaten
			u32 worldMapSettings = CreateBootParam();
			DoSceneChange(ProfileId::WORLD_MAP, worldMapSettings, 0);
		} else {
			DoSceneChange(ProfileId::WORLD_9_DEMO, 0, 0);
		}
	}
}

Vec2 dCreditsMgr_c::_vf70() {
	// HACK OF THE MILLENIUM
	// DON'T TRY THIS AT HOME.
	Vec2 *v = (Vec2*)this;
	v->x = 10454.0f;
	v->y = -320.0f;
	return (const Vec2){12345.0f, 67890.f};
}



void EFBMagic2() {
	if (getNextEFB) {
		getNextEFB = false;

		GXRModeObj *ro = nw4r::g3d::G3DState::GetRenderModeObj();
		efbTexture.format = GX_TF_RGB565;
		efbTexture.width = ro->fbWidth;
		efbTexture.height = ro->efbHeight;
		efbTexture.wrapS = GX_CLAMP;
		efbTexture.wrapT = GX_CLAMP;

		if (efbTexture.getBuffer() == 0)
			efbTexture.allocateBuffer(GameHeaps[2]);

		GXSetTexCopySrc(0, 0, efbTexture.width, efbTexture.height);
		GXSetTexCopyDst(efbTexture.width, efbTexture.height, efbTexture.format, GX_FALSE);
		GXSetCopyFilter(GX_FALSE, 0, GX_FALSE, 0);
		GXCopyTex(efbTexture.getBuffer(), GX_FALSE);

		GXPixModeSync();
		GXInvalidateTexAll();
	}
}

void dFlipbookRenderer_c::execute() {
	if (flipFrame == 7) {
		loadNewBG(scheduledBG, true);
	}

	if (isEnabled) {
		flipFrame += 7;

		ClassWithCameraInfo *cwci = ClassWithCameraInfo::instance;
		if (flipFrame > int(cwci->screenWidth)) {
			loadNewBG(scheduledBG, false);
			dCreditsMgr_c::instance->animComplete();

			if (!dCreditsMgr_c::instance->endingMode)
				MakeMarioExitDemoMode();
			isEnabled = false;
			OSReport("DONE!\n");
		}
	}
}


static void setupGXForDrawingCrap() {
	GXSetNumChans(0);
	GXSetChanCtrl(GX_COLOR0A0, GX_DISABLE, GX_SRC_REG, GX_SRC_REG, GX_LIGHTNULL, GX_DF_NONE, GX_AF_NONE);
	GXSetChanAmbColor(GX_COLOR0A0, (GXColor){255,255,255,255});
	GXSetChanMatColor(GX_COLOR0A0, (GXColor){255,255,255,255});
	GXSetNumTexGens(1);
	GXSetTexCoordGen2(GX_TEXCOORD0, GX_TG_MTX3x4, GX_TG_NRM, GX_IDENTITY, GX_FALSE, GX_DTTIDENTITY);

	GXSetNumTevStages(1);
	GXSetNumIndStages(0);
	for (int i = 0; i < 0x10; i++)
		GXSetTevDirect(i);

	GXSetTevOp(GX_TEVSTAGE0, GX_REPLACE);
	GXSetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD0, GX_TEXMAP0, GX_COLORNULL);

	GXSetTevSwapModeTable(GX_TEV_SWAP0, GX_CH_RED, GX_CH_GREEN, GX_CH_BLUE, GX_CH_ALPHA);

	GXSetZCompLoc(GX_FALSE);
	GXSetBlendMode(GX_BM_BLEND, GX_BL_SRCALPHA, GX_BL_INVSRCALPHA, GX_LO_SET);
	//GXSetBlendMode(GX_BM_NONE, GX_BL_ZERO, GX_BL_ZERO, GX_LO_SET);
	GXSetZMode(GX_TRUE, GX_ALWAYS, GX_FALSE);
	GXSetAlphaCompare(GX_ALWAYS, 0, GX_AOP_OR, GX_ALWAYS, 0);

	GXSetFog(GX_FOG_NONE, 0, 0, 0, 0, (GXColor){0,0,0,0});
	GXSetFogRangeAdj(GX_FALSE, 0, 0);

	GXSetAlphaUpdate(GX_TRUE);

	GXSetCullMode(GX_CULL_NONE);

	GXSetDither(GX_TRUE);

	GXSetTevColor(GX_TEVREG0, (GXColor){255,255,255,255});
	GXSetTevColor(GX_TEVREG1, (GXColor){255,255,255,255});
	GXSetTevColor(GX_TEVREG2, (GXColor){255,255,255,255});

	GXSetZMode(GX_TRUE, GX_LEQUAL, GX_TRUE);

	nw4r::g3d::Camera cam(GetCameraByID(GetCurrentCameraID()));
	Mtx matrix;
	cam.GetCameraMtx(&matrix);
	GXLoadPosMtxImm(matrix, 0);
	GXSetCurrentMtx(0);

	GXClearVtxDesc();

	GXSetVtxDesc(GX_VA_POS, GX_DIRECT);
	GXSetVtxDesc(GX_VA_NRM, GX_DIRECT);

	GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS, GX_POS_XYZ, GX_F32, 0);
	GXSetVtxAttrFmt(GX_VTXFMT0, GX_VA_NRM, GX_NRM_XYZ, GX_F32, 0);
}

void dFlipbookRenderer_c::drawXlu() {
	if (!isEnabled || flipFrame < 2)
		return;

	setupGXForDrawingCrap();

	ClassWithCameraInfo *cwci = ClassWithCameraInfo::instance;

	float screenTop = cwci->screenTop + Stage80::instance->screenYOffset;
	float left = cwci->screenLeft + Stage80::instance->screenXOffset;
	float right = left + cwci->screenWidth;

	float halfWidth = (cwci->screenWidth * 0.5f);
	float midpoint = left + halfWidth;

	float value = (flipFrame / cwci->screenWidth);
	float sinThing = 50.0f * sin(3.14159f * value);

	bool drawBackside = (flipFrame > halfWidth);

	float xformedFlipEdge = right - flipFrame;

	// EFB SPECIFIC VERTICAL VARIABLES
	float efbEffectiveHeight = cwci->screenHeight;
	if (!IsWideScreen())
		efbEffectiveHeight *= 1.295f;

	float efbHalfHeight = (efbEffectiveHeight * 0.5f);

	float efbYCentre = screenTop - (cwci->screenHeight * 0.5f);
	if (!IsWideScreen())
		efbYCentre += 1.0f;
	float efbTop = efbYCentre + efbHalfHeight;
	float efbBottom = efbYCentre - efbHalfHeight;

	float efbExCoord = (efbEffectiveHeight + sinThing + sinThing) * 0.5f;
	// TPL SPECIFIC VERTICAL VARIABLES
	float tplHalfHeight = cwci->screenHeight * 0.5f;
	float tplTop = screenTop;
	float tplBottom = screenTop - cwci->screenHeight;

	float tplExCoord = (cwci->screenHeight + sinThing + sinThing) * 0.5f;


	// EFB Left
	efbTexture.load(GX_TEXMAP0);

	GXBegin(GX_QUADS, GX_VTXFMT0, 4);
	{
		// Bottom Right
		GXPosition3f32(midpoint, efbBottom, 9990.0f);
		GXNormal3f32(0.5f, 1.0f, 1.0f);
		// Top Right
		GXPosition3f32(midpoint, efbTop, 9990.0f);
		GXNormal3f32(0.5f, 0.0f, 1.0f);
		// Top Left
		GXPosition3f32(left, efbTop, 9990.0f);
		GXNormal3f32(0.0f, 0.0f, 1.0f);
		// Bottom Left
		GXPosition3f32(left, efbBottom, 9990.0f);
		GXNormal3f32(0.0f, 1.0f, 1.0f);
	}
	GXEnd();

	// TPL Right
	GXLoadTexObj(&bgTexObj[1], GX_TEXMAP0);

	GXBegin(GX_QUADS, GX_VTXFMT0, 4);
	{
		// Bottom Right
		GXPosition3f32(right, tplBottom, 9990.0f);
		GXNormal3f32(1.0f, 1.0f, 1.0f);
		// Top Right
		GXPosition3f32(right, tplTop, 9990.0f);
		GXNormal3f32(1.0f, 0.0f, 1.0f);
		// Top Left
		GXPosition3f32(midpoint, tplTop, 9990.0f);
		GXNormal3f32(0.5f, 0.0f, 1.0f);
		// Bottom Left
		GXPosition3f32(midpoint, tplBottom, 9990.0f);
		GXNormal3f32(0.5f, 1.0f, 1.0f);

	}
	GXEnd();


	if (!drawBackside) {
		// Flipping right side: EFB

		efbTexture.load(GX_TEXMAP0);

		GXBegin(GX_QUADS, GX_VTXFMT0, 4);

		// EFB Right (Flipped)
		// Bottom Left
		GXPosition3f32(midpoint, efbBottom, 9990.0f);
		GXNormal3f32(efbHalfHeight * 0.5f, efbHalfHeight, efbHalfHeight);
		// Top Left
		GXPosition3f32(midpoint, efbTop, 9990.0f);
		GXNormal3f32(efbHalfHeight * 0.5f, 0.0f, efbHalfHeight);
		// Top Right
		GXPosition3f32(xformedFlipEdge, efbTop + sinThing, 9990.0f);
		GXNormal3f32(efbExCoord, 0.0f, efbExCoord);
		// Bottom Right
		GXPosition3f32(xformedFlipEdge, efbBottom - sinThing, 9990.0f);
		GXNormal3f32(efbExCoord, efbExCoord, efbExCoord);

		GXEnd();

	} else {
		// Flipping left side

		GXLoadTexObj(&bgTexObj[1], GX_TEXMAP0);

		GXBegin(GX_QUADS, GX_VTXFMT0, 4);

		// TPL Left (Flipped))
		// Bottom Left
		GXPosition3f32(xformedFlipEdge, tplBottom - sinThing, 9990.0f);
		GXNormal3f32(0.0f, tplExCoord, tplExCoord);
		// Top Left
		GXPosition3f32(xformedFlipEdge, tplTop + sinThing, 9990.0f);
		GXNormal3f32(0.0f, 0.0f, tplExCoord);
		// Top Right
		GXPosition3f32(midpoint, tplTop, 9990.0f);
		GXNormal3f32(tplHalfHeight * 0.5f, 0.0f, tplHalfHeight);
		// Bottom Right
		GXPosition3f32(midpoint, tplBottom, 9990.0f);
		GXNormal3f32(tplHalfHeight * 0.5f, tplHalfHeight, tplHalfHeight);

		GXEnd();
	}
}


void dFlipbookRenderer_c::drawOpa() {
	setupGXForDrawingCrap();

	GXLoadTexObj(&bgTexObj[0], GX_TEXMAP0);

	ClassWithCameraInfo *cwci = ClassWithCameraInfo::instance;
	float left = cwci->screenLeft + Stage80::instance->screenXOffset;
	float right = left + cwci->screenWidth;
	float top = cwci->screenTop + Stage80::instance->screenYOffset;
	float bottom = top - cwci->screenHeight;

	GXBegin(GX_QUADS, GX_VTXFMT0, 4);
	GXPosition3f32(right, bottom, -4000.0f);
	GXNormal3f32(1.0f, 1.0f, 1.0f);
	GXPosition3f32(right, top, -4000.0f);
	GXNormal3f32(1.0f, 0.0f, 1.0f);
	GXPosition3f32(left, top, -4000.0f);
	GXNormal3f32(0.0f, 0.0f, 1.0f);
	GXPosition3f32(left, bottom, -4000.0f);
	GXNormal3f32(0.0f, 1.0f, 1.0f);
	GXEnd();
}

void dFlipbookRenderer_c::loadNewBG(int bgID, bool isBackface) {
	OSReport("Will load BG: %d\n", bgID);

	int setID = isBackface ? 1 : 0;

	char bgName[32];
	sprintf(bgName, isBackface ? "/Back%d.tpl.LZ" : "/BG%d.tpl.LZ", bgID);
	OSReport("Getting %s\n", bgName);

	u8 *sourceBuf = getResource("CreditsBG", bgName);
	u32 bufSize = CXGetUncompressedSize(sourceBuf);

	if (tplBuffer[setID] && (tplBufferSize[setID] != bufSize)) {
		OSReport("Current TPL buffer (%p) is size %d (0x%x), freeing\n", tplBuffer[setID], tplBufferSize[setID], tplBufferSize[setID]);
		EGG__Heap__free(tplBuffer[setID], GameHeaps[2]);
		tplBuffer[setID] = 0;
	}

	if (!tplBuffer[setID]) {
		OSReport("Allocating TPL buffer of size %d (0x%x)\n", bufSize, bufSize);
		tplBuffer[setID] = (char*)EGG__Heap__alloc(bufSize, 0x20, GameHeaps[2]);
		tplBufferSize[setID] = bufSize;
	}

	CXUncompressLZ(sourceBuf, tplBuffer[setID]);
	OSReport("Butts. Decompressing %p to %p.\n", sourceBuf, tplBuffer[setID]);

	TPLBind((TPLPalette*)tplBuffer[setID]);
	TPLImage *image = TPLGet((TPLPalette*)tplBuffer[setID], 0);
	TPLTexHeader *tex = image->texture;
	OSReport("Received TPLHeader %p; Data: %p; Size: %d x %d; Format; %d\n", tex, tex->data, tex->width, tex->height, tex->format);

	GXInitTexObj(&bgTexObj[setID], tex->data, tex->width, tex->height,
			tex->format, tex->wrapS, tex->wrapT, GX_FALSE);
}

dFlipbookRenderer_c::dFlipbookRenderer_c() {
	scheduledBG = -1;
}

dFlipbookRenderer_c::~dFlipbookRenderer_c() {
	for (int setID = 0; setID < 2; setID++) {
		if (tplBuffer[setID]) {
			EGG__Heap__free(tplBuffer[setID], GameHeaps[2]);
			tplBuffer[setID] = 0;
		}
	}
}



extern "C" void replayRecord();

void LoadDanceValues() {
	/*
	//OSReport("AnmSpd: %4d / DBAG: 0x%02x / Bahp: 0x%02x / Cred: 0x%02x\n",
	//	DanceValues_AnimSpeed, DanceValues_DummyBlockAndGrass, DanceValues_Bahps, DanceValues_CreditsControl);
	if (DanceValues_CreditsControl > 0)
		OSReport("[ORIG DANCE] Credits Control: 0x%02x\n", DanceValues_CreditsControl);
	// if (DanceValues_DummyBlockAndGrass > 0)
	// 	OSReport("[ORIG DANCE] DummyBlockAndGrass: 0x%02x\n", DanceValues_DummyBlockAndGrass);
	if (DanceValues_Bahps > 0)
		OSReport("[ORIG DANCE] Bahps: 0x%02x\n", DanceValues_Bahps);
	*/

	dCreditsMgr_c *cred = dCreditsMgr_c::instance;

	if (!cred) {
		replayRecord();
		return;
	}
	danceInfo_s *cmd = cred->danceCommand;
	if (!cmd)
		return;
	//OSReport("TIMER: %d\n", cred->danceTimer);

	if (cred->danceTimer == cmd->when) {
		//OSReport("Timer reached %d, triggering dance 0x%02x, next is at %d\n", cmd->when, cmd->bahpFlag, cmd[1].when);
		DanceValues_AnimSpeed = cmd->animSpeed;
		DanceValues_DummyBlockAndGrass = cmd->dummyBlockFlag;
		DanceValues_Bahps = cmd->bahpFlag;
		DanceValues_CreditsControl = cmd->creditsFlag;

		cred->danceCommand++;
	} else {
		DanceValues_AnimSpeed = 120;
		DanceValues_DummyBlockAndGrass = 0;
		DanceValues_Bahps = 0;
		DanceValues_CreditsControl = 0;
	}
}

extern u32 HasBonusNoCap;
extern bool CreditsModeActive;
void checkBonusNoCap() {
	HasBonusNoCap = 0;
	// don't remove hat if lives are less than 99, or if we're in credits
	if (Player_Lives[0] < 99 || CreditsModeActive) {
		return;
	}
	HasBonusNoCap = 1;
}



//
// processed\../src/endingMgr.cpp
//

#include <game.h>
#include <playerAnim.h>
#include <profileid.h>
#include <sfx.h>
#include <stage.h>
#include <profile.h>

extern void *SoundRelatedClass;

class dEndingMgr_c : public daBossDemo_c {
	int onCreate();
	int onDelete();

	void init();
	Vec2 _vf70();

	USING_STATES(dEndingMgr_c);
	DECLARE_STATE_VIRTUAL(DemoSt);
	DECLARE_STATE(GoRight);
	DECLARE_STATE(LookUp);
	DECLARE_STATE(JumpOntoSwitch);
	DECLARE_STATE(ThanksPeach);

	dAcPy_c *players[4];

	int timer;

	public: static dActor_c *build();
};

const SpriteData EndingMgrSpriteData = {ProfileId::AC_ENDING_MGR, 0, 0, 0, 0, 0x10, 0x10, 0, 0, 0, 0, 2};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile EndingMgrProfile(&dEndingMgr_c::build, SpriteId::AC_ENDING_MGR, &EndingMgrSpriteData, ProfileId::RIVER_MGR, ProfileId::AC_ENDING_MGR, "AC_ENDING_MGR");

dActor_c *dEndingMgr_c::build() {
	void *buf = AllocFromGameHeap1(sizeof(dEndingMgr_c));
	return new(buf) dEndingMgr_c;
}


int dEndingMgr_c::onCreate() {
	if (StageE4::instance->currentBossDemo) {
		fBase_c::Delete();
		return false;
	}
	StageE4::instance->currentBossDemo = this;

	init();

	acState.setState(&StateID_DemoSt);
	acState.executeNextStateThisTick();

	return true;
}

int dEndingMgr_c::onDelete() {
	nw4r::snd::SoundHandle *fanfare = (nw4r::snd::SoundHandle*)
		(((u32)SoundRelatedClass) + 0x900);
	if (fanfare->Exists())
		fanfare->Stop(60);

	daBossDemo_c::onDelete();
	WLClass::instance->disableDemoControl(true);
	return true;
}


void dEndingMgr_c::init() {
	dStageActorMgr_c::instance->_BCA = true;
	WLClass::instance->demoControlAllPlayers();
	BalloonRelatedClass::instance->_20 = 1;
}


CREATE_STATE(dEndingMgr_c, DemoSt);

void dEndingMgr_c::beginState_DemoSt() {
	_360 = 1;
}
void dEndingMgr_c::endState_DemoSt() {
}
void dEndingMgr_c::executeState_DemoSt() {
	for (int i = 0; i < 4; i++) {
		dAcPy_c *player;
		if (player = dAcPy_c::findByID(i)) {
			if (!player->isReadyForDemoControlAction())
				return;
		}
	}
	acState.setState(&StateID_GoRight);
}

static float manipFourPlayerPos(int id, float pos) {
	int fromRight = 3 - id;
	return pos - (fromRight * 20.0f);
}

CREATE_STATE(dEndingMgr_c, GoRight);
void dEndingMgr_c::beginState_GoRight() {
	timer = 0;

	// Sort the players into a list
	// We shall first find the rightmost player, then the second
	// rightmost, then ...
	float maxBound = 50000.0f;
	for (int targetOffs = 3; targetOffs >= 0; targetOffs--) {
		float maxX = 0.0f;
		dAcPy_c *maxPlayer = 0;

		for (int check = 0; check < 4; check++) {
			if (dAcPy_c *player = dAcPy_c::findByID(check)) {
				if (player->pos.x >= maxBound)
					continue;

				if (player->pos.x > maxX) {
					maxX = player->pos.x;
					maxPlayer = player;
				}
			}
		}

		maxBound = maxX;
		players[targetOffs] = maxPlayer;
	}

	// And now move them
	for (int i = 0; i < 4; i++) {
		if (dAcPy_c *player = players[i]) {
			float target = manipFourPlayerPos(i, 1060.0f);
			float speed = 2.0f;
			player->moveInDirection(&target, &speed);
		}
	}
}

void dEndingMgr_c::endState_GoRight() { }

void dEndingMgr_c::executeState_GoRight() {
	for (int i = 0; i < 4; i++) {
		if (dAcPy_c *player = players[i]) {
			if (player->pos.x > manipFourPlayerPos(i, 920.0f)) {
				player->demoMoveSpeed *= 0.994f;
			}
		}
	}

	// Can we leave this state yet?
	for (int i = 0; i < 4; i++) {
		if (dAcPy_c *player = players[i]) {
			if (!player->isReadyForDemoControlAction())
				return;
		}
	}

	// WE CAN LEAVE YAY
	timer++;
	if (timer >= 20)
		acState.setState(&StateID_LookUp);
}

CREATE_STATE(dEndingMgr_c, LookUp);
void dEndingMgr_c::beginState_LookUp() {
	_120 |= 8;
	lookAtMode = 2; // Higher maximum distance

	timer = 0;
}

void dEndingMgr_c::endState_LookUp() {
}

void dEndingMgr_c::executeState_LookUp() {
	timer++;

	if (timer >= 60)
		_120 &= ~8;

	if (timer >= 90)
		acState.setState(&StateID_JumpOntoSwitch);
}


CREATE_STATE(dEndingMgr_c, JumpOntoSwitch);
void dEndingMgr_c::beginState_JumpOntoSwitch() {
	for (int i = 0; i < 4; i++) {
		if (dAcPy_c *player = players[i]) {
			float target = manipFourPlayerPos(i, 1144.0f);
			float speed = 2.0f;
			player->moveInDirection(&target, &speed);
		}
	}

	timer = 0;
}
void dEndingMgr_c::endState_JumpOntoSwitch() {
}
void dEndingMgr_c::executeState_JumpOntoSwitch() {
	dAcPy_c *player = players[3];

	if (timer > 60) {
		acState.setState(&StateID_ThanksPeach);
	} else if (player->isReadyForDemoControlAction()) {
		player->input.setTransientForcedButtons(WPAD_DOWN);
	} else if (timer > 30) {
		player->input.unsetPermanentForcedButtons(WPAD_TWO);
	} else if (timer > 15) {
		player->input.setPermanentForcedButtons(WPAD_TWO);
	}

	timer++;
}

static daEnBossKoopaDemoPeach_c *getPeach() {
	return (daEnBossKoopaDemoPeach_c*)dEn_c::searchByProfileId(ProfileId::EN_BOSS_KOOPA_DEMO_PEACH);
}

CREATE_STATE(dEndingMgr_c, ThanksPeach);
void dEndingMgr_c::beginState_ThanksPeach() {
	timer = -1;
	getPeach()->doStateChange(&daEnBossKoopaDemoPeach_c::StateID_Turn);
}
void dEndingMgr_c::endState_ThanksPeach() {
}
extern "C" void startStaffCredit(GameMgr *);
void dEndingMgr_c::executeState_ThanksPeach() {
	daEnBossKoopaDemoPeach_c *peach = getPeach();
	dStateBase_c *peachSt = peach->acState.getCurrentState();

	if (peach->stage == 1 && peachSt == &peach->StateID_Turn) {
		timer++;
		if (timer == 1) {
			// This plays the Peach harp fanfare
			sub_8019C390(_8042A788, 6);
		}
		if (timer > 20) {
			peach->doStateChange(&peach->StateID_Open);
			peach->_120 |= 8;
			timer = -1;
		}
	}

	if (peach->stage == 1 && peachSt == &peach->StateID_Open) {
		peach->doStateChange(&peach->StateID_Rescue);
	}

	if (peach->stage == 3 && peachSt == &peach->StateID_Rescue) {
		peach->doStateChange(&peach->StateID_Thank);
	}

	if (peachSt == &peach->StateID_Thank) {
		// 1. Freeze Peach by changing to Stage 8 as soon as she's almost done
		// 2. Do our thing
		// 3. Go back!
		if (peach->stage == 0 && peach->counter == 33 && timer == -1) {
			peach->stage = 8;
			timer = 0;
		} else if (peach->stage == 8) {
			timer++;
			if (timer == 8) {
				float target = peach->pos.x - 20.0f;
				float speed = 1.5f;
				players[3]->moveInDirection(&target, &speed);
			} else if (timer == 90) {
				peach->stage = 0;
				players[3]->setAnimePlayWithAnimID(dm_escort);
			}
		} else if (peach->stage == 7) {
			// All the players are glad
			timer = 0;
			peach->stage = 9;
			for (int i = 0; i < 4; i++) {
				if (dAcPy_c *player = players[i]) {
					OSReport("Going to dmglad\n");
					OSReport("Player %d states: %s and %s\n", i, player->states2.getCurrentState()->getName(), player->demoStates.getCurrentState()->getName());
					player->setAnimePlayWithAnimID(dm_glad);

					static const int vocs[4] = {
						SE_VOC_MA_SAVE_PRINCESS,
						SE_VOC_LU_SAVE_PRINCESS,
						SE_VOC_KO_SAVE_PRINCESS,
						SE_VOC_KO2_SAVE_PRINCESS
					};
					dPlayerModelHandler_c *pmh = (dPlayerModelHandler_c*)(((u32)player) + 0x2A60);
					int voc = vocs[pmh->mdlClass->player_id_2];
					nw4r::snd::SoundHandle handle;
					PlaySoundWithFunctionB4(SoundRelatedClass, &handle, voc, 1);

					int powerup = *((u32*)( 0x1090 + ((u8*)player) ));
					handle.SetPitch(powerup == 3 ? 1.5f : 1.0f);
				}
			}
		} else if (peach->stage == 9) {
			timer++;
			if (timer == 90) {
				StartLevelInfo ls;
				ls.purpose = 0;
				ls.world1 = 0;
				ls.world2 = 0;
				ls.level1 = 41;
				ls.level2 = 41;
				ls.areaMaybe = 0;
				ls.entrance = 0xFF;
				ls.unk4 = 0; // load replay
				DontShowPreGame = true;
				ActivateWipe(MARIO_WIPE);
				DoStartLevel(GameMgrP, &ls);
			}
		}
	}
}




Vec2 dEndingMgr_c::_vf70() {
	// HACK OF THE MILLENIUM
	// DON'T TRY THIS AT HOME.
	Vec2 *v = (Vec2*)this;
	v->x = 1195.0f;
	v->y = -394.0f;
	return (const Vec2){12345.0f, 67890.f};
}


//
// processed\../src/chestnut.cpp
//

#include <game.h>
#include <profileid.h>
#include <sfx.h>
#include <profile.h>
const char *ChestnutFileList[] = {"chestnut", "kuribo", "togezo", "star_coin", 0};

class daEnChestnut_c : public dEn_c {
	public:
		static dActor_c *build();

		mHeapAllocator_c allocator;
		nw4r::g3d::ResFile resFile;
		m3d::mdl_c model;
		m3d::anmChr_c animation;

		void playAnimation(const char *name, bool loop = false);
		void playLoopedAnimation(const char *name) {
			playAnimation(name, true);
		}

		int objNumber;
		int starCoinNumber;
		bool ignorePlayers;
		bool breaksBlocks;
		float shakeWindow, fallWindow;

		int timeSpentExploding;

		lineSensor_s belowSensor;

		float nearestPlayerDistance();

		int onCreate();
		int onDelete();
		int onExecute();
		int onDraw();

		void spawnObject();

		bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
		bool collisionCat5_Mario(ActivePhysics *apThis, ActivePhysics *apOther);

		bool CreateIceActors();

		u32 canBePowed();
		void powBlockActivated(bool isNotMPGP);

		USING_STATES(daEnChestnut_c);
		DECLARE_STATE(Idle);
		DECLARE_STATE(Shake);
		DECLARE_STATE(Fall);
		DECLARE_STATE(Explode);
};

CREATE_STATE(daEnChestnut_c, Idle);
CREATE_STATE(daEnChestnut_c, Shake);
CREATE_STATE(daEnChestnut_c, Fall);
CREATE_STATE(daEnChestnut_c, Explode);

const SpriteData ChestnutSpriteData = {ProfileId::EN_CHESTNUT, 8, 0xFFFFFFF0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile ChestnutProfile(&daEnChestnut_c::build, SpriteId::EN_CHESTNUT, &ChestnutSpriteData, ProfileId::REMO_SLIDE_DOOR, ProfileId::EN_CHESTNUT, "EN_CHESTNUT", ChestnutFileList, 0x12);

dActor_c *daEnChestnut_c::build() {
	void *buf = AllocFromGameHeap1(sizeof(daEnChestnut_c));
	return new(buf) daEnChestnut_c;
}


int daEnChestnut_c::onCreate() {
	// Get settings
	int texNum = settings & 0xF;
	int rawScale = (settings & 0xF0) >> 4;
	starCoinNumber = (settings & 0xF00) >> 8;
	ignorePlayers = ((settings & 0x1000) != 0);
	breaksBlocks = ((settings & 0x2000) != 0);
	objNumber = (settings & 0xF0000) >> 16;

	if ((settings & 0x4000) != 0) {
		shakeWindow = 96.0f;
		fallWindow = 64.0f;
	} else {
		shakeWindow = 64.0f;
		fallWindow = 32.0f;
	}

	// Set up models
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	char rfName[64];
	sprintf(rfName, "g3d/t%02d.brres", texNum);

	resFile.data = getResource("chestnut", rfName);

	nw4r::g3d::ResMdl resMdl = resFile.GetResMdl("kuribo_iga");
	nw4r::g3d::ResAnmChr resAnm = resFile.GetResAnmChr("wait");

	model.setup(resMdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&model, 0);

	animation.setup(resMdl, resAnm, &allocator, 0);

	allocator.unlink();


	// Scale us
	scale.x = scale.y = scale.z = (1.0f + (float(rawScale) * 0.5f));

	// Physics and crap
	ActivePhysics::Info ccInfo;
	ccInfo.xDistToCenter = 0.0f;
	ccInfo.xDistToEdge = 12.0f * scale.x;
	ccInfo.yDistToCenter = 1.0f + (12.0f * scale.y);
	ccInfo.yDistToEdge = 12.0f * scale.y;

	ccInfo.category1 = 3;
	ccInfo.category2 = 0;
	ccInfo.bitfield1 = 0x6F;
	ccInfo.bitfield2 = 0xFFBAFFFE;

	ccInfo.unkShort1C = 0;
	ccInfo.callback = &dEn_c::collisionCallback;

	aPhysics.initWithStruct(this, &ccInfo);
	aPhysics.addToList();

	// WE'RE READY
	doStateChange(&StateID_Idle);

	return true;
}

void daEnChestnut_c::playAnimation(const char *name, bool loop) {
	animation.bind(&model, resFile.GetResAnmChr(name), !loop);
	model.bindAnim(&animation, 0.0f);
	animation.setUpdateRate(1.0f);
}

int daEnChestnut_c::onDelete() {
	aPhysics.removeFromList();
	return true;
}

int daEnChestnut_c::onExecute() {
	acState.execute();

	matrix.translation(pos.x, pos.y, pos.z);

	model.setDrawMatrix(matrix);
	model.setScale(&scale);
	model.calcWorld(false);

	model._vf1C();

	return true;
}

int daEnChestnut_c::onDraw() {
	model.scheduleForDrawing();

	return true;
}

float daEnChestnut_c::nearestPlayerDistance() {
	float bestSoFar = 10000.0f;

	for (int i = 0; i < 4; i++) {
		if (dAcPy_c *player = dAcPy_c::findByID(i)) {
			if (strcmp(player->states2.getCurrentState()->getName(), "dAcPy_c::StateID_Balloon")) {
				float thisDist = abs(player->pos.x - pos.x);
				if (thisDist < bestSoFar)
					bestSoFar = thisDist;
			}
		}
	}

	return bestSoFar;
}



void daEnChestnut_c::beginState_Idle() {
	playLoopedAnimation("wait");
}
void daEnChestnut_c::endState_Idle() { }


void daEnChestnut_c::executeState_Idle() {
	if (ignorePlayers)
		return;

	float dist = nearestPlayerDistance();

	if (dist < fallWindow)
		doStateChange(&StateID_Fall);
	else if (dist < shakeWindow)
		doStateChange(&StateID_Shake);
}



void daEnChestnut_c::beginState_Shake() {
	playLoopedAnimation("shake");
	animation.setUpdateRate(2.0f);

	nw4r::snd::SoundHandle handle;
	PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_PLY_CLIMB_KUSARI, 1);
}
void daEnChestnut_c::endState_Shake() { }

void daEnChestnut_c::executeState_Shake() {
	float dist = nearestPlayerDistance();

	if (dist >= shakeWindow)
		doStateChange(&StateID_Idle);
	else if (dist < fallWindow)
		doStateChange(&StateID_Fall);
}



void daEnChestnut_c::beginState_Fall() {
	animation.setUpdateRate(0.0f); // stop animation

	int size = 12*scale.x;

	belowSensor.flags = SENSOR_LINE;
	if (breaksBlocks)
		belowSensor.flags |= SENSOR_10000000 | SENSOR_BREAK_BLOCK | SENSOR_BREAK_BRICK;
	// 10000000 makes it pass through bricks

	belowSensor.lineA = -size << 12;
	belowSensor.lineB = size << 12;
	belowSensor.distanceFromCenter = 0;

	collMgr.init(this, &belowSensor, 0, 0);

	speed.y = 0.0f;
	y_speed_inc = -0.1875f;
	max_speed.y = -4.0f;

	nw4r::snd::SoundHandle handle;
	PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_DEMO_OP_PRESENT_THROW_2308f, 1);
}

void daEnChestnut_c::endState_Fall() { }

void daEnChestnut_c::executeState_Fall() {
	HandleYSpeed();
	doSpriteMovement();
	UpdateObjectPosBasedOnSpeedValuesReal();

	if (collMgr.calculateBelowCollision() & (~0x400000)) {
		doStateChange(&StateID_Explode);
	}
}



void daEnChestnut_c::beginState_Explode() {
	OSReport("Entering Explode\n");
	playAnimation("break");
	animation.setUpdateRate(2.0f);

	nw4r::snd::SoundHandle handle;
	PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_DEMO_OP_LAND_JR_0983f, 1);

	timeSpentExploding = 0;
}
void daEnChestnut_c::endState_Explode() { }

void daEnChestnut_c::executeState_Explode() {
	timeSpentExploding++;

	if (timeSpentExploding == 10) {
		S16Vec efRot = {0,0,0};
		SpawnEffect("Wm_en_burst_ss", 0, &pos, &efRot, &scale);
		spawnObject();
	}

	if (animation.isAnimationDone()) {
		Delete(1);
	}
}



bool daEnChestnut_c::CreateIceActors() {
	animation.setUpdateRate(0.0f);

	IceActorSpawnInfo info;
	info.flags = 0;
	info.pos = pos;
	info.pos.y -= (6.0f * info.scale.y);
	info.scale.x = info.scale.y = info.scale.z = scale.x * 1.35f;
	for (int i = 0; i < 8; i++)
		info.what[0] = 0.0f;

	return frzMgr.Create_ICEACTORs(&info, 1);
}

u32 daEnChestnut_c::canBePowed() {
	return true;
}
void daEnChestnut_c::powBlockActivated(bool isNotMPGP) {
	if (!isNotMPGP)
		return;

	dStateBase_c *state = acState.getCurrentState();
	if (state == &StateID_Idle || state == &StateID_Shake)
		doStateChange(&StateID_Fall);
}

bool daEnChestnut_c::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
	SpawnEffect("Wm_en_igafirehit", 0, &pos, &rot, &scale);

	if (acState.getCurrentState() != &StateID_Explode)
		doStateChange(&StateID_Explode);

	return true;
}

bool daEnChestnut_c::collisionCat5_Mario(ActivePhysics *apThis, ActivePhysics *apOther) {
	this->_vf220(apOther->owner);
	return true;
}


void daEnChestnut_c::spawnObject() {
	VEC3 acPos = pos;

	static const u32 things[] = {
		ProfileId::EN_KURIBO, 0,
		ProfileId::EN_TOGEZO, 0,
		ProfileId::EN_COIN_JUMP, 0,
		ProfileId::EN_ITEM, 0x05000009,
		ProfileId::EN_STAR_COIN, 0x10000000,
	};

	u32 acSettings = things[objNumber*2+1];

	if (objNumber == 4) {
		acSettings |= (starCoinNumber << 8);
		acPos.x -= 12.0f;
		acPos.y += 32.0f;
	}

	aPhysics.removeFromList();

	OSReport("Crap %d, %d, %08x\n", objNumber, things[objNumber*2], acSettings);
	dStageActor_c *ac =
		dStageActor_c::create(things[objNumber*2], acSettings, &acPos, 0, currentLayerID);

	S16Vec efRot = {0,0,0};
	SpawnEffect("Wm_ob_itemsndlandsmk", 0, &pos, &efRot, &scale);

	if (objNumber == 0) {
		dEn_c *en = (dEn_c*)ac;
		en->direction = 1;
		en->rot.y = -8192;
	}
}

//
// processed\../src/flipblock.cpp
//

#include <common.h>
#include <game.h>
#include <profile.h>

const char *FlipBlockFileList[] = {"block_rotate", 0};

class daEnFlipBlock_c : public daEnBlockMain_c {
public:
	Physics::Info physicsInfo;

	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	void calledWhenUpMoveExecutes();
	void calledWhenDownMoveExecutes();

	void blockWasHit(bool isDown);

	bool playerOverlaps();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;
	m3d::mdl_c model;

	int flipsRemaining;

	USING_STATES(daEnFlipBlock_c);
	DECLARE_STATE(Wait);
	DECLARE_STATE(Flipping);

	static dActor_c *build();
};

const SpriteData flipBlockSpriteData = { ProfileId::EN_FLIP_BLOCK, 8, 0xFFFFFFF8 , 0 , 0, 0x100, 0x100, 0, 0, 0, 0, 0 };
 // Using WM_GRID as the execute order profile ID fixes bugs; original FlipBlock uses it as well
Profile flipBlockProfile(&daEnFlipBlock_c::build, SpriteId::EN_FLIP_BLOCK, &flipBlockSpriteData, ProfileId::WM_GRID, ProfileId::EN_FLIP_BLOCK, "EN_FLIP_BLOCK", FlipBlockFileList, 0x2);


CREATE_STATE(daEnFlipBlock_c, Wait);
CREATE_STATE(daEnFlipBlock_c, Flipping);


int daEnFlipBlock_c::onCreate() {
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	resFile.data = getResource("block_rotate", "g3d/block_rotate.brres");
	model.setup(resFile.GetResMdl("block_rotate"), &allocator, 0, 1, 0);
	SetupTextures_MapObj(&model, 0);

	allocator.unlink();



	blockInit(pos.y);

	physicsInfo.x1 = -8;
	physicsInfo.y1 = 8;
	physicsInfo.x2 = 8;
	physicsInfo.y2 = -8;

	physicsInfo.otherCallback1 = &daEnBlockMain_c::OPhysicsCallback1;
	physicsInfo.otherCallback2 = &daEnBlockMain_c::OPhysicsCallback2;
	physicsInfo.otherCallback3 = &daEnBlockMain_c::OPhysicsCallback3;

	physics.setup(this, &physicsInfo, 3, currentLayerID);
	physics.flagsMaybe = 0x260;
	physics.callback1 = &daEnBlockMain_c::PhysicsCallback1;
	physics.callback2 = &daEnBlockMain_c::PhysicsCallback2;
	physics.callback3 = &daEnBlockMain_c::PhysicsCallback3;
	physics.addToList();

	doStateChange(&daEnFlipBlock_c::StateID_Wait);

	return true;
}


int daEnFlipBlock_c::onDelete() {
	physics.removeFromList();

	return true;
}


int daEnFlipBlock_c::onExecute() {
	acState.execute();
	physics.update();
	blockUpdate();

	// now check zone bounds based on state
	if (acState.getCurrentState()->isEqual(&StateID_Wait)) {
		checkZoneBoundaries(0);
	}

	return true;
}


int daEnFlipBlock_c::onDraw() {
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	model.setDrawMatrix(matrix);
	model.setScale(&scale);
	model.calcWorld(false);
	model.scheduleForDrawing();

	return true;
}


dActor_c *daEnFlipBlock_c::build() {

	void *buffer = AllocFromGameHeap1(sizeof(daEnFlipBlock_c));
	daEnFlipBlock_c *c = new(buffer) daEnFlipBlock_c;


	return c;
}


void daEnFlipBlock_c::blockWasHit(bool isDown) {
	pos.y = initialY;

	doStateChange(&StateID_Flipping);
}



void daEnFlipBlock_c::calledWhenUpMoveExecutes() {
	if (initialY >= pos.y)
		blockWasHit(false);
}

void daEnFlipBlock_c::calledWhenDownMoveExecutes() {
	if (initialY <= pos.y)
		blockWasHit(true);
}



void daEnFlipBlock_c::beginState_Wait() {
}

void daEnFlipBlock_c::endState_Wait() {
}

void daEnFlipBlock_c::executeState_Wait() {
	int result = blockResult();

	if (result == 0)
		return;

	if (result == 1) {
		doStateChange(&daEnBlockMain_c::StateID_UpMove);
		anotherFlag = 2;
		isGroundPound = false;
	} else {
		doStateChange(&daEnBlockMain_c::StateID_DownMove);
		anotherFlag = 1;
		isGroundPound = true;
	}
}


void daEnFlipBlock_c::beginState_Flipping() {
	flipsRemaining = 7;
	physics.removeFromList();
}
void daEnFlipBlock_c::executeState_Flipping() {
	if (isGroundPound)
		rot.x += 0x800;
	else
		rot.x -= 0x800;

	if (rot.x == 0) {
		flipsRemaining--;
		if (flipsRemaining <= 0) {
			if (!playerOverlaps())
				doStateChange(&StateID_Wait);
		}
	}
}
void daEnFlipBlock_c::endState_Flipping() {
	physics.setup(this, &physicsInfo, 3, currentLayerID);
	physics.addToList();
}



bool daEnFlipBlock_c::playerOverlaps() {
	dStageActor_c *player = 0;

	Vec myBL = {pos.x - 8.0f, pos.y - 8.0f, 0.0f};
	Vec myTR = {pos.x + 8.0f, pos.y + 8.0f, 0.0f};

	while ((player = (dStageActor_c*)fBase_c::searchByProfileId(ProfileId::PLAYER, player)) != 0) {
		float centerX = player->pos.x + player->aPhysics.info.xDistToCenter;
		float centerY = player->pos.y + player->aPhysics.info.yDistToCenter;

		float left = centerX - player->aPhysics.info.xDistToEdge;
		float right = centerX + player->aPhysics.info.xDistToEdge;

		float top = centerY + player->aPhysics.info.yDistToEdge;
		float bottom = centerY - player->aPhysics.info.yDistToEdge;

		Vec playerBL = {left, bottom + 0.1f, 0.0f};
		Vec playerTR = {right, top - 0.1f, 0.0f};

		if (RectanglesOverlap(&playerBL, &playerTR, &myBL, &myTR))
			return true;
	}

	return false;
}

//
// processed\../src/magicplatform.cpp
//

#include <game.h>
#include <dCourse.h>
#include <profile.h>

class daEnMagicPlatform_c : public dEn_c {
	public:
		static dActor_c *build();

		int onCreate();
		int onExecute();
		int onDelete();

		enum CollisionType {
			Solid = 0,
			SolidOnTop = 1,
			None = 2,
			ThinLineRight = 3,
			ThinLineLeft = 4,
			ThinLineTop = 5,
			ThinLineBottom = 6,
			NoneWithZ500 = 7
		};

		// Settings
		CollisionType collisionType;
		u8 rectID, moveSpeed, moveDirection, moveLength;

		u8 moveDelay, currentMoveDelay;

		bool doesMoveInfinitely;

		float moveMin, moveMax, moveDelta, moveBaseDelta;
		float *moveTarget;

		bool isMoving;
		void setupMovement();
		void handleMovement();

		Physics physics;
		StandOnTopCollider sotCollider;

		TileRenderer *renderers;
		int rendererCount;

		void findSourceArea();
		void createTiles();
		void deleteTiles();
		void updateTilePositions();

		void checkVisibility();
		void setVisible(bool shown);

		bool isVisible;

		int srcX, srcY;
		int width, height;
};

/*****************************************************************************/
// Glue Code
const SpriteData MagicPlatformSpriteData = {ProfileId::EN_MAGICPLATFORM, 0, 0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 2};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile MagicPlatformProfile(&daEnMagicPlatform_c::build, SpriteId::EN_MAGICPLATFORM, &MagicPlatformSpriteData, ProfileId::EN_SLIP_PENGUIN, ProfileId::EN_MAGICPLATFORM, "EN_MAGICPLATFORM");

dActor_c *daEnMagicPlatform_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daEnMagicPlatform_c));
	daEnMagicPlatform_c *c = new(buffer) daEnMagicPlatform_c;
	return c;
}

extern "C" void HurtMarioBecauseOfBeingSquashed(void *mario, dStageActor_c *squasher, int type);

static void PhysCB1(daEnMagicPlatform_c *one, dStageActor_c *two) {
	if (two->stageActorType != 1)
		return;

	// if left/right
	if (one->moveDirection <= 1)
		return;

	if (one->pos_delta.y > 0.0f)
		HurtMarioBecauseOfBeingSquashed(two, one, 1);
	else
		HurtMarioBecauseOfBeingSquashed(two, one, 9);
}

static void PhysCB2(daEnMagicPlatform_c *one, dStageActor_c *two) {
	if (two->stageActorType != 1)
		return;

	// if left/right
	if (one->moveDirection <= 1)
		return;

	if (one->pos_delta.y < 0.0f)
		HurtMarioBecauseOfBeingSquashed(two, one, 2);
	else
		HurtMarioBecauseOfBeingSquashed(two, one, 10);
}

static void PhysCB3(daEnMagicPlatform_c *one, dStageActor_c *two, bool unkMaybeNotBool) {
	if (two->stageActorType != 1)
		return;

	// if up/down
	if (one->moveDirection > 1)
		return;

	if (unkMaybeNotBool) {
		if (one->pos_delta.x > 0.0f)
			HurtMarioBecauseOfBeingSquashed(two, one, 6);
		else
			HurtMarioBecauseOfBeingSquashed(two, one, 12);
	} else {
		if (one->pos_delta.x < 0.0f)
			HurtMarioBecauseOfBeingSquashed(two, one, 5);
		else
			HurtMarioBecauseOfBeingSquashed(two, one, 11);
	}
}

static bool PhysCB4(daEnMagicPlatform_c *one, dStageActor_c *two) {
	return (one->pos_delta.y > 0.0f);
}

static bool PhysCB5(daEnMagicPlatform_c *one, dStageActor_c *two) {
	return (one->pos_delta.y < 0.0f);
}

static bool PhysCB6(daEnMagicPlatform_c *one, dStageActor_c *two, bool unkMaybeNotBool) {
	if (unkMaybeNotBool) {
		if (one->pos_delta.x > 0.0f)
			return true;
	} else {
		if (one->pos_delta.x < 0.0f)
			return true;
	}
	return false;
}

int daEnMagicPlatform_c::onCreate() {
	rectID = settings & 0xFF;

	moveSpeed = (settings & 0xF00) >> 8;
	moveDirection = (settings & 0x3000) >> 12;
	moveLength = ((settings & 0xF0000) >> 16) + 1;

	moveDelay = ((settings & 0xF00000) >> 20) * 6;

	collisionType = (CollisionType)((settings & 0xF000000) >> 24);

	doesMoveInfinitely = (settings & 0x10000000);

	if (settings & 0xE0000000) {
		int putItBehind = settings >> 29;
		pos.z = -3600.0f - (putItBehind * 16);
	}
	if (collisionType == NoneWithZ500)
		pos.z = 500.0f;

	setupMovement();

	findSourceArea();
	createTiles();

	float fWidth = width * 16.0f;
	float fHeight = height * 16.0f;

	switch (collisionType) {
		case Solid:
			physics.setup(this,
					0.0f, 0.0f, fWidth, -fHeight,
					(void*)&PhysCB1, (void*)&PhysCB2, (void*)&PhysCB3, 1, 0, 0);

			physics.callback1 = (void*)&PhysCB4;
			physics.callback2 = (void*)&PhysCB5;
			physics.callback3 = (void*)&PhysCB6;

			physics.addToList();
			break;
		case SolidOnTop:
			sotCollider.init(this,
					/*xOffset=*/0.0f, /*yOffset=*/0.0f,
					/*topYOffset=*/0,
					/*rightSize=*/fWidth, /*leftSize=*/0,
					/*rotation=*/0, /*_45=*/1
					);

			// What is this for. I dunno
			sotCollider._47 = 0xA;
			sotCollider.flags = 0x80180 | 0xC00;

			sotCollider.addToList();

			break;
		case ThinLineLeft: case ThinLineRight:
		case ThinLineTop: case ThinLineBottom:
			physics.setup(this,
				fWidth * (collisionType == ThinLineRight ? 0.875f : 0.0f),
				fHeight * (collisionType == ThinLineBottom ? -0.75f : 0.0f),
				fWidth * (collisionType == ThinLineLeft ? 0.125f : 1.0f),
				fHeight * (collisionType == ThinLineTop ? -0.25f : -1.0f),
				(void*)&PhysCB1, (void*)&PhysCB2, (void*)&PhysCB3, 1, 0, 0);

			physics.callback1 = (void*)&PhysCB4;
			physics.callback2 = (void*)&PhysCB5;
			physics.callback3 = (void*)&PhysCB6;

			physics.addToList();
			break;
	}

	return 1;
}

int daEnMagicPlatform_c::onDelete() {
	deleteTiles();

	switch (collisionType) {
		case ThinLineLeft: case ThinLineRight:
		case ThinLineTop: case ThinLineBottom:
		case Solid: physics.removeFromList(); break;
	}

	return 1;
}

int daEnMagicPlatform_c::onExecute() {
	handleMovement();

	checkVisibility();

	updateTilePositions();

	switch (collisionType) {
		case ThinLineLeft: case ThinLineRight:
		case ThinLineTop: case ThinLineBottom:
		case Solid: physics.update(); break;
		case SolidOnTop: sotCollider.update(); break;
	}

	return 1;
}

/*****************************************************************************/
// Movement
void daEnMagicPlatform_c::setupMovement() {
	float fMoveLength = 16.0f * moveLength;
	float fMoveSpeed = 0.2f * moveSpeed;

	switch (moveDirection) {
		case 0: // RIGHT
			moveTarget = &pos.x;
			moveMin = pos.x;
			moveMax = pos.x + fMoveLength;
			moveBaseDelta = fMoveSpeed;
			break;
		case 1: // LEFT
			moveTarget = &pos.x;
			moveMin = pos.x - fMoveLength;
			moveMax = pos.x;
			moveBaseDelta = -fMoveSpeed;
			break;
		case 2: // UP
			moveTarget = &pos.y;
			moveMin = pos.y;
			moveMax = pos.y + fMoveLength;
			moveBaseDelta = fMoveSpeed;
			break;
		case 3: // DOWN
			moveTarget = &pos.y;
			moveMin = pos.y - fMoveLength;
			moveMax = pos.y;
			moveBaseDelta = -fMoveSpeed;
			break;
	}

	if (spriteFlagNum == 0) {
		isMoving = (moveSpeed > 0);
		moveDelta = moveBaseDelta;
	} else {
		isMoving = false;
	}

	currentMoveDelay = 0;
}

void daEnMagicPlatform_c::handleMovement() {
	if (spriteFlagNum > 0) {
		// Do event checks
		bool flagOn = ((dFlagMgr_c::instance->flags & spriteFlagMask) != 0);

		if (isMoving) {
			if (!flagOn) {
				// Flag was turned off while moving, so go back
				moveDelta = -moveBaseDelta;
			} else {
				moveDelta = moveBaseDelta;
			}
		} else {
			if (flagOn) {
				// Flag was turned on, so start moving
				moveDelta = moveBaseDelta;
				isMoving = true;
			}
		}
	}

	if (!isMoving)
		return;

	if (currentMoveDelay > 0) {
		currentMoveDelay--;
		return;
	}

	// Do it
	bool goesForward = (moveDelta > 0.0f);
	bool reachedEnd = false;

	*moveTarget += moveDelta;

	// if we're set to move infinitely, never stop
	if (doesMoveInfinitely)
		return;

	if (goesForward) {
		if (*moveTarget >= moveMax) {
			*moveTarget = moveMax;
			reachedEnd = true;
		}
	} else {
		if (*moveTarget <= moveMin) {
			*moveTarget = moveMin;
			reachedEnd = true;
		}
	}

	if (reachedEnd) {
		if (spriteFlagNum > 0) {
			// If event, just do nothing.. depending on what side we are on
			if ((moveDelta > 0.0f && moveBaseDelta > 0.0f) || (moveDelta < 0.0f && moveBaseDelta < 0.0f)) {
				// We reached the end, so keep isMoving on for when we need to reverse
			} else {
				// We're back at the start, so turn it off
				isMoving = false;
			}
		} else {
			// Otherwise, reverse
			moveDelta = -moveDelta;
			currentMoveDelay = moveDelay;
		}
	}
}

/*****************************************************************************/
// Tile Renderers

void daEnMagicPlatform_c::findSourceArea() {
	mRect rect;
	dCourseFull_c::instance->get(GetAreaNum())->getRectByID(rectID, &rect);

	// Round the positions down/up to get the rectangle
	int left = rect.x;
	int right = left + rect.width;
	int top = -rect.y;
	int bottom = top + rect.height;

	left &= 0xFFF0;
	right = (right + 15) & 0xFFF0;

	top &= 0xFFF0;
	bottom = (bottom + 15) & 0xFFF0;

	// Calculate the actual stuff
	srcX = left >> 4;
	srcY = top >> 4;
	width = (right - left) >> 4;
	height = (bottom - top) >> 4;

	//OSReport("Area: %f, %f ; %f x %f\n", rect.x, rect.y, rect.width, rect.height);
	//OSReport("Source: %d, %d ; Size: %d x %d\n", srcX, srcY, width, height);
}


void daEnMagicPlatform_c::createTiles() {
	rendererCount = width * height;
	renderers = new TileRenderer[rendererCount];

	// copy all the fuckers over
	int baseWorldX = srcX << 4, worldY = srcY << 4, rendererID = 0;

	for (int y = 0; y < height; y++) {
		int worldX = baseWorldX;

		for (int x = 0; x < width; x++) {
			u16 *pExistingTile = dBgGm_c::instance->getPointerToTile(worldX, worldY, 0);

			if (*pExistingTile > 0) {
				TileRenderer *r = &renderers[rendererID];
				r->tileNumber = *pExistingTile;
				r->z = pos.z;
			}

			worldX += 16;
			rendererID++;
		}

		worldY += 16;
	}

}

void daEnMagicPlatform_c::deleteTiles() {
	if (renderers != 0) {
		setVisible(false);

		delete[] renderers;
		renderers = 0;
	}
}

void daEnMagicPlatform_c::updateTilePositions() {
	float baseX = pos.x;

	float y = -pos.y;

	int rendererID = 0;

	for (int yIdx = 0; yIdx < height; yIdx++) {
		float x = baseX;

		for (int xIdx = 0; xIdx < width; xIdx++) {
			TileRenderer *r = &renderers[rendererID];
			r->x = x;
			r->y = y;

			x += 16.0f;
			rendererID++;
		}

		y += 16.0f;
	}
}



void daEnMagicPlatform_c::checkVisibility() {
	float effectiveLeft = pos.x, effectiveRight = pos.x + (width * 16.0f);
	float effectiveBottom = pos.y - (height * 16.0f), effectiveTop = pos.y;

	ClassWithCameraInfo *cwci = ClassWithCameraInfo::instance;

	float screenRight = cwci->screenLeft + cwci->screenWidth;
	float screenBottom = cwci->screenTop - cwci->screenHeight;

	bool isOut = (effectiveLeft > screenRight) ||
		(effectiveRight < cwci->screenLeft) ||
		(effectiveTop < screenBottom) ||
		(effectiveBottom > cwci->screenTop);

	setVisible(!isOut);
}

void daEnMagicPlatform_c::setVisible(bool shown) {
	if (isVisible == shown)
		return;
	isVisible = shown;

	TileRenderer::List *list = dBgGm_c::instance->getTileRendererList(0);

	for (int i = 0; i < rendererCount; i++) {
		if (renderers[i].tileNumber > 0) {
			if (shown) {
				list->add(&renderers[i]);
			} else {
				list->remove(&renderers[i]);
			}
		}
	}
}


//
// processed\../src/bonepiece.cpp
//

#include <game.h>
#include <profile.h>

const char* BonePieceNameList [] = {
	"lift_torokko",
	NULL
};

class daBonePiece_c : public dStageActor_c {
	public:
		static dActor_c  *build();

		int onCreate();
		int onExecute();
		int onDraw();
		int onDelete();

		StandOnTopCollider collider;

		nw4r::g3d::ResFile resFile;
		mHeapAllocator_c allocator;
		m3d::mdl_c model;
};

//0289 0000  00000000 00000000  00000000 00000000 00000100 00000100  0000 0000 0000 0000  0002 0000
const SpriteData BonePieceSpriteData = { ProfileId::AC_BONE_PIECE, 0, 0 , 0 , 0, 0x100, 0x100, 0, 0, 0, 0, 2};
Profile BonePieceProfile(&daBonePiece_c::build, SpriteId::AC_BONE_PIECE, &BonePieceSpriteData, ProfileId::WM_BOSS_IGGY, ProfileId::AC_BONE_PIECE, "AC_BONE_PIECE", BonePieceNameList);

// Glue Code
dActor_c  *daBonePiece_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daBonePiece_c));
	daBonePiece_c *c = new(buffer) daBonePiece_c;
	return c;
}

int daBonePiece_c::onCreate() {
	// Load the model
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	resFile.data = getResource(BonePieceNameList[0], "g3d/t00.brres");

	static char thing[] = "lift_torokko?";
	thing[0xC] = 'A' + (settings & 3);

	nw4r::g3d::ResMdl resmdl = resFile.GetResMdl(thing);
	model.setup(resmdl, &allocator, 0, 1, 0);
	SetupTextures_MapObj(&model, 0);

	allocator.unlink();

	// If rotation is off, do nothing else
	if ((settings >> 28) & 1) {
		// OK, figure out the rotation
		u8 sourceRotation = (settings >> 24) & 0xF;

		// 0 is up. -0x4000 is right, 0x4000 is left ...
		s16 rotation;

		// We'll flip it later.
		// Thus: 0..7 rotates left (in increments of 0x800),
		// 8..15 rotates right (in increments of 0x800 too).
		// To specify facing up, well.. just use 0.

		if (sourceRotation < 8)
			rotation = (sourceRotation * 0x800) - 0x4000;
		else
			rotation = (sourceRotation * 0x800) - 0x3800;

		rot.z = -rotation;
	}

	if ((settings >> 20) & 1)
		rot.y = 0x8000;
	
	float xOffs, yOffs;

	if (-0x2000 <= rot.z && rot.z <= 0x2000)
		xOffs = 8.0f * sin(rot.z) * cos(rot.z);
	else
		xOffs = 5.0f * sin(rot.z);

	if (rot.z < 0)
		yOffs = -xOffs;
	else
		yOffs = xOffs;

	collider.init(this, xOffs, yOffs, 0, 16.0f, -16.0f, rot.z, 1); // X Offset, Y Offset, Top Y Offset, Right Size, Left Size, Rotation, _45
	collider._47 = 0;
	collider.flags = 0x80180 | 0xC00;
	collider.addToList();

	return true;
}

int daBonePiece_c::onDelete() {
	return true;
}

int daBonePiece_c::onExecute() {
	matrix.translation(pos.x, pos.y - 8.0f, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	model.setDrawMatrix(matrix);
	model.setScale(&scale);
	model.calcWorld(false);

	collider.update();

	return true;
}

int daBonePiece_c::onDraw() {
	model.scheduleForDrawing();
	return true;
}
//
// processed\../src/music.cpp
//

#include <game.h>
#include <sfx.h>
#include "music.h"

struct HijackedStream {
	//const char *original;
	//const char *originalFast;
	u32 stringOffset;
	u32 stringOffsetFast;
	u32 infoOffset;
	u8 originalID;
	int streamID;
};

struct Hijacker {
	HijackedStream stream[2];
	u8 currentStream;
	u8 currentCustomTheme;
};


const char* SongNameList [] = {
"AIRSHIP",          // ID 100
	"BOSS_TOWER",       // ID 101
	"MENU",
	"UNDERWATER",
	"ATHLETIC",
	"CASTLE",
	"MAIN",
	"MOUNTAIN",
	"TOWER",
	"UNDERGROUND",
	"DESERT",
	"FIRE",
	"FOREST",
	"FREEZEFLAME",
	"JAPAN",
	"PUMPKIN",
	"SEWER",
	"SPACE",
	"BOWSER",
	"BONUS",
	"AMBUSH",
	"BRIDGE_DRUMS",
	"SNOW2",
	"MINIMEGA",
	"CLIFFS",
	"AUTUMN",
	"CRYSTALCAVES",
	"GHOST_HOUSE",
	"GRAVEYARD",
	"JUNGLE",
	"TROPICAL",
	"SKY_CITY",
	"SNOW",
	"STAR_HAVEN",
	"SINGALONG",
	"FACTORY",
	"TANK",
	"TRAIN",
	"YOSHIHOUSE",
	"FACTORYB",
	"CAVERN",
	"SAND",
	"SHYGUY",
	"MINIGAME",
	"BONUS_AREA",
	"CHALLENGE",
	"BOWSER_CASTLE",    // ID 146
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"BOSS_CASTLE",      // ID 156
	"BOSS_AIRSHIP",     // ID 157
	"",
	"",
	"Underground Room",         // ID 160
	"Gap of Crag",
	"Whoa Zone",
	"A Powerful Enemy Emerges",
	"Nostalgic Underground",
	"Fort Francis",
	"Mimi Battle",
	"Merlee's Mansion",
	"Outside Merlee's Mansion",
	"King Croacus Battle",
	"Castle Bleck",
	"Bowser Battle",
	"Ready, GO!",
	"Francis Battle",
	"Brobot L-Type Battle",
	"Fracktail Battle",
	"Brobot Battle",
	"Bonechill Battle",
	"GaMetal - The Ultimate Show",
	"4 Heroes Unite",
	"Hammer Whacker",
	"Dimentio, Charming Magician",
	"O'Chunks, Warrior",
	"Bonechill Appears",
	"Mimi the Copycat",
	"King Croacus Appears",
	"Mr. L, Green Thunder!",
	"Outer Space",
	"SONG_188",
	"SONG_189",
	"SONG_190",
	"SONG_191",
	"SONG_192",
	"SONG_193",
	"Freezy Flake Galaxy",
	"Digga-Leg",
	"Beep Block Skyway (w_ Beeps)",
	"Speed Run",
	"Cosmic Comet",
	"Purple Comet",         // ID 199
	NULL
};


// Offsets are from the start of the INFO block, not the start of the brsar.
// INFO begins at 0x212C0, so that has to be subtracted from absolute offsets
// within the brsar.

#define _I(offs) ((offs)-0x212C0)

Hijacker Hijackers[2] = {
	{
		{
			{/*"athletic_lr.n.32.brstm", "athletic_fast_lr.n.32.brstm",*/ _I(0x4A8F8), _I(0x4A938), _I(0x476C4), 4, STRM_BGM_ATHLETIC},
			{/*"BGM_SIRO.32.brstm", "BGM_SIRO_fast.32.brstm",*/ _I(0x4B2E8), _I(0x4B320), _I(0x48164), 10, STRM_BGM_SHIRO}
		},
		0, 0
	},

	{
		{
			{/*"STRM_BGM_CHIJOU.brstm", "STRM_BGM_CHIJOU_FAST.brstm",*/ _I(0x4A83C), _I(0x4A8B4), 0, 1, STRM_BGM_CHIJOU},
			{/*"STRM_BGM_CHIKA.brstm", "STRM_BGM_CHIKA_FAST.brstm",*/ _I(0x4A878), _I(0x4A780), 0, 2, STRM_BGM_CHIKA},
		},
		0, 0
	}
};

extern void *SoundRelatedClass;
inline char *BrsarInfoOffset(u32 offset) {
	return (char*)(*(u32*)(((u32)SoundRelatedClass) + 0x5CC)) + offset;
}

void FixFilesize(u32 streamNameOffset);

u8 hijackMusicWithSongName(const char *songName, int themeID, bool hasFast, int channelCount, int trackCount, int *wantRealStreamID) {
	Hijacker *hj = &Hijackers[channelCount==4?1:0];

	// do we already have this theme in this slot?
	// if so, don't switch streams
	// if we do, NSMBW will think it's a different song, and restart it ...
	// but if it's just an area transition where both areas are using the same
	// song, we don't want that
	if ((themeID >= 0) && hj->currentCustomTheme == themeID)
		return hj->stream[hj->currentStream].originalID;

	// which one do we use this time...?
	int toUse = (hj->currentStream + 1) & 1;

	hj->currentStream = toUse;
	hj->currentCustomTheme = themeID;

	// write the stream's info
	HijackedStream *stream = &hj->stream[hj->currentStream];

	if (stream->infoOffset) {
		u16 *thing = (u16*)(BrsarInfoOffset(stream->infoOffset) + 4);
		OSReport("Modifying stream info, at offset %x which is at pointer %x\n", stream->infoOffset, thing);
		OSReport("It currently has: channel count %d, track bitfield 0x%x\n", thing[0], thing[1]);
		thing[0] = channelCount;
		thing[1] = (1 << trackCount) - 1;
		OSReport("It has been set to: channel count %d, track bitfield 0x%x\n", thing[0], thing[1]);
	}

	sprintf(BrsarInfoOffset(stream->stringOffset), "stream/%s.brstm", songName);
	sprintf(BrsarInfoOffset(stream->stringOffsetFast), hasFast?"stream/%s_F.brstm":"stream/%s.brstm", songName);

	// update filesizes
	FixFilesize(stream->stringOffset);
	FixFilesize(stream->stringOffsetFast);

	// done!
	if (wantRealStreamID)
		*wantRealStreamID = stream->streamID;

	return stream->originalID;
}


//oh for fuck's sake
#include "fileload.h"
//#include <rvl/dvd.h>

void FixFilesize(u32 streamNameOffset) {
	char *streamName = BrsarInfoOffset(streamNameOffset);

	char nameWithSound[80];
	snprintf(nameWithSound, 79, "/Sound/%s", streamName);

	s32 entryNum;
	DVDHandle info;
	
	if ((entryNum = DVDConvertPathToEntrynum(nameWithSound)) >= 0) {
		if (DVDFastOpen(entryNum, &info)) {
			u32 *lengthPtr = (u32*)(streamName - 0x1C);
			*lengthPtr = info.length;
		}
	} else
		OSReport("What, I couldn't find \"%s\" :(\n", nameWithSound);
}



extern "C" u8 after_course_getMusicForZone(u8 realThemeID) {
	if (realThemeID < 100)
		return realThemeID;

	bool usesDrums = (realThemeID >= 200);
	const char *name = SongNameList[realThemeID - (usesDrums ? 200 : 100)];
	return hijackMusicWithSongName(name, realThemeID, true, usesDrums?4:2, usesDrums?2:1, 0);
}



//
// processed\../src/levelinfo.cpp
//

#include "levelinfo.h"

dDvdLoader_c s_levelInfoLoader;
bool s_levelInfoLoaded = false;

dLevelInfo_c dLevelInfo_c::s_info;

bool LoadLevelInfo() {
	if (s_levelInfoLoaded)
		return true;

	void *data = s_levelInfoLoader.load("/LevelInfo.bin");
	if (data) {
		dLevelInfo_c::s_info.load(data);
		s_levelInfoLoaded = true;
		return true;
	}

	return false;
}


void dLevelInfo_c::load(void *buffer) {
	data = (header_s*)buffer;

	// decode all the level names
	for (int sect = 0; sect < sectionCount(); sect++) {
		// parse this section
		section_s *thisSect = getSectionByIndex(sect);

		for (int lev = 0; lev < thisSect->levelCount; lev++) {
			entry_s *level = &thisSect->levels[lev];
			if (level->levelSlot < 42)
				SetSomeConditionShit(level->worldSlot, level->levelSlot, level->flags);

			char *name = (char*)getNameForLevel(level);

			for (int i = 0; i < level->nameLength+1; i++) {
				name[i] -= 0xD0;
			}
		}
	}
}

dLevelInfo_c::entry_s *dLevelInfo_c::searchBySlot(int world, int level) {
	for (int i = 0; i < sectionCount(); i++) {
		section_s *sect = getSectionByIndex(i);

		for (int j = 0; j < sect->levelCount; j++) {
			entry_s *entry = &sect->levels[j];
			if (entry->worldSlot == world && entry->levelSlot == level)
				return entry;
		}
	}

	return 0;
}

dLevelInfo_c::entry_s *dLevelInfo_c::searchByDisplayNum(int world, int level) {
	for (int i = 0; i < sectionCount(); i++) {
		section_s *sect = getSectionByIndex(i);

		for (int j = 0; j < sect->levelCount; j++) {
			entry_s *entry = &sect->levels[j];
			if (entry->displayWorld == world && entry->displayLevel == level)
				return entry;
		}
	}

	return 0;
}


void UpdateFSStars() {
	dLevelInfo_c *li = &dLevelInfo_c::s_info;
	SaveBlock *save = GetSaveFile()->GetBlock(-1);

	bool coinsNormal = true, exitsNormal = true;
	bool coinsW9 = true, exitsW9 = true;

	for (int i = 0; i < li->sectionCount(); i++) {
		dLevelInfo_c::section_s *sect = li->getSectionByIndex(i);

		for (int j = 0; j < sect->levelCount; j++) {
			dLevelInfo_c::entry_s *entry = &sect->levels[j];

			// Levels only
			if (!(entry->flags & 2))
				continue;

			u32 conds = save->GetLevelCondition(entry->worldSlot, entry->levelSlot);

			if (entry->displayWorld == 9) {
				if ((conds & COND_COIN_ALL) != COND_COIN_ALL)
					coinsW9 = false;
				if (entry->flags & 0x10)
					if (!(conds & COND_NORMAL))
						exitsW9 = false;
				if (entry->flags & 0x20)
					if (!(conds & COND_SECRET))
						exitsW9 = false;
			} else {
				if ((conds & COND_COIN_ALL) != COND_COIN_ALL)
					coinsNormal = false;
				if (entry->flags & 0x10)
					if (!(conds & COND_NORMAL))
						exitsNormal = false;
				if (entry->flags & 0x20)
					if (!(conds & COND_SECRET))
						exitsNormal = false;
			}
		}
	}

	bool beatGame = (save->GetLevelCondition(7, 23) & COND_NORMAL) != 0;

//	save->bitfield &= ~0x3E;
	save->bitfield &= ~0x3C;
	save->bitfield |=
//		(beatGame ? 2 : 0) |
		(exitsNormal ? 4 : 0) |
		(coinsNormal ? 8 : 0) |
		(exitsW9 ? 0x10 : 0) |
		(coinsW9 ? 0x20 : 0);

	OSReport("FS Stars updated: Status: Game beaten: %d, Normal exits: %d, Normal coins: %d, W9 exits: %d, W9 coins: %d\n", beatGame, exitsNormal, coinsNormal, exitsW9, coinsW9);
}


//
// processed\../src/newer.cpp
//

#include <game.h>
#include <newer.h>
#include "levelinfo.h"

int lastLevelIDs[] = {
	-1, /*no world*/
	27, 27, 27, 27, 27, 27, 27, 25,
	10,
	24, 24, 21, 24, 3
};


/*
extern "C" void FuckUpYoshi(void *_this) {
	dEn_c *koopa = (dEn_c*)fBase_c::searchByProfileId(ProfileId::EN_NOKONOKO, 0);
	static int thing = 0;
	thing++;
	nw4r::db::Exception_Printf_("Fruit eaten: %d\n", thing);
	if (thing == 5) {
		nw4r::db::Exception_Printf_("5th fruit eaten\n");
		nw4r::db::Exception_Printf_("Let's try fucking up Yoshi!\n");
		daPlBase_c *yoshi = (daPlBase_c*)fBase_c::searchByProfileId(ProfileId::YOSHI, 0);
		nw4r::db::Exception_Printf_("Fruit: %p ; Koopa: %p ; Yoshi: %p\n", _this, koopa, yoshi);
		koopa->_vf220(yoshi);
		nw4r::db::Exception_Printf_("Yoshi fucked up. Yay.\n");
		thing = 0;
	}
}

extern "C" void FuckUpYoshi2() {
	dEn_c *koopa = (dEn_c*)fBase_c::searchByProfileId(ProfileId::EN_NOKONOKO, 0);
	nw4r::db::Exception_Printf_("Let's try fucking up Yoshi!\n");
	daPlBase_c *yoshi = (daPlBase_c*)fBase_c::searchByProfileId(ProfileId::YOSHI, 0);
	koopa->_vf220(yoshi);
	nw4r::db::Exception_Printf_("Yoshi fucked up. Yay.\n");
}

extern "C" void StartAnimOrig(dPlayerModelBase_c *_this, int id, float updateRate, float unk, float frame);
extern "C" void YoshiStartAnimWrapper(dPlayerModelBase_c *_this, int id, float updateRate, float unk, float frame) {
	nw4r::db::Exception_Printf_("[%d] anim %d (%f, %f, %f)\n", GlobalTickCount, id, updateRate, unk, frame);
	StartAnimOrig(_this, id, updateRate, unk, frame);
}
extern "C" void YoshiStateOrig(daPlBase_c *_this, dStateBase_c *state, void *param);
extern "C" void YoshiStateWrapper(daPlBase_c *_this, dStateBase_c *state, void *param) {
	nw4r::db::Exception_Printf_("[%d] %s,%p\n", GlobalTickCount, state->getName(), param);
	YoshiStateOrig(_this, state, param);
}
*/


void WriteAsciiToTextBox(nw4r::lyt::TextBox *tb, const char *source) {
	int i = 0;
	wchar_t buffer[1024];
	while (i < 1023 && source[i]) {
		buffer[i] = source[i];
		i++;
	}
	buffer[i] = 0;

	tb->SetString(buffer);
}


void getNewerLevelNumberString(int world, int level, wchar_t *dest) {
	static const wchar_t *numberKinds[] = {
		// 0-19 are handled by code
		// To insert a picturefont character:
		// \x0B\x01YY\xZZZZ
		// YY is the character code, ZZZZ is ignored
		L"A", // 20, alternate
		L"\x0B\x0148\xBEEF", // 21, tower
		L"\x0B\x0148\xBEEF" L"2", // 22, tower 2
		L"\x0B\x012E\xBEEF", // 23, castle
		L"\x0B\x012F\xBEEF", // 24, fortress
		L"\x0B\x013D\xBEEF", // 25, final castle
		L"\x0B\x014D\xBEEF", // 26, train
		L"\x0B\x0132\xBEEF", // 27, airship
		L"Palace", // 28, switch palace
		L"\x0B\x0147\xBEEF", // 29, yoshi's house
		L"\x0B\x014E\xBEEF" L"1", // 30, key 1
		L"\x0B\x014E\xBEEF" L"2", // 31, key 2
		L"\x0B\x014E\xBEEF" L"3", // 32, key 3
		L"\x0B\x014E\xBEEF" L"4", // 33, key 4
		L"\x0B\x014E\xBEEF" L"5", // 34, key 5
		L"\x0B\x014E\xBEEF" L"6", // 35, key 6
		L"\x0B\x0138\xBEEF", // 36, music house
		L"\x0B\x0133\xBEEF", // 37, shop
		L"\x0B\x0139\xBEEF", // 38, challenge house
		L"\x0B\x0151\xBEEF", // 39, red switch palace
		L"\x0B\x0152\xBEEF", // 40, blue switch palace
		L"\x0B\x0153\xBEEF", // 41, yellow switch palace
		L"\x0B\x0154\xBEEF", // 42, green switch palace
	};

	dest[0] = (world >= 10) ? (world-10+'A') : (world+'0');
	dest[1] = '-';
	if (level >= 20) {
		wcscpy(&dest[2], numberKinds[level-20]);
	} else if (level >= 10) {
		dest[2] = '1';
		dest[3] = ('0' - 10) + level;
		dest[4] = 0;
	} else {
		dest[2] = '0' + level;
		dest[3] = 0;
	}
}

int getStarCoinCount() {
	SaveBlock *save = GetSaveFile()->GetBlock(-1);
	int coinsEarned = 0;

	for (int w = 0; w < 10; w++) {
		for (int l = 0; l < 42; l++) {
			u32 conds = save->GetLevelCondition(w, l);

			if (conds & COND_COIN1) { coinsEarned++; }
			if (conds & COND_COIN2) { coinsEarned++; }
			if (conds & COND_COIN3) { coinsEarned++; }
		}
	}

	return coinsEarned;
}


struct GEIFS {
	int starCoins, exits;
};
extern "C" GEIFS *GrabExitInfoForFileSelect(GEIFS *out, SaveBlock *save) {
	out->starCoins = 0;
	out->exits = 0;

	for (int i = 0; i < dLevelInfo_c::s_info.sectionCount(); i++) {
		dLevelInfo_c::section_s *section = dLevelInfo_c::s_info.getSectionByIndex(i);

		for (int j = 0; j < section->levelCount; j++) {
			dLevelInfo_c::entry_s *l = &section->levels[j];
			if (l->flags & 2) {
				//OSReport("Checking %d-%d...\n", l->worldSlot+1, l->levelSlot+1);
				u32 cond = save->GetLevelCondition(l->worldSlot, l->levelSlot);
				if ((l->flags & 0x10) && (cond & COND_NORMAL))
					out->exits++;
				if ((l->flags & 0x20) && (cond & COND_SECRET))
					out->exits++;
				if (cond & COND_COIN1)
					out->starCoins++;
				if (cond & COND_COIN2)
					out->starCoins++;
				if (cond & COND_COIN3)
					out->starCoins++;
			}
		}
	}

	OSReport("Done, got %d coins and %d exits\n", out->starCoins, out->exits);

	return out;
}



//
// processed\../src/boss.cpp
//

#include "boss.h"
#include <profileid.h>



void DamagePlayer(dEn_c *actor, ActivePhysics *apThis, ActivePhysics *apOther) {

	actor->dEn_c::playerCollision(apThis, apOther);
	actor->_vf220(apOther->owner);

	// fix multiple player collisions via megazig
	actor->deathInfo.isDead = 0;
	actor->flags_4FC |= (1<<(31-7));
	if (apOther->owner->which_player == 255 ) {
		actor->counter_504[0] = 0;
		actor->counter_504[1] = 0;
		actor->counter_504[2] = 0;
		actor->counter_504[3] = 0;
	}
	else {
		actor->counter_504[apOther->owner->which_player] = 0;
	}
}


void SetupKameck(daBoss *actor, daKameckDemo *Kameck) {

	// Stop the BGM Music
	StopBGMMusic();

	// Set the necessary Flags and make Mario enter Demo Mode
	dStage32C_c::instance->freezeMarioBossFlag = 1;
	WLClass::instance->_4 = 4;
	WLClass::instance->_8 = 0;

	MakeMarioEnterDemoMode();

	// Make sure to use the correct position
	Vec pos = (Vec){actor->pos.x - 124.0, actor->pos.y + 104.0, 3564.0};
	S16Vec rot = (S16Vec){0, 0, 0};

	// Create And use Kameck
	actor->Kameck = (daKameckDemo*)actor->createChild(ProfileId::KAMECK_FOR_CASTLE_DEMO, (dStageActor_c*)actor, 0, &pos, &rot, 0);
	actor->Kameck->doStateChange(&daKameckDemo::StateID_DemoWait);

}


void CleanupKameck(daBoss *actor, daKameckDemo *Kameck) {
	// Clean up the flags and Kameck
	dStage32C_c::instance->freezeMarioBossFlag = 0;
	WLClass::instance->_8 = 1;

	MakeMarioExitDemoMode();
	StartBGMMusic();

	actor->Kameck->Delete(1);
}


bool GrowBoss(daBoss *actor, daKameckDemo *Kameck, float initialScale, float endScale, float yPosModifier, int timer) {
	if (timer == 130) { actor->Kameck->doStateChange(&daKameckDemo::StateID_DemoSt); }
	if (timer == 400) { actor->Kameck->doStateChange(&daKameckDemo::StateID_DemoSt2); }

	float scaleSpeed, yPosScaling;

	if (timer == 150) { PlaySound(actor, SE_BOSS_IGGY_WANWAN_TO_L);  }

	if ((timer > 150) && (timer < 230)) {
		scaleSpeed = (endScale -initialScale) / 80.0;

		float modifier;

		modifier = initialScale + ((timer - 150) * scaleSpeed);

		actor->scale = (Vec){modifier, modifier, modifier};
		actor->pos.y = actor->pos.y + (yPosModifier/80.0);
	}

	if (timer == 360) {
		Vec tempPos = (Vec){actor->pos.x - 40.0, actor->pos.y + 120.0, 3564.0};
		SpawnEffect("Wm_ob_greencoinkira", 0, &tempPos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		SpawnEffect("Wm_mr_yoshiicehit_a", 0, &tempPos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		SpawnEffect("Wm_mr_yoshiicehit_b", 0, &tempPos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		SpawnEffect("Wm_ob_redringget", 0, &tempPos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		SpawnEffect("Wm_ob_keyget01", 0, &tempPos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		SpawnEffect("Wm_ob_greencoinkira_a", 0, &tempPos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		SpawnEffect("Wm_ob_keyget01_c", 0, &tempPos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
	}

	if (timer > 420) { return true; }
	return false;
}


void OutroSetup(daBoss *actor) {
	actor->removeMyActivePhysics();

	StopBGMMusic();

	WLClass::instance->_4 = 5;
	WLClass::instance->_8 = 0;
	dStage32C_c::instance->freezeMarioBossFlag = 1;

	nw4r::snd::SoundHandle handle;
	PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_BOSS_CMN_DAMAGE_LAST, 1);
}


bool ShrinkBoss(daBoss *actor, Vec *pos, float scale, int timer) {
	// Adjust actor to equal the scale of your boss / 80.
	actor->scale.x -= scale / 80.0;
	actor->scale.y -= scale / 80.0;
	actor->scale.z -= scale / 80.0;

	// actor->pos.y += 2.0;

	if (timer == 30) {
		SpawnEffect("Wm_ob_starcoinget_gl", 0, pos, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
		SpawnEffect("Wm_mr_vshipattack_hosi", 0, pos, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
		SpawnEffect("Wm_ob_keyget01_b", 0, pos, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
	}

	if (actor->scale.x < 0) { return true; }
	else { return false; }
}


void BossExplode(daBoss *actor, Vec *pos) {
	actor->scale.x = 0.0;
	actor->scale.y = 0.0;
	actor->scale.z = 0.0;

	SpawnEffect("Wm_ob_keyget02", 0, pos, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
	actor->dying = 1;
	actor->timer = 0;

	nw4r::snd::SoundHandle handle;
	PlaySoundWithFunctionB4(SoundRelatedClass, &handle, STRM_BGM_SHIRO_BOSS_CLEAR, 1);

	//MakeMarioEnterDemoMode();
	BossGoalForAllPlayers();
}

void BossGoalForAllPlayers() {
	for (int i = 0; i < 4; i++) {
		daPlBase_c *player = GetPlayerOrYoshi(i);
		if (player)
			player->setAnimePlayStandardType(2);
	}
}


void PlayerVictoryCries(daBoss *actor) {
	UpdateGameMgr();
	/*nw4r::snd::SoundHandle handle1, handle2, handle3, handle4;

	dAcPy_c *players[4];
	for (int i = 0; i < 4; i++)
		players[i] = (dAcPy_c *)GetSpecificPlayerActor(i);

	if (players[0] && strcmp(players[0]->states2.getCurrentState()->getName(), "dAcPy_c::StateID_Balloon"))
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle1, SE_VOC_MA_CLEAR_BOSS, 1);
	if (players[1] && strcmp(players[1]->states2.getCurrentState()->getName(), "dAcPy_c::StateID_Balloon"))
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle2, SE_VOC_LU_CLEAR_BOSS, 1);
	if (players[2] && strcmp(players[2]->states2.getCurrentState()->getName(), "dAcPy_c::StateID_Balloon"))
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle3, SE_VOC_KO_CLEAR_BOSS, 1);
	if (players[3] && strcmp(players[3]->states2.getCurrentState()->getName(), "dAcPy_c::StateID_Balloon"))
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle4, SE_VOC_KO2_CLEAR_BOSS, 1);*/
}

//
// processed\../src/levelnames.cpp
//

// Alright, so you might be wondering what this is...
// This is essentially the early pregame you see in early newer videos, just remade to work with modern levelinfo
// You'll need to make the layout yourself though... it's pretty simple, just add a TXT_WorldName and TXT_LevelName textbox in your pregame layout.
#include <common.h>
#include <game.h>
#include <profileid.h>
#include <stage.h>
#include "levelinfo.h"

extern char CurrentLevel;
extern char CurrentWorld;

int DoNames(int state) {
	int wnum = (int)CurrentWorld;
	int lnum = (int)CurrentLevel;
	const char *levelname;
	const char *worldname;
	nw4r::lyt::TextBox
		*worldObj, *levelObj;
	// Skip the title screen
	// and only process the code if the State is set to 1
	// (the screen has been initialised)
	if (state == 1 && lnum != STAGE_TITLE) { // NOTE: Will not work with Newer's multiple titlescreens.
		// grab the CRSIN object
		fBase_c *ptr = fBase_c::searchByProfileId(ProfileId::CRSIN, 0);

		// FIX !!!!!

		if (ptr != 0) {
			m2d::EmbedLayout_c *layout = (m2d::EmbedLayout_c*)((u32)ptr+0xB0);
			worldObj = layout->findTextBoxByName("TXT_WorldName");
			levelObj = layout->findTextBoxByName("TXT_LevelName");
			if (worldObj == 0 || levelObj == 0) return state;

			dLevelInfo_c::entry_s *level = dLevelInfo_c::s_info.searchBySlot(CurrentWorld, CurrentLevel);
			dLevelInfo_c::entry_s *world = dLevelInfo_c::s_info.searchByDisplayNum(CurrentWorld+1, 100);
			if (level) {
				levelname = dLevelInfo_c::s_info.getNameForLevel(level);
			} else {
				char levelNumber[15];
				sprintf(levelNumber, "%d-%d (UNNAMED)", wnum+1, lnum+1);
				levelname = levelNumber;
			}
			if (world) {
				worldname = dLevelInfo_c::s_info.getNameForLevel(world);
			} else {
				char worldNumber[8];
				sprintf(worldNumber, "World %d (UNNAMED)", wnum+1);
				worldname = worldNumber;
			}

			wchar_t wbuffer[0x40], lbuffer[0x40];
			for (int i = 0; i < 0x40; i++) {
				wbuffer[i] = (unsigned short)worldname[i];
				lbuffer[i] = (unsigned short)levelname[i];
			}

			worldObj->SetString(wbuffer);
			levelObj->SetString(lbuffer);
		}
	} else {
	}

	return state;
}
//
// processed\../src/pregame.cpp
//

#include <game.h>
#include "levelinfo.h"
#include <newer.h>

class PregameLytHandler {
	public:
		m2d::EmbedLayout_c layout;

		nw4r::lyt::Pane *rootPane;

		nw4r::lyt::TextBox
			*T_minus_00, *T_world_00, *T_worldNum_00,
			*T_pictureFont_00, *T_corseNum_00,
			*T_remainder_00, *T_remainder_01, *T_remainder_02, *T_remainder_03,
			*T_remainder_10, *T_remainder_11, *T_remainder_12, *T_remainder_13,
			*T_x_00, *T_x_01, *T_x_02, *T_x_03, *T_x_10, *T_x_11, *T_x_12, *T_x_13,
			*T_x_00_o, *T_x_10_o,
			*T_otasukePlay_00, *T_otasukePlay_01,
			*T_recommend_00, *T_remainder_00_o, *T_remainder_10_o;

		nw4r::lyt::Picture
			*P_Wx_00[9], *P_coin_00, *P_free_00,
			*P_batB_0x[4], *P_bat_00,
			*P_batB_1x[4], *P_bat_01,
			*P_batB_2x[4], *P_bat_02,
			*P_batB_3x[4], *P_bat_03,
			*P_luijiIcon_00_o, *P_luijiIcon_10_o, *P_coinStage_00;

		nw4r::lyt::Pane
			*N_mario_00, *N_luiji_00, *N_kinoB_01, *N_kinoY_00,
			*N_zankiPos_x[4], *N_zanki_00,
			*Null_battPosxP[4], *N_batt_x[4],
			*N_batt, *N_otasukePlay_00;

		u8 layoutLoaded, somethingHasBeenDone, isVisible, hasShownLuigiThing_orSomething;

		u32 currentStateID;

		u32 _2E8;

		u32 countdownToEndabilityCopy, activePlayerCountMultBy4_maybe;
		u32 batteryLevels[4];
		u32 pgCountdown;

		void hijack_loadLevelNumber(); // replaces 80B6BDD0
};

// Notes:
// Deleted; P_coinStage_00, T_recommend_00, T_worldNum_00,
// T_-_00, T_pictureFont_00, T_corseNum_00, T_world_00
// P_Wx_00, P_coin_00, P_free_00

extern char CurrentLevel;
extern char CurrentWorld;

void LoadPregameStyleNameAndNumber(m2d::EmbedLayout_c *layout) {
	nw4r::lyt::TextBox
		*LevelNumShadow, *LevelNum,
		*LevelNameShadow, *LevelName;

	LevelNumShadow = layout->findTextBoxByName("LevelNumShadow");
	LevelNum = layout->findTextBoxByName("LevelNum");
	LevelNameShadow = layout->findTextBoxByName("LevelNameShadow");
	LevelName = layout->findTextBoxByName("LevelName");

	// work out the thing now
	dLevelInfo_c::entry_s *level = dLevelInfo_c::s_info.searchBySlot(CurrentWorld, CurrentLevel);
	if (level) {
		wchar_t convLevelName[160];
		const char *srcLevelName = dLevelInfo_c::s_info.getNameForLevel(level);
		int i = 0;
		while (i < 159 && srcLevelName[i]) {
			convLevelName[i] = srcLevelName[i];
			i++;
		}
		convLevelName[i] = 0;
		LevelNameShadow->SetString(convLevelName);
		LevelName->SetString(convLevelName);

		wchar_t levelNumber[32];
		wcscpy(levelNumber, L"World ");
		getNewerLevelNumberString(level->displayWorld, level->displayLevel, &levelNumber[6]);

		LevelNum->SetString(levelNumber);

		// make the picture shadowy
		int sidx = 0;
		while (levelNumber[sidx]) {
			if (levelNumber[sidx] == 11) {
				levelNumber[sidx+1] = 0x200 | (levelNumber[sidx+1]&0xFF);
				sidx += 2;
			}
			sidx++;
		}
		LevelNumShadow->SetString(levelNumber);

	} else {
		LevelNameShadow->SetString(L"Not found in LevelInfo!");
		LevelName->SetString(L"Not found in LevelInfo!");
	}
}

#include "fileload.h"
void PregameLytHandler::hijack_loadLevelNumber() {
	LoadPregameStyleNameAndNumber(&layout);

	nw4r::lyt::Picture *LevelSample;
	LevelSample = layout.findPictureByName("LevelSample");

	// this is not the greatest way to read a file but I suppose it works in a pinch
	char tplName[64];
	sprintf(tplName, "/LevelSamples/%02d-%02d.tpl", CurrentWorld+1, CurrentLevel+1);
	static File tpl;
	if (tpl.open(tplName)) {
		LevelSample->material->texMaps[0].ReplaceImage((TPLPalette*)tpl.ptr(), 0);
	}
}





//
// processed\../src/layouthax.cpp
//

#include <game.h>
#include <levelinfo.h>
#include <newer.h>

extern char CurrentLevel;
extern char CurrentWorld;

void LoadPauseMenuNameAndNumber(m2d::EmbedLayout_c *layout) {
	nw4r::lyt::TextBox
		*LevelNumShadow, *LevelNum,
		*LevelNameShadow, *LevelName;

	LevelNumShadow = layout->findTextBoxByName("LevelNumShadow");
	LevelNum = layout->findTextBoxByName("LevelNum");
	LevelNameShadow = layout->findTextBoxByName("LevelNameShadow");
	LevelName = layout->findTextBoxByName("LevelName");

	// work out the thing now
	dLevelInfo_c::entry_s *level = dLevelInfo_c::s_info.searchBySlot(CurrentWorld, CurrentLevel);
	if (level) {
		wchar_t convLevelName[160];
		const char *srcLevelName = dLevelInfo_c::s_info.getNameForLevel(level);
		int i = 0;
		while (i < 159 && srcLevelName[i]) {
			convLevelName[i] = srcLevelName[i];
			i++;
		}
		convLevelName[i] = 0;
		LevelNameShadow->SetString(convLevelName);
		LevelName->SetString(convLevelName);

		wchar_t levelNumber[32];
		wcscpy(levelNumber, L"World ");
		getNewerLevelNumberString(level->displayWorld, level->displayLevel, &levelNumber[6]);

		LevelNum->SetString(levelNumber);

		// make the picture shadowy
		int sidx = 0;
		while (levelNumber[sidx]) {
			if (levelNumber[sidx] == 11) {
				levelNumber[sidx+1] = 0x200 | (levelNumber[sidx+1]&0xFF);
				sidx += 2;
			}
			sidx++;
		}
		LevelNumShadow->SetString(levelNumber);

	} else {
		LevelNameShadow->SetString(L"Not found in LevelInfo!");
		LevelName->SetString(L"Not found in LevelInfo!");
	}
}

extern "C" void InsertPauseWindowText(void *thing) {
	m2d::EmbedLayout_c *el = (m2d::EmbedLayout_c*)(((u8*)thing)+0x70);
	LoadPauseMenuNameAndNumber(el);
}


//
// processed\../src/animtiles.cpp
//

#include <common.h>
#include <game.h>
#include "fileload.h"

struct AnimDef_Header {
	u32 magic;
	u32 entryCount;
};

struct AnimDef_Entry {
	u16 texNameOffset;
	u16 frameDelayOffset;
	u16 tileNum;
	u8 tilesetNum;
	u8 reverse;
};

FileHandle fh;

void DoTiles(void* self) {
	AnimDef_Header *header;
	
	header = (AnimDef_Header*)LoadFile(&fh, "/AnimTiles.bin");
	
	if (!header) {
		OSReport("anim load fail\n");
		return;
	}
	
	if (header->magic != 'NWRa') {
		OSReport("anim info incorrect\n");
		FreeFile(&fh);
		return;
	}
	
	AnimDef_Entry *entries = (AnimDef_Entry*)(header+1);
	
	for (int i = 0; i < header->entryCount; i++) {
		AnimDef_Entry *entry = &entries[i];
		char *name = (char*)fh.filePtr+entry->texNameOffset;
		char *frameDelays = (char*)fh.filePtr+entry->frameDelayOffset;
		
		char realName[0x40];
		snprintf(realName, 0x40, "BG_tex/%s", name);
		
		void *blah = BgTexMng__LoadAnimTile(self, entry->tilesetNum, entry->tileNum, realName, frameDelays, entry->reverse);
	}
}


void DestroyTiles(void *self) {
	FreeFile(&fh);
}


extern "C" void CopyAnimTile(u8 *target, int tileNum, u8 *source, int frameNum) {
	int tileRow = tileNum >> 5; // divided by 32
	int tileColumn = tileNum & 31; // modulus by 32

	u8 *baseRow = target + (tileRow * 2 * 32 * 1024);
	u8 *baseTile = baseRow + (tileColumn * 32 * 4 * 2);

	u8 *sourceRow = source + (frameNum * 2 * 32 * 32);

	for (int i = 0; i < 8; i++) {
		memcpy(baseTile, sourceRow, 32*4*2);
		baseTile += (2 * 4 * 1024);
		sourceRow += (2 * 32 * 4);
	}
}

//
// processed\../src/fileload.cpp
//

#include "fileload.h"

extern "C" void UncompressBackward(void *bottom);


void *LoadFile(FileHandle *handle, const char *name) {

	int entryNum = DVDConvertPathToEntrynum(name);

	DVDHandle dvdhandle;
	if (!DVDFastOpen(entryNum, &dvdhandle)) {
		return 0;
	}

	handle->length = dvdhandle.length;
	handle->filePtr = EGG__Heap__alloc((handle->length+0x1F) & ~0x1F, 0x20, GetArchiveHeap());

	int ret = DVDReadPrio(&dvdhandle, handle->filePtr, (handle->length+0x1F) & ~0x1F, 0, 2);

	DVDClose(&dvdhandle);


	return handle->filePtr;
}

bool FreeFile(FileHandle *handle) {
	if (!handle) return false;

	if (handle->filePtr) {
		EGG__Heap__free(handle->filePtr, GetArchiveHeap());
	}

	handle->filePtr = 0;
	handle->length = 0;

	return true;
}




File::File() {
	m_loaded = false;
}

File::~File() {
	close();
}

bool File::open(const char *filename) {
	if (m_loaded)
		close();

	void *ret = LoadFile(&m_handle, filename);
	if (ret != 0)
		m_loaded = true;

	return (ret != 0);
}

/*bool File::openCompressed(const char *filename) {
	if (m_loaded)
		close();

	void *ret = LoadCompressedFile(&m_handle, filename);
	if (ret != 0)
		m_loaded = true;

	return (ret != 0);
}*/

void File::close() {
	if (!m_loaded)
		return;

	m_loaded = false;
	FreeFile(&m_handle);
}

bool File::isOpen() {
	return m_loaded;
}

void *File::ptr() {
	if (m_loaded)
		return m_handle.filePtr;
	else
		return 0;
}

u32 File::length() {
	if (m_loaded)
		return m_handle.length;
	else
		return 0xFFFFFFFF;
}


//
// processed\../src/levelspecial.cpp
//

#include <common.h>
#include <game.h>
#include <dCourse.h>
#include <profile.h>

class LevelSpecial : public dStageActor_c {
public:
	u64 eventFlag;
	u8 type;
	u8 effect;
	u8 lastEvState;
	u8 func;
	u32 keepTime;
	u32 setTime;

	int onCreate();
	int onExecute();

	static dActor_c* build();

};

extern u16 TimeStopFlag;
extern u32 AlwaysDrawFlag;
extern u32 AlwaysDrawBranch;

extern float MarioDescentRate;
extern float MarioJumpMax;
extern float MarioJumpArc;
extern float MiniMarioJumpArc;
// extern float MarioSize;

extern float GlobalSpriteSize;
extern float GlobalSpriteSpeed;
extern float GlobalRiderSize;
extern char SizerOn;
extern char ZOrderOn;
extern int GlobalStarsCollected;

extern VEC2 BGScaleFront;
extern VEC2 BGScaleBack;
extern char BGScaleEnabled;

extern u32 GameTimer;

#define time *(u32*)((GameTimer) + 0x4)


static const float GlobalSizeFloatModifications [] = {1, 0.25, 0.5, 0.75, 1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5, 6, 7, 8, 10 };
static const float GlobalRiderFloatModifications [] = {1, 0.6, 0.7, 0.9, 1, 1, 1, 1.1, 1.25, 1.5, 2, 2.5, 3, 3.5, 4, 5};
static const float BGScaleChoices[] = {0.1f, 0.15f, 0.25f, 0.375f, 0.5f, 0.625f, 0.75f, 0.9f, 1.0f, 1.125f, 1.25f, 1.5f, 1.75f, 2.0f, 2.25f, 2.5f};

bool NoMichaelBuble = false;

bool ResetAfterLevel();

#define ACTIVATE	1
#define DEACTIVATE	0

extern "C" void dAcPy_vf294(void *Mario, dStateBase_c *state, u32 unk);
void MarioStateChanger(void *Mario, dStateBase_c *state, u32 unk) {
	//OSReport("State: %p, %s", state, state->getName());

	if ((strcmp(state->getName(), "dAcPy_c::StateID_Balloon") == 0) && (NoMichaelBuble)) { return; }

	dAcPy_vf294(Mario, state, unk);
}

bool ResetAfterLevel(bool didItWork) {
	// TimeStopFlag = 0;
	MarioDescentRate = -4;
	MarioJumpMax = 3.628;
	MarioJumpArc = 2.5;
	MiniMarioJumpArc = 2.5;
	// MarioSize = 1.0;
	GlobalSpriteSize = 1.0;
	GlobalSpriteSpeed = 1.0;
	GlobalRiderSize = 1.0;
	SizerOn = 0;
	AlwaysDrawFlag = 0x9421FFF0;
	AlwaysDrawBranch = 0x7C0802A6;
	ZOrderOn = 0;
	GlobalStarsCollected = 0;
	NoMichaelBuble = false;
	BGScaleEnabled = 0;
	return didItWork;
}

void FuckinBubbles() {
	dCourse_c *course = dCourseFull_c::instance->get(GetAreaNum());
	bool thing = false;

	int zone = GetZoneNum();
	for (int i = 0; i < course->zoneSpriteCount[zone]; i++) {
		dCourse_c::sprite_s *spr = &course->zoneFirstSprite[zone][i];
		if (spr->type == 246 && (spr->settings & 0xF) == 8)
			thing = true;
	}

	if (thing) {
		OSReport("DISABLING EXISTING BUBBLES.\n");
		for (int i = 0; i < 4; i++)
			Player_Flags[i] &= ~4;
	}
}

dActor_c* LevelSpecial::build() {
	void *buffer = AllocFromGameHeap1(sizeof(LevelSpecial));
	return new(buffer) LevelSpecial;
}

const SpriteData LevelSpecialSpriteData = { ProfileId::AC_SPECIAL_EVENT, 0, 0, 0, 0, 0x8, 0x8, 0, 0, 0, 0, 2 };
Profile LevelSpecialProfile(&LevelSpecial::build, SpriteId::AC_SPECIAL_EVENT, &LevelSpecialSpriteData, ProfileId::TAG_THUNDER, ProfileId::AC_SPECIAL_EVENT, "AC_SPECIAL_EVENT");


int LevelSpecial::onCreate() {
    char eventNum	= (this->settings >> 24)	& 0xFF;
	this->eventFlag = (u64)1 << (eventNum - 1);
	
	this->keepTime  = 0;
	
	this->type		= (this->settings)			& 15;
	this->effect	= (this->settings >> 4)		& 15;
	this->setTime	= (this->settings >> 8)     & 0xFFFF;

	this->lastEvState = 0xFF;

	this->onExecute();

	return true;
}

int LevelSpecial::onExecute() {
	if (this->keepTime > 0) {
		time = this->keepTime; }
    
	u8 newEvState = 0;
	if (dFlagMgr_c::instance->flags & this->eventFlag)
		newEvState = 1;
	
	if (newEvState == this->lastEvState)
		return true;
		
	
	u8 offState;
	if (newEvState == ACTIVATE)
	{
		offState = (newEvState == 1) ? 1 : 0;

		switch (this->type) {
			// case 1:											// Time Freeze
			// 	TimeStopFlag = this->effect * 0x100;
			// 	break;
				
			case 2:											// Stop Timer
				this->keepTime  = time;
				break;
		
	
			case 3:											// Mario Gravity
				if (this->effect == 0)
				{											//Low grav
					MarioDescentRate = -2;
					MarioJumpArc = 0.5;
					MiniMarioJumpArc = 0.5;
					MarioJumpMax = 4.5;
				}
				else
				{											//Anti-grav
					MarioDescentRate = 0.5;
					MarioJumpArc = 4.0;
					MiniMarioJumpArc = 4.0;
					MarioJumpMax = 0.0;
				}
				break;
	
			case 4:											// Set Time
				time = (this->setTime << 0xC) - 1; // Possibly - 0xFFF?
				break;


			case 5:											// Global Enemy Size
				SizerOn = 3;

				GlobalSpriteSize = GlobalSizeFloatModifications[this->effect];
				GlobalRiderSize = GlobalRiderFloatModifications[this->effect];
				GlobalSpriteSpeed = GlobalRiderFloatModifications[this->effect];

				AlwaysDrawFlag = 0x38600001;
				AlwaysDrawBranch = 0x4E800020;
				break;
	
			case 6:											// Individual Enemy Size
				AlwaysDrawFlag = 0x38600001;
				AlwaysDrawBranch = 0x4E800020;

				if (this->effect == 0)
				{	
					SizerOn = 1;							// Nyb 5
				}
				else
				{											
					SizerOn = 2;							// Nyb 7
				}
				break;
		
			case 7:											// Z Order Hack
				ZOrderOn = 1;
				break;

			case 8:
				NoMichaelBuble = true;
				break;

			case 9:
				BGScaleEnabled = true;
				BGScaleFront.x = BGScaleChoices[(this->settings >> 20) & 15];
				BGScaleFront.y = BGScaleChoices[(this->settings >> 16) & 15];
				BGScaleBack.x = BGScaleChoices[(this->settings >> 12) & 15];
				BGScaleBack.y = BGScaleChoices[(this->settings >> 8) & 15];
				break;

			default:
				break;
		}
	}
	
	else
	{
		offState = (newEvState == 1) ? 0 : 1;

		switch (this->type) {
			// case 1:											// Time Freeze
			// 	TimeStopFlag = 0;
			// 	break;
				
			case 2:											// Stop Timer
				this->keepTime  = 0;
				break;
		
	
			case 3:											// Mario Gravity
				MarioDescentRate = -4;
				MarioJumpArc = 2.5;
				MiniMarioJumpArc = 2.5;
				MarioJumpMax = 3.628;
				break;
	
			case 4:											// Mario Size
				break;
		
			case 5:											// Global Enemy Size
				SizerOn = 0;

				GlobalSpriteSize = 1.0;
				GlobalRiderSize = 1.0;
				GlobalSpriteSpeed = 1.0;

				AlwaysDrawFlag = 0x9421FFF0;
				AlwaysDrawBranch = 0x7C0802A6;
				break;

			case 6:											// Individual Enemy Size
				SizerOn = 0;

				AlwaysDrawFlag = 0x9421FFF0;
				AlwaysDrawBranch = 0x7C0802A6;
				break;
		
			case 7:											// Z Order Hack
				ZOrderOn = 0;
				break;
				
			case 8:
				NoMichaelBuble = false;
				break;

			case 9:
				BGScaleEnabled = false;
				break;
	
			default:
				break;
		}
	}



	
	
	this->lastEvState = newEvState;
	return true;
}
//
// processed\../src/mrsun.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <profile.h>

#include "boss.h"

const char* MSarcNameList [] = {
	"mrsun",
	NULL
};

class daMrSun_c : public dEn_c {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;
	m3d::mdl_c glowModel;

	bool hasGlow;

	float Baseline;
	float SwoopSlope;
	float SpiralLoop;
	float yThreshold;
	float yAccel;
	Vec	swoopTarget;
	u32 timer;
	float xSpiralOffset;
	float ySpiralOffset;
	float swoopA;
	float swoopB;
	float swoopC;
	float swoopSpeed;
	float glowPos;
	short spinReduceZ;
	short spinReduceY;
	float spinStateOn;
	int dying;
	char sunDying;
	char killFlag;

	u64 eventFlag;


	void dieFall_Execute();
	public: static dActor_c *build();

	void updateModelMatrices();

	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat5_Mario(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);

	USING_STATES(daMrSun_c);
	DECLARE_STATE(Follow);
	DECLARE_STATE(Swoop);
	DECLARE_STATE(Spiral);
	DECLARE_STATE(Spit);
	DECLARE_STATE(Spin);
	DECLARE_STATE(Wait);
};

const SpriteData MrSunSpriteData = {ProfileId::EN_ANGRYSUN, 0, 0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile MrSunProfile(&daMrSun_c::build, SpriteId::EN_ANGRYSUN, &MrSunSpriteData, ProfileId::EN_WALLINSECT, ProfileId::EN_ANGRYSUN, "EN_ANGRYSUN", MSarcNameList, 0x12);

dActor_c *daMrSun_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daMrSun_c));
	return new(buffer) daMrSun_c;
}


CREATE_STATE(daMrSun_c, Follow);
CREATE_STATE(daMrSun_c, Swoop);
CREATE_STATE(daMrSun_c, Spiral);
CREATE_STATE(daMrSun_c, Spit);
CREATE_STATE(daMrSun_c, Spin);
CREATE_STATE(daMrSun_c, Wait);

#define ACTIVATE	1
#define DEACTIVATE	0




void daMrSun_c::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {  DamagePlayer(this, apThis, apOther); }

bool daMrSun_c::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true;
}
bool daMrSun_c::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) {

	if (this->settings == 1) {  // It's a moon
		if (apOther->owner->profileId == ProfileId::BROS_ICEBALL) {
			return true;
			}
	}
	return false;
}
bool daMrSun_c::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
	this->timer = 0;
	PlaySound(this, SE_EMY_DOWN);
	doStateChange(&StateID_DieFall);
	return true;
}
bool daMrSun_c::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
	this->timer = 0;
	PlaySound(this, SE_EMY_DOWN);
	doStateChange(&StateID_DieFall);
	return true;
}
bool daMrSun_c::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther) {
	this->timer = 0;
	PlaySound(this, SE_EMY_DOWN);
	doStateChange(&StateID_DieFall);
	return true;
}
bool daMrSun_c::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
	return true;
}
bool daMrSun_c::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
	return true;
}
bool daMrSun_c::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
	return true;
}
bool daMrSun_c::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
	return true;
}
bool daMrSun_c::collisionCat5_Mario(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
	return true;
}


void daMrSun_c::dieFall_Execute() {

	if (this->killFlag == 1) { return; }

	this->timer = this->timer + 1;

	this->dying = this->dying + 0.15;

	this->pos.x = this->pos.x + 0.15;
	this->pos.y = this->pos.y - ((-0.2 * (this->dying*this->dying)) + 5);

	this->dEn_c::dieFall_Execute();

	if (this->timer > 450) {

		if ((this->settings >> 28) > 0) {
			this->kill();
			this->pos.y = this->pos.y + 800.0;
			this->killFlag = 1;
			return;
		}

		dStageActor_c *Player = GetSpecificPlayerActor(0);
		if (Player == 0) { Player = GetSpecificPlayerActor(1); }
		if (Player == 0) { Player = GetSpecificPlayerActor(2); }
		if (Player == 0) { Player = GetSpecificPlayerActor(3); }


		if (Player == 0) {
			this->pos.x = 0;
			doStateChange(&StateID_Follow); }
		else {
			Player->pos;
			this->pos.x = Player->pos.x - 300;
		}

		this->pos.y = this->Baseline;

		this->aPhysics.addToList();
		doStateChange(&StateID_Follow);
	}
}


int daMrSun_c::onCreate() {
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	if ((this->settings & 0xF) == 0) { // It's a sun
		hasGlow = true;

		nw4r::g3d::ResFile rf(getResource("mrsun", "g3d/sun.brres"));
		bodyModel.setup(rf.GetResMdl("Sun"), &allocator, 0x224, 1, 0);
		SetupTextures_Enemy(&bodyModel, 0);

		glowModel.setup(rf.GetResMdl("SunGlow"), &allocator, 0x224, 1, 0);
		SetupTextures_Enemy(&glowModel, 0);
	}

	else { // It's a moon
		hasGlow = false;

		nw4r::g3d::ResFile rf(getResource("mrsun", "g3d/moon.brres"));
		bodyModel.setup(rf.GetResMdl("Moon"), &allocator, 0x224, 1, 0);
		SetupTextures_Enemy(&bodyModel, 0);
	}

	allocator.unlink();

	this->scale = (Vec){0.5, 0.5, 0.5};


	ActivePhysics::Info HitMeBaby;
	HitMeBaby.xDistToCenter = 0.0;
	HitMeBaby.yDistToCenter = 0.0;
	HitMeBaby.category1 = 0x3;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x6F;

	if ((this->settings & 0xF) == 0) { // It's a sun
		HitMeBaby.bitfield2 = 0xffbafffc;
		HitMeBaby.xDistToEdge = 24.0;
		HitMeBaby.yDistToEdge = 24.0;
	}
	else { // It's a moon
		HitMeBaby.bitfield2 = 0xffbafffe;
		HitMeBaby.xDistToEdge = 12.0;
		HitMeBaby.yDistToEdge = 12.0;
	}

	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &dEn_c::collisionCallback;


	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();

	this->Baseline = this->pos.y;
	this->SwoopSlope = 0.0;
	this->SpiralLoop = 0;
	this->yThreshold = 15.0;
	this->yAccel = 0.2;
	this->timer = 0;
	this->xSpiralOffset = 0.0;
	this->ySpiralOffset = 0.0;
	this->dying = -5;
	this->sunDying = 0;
	this->killFlag = 0;

	if (this->settings == 1)
		this->pos.z = 6000.0f; // moon
	else
		this->pos.z = 5750.0f; // sun


	char eventNum	= (this->settings >> 16) & 0xFF;

	this->eventFlag = (u64)1 << (eventNum - 1);



	doStateChange(&StateID_Follow);

	// this->onExecute();
	return true;
}

int daMrSun_c::onDelete() {
	return true;
}

int daMrSun_c::onExecute() {
	acState.execute();
	updateModelMatrices();

	if (dFlagMgr_c::instance->flags & this->eventFlag) {
		if (this->killFlag == 0 && acState.getCurrentState()->isNotEqual(&StateID_DieFall)) {
			this->kill();
			this->pos.y = this->pos.y + 800.0;
			this->killFlag = 1;
			doStateChange(&StateID_DieFall);
		}
	}

	return true;
}

int daMrSun_c::onDraw() {
	bodyModel.scheduleForDrawing();
	if (hasGlow)
		glowModel.scheduleForDrawing();

	return true;
}


void daMrSun_c::updateModelMatrices() {
	// This won't work with wrap because I'm lazy.
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);

	if (hasGlow) {
		mMtx glowMatrix;
		short rotY;

		glowPos += 0.01666666666666;
		if (glowPos > 1) { glowPos = 0; }

		rotY = (1000 * sin(glowPos * 3.14)) + 500;


		glowMatrix.translation(pos.x, pos.y, pos.z);
		glowMatrix.applyRotationX(&rot.x);
		glowMatrix.applyRotationY(&rotY);

		glowModel.setDrawMatrix(glowMatrix);
		glowModel.setScale(&scale);
		glowModel.calcWorld(false);
	}
}


// Follow State

void daMrSun_c::beginState_Follow() {
	this->timer = 0;
	this->rot.x = 18000;
	this->rot.y = 0;
	this->rot.z = 0;
}
void daMrSun_c::executeState_Follow() {

	if (this->timer > 200) { this->doStateChange(&StateID_Wait); }

	this->direction = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);

	float speedDelta;
	if ((this->settings & 0xF) == 0) { speedDelta = 0.1; } // It's a sun
	else { speedDelta = 0.15; } // It's a moon


	if (this->direction == 0) {
		this->speed.x = this->speed.x + speedDelta;

		if (this->speed.x < 0) { this->speed.x = this->speed.x + (speedDelta / 2); }
		if (this->speed.x < 6.0) { this->speed.x = this->speed.x + (speedDelta); }
	}
	else {
		this->speed.x = this->speed.x - speedDelta;

		if (this->speed.x > 0) { this->speed.x = this->speed.x - (speedDelta / 2); }
		if (this->speed.x > 6.0) { this->speed.x = this->speed.x - (speedDelta); }
	}

	this->HandleXSpeed();


	float yDiff;
	yDiff = (this->Baseline - this->pos.y) / 8;
	this->speed.y = yDiff;

	this->HandleYSpeed();

	this->UpdateObjectPosBasedOnSpeedValuesReal();

	this->timer = this->timer + 1;
}
void daMrSun_c::endState_Follow() {
	this->speed.y = 0;
}


// Swoop State

void daMrSun_c::beginState_Swoop() {

	// Not enough space to swoop, spit instead.
	if (this->swoopTarget.y < (this->pos.y - 50)) { doStateChange(&StateID_Spit); }
	if (((this->pos.x - 96) < this->swoopTarget.x) && (this->swoopTarget.x < (this->pos.x + 96))) { doStateChange(&StateID_Spit); }

	if ((this->settings & 0xF) == 0) {
		this->swoopTarget.y = this->swoopTarget.y - 16;
	} // It's a sun

	else {
		this->swoopTarget.y = this->swoopTarget.y - 4;
	} // It's a moon


	float x1, x2, x3, y1, y2, y3;

	x1 = this->pos.x - this->swoopTarget.x;
	x2 = 0;
	x3 = -x1;

	y1 = this->pos.y - this->swoopTarget.y;
	y2 = 0;
	y3 = y1;

	float denominator = (x1 - x2) * (x1 - x3) * (x2 - x3);
	this->swoopA      = (x3 * (y2 - y1) + x2 * (y1 - y3) + x1 * (y3 - y2)) / denominator;
	this->swoopB      = (x3*x3 * (y1 - y2) + x2*x2 * (y3 - y1) + x1*x1 * (y2 - y3)) / denominator;
	this->swoopC      = (x2 * x3 * (x2 - x3) * y1 + x3 * x1 * (x3 - x1) * y2 + x1 * x2 * (x1 - x2) * y3) / denominator;

	this->swoopSpeed = x3 * 2 / 75;


	PlaySound(this, 284);

}
void daMrSun_c::executeState_Swoop() {

	// Everything is calculated up top, just need to modify it.

	this->pos.x = this->pos.x + this->swoopSpeed;

	this->pos.y = ( this->swoopA*(this->pos.x - this->swoopTarget.x)*(this->pos.x - this->swoopTarget.x) + this->swoopB*(this->pos.x - this->swoopTarget.x) + this->swoopC ) + this->swoopTarget.y;

	if (this->pos.y > this->Baseline) { doStateChange(&StateID_Follow); }

}
void daMrSun_c::endState_Swoop() {
	this->speed.y = 0;
}



// Spiral State

void daMrSun_c::beginState_Spiral() {

	this->SpiralLoop = 0;
	this->xSpiralOffset = this->pos.x;
	this->ySpiralOffset = this->pos.y;

	PlaySound(this, 284);
}
void daMrSun_c::executeState_Spiral() {

	float Loops;
	float Magnitude;
	float Period;

	Loops = 6.0;
	Magnitude = 11.0;

	// Use a period of 0.1 for the moon
	if ((this->settings & 0xF) == 0) { Period = 0.1; } // It's a sun
	else { Period = 0.125; } // It's a moon

	this->pos.x = this->xSpiralOffset + Magnitude*((this->SpiralLoop * cos(this->SpiralLoop)));
	this->pos.y = this->ySpiralOffset + Magnitude*((this->SpiralLoop * sin(this->SpiralLoop)));

	this->SpiralLoop = this->SpiralLoop + Period;

	if (this->SpiralLoop > (3.14 * Loops)) { doStateChange(&StateID_Follow); }

}
void daMrSun_c::endState_Spiral() { }



// Spit State

void daMrSun_c::beginState_Spit() {

	this->timer = 0;
	this->spinStateOn = 1;

}
void daMrSun_c::executeState_Spit() {

	if (this->timer == 10) {

		PlaySound(this, 431);

		this->direction = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);

		float neg = -1.0;
		if (this->direction == 0) { neg = 1.0; }


		if ((this->settings & 0xF) == 0) {
			dStageActor_c *spawner = CreateActor(ProfileId::PAKKUN_FIREBALL, 0, this->pos, 0, 0);
			spawner->speed.x = 6.0 * neg;
			spawner->speed.y = -2.5;
			spawner->pos.z = 5550.0;

			spawner = CreateActor(ProfileId::PAKKUN_FIREBALL, 0, this->pos, 0, 0);
			spawner->speed.x = 0.0 * neg;
			spawner->speed.y = -6.0;
			spawner->pos.z = 5550.0;

			spawner = CreateActor(ProfileId::PAKKUN_FIREBALL, 0, this->pos, 0, 0);
			spawner->speed.x = 3.5 * neg;
			spawner->speed.y = -6.0;
			spawner->pos.z = 5550.0;
		} // It's a sun


		else {
			dStageActor_c *spawner = CreateActor(ProfileId::BROS_ICEBALL, 0, this->pos, 0, 0);
			spawner->speed.x = 6.0 * neg;
			spawner->speed.y = -2.5;
			spawner->pos.z = 5550.0;
			*((u32 *) (((char *) spawner) + 0x3DC)) = this->id;

			spawner = CreateActor(ProfileId::BROS_ICEBALL, 0, this->pos, 0, 0);
			spawner->speed.x = 0.0 * neg;
			spawner->speed.y = -6.0;
			spawner->pos.z = 5550.0;
			*((u32 *) (((char *) spawner) + 0x3DC)) = this->id;

			spawner = CreateActor(ProfileId::BROS_ICEBALL, 0, this->pos, 0, 0);
			spawner->speed.x = 3.5 * neg;
			spawner->speed.y = -6.0;
			spawner->pos.z = 5550.0;
			*((u32 *) (((char *) spawner) + 0x3DC)) = this->id;
		} // It's a moon

	}

	this->timer = this->timer + 1;

	if (this->timer > 30) { doStateChange(&StateID_Follow); }

}
void daMrSun_c::endState_Spit() {
	this->spinStateOn = 0;
}



// Spin State

void daMrSun_c::beginState_Spin() {
	this->spinReduceZ = 0;
	this->spinReduceY = 0;
}
void daMrSun_c::executeState_Spin() {

	PlaySound(this, 282);

	this->direction = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);

	if (this->direction == 0) {
		this->speed.x = this->speed.x + 0.2;

		if (this->speed.x < 0) { this->speed.x = this->speed.x + (0.2 / 2); }
		if (this->speed.x < 80.0) { this->speed.x = this->speed.x + (0.2 * 2); }
	}
	else {
		this->speed.x = this->speed.x - 0.2;

		if (this->speed.x > 0) { this->speed.x = this->speed.x - (0.2 / 2); }
		if (this->speed.x > 80.0) { this->speed.x = this->speed.x - (0.2 * 2); }
	}

	this->HandleXSpeed();
	this->UpdateObjectPosBasedOnSpeedValuesReal();

	this->timer = this->timer + 1;

	short rotBonus;
	if (this->timer < 60) { rotBonus = this->timer; }
	else { rotBonus = 120 - this->timer; }

	// 1-59 + 60-1 = 3542

//	if (this->timer > 100) {
//		if (this->spinReduceZ = 0) {
//			this->spinReduceZ = this->rot.z / 20; }
//		if (this->spinReduceY = 0) {
//			this->spinReduceY = this->rot.y / 20; }
//
//		this->rot.z = this->rot.z - this->spinReduceZ;
//		this->rot.y = this->rot.y - this->spinReduceY; }
//
//	else {
		this->rot.z = this->rot.z + (55.1 * rotBonus);
		this->rot.y = this->rot.y + (18.4 * rotBonus); //}


	float spitspeed;
	if ((this->settings & 0xF) == 0) { spitspeed = 3.0; } // It's a sun
	else { spitspeed = 4.0;  } // It's a moon

	int randomBall;
	randomBall = GenerateRandomNumber(8);
	if (randomBall == 1) {
		int direction;
		direction = GenerateRandomNumber(8);

		float xlaunch;
		float ylaunch;

		if (direction == 0) {
			xlaunch = spitspeed;
			ylaunch = 0.0; }
		else if (direction == 1) { // SE
			xlaunch = spitspeed;
			ylaunch = spitspeed; }
		else if (direction == 2) { // S
			xlaunch = 0.0;
			ylaunch = spitspeed; }
		else if (direction == 3) { // SW
			xlaunch = -spitspeed;
			ylaunch = spitspeed; }
		else if (direction == 4) {	// W
			xlaunch = -spitspeed;
			ylaunch = 0.0; }
		else if (direction == 5) {	// NW
			xlaunch = -spitspeed;
			ylaunch = -spitspeed; }
		else if (direction == 6) {	// N
			xlaunch = 0.0;
			ylaunch = -spitspeed; }
		else if (direction == 7) {	// NE
			xlaunch = spitspeed;
			ylaunch = -spitspeed; }

		PlaySound(this, 431);

		if ((this->settings & 0xF) == 0) {
			dStageActor_c *spawner = CreateActor(ProfileId::PAKKUN_FIREBALL, 0, this->pos, 0, 0);
			spawner->speed.x = xlaunch;
			spawner->speed.y = ylaunch;
			spawner->pos.z = 5550.0;
		} // It's a sun

		else {
			dStageActor_c *spawner = CreateActor(ProfileId::BROS_ICEBALL, 0, this->pos, 0, 0);
			spawner->speed.x = xlaunch;
			spawner->speed.y = ylaunch;
			spawner->pos.z = 5550.0;

			*((u32 *) (((char *) spawner) + 0x3DC)) = this->id;
		} // It's a moon
	}

	if (this->timer > 120) { this->doStateChange(&StateID_Follow); }

}
void daMrSun_c::endState_Spin() {

	this->rot.x = 18000;
	this->rot.y = 0;
	this->rot.z = 0;

	this->speed.x = 0;
}



// Wait State

void daMrSun_c::beginState_Wait() {


	this->timer = 0;
	this->speed.x = 0.0;

	dStageActor_c *Player = GetSpecificPlayerActor(0);
	if (Player == 0) { Player = GetSpecificPlayerActor(1); }
	if (Player == 0) { Player = GetSpecificPlayerActor(2); }
	if (Player == 0) { Player = GetSpecificPlayerActor(3); }
	if (Player == 0) { doStateChange(&StateID_Follow); }

	this->swoopTarget = Player->pos;
}
void daMrSun_c::executeState_Wait() {
	int Choice;
	int TimerMax;

	if ((this->settings & 0xF) == 0) { TimerMax = 60; } // It's a sun
	else { TimerMax = 30; } // It's a moon

	if (this->timer > TimerMax) {

		Choice = GenerateRandomNumber(9);


		if (Choice == 0) { doStateChange(&StateID_Spit); }
		else if (Choice == 1) { doStateChange(&StateID_Spit); }
		else if (Choice == 2) { doStateChange(&StateID_Spin); }
		else if (Choice == 3) { doStateChange(&StateID_Spiral); }
		else { doStateChange(&StateID_Swoop); }

	}

	this->timer = this->timer + 1;
}
void daMrSun_c::endState_Wait() {
	this->timer = 0;
}



//
// processed\../src/firelaser.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <profile.h>

class daFireLaser_c : public dEn_c {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	public: static dActor_c *build();

	int timer;
	float spitspeed;
	char direction;
	u64 eventFlag;

	USING_STATES(daFireLaser_c);
	DECLARE_STATE(pewpewpew);
};

const SpriteData FireLaserSpriteData = {ProfileId::EN_FIRELASER, 0, 0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 2};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile FireLaserProfile(&daFireLaser_c::build, SpriteId::EN_FIRELASER, &FireLaserSpriteData, ProfileId::DUMMY_DOOR_PARENT, ProfileId::EN_FIRELASER, "EN_FIRELASER");


dActor_c *daFireLaser_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daFireLaser_c));
	return new(buffer) daFireLaser_c;
}


CREATE_STATE(daFireLaser_c, pewpewpew);




int daFireLaser_c::onCreate() {

	this->timer = 0;
	this->direction = this->settings & 0xF;
	this->spitspeed = 8.0;

	char eventNum	= (this->settings >> 16) & 0xFF;
	this->eventFlag = (u64)1 << (eventNum - 1);


	doStateChange(&StateID_pewpewpew);
	this->onExecute();
	return true;
}

int daFireLaser_c::onDelete() {
	return true;
}

int daFireLaser_c::onExecute() {
	acState.execute();
	return true;
}

int daFireLaser_c::onDraw() {
	return true;
}



// Pew Pew State

void daFireLaser_c::beginState_pewpewpew() {
	this->timer = 0;
}
void daFireLaser_c::executeState_pewpewpew() {


	if (dFlagMgr_c::instance->flags & this->eventFlag) {

		this->timer = this->timer + 1;

		if (this->timer < 20) {
			float xlaunch;
			float ylaunch;

			if (this->direction == 0) {
				xlaunch = this->spitspeed;
				ylaunch = 0.0; }
			else if (this->direction == 1) { // SE
				xlaunch = this->spitspeed;
				ylaunch = this->spitspeed; }
			else if (this->direction == 2) { // S
				xlaunch = 0.0;
				ylaunch = this->spitspeed; }
			else if (this->direction == 3) { // SW
				xlaunch = -this->spitspeed;
				ylaunch = this->spitspeed; }
			else if (this->direction == 4) {	// W
				xlaunch = -this->spitspeed;
				ylaunch = 0.0; }
			else if (this->direction == 5) {	// NW
				xlaunch = -this->spitspeed;
				ylaunch = -this->spitspeed; }
			else if (this->direction == 6) {	// N
				xlaunch = 0.0;
				ylaunch = -this->spitspeed; }
			else if (this->direction == 7) {	// NE
				xlaunch = this->spitspeed;
				ylaunch = -this->spitspeed; }


			dStageActor_c *spawner = CreateActor(ProfileId::PAKKUN_FIREBALL, 0, this->pos, 0, 0);
			spawner->speed.x = xlaunch;
			spawner->speed.y = ylaunch;
		}

		if (this->timer > 60) {
			this->timer = 0;
		}

	}

	else { this->timer = 0; }

}
void daFireLaser_c::endState_pewpewpew() {

}














//
// processed\../src/gakenoko.cpp
//

#include <game.h>

struct daEnGakeNoko_c : public dEn_c {
	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;
	m3d::mdl_c model;
	m3d::anmChr_c anmChr;
	nw4r::g3d::ResAnmTexPat resAnmTexPat;
	m3d::anmTexPat_c anmTexPat;
	u32 _5EC;
	int countdown;
	u8 gap[0x12C];

	USING_STATES(daEnGakeNoko_c);
	REF_NINTENDO_STATE(FoolMove);
	REF_NINTENDO_STATE(Move);
	REF_NINTENDO_STATE(Air);
	REF_NINTENDO_STATE(Awake);
	REF_NINTENDO_STATE(Fall);
	REF_NINTENDO_STATE(Fall2);
	REF_NINTENDO_STATE(Hang);
	REF_NINTENDO_STATE(DieFumi);
};

const ActivePhysics::Info GakeNokoColl = {
    0.0f,  // float xDistToCenter;
    11.0f,  // float yDistToCenter;
    8.0f,  // float xDistToEdge;
    11.0f,  // float yDistToEdge;
    3,  // u8 category1;
    0,  // u8 category2;
    0x4F,  // u32 bitfield1;
    0xFFBAFFFE,  // u32 bitfield2;
    0,  // u16 unkShort1C;
    &dEn_c::collisionCallback  // Callback callback;
};

int EN_GAKE_NOKO_ctor_new(daEnGakeNoko_c *self) {								//b @ 0x80A025A0
	self->allocator.link(-1, mHeap::gameHeaps[0], 0, 0x20);
	self->resFile.data = getResource("nokonokoB", "g3d/nokonokoB.brres");

	nw4r::g3d::ResMdl resMdl = self->resFile.GetResMdl("nokonokoB");
	self->model.setup(resMdl, &self->allocator, 0x7FFF, 1, 0);
	SetupTextures_Enemy(&self->model, 0);

	nw4r::g3d::ResAnmChr resAnmChr = self->resFile.GetResAnmChr("net_walk2");
	self->anmChr.setup(resMdl, resAnmChr, &self->allocator, 0);

	self->resAnmTexPat = self->resFile.GetResAnmTexPat("nokonokoB");
	self->anmTexPat.setup(resMdl, self->resAnmTexPat, &self->allocator, 0, 1);
	self->anmTexPat.bindEntry(&self->model, &self->resAnmTexPat, 0, 1);

	self->allocator.unlink();

	// Nybble 10: green (0) / red (1)
	if ((self->settings >> 8) & 1) {
		self->doStateChange(&daEnGakeNoko_c::StateID_Move);
	} else {
		self->doStateChange(&daEnGakeNoko_c::StateID_FoolMove);
	}
	if ((self->settings >> 8) & 1) {
		self->anmTexPat.setEntryByte34(1, 0);
		self->model.bindAnim(&self->anmTexPat, 0.0);
		self->anmTexPat.setFrameForEntry(1.0, 0);
	} else {
		self->anmTexPat.setFrameForEntry(0.0, 0);
	}

	// Nybble 11: initial direction: right (0) / left (1)
	if ((self->settings >> 4) & 1) {
		// (Logic copied from how the Move state switches directions
		// at the end of a ledge -- basic block at 80A02E00 in PALv1)
		self->direction ^= 1;
		self->speed.x = -self->speed.x;
		self->anmChr.playState = 2;
	}

	// Nybble 12: if 1, vertical positioning is improved
	if (self->settings & 1) {
		self->pos.y += 16.0;
	}

	// ActivePhysics for 2021
	self->aPhysics.initWithStruct(self, (ActivePhysics::Info *)&GakeNokoColl);
	self->aPhysics.addToList();

	self->rot.y = 0x8000;  // Face the wall

	return 1;
}


// Edit some Y-position-related constants in various states if nybble 12 is enabled
float twenty_four_or_alt_f[2] = { 24.0f, 8.0f };
float thirty_one_or_alt_f[2] = { 31.0f, 15.0f };

//
// processed\../src/poweruphax.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>


void ThwompHammer(dEn_c *thwomp, ActivePhysics *apThis, ActivePhysics *apOther) {
	if (thwomp->profileId == ProfileId::EN_DOSUN) {
		thwomp->dEn_c::collisionCat13_Hammer(apThis, apOther);
	}
	return;
}

void BooHammer(dEn_c *boo, ActivePhysics *apThis, ActivePhysics *apOther) {
	if (boo->profileId == ProfileId::EN_TERESA) {
		boo->dEn_c::collisionCat13_Hammer(apThis, apOther);
	}
	return;
}

void UrchinHammer(dEn_c *urchin, ActivePhysics *apThis, ActivePhysics *apOther) {
	return;
}


#include "poweruphax.h"

void SetCullModeForMaterial(m3d::mdl_c *model, int materialID, u32 cullMode);


dHammerSuitRenderer_c *dHammerSuitRenderer_c::build() {
	return new dHammerSuitRenderer_c;
}

dHammerSuitRenderer_c::dHammerSuitRenderer_c() { }
dHammerSuitRenderer_c::~dHammerSuitRenderer_c() { }

void dHammerSuitRenderer_c::setup(dPlayerModelHandler_c *handler) {
	setup(handler, 0);
}

void dHammerSuitRenderer_c::setup(dPlayerModelHandler_c *handler, int sceneID) {
	victim = (dPlayerModel_c*)handler->mdlClass;

	allocator.link(-1, GameHeaps[0], 0, 0x20);

	nw4r::g3d::ResFile rf(getResource("hammerM", "g3d/suit.brres"));

	if (victim->player_id_2 <= 1) {
		helmet.setup(rf.GetResMdl((victim->player_id_2 == 0) ? "marioHelmet" : "luigiHelmet"), &allocator, 0, 1, 0);
		SetupTextures_Player(&helmet, sceneID);
	}

	const char *shellNames[] = {
		"shell", "shell", "shell", "shell", "shell"
	};
	shell.setup(rf.GetResMdl(shellNames[victim->player_id_2]), &allocator, 0, 1, 0);
	SetupTextures_Player(&shell, sceneID);

	allocator.unlink();


	victimModel = &victim->models[0].body;
	nw4r::g3d::ResMdl *playerResMdl =
		(nw4r::g3d::ResMdl*)(((u32)victimModel->scnObj) + 0xE8);

	//headNodeID = playerResMdl->GetResNode("player_head").GetID();
	if (victim->player_id_2 <= 1) {
		nw4r::g3d::ResNode face_1 = playerResMdl->GetResNode("face_1");
		headNodeID = face_1.GetID();
	}

	nw4r::g3d::ResNode skl_root = playerResMdl->GetResNode("spin");
	rootNodeID = skl_root.GetID();
	
	this->sceneNum = sceneID;
}

void dHammerSuitRenderer_c::draw() {
	if (victim->powerup_id != 7)
		return;

	if (victim->player_id_2 <= 1) {
		// Materials: 2=hair 3=hat; Modes: BACK=visible ALL=invisible
		SetCullModeForMaterial(&victim->getCurrentModel()->head, 3, GX_CULL_ALL);
		SetCullModeForMaterial(&victim->getCurrentModel()->head, 2, GX_CULL_ALL);

		Mtx headMtx;
		victimModel->getMatrixForNode(headNodeID, &headMtx);

		helmet.setDrawMatrix(&headMtx);
		helmet.setScale(1.0f, 1.0f, 1.0f);
		helmet.calcWorld(false);
		SetupTextures_Player(&helmet, sceneNum);

		helmet.scheduleForDrawing();
	}

	Mtx rootMtx;
	victimModel->getMatrixForNode(rootNodeID, &rootMtx);

	shell.setDrawMatrix(&rootMtx);
	shell.setScale(1.0f, 1.0f, 1.0f);
	shell.calcWorld(false);
	SetupTextures_Player(&shell, sceneNum);

	shell.scheduleForDrawing();
}








// NEW VERSION
void CrapUpPositions(Vec *out, const Vec *in);

void dStockItem_c::setScalesOfSomeThings() {
	nw4r::lyt::Pane *ppos = N_forUse_PPos[playerCount];

	int howManyPlayers = 0;
	for (int i = 0; i < 4; i++) {
		if (isPlayerActive[i]) {
			int picID = getIconPictureIDforPlayer(howManyPlayers);
			int charID = Player_ID[i];

			if (picID != 24) {
				nw4r::lyt::Picture *pic = P_icon[picID];

				Vec in, out;

				in.x = pic->effectiveMtx[0][3];
				in.y = pic->effectiveMtx[1][3];
				in.z = pic->effectiveMtx[2][3];

				CrapUpPositions(&out, &in);

				u8 *wmp = (u8*)player2d[charID];
				*((float*)(wmp+0xAC)) = out.x;
				*((float*)(wmp+0xB0)) = out.y;
				*((float*)(wmp+0xB4)) = out.z;
				*((float*)(wmp+0x220)) = 0.89999998f;
				*((float*)(wmp+0x224)) = 0.89999998f;
				*((float*)(wmp+0x228)) = 0.89999998f;
				*((float*)(wmp+0x25C)) = 26.0f;
			}
			howManyPlayers++;
		}
	}


	for (int i = 0; i < 8; i++) {
		u8 *item = (u8*)newItemPtr[i];

		nw4r::lyt::Pane *icon = newIconPanes[i];

		Vec in, out;
		in.x = icon->effectiveMtx[0][3];
		in.y = icon->effectiveMtx[1][3];
		in.z = icon->effectiveMtx[2][3];

		CrapUpPositions(&out, &in);

		*((float*)(item+0xAC)) = out.x;
		*((float*)(item+0xB0)) = out.y;
		*((float*)(item+0xB4)) = out.z;
		*((float*)(item+0x1F4)) = P_buttonBase[i]->scale.x;
		*((float*)(item+0x1F8)) = P_buttonBase[i]->scale.y;
		*((float*)(item+0x1FC)) = 1.0f;
	}


	nw4r::lyt::Pane *shdRoot = shadow->rootPane;
	shdRoot->trans.x = N_stockItem->effectiveMtx[0][3];
	shdRoot->trans.y = N_stockItem->effectiveMtx[1][3];
	shdRoot->trans.z = N_stockItem->effectiveMtx[2][3];
	shdRoot->scale.x = N_stockItem_01->effectiveMtx[0][0];
	shdRoot->scale.y = N_stockItem_01->effectiveMtx[1][1];

	for (int i = 0; i < 7; i++)
		shadow->buttonBases[i]->scale = newButtonBase[i]->scale;
	shadow->hammerButtonBase->scale = newButtonBase[7]->scale;
}



//
// processed\../src/randtiles.cpp
//

#include <game.h>

class RandomTileData {
public:
	enum Type {
		CHECK_NONE = 0,
		CHECK_HORZ = 1,
		CHECK_VERT = 2,
		CHECK_BOTH = 3
	};

	enum Special {
		SP_NONE = 0,
		SP_VDOUBLE_TOP = 1,
		SP_VDOUBLE_BOTTOM = 2
	};

	class NameList {
	public:
		u32 count;
		u32 offsets[1]; // variable size

		const char *getName(int index) {
			return ((char*)this) + offsets[index];
		}

		bool contains(const char *name) {
			for (int i = 0; i < count; i++) {
				if (strcmp(name, getName(i)) == 0)
					return true;
			}

			return false;
		}
	};

	class Entry {
	public:
		u8 lowerBound, upperBound;
		u8 count, type;
		u32 tileNumOffset;

		u8 *getTileNums() {
			return ((u8*)this) + tileNumOffset;
		}
	};

	class Section {
	public:
		u32 nameListOffset;
		u32 entryCount;
		Entry entries[1]; // variable size

		NameList *getNameList() {
			return (NameList*)(((u32)this) + nameListOffset);
		}
	};

	u32 magic;
	u32 sectionCount;
	u32 offsets[1]; // variable size

	Section *getSection(int id) {
		return (Section*)(((char*)this) + offsets[id]);
	}

	Section *getSection(const char *name);

	static RandomTileData *instance;
};

class RTilemapClass : public TilemapClass {
public:
	// NEWER ADDITIONS
	RandomTileData::Section *sections[4];
};

RandomTileData::Section *RandomTileData::getSection(const char *name) {
	for (int i = 0; i < sectionCount; i++) {
		RandomTileData::Section *sect = getSection(i);

		if (sect->getNameList()->contains(name))
			return sect;
	}

	return 0;
}


// Real tile handling code

RandomTileData *RandomTileData::instance = 0;

dDvdLoader_c RandTileLoader;

// This is a bit hacky but I'm lazy
bool LoadLevelInfo();

extern "C" bool RandTileLoadHook() {
	// OSReport("Trying to load...");
	void *buf = RandTileLoader.load("/RandTiles.bin");
	bool LIresult = LoadLevelInfo();
	if (buf == 0) {
		// OSReport("Failed.\n");
		return false;
	} else {
		// OSReport("Successfully loaded RandTiles.bin [%p].\n", buf);
		RandomTileData::instance = (RandomTileData*)buf;
		return LIresult;
	}
}


extern "C" void IdentifyTilesets(RTilemapClass *self) {
	self->_C0C = 0xFFFFFFFF;

	for (int i = 0; i < 4; i++) {
		const char *tilesetName = BGDatClass::instance->getTilesetName(self->areaID, i);

		self->sections[i] = RandomTileData::instance->getSection(tilesetName);
		// OSReport("[%d] Chose %p for %s\n", i, self->sections[i], tilesetName);
	}
}

extern "C" void TryAndRandomise(RTilemapClass *self, BGRender *bgr) {
	int fullTile = bgr->tileToPlace & 0x3FF;
	int tile = fullTile & 0xFF;
	int tileset = fullTile >> 8;

	RandomTileData::Section *rtSect = self->sections[tileset];
	if (rtSect == 0)
		return;

	for (int i = 0; i < rtSect->entryCount; i++) {
		RandomTileData::Entry *entry = &rtSect->entries[i];

		if (tile >= entry->lowerBound && tile <= entry->upperBound) {
			// Found it!!
			// Try to make one until we meet the conditions
			u8 type = entry->type & 3;
			u8 special = entry->type >> 2;

			u8 *tileNums = entry->getTileNums();
			u16 chosen = 0xFF;

			// If it's the top special, then ignore this tile, we'll place that one
			// once we choose the bottom one
			if (special == RandomTileData::SP_VDOUBLE_TOP)
				break;

			u16 *top = 0, *left = 0, *right = 0, *bottom = 0;
			if (type == RandomTileData::CHECK_HORZ || type == RandomTileData::CHECK_BOTH) {
				left = self->getPointerToTile((bgr->curX - 1) * 16, bgr->curY * 16);
				right = self->getPointerToTile((bgr->curX + 1) * 16, bgr->curY * 16);
			}

			if (type == RandomTileData::CHECK_VERT || type == RandomTileData::CHECK_BOTH) {
				top = self->getPointerToTile(bgr->curX * 16, (bgr->curY - 1) * 16);
				bottom = self->getPointerToTile(bgr->curX * 16, (bgr->curY + 1) * 16);
			}

			int attempts = 0;
			while (true) {
				// is there even a point to using that special random function?
				chosen = (tileset << 8) | tileNums[MakeRandomNumberForTiles(entry->count)];

				// avoid infinite loops
				attempts++;
				if (attempts > 5)
					break;

				if (top != 0 && *top == chosen)
					continue;
				if (bottom != 0 && *bottom == chosen)
					continue;
				if (left != 0 && *left == chosen)
					continue;
				if (right != 0 && *right == chosen)
					continue;
				break;
			}

			bgr->tileToPlace = chosen;

			if (special == RandomTileData::SP_VDOUBLE_BOTTOM) {
				if (top == 0)
					top = self->getPointerToTile(bgr->curX * 16, (bgr->curY - 1) * 16);

				*top = (chosen - 0x10);
			}

			return;
		}
	}
}



//
// processed\../src/objkinoko.cpp
//

#include <game.h>
#include <g3dhax.h>


class SomethingAboutShrooms {
	public:
		m3d::mdl_c models[3];
		float scale, _C4, offsetToEdge;
		m3d::anmTexPat_c animations[3];

		struct info_s {
			const char *leftName;
			const char *middleName;
			const char *rightName;
			float size; // 8 for small, 16 for big
			const char *lrName;
			const char *middleNameAgain;
		};

		void setup(mAllocator_c *allocator,
				nw4r::g3d::ResFile *resFile, info_s *info,
				float length, float colour, float scale);

		// plus more methods I don't know

		void drawWithMatrix(float yOffset, mMtx *matrix);
};


class dRotatorThing_c {
	public:
		s16 _p5, output, _p1, _p2, _p3;
		s16 _p6, _p7, _p0;
		u32 someBool;

		void setup(s16 a, s16 b, s16 c, s16 d, s16 initialRotation, s16 f, s16 g, s16 h);
		s16 execute();
};


class daObjKinoko_c : public dStageActor_c {
	public:
		mHeapAllocator_c allocator;
		nw4r::g3d::ResFile resFile;
		SomethingAboutShrooms renderer;
		StandOnTopCollider colliders[3];
		dRotatorThing_c xRotator;
		dRotatorThing_c zRotator;
		u8 thickness, touchCompare;

		void loadModels(int thickness, float length, float colour, float scale);
		void addAllColliders();
		void updateAllColliders();
		void removeAllColliders();
		u8 checkIfTouchingObject();

		int onCreate();
		int onExecute();
		int onDraw();
		int onDelete();

		int creationHook();
		int drawHook();

		int original_onCreate();

		~daObjKinoko_c();
};


// This will replace Nintendo's onCreate
int daObjKinoko_c::creationHook() {
	original_onCreate();

	// if rotation is off, do nothing else
	if (!((settings >> 28) & 1))
		return 1;

	// OK, figure out the rotation
	u8 sourceRotation = (settings >> 24) & 0xF;

	// 0 is up. -0x4000 is right, 0x4000 is left ...
	s16 rotation;

	// We'll flip it later.
	// Thus: 0..7 rotates left (in increments of 0x800),
	// 8..15 rotates right (in increments of 0x800 too).
	// To specify facing up, well.. just use 0.

	if (sourceRotation < 8)
		rotation = (sourceRotation * 0x800) - 0x4000;
	else
		rotation = (sourceRotation * 0x800) - 0x3800;

	rotation = -rotation;

	rot.z = rotation;

	/* Original code: */
	int lengthInTiles = settings & 0xF;

	float sizeMult = (thickness == 1) ? 1.0f : 0.5f;
	float length = sizeMult * ((32.0f + (lengthInTiles * 16.0f)) - 16.0f);

	float topPos = (sizeMult * 16.0f);

	float cosThing = nw4r::math::CosFIdx((lengthInTiles * 16.0f) / 256.0f);
	float anotherThing = (4.0f + topPos) / cosThing;

	// Middle Collider
	colliders[0].init(this,
			/*xOffset=*/0.0f, /*yOffset=*/0.0f,
			/*topYOffset=*/topPos,
			/*rightSize=*/length, /*leftSize=*/-length,
			/*rotation=*/rotation, /*_45=*/1
			);

	colliders[0]._47 = 0;
	colliders[0].flags = 0x80180 | 0xC00;

	// Now get the info to move the colliders by ....
	float rotFIdx = ((float)rotation) / 256.0f;
	float sinRot, cosRot;
	nw4r::math::SinCosFIdx(&sinRot, &cosRot, rotFIdx);
	//OSReport("Rotation is %d, so rotFIdx is %f\n", rotation, rotFIdx);
	//OSReport("Sin: %f, Cos: %f\n", sinRot, cosRot);
	
	float leftXOffs = (cosRot * -length) - (sinRot * topPos);
	float leftYOffs = (sinRot * -length) + (cosRot * topPos);
	float rightXOffs = (cosRot * length) - (sinRot * topPos);
	float rightYOffs = (sinRot * length) + (cosRot * topPos);
	//OSReport("leftXOffs: %f, leftYOffs: %f\n", leftXOffs, leftYOffs);
	//OSReport("rightXOffs: %f, rightYOffs: %f\n", rightXOffs, rightYOffs);

	// Right Collider
	colliders[1].init(this,
			/*xOffset=*/rightXOffs, /*yOffset=*/rightYOffs,
			/*topYOffset=*/0.0f,
			/*rightSize=*/anotherThing, /*leftSize=*/0.0f,
			/*rotation=*/rotation - 0x2000, /*_45=*/1
			);

	colliders[1]._47 = 0;
	colliders[1].flags = 0x80100 | 0x800;

	// Left Collider
	colliders[2].init(this,
			/*xOffset=*/leftXOffs, /*yOffset=*/leftYOffs,
			/*topYOffset=*/0.0f,
			/*rightSize=*/0.0f, /*leftSize=*/-anotherThing,
			/*rotation=*/rotation + 0x2000, /*_45=*/1
			);

	colliders[2]._47 = 0;
	colliders[2].flags = 0x80080 | 0x400;

	return 1;
}


// This will replace Nintendo's onDraw
int daObjKinoko_c::drawHook() {
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationZ(&rot.z);
	matrix.applyRotationX(&xRotator.output);
	matrix.applyRotationZ(&zRotator.output);
	renderer.drawWithMatrix(0.0f, &matrix);

	return 1;
}



//
// processed\../src/tilegod.cpp
//

#include <game.h>
#include <sfx.h>

//#define REIMPLEMENT

extern "C" bool SpawnEffect(const char*, int, Vec*, S16Vec*, Vec*);

class daChengeBlock_c : public dStageActor_c {
	static daChengeBlock_c *build();

	u32 _394;
	u64 initialFlags;

	enum Action { Destroy, Create };
	enum Pattern { Fill, CheckerA, CheckerB };

	int width, height;
	Action action;
	int blockType;
	int isPermanent;
	Pattern pattern;
	u16 hasTriggered;

	u32 _3BC;


	int onCreate();
	int onExecute();

	void doStuff(Action action, bool wasCalledOnCreation);
	void tryToTrigger();
};

#ifdef REIMPLEMENT
daChengeBlock_c *daChengeBlock_c::build() {
	return new(AllocFromGameHeap1(sizeof(daChengeBlock_c))) daChengeBlock_c;
}



int daChengeBlock_c::onCreate() {
	hasTriggered = 0;

	height = settings & 0xF;
	width = (settings & 0xF0) >> 4;
	blockType = (settings & 0xF000) >> 12;
	pattern = (Pattern)((settings & 0x30000) >> 16);
	isPermanent = (settings & 0xF0000000) >> 28;

	if (width == 0)
		width++;
	if (height == 0)
		height++;

	action = (Action)((settings & 0xF00) >> 8);

	initialFlags = dFlagMgr_c::instance->flags & dStageActor_c::creatingFlagMask;

	if (initialFlags) {
		if (action == Destroy) {
			doStuff(Destroy, true);
		} else {
			doStuff(Create, true);
			hasTriggered = true;
		}

		if (isPermanent)
			return 2;
	}

	return 1;
}


int daChengeBlock_c::onExecute() {
	tryToTrigger();

	if (!hasTriggered)
		checkZoneBoundaries(0);

	return 1;
}


#endif // REIMPLEMENT

// Red, Brick, Blank/Unused, Stone, Wood, Blank
static const u16 Tiles[] = {124, 2, 12, 123, 15, 0};

void daChengeBlock_c::doStuff(Action action, bool wasCalledOnCreation) {
	u16 perTilePatternFlag = 1, perRowPatternFlag = 1;

	u16 worldX = ((u16)pos.x) & 0xFFF0;
	u16 baseWorldX = worldX;
	u16 worldY = ((u16)(-pos.y)) & 0xFFF0;

	if (pattern == CheckerB) {
		perTilePatternFlag = 0;
		perRowPatternFlag = 0;
	}

	u16 tile;
	if (action != Destroy) {
		if (blockType & 8) {
			// Specify a tile number
			tile = 0x8000 | ((blockType & 3) << 8) | ((settings & 0xFF00000) >> 20);
		} else {
			// fall through
			tile = Tiles[blockType];
		}
	} else {
		tile = 0;
	}

	for (u16 y = 0; y < height; y++) {
		for (u16 x = 0; x < width; x++) {
			if (perTilePatternFlag) {
				u16 *pExistingTile = dBgGm_c::instance->getPointerToTile(worldX, worldY, currentLayerID);
				u16 existingTile = pExistingTile ? *pExistingTile : 0;

				dBgGm_c::instance->placeTile(worldX, worldY, currentLayerID, tile);

				if (!wasCalledOnCreation) {
					Vec effectPos;

					if (action == Destroy) {
						if (blockType != 2) {
							effectPos.x = ((float)(worldX)) + 8.0f;
							effectPos.y = ((float)(-worldY)) - 8.0f;
							effectPos.z = pos.z;

							u16 shardType;
							switch (existingTile) {
								case 0x30: shardType = 0; break;
								case 0x31: shardType = 3; break;
								case 0x32: shardType = 4; break;
								case 0x33: shardType = 2; break;
								case 0x34: shardType = 1; break;
								case 0x37: shardType = 5; break;
								default: shardType = 0xFFFF;
							}

							if (!(settings & 0x40000)) {
								if (shardType == 0xFFFF) {
									SpawnEffect("Wm_en_burst_ss", 0, &effectPos, 0, 0);
								} else {
									u32 sets = (shardType << 8) | 3;
									effectPos.y -= 8;
									dEffectBreakMgr_c::instance->spawnTile(&effectPos, sets, 0);
								}
							}

							if (!(settings & 0x80000)) {
								Vec2 soundPos;
								ConvertStagePositionToScreenPosition(&soundPos, &effectPos);
								SoundPlayingClass::instance2->PlaySoundAtPosition(SE_OBJ_BLOCK_BREAK, &soundPos, 0);
							}
						}
					} else {
						effectPos.x = ((float)(worldX)) + 8.0f;
						effectPos.y = ((float)(-worldY)) - 8.0f;
						effectPos.z = pos.z;

						if (!(settings & 0x40000)) {
							if (blockType != 2) {
								SpawnEffect("Wm_en_burst_ss", 0, &effectPos, 0, 0);
							}
						}
					}
				}
			}

			if (pattern != Fill) {
				perTilePatternFlag ^= 1;
			}

			worldX += 16;
		}

		if (pattern != Fill) {
			perRowPatternFlag ^= 1;
			perTilePatternFlag = perRowPatternFlag;
		}

		worldX = baseWorldX;
		worldY += 16;
	}
}


#ifdef REIMPLEMENT
void daChengeBlock_c::tryToTrigger() {
	u64 result = spriteFlagMask & dFlagMgr_c::instance->flags;

	if (action == Destroy) {
		if (result & initialFlags) {
			if (result) {
				doStuff(Destroy, false);
				hasTriggered = true;
			} else {
				doStuff(Create, false);
				hasTriggered = false;
			}

			initialFlags = result;

			if (isPermanent)
				fBase_c::Delete();
		}
	} else {
		if (result & initialFlags) {
			if (result) {
				doStuff(Create, false);
				hasTriggered = true;
			} else {
				doStuff(Destroy, false);
				hasTriggered = false;
			}

			initialFlags = result;

			if (isPermanent)
				fBase_c::Delete();
		}
	}
}
#endif


//
// processed\../src/linegod.cpp
//

#include <common.h>
#include <game.h>
#include <profile.h>

// TODO: make "No Deactivation"

struct BgActor {
	u16 def_id;		// 0x00
	u16 x;			// 0x02
	u16 y;			// 0x04
	u8 layer;		// 0x06
	u8 EXTRA_off;	// 0x07
	u32 actor_id;	// 0x08
};

struct BgActorDef {
	u32 tilenum;
	u16 actor;
	u8 _06[2];
	float x;
	float y;
	float z;
	float width;
	float height;
	u32 extra_var;
};

struct dBgActorManager_c {
	u32 vtable;		// 0x00
	u8 _04[0x34];	// 0x04
	BgActor *array;	// 0x38
	u32 count;		// 0x3C
	u32 type;		// 0x40
};

extern dBgActorManager_c *dBgActorManager;

extern BgActorDef *BgActorDefs;

struct BG_GM_hax {
	u8 _00[0x8FE64];
	float _0x8FE64;
	float _0x8FE68;
	float _0x8FE6C;
	float _0x8FE70;
};

extern BG_GM_hax *BG_GM_ptr;

#define LINEGOD_FUNC_ACTIVATE	0
#define LINEGOD_FUNC_DEACTIVATE	1

class LineGod : public dStageActor_c {
	int onCreate();
	int onExecute();

	u64 eventFlag;
	u8 func;
	u8 width;
	u8 height;
	u8 lastEvState;
	BgActor *ac[8];

	public: static dActor_c *build();

	void BuildList();
	bool AppendToList(BgActor *ac);
	void Update();
};

dActor_c *LineGod::build() {
	void *buffer = AllocFromGameHeap1(sizeof(LineGod));
	return new(buffer) LineGod;
}

const SpriteData LineGodSpriteData = { ProfileId::AC_LINEGOD, 0, 0, 0 , 0, 0x10, 0x10, 0, 0, 0, 0, 8};
Profile LineGodProfile(&LineGod::build, SpriteId::AC_LINEGOD, &LineGodSpriteData, ProfileId::RIVER_MGR, ProfileId::AC_LINEGOD, "AC_LINEGOD");

u16 *GetPointerToTile(BG_GM_hax *self, u16 x, u16 y, u16 layer, short *blockID_p, bool unused);

int LineGod::onCreate() {
	char eventNum = (this->settings >> 24) & 0xFF;
	this->eventFlag = (u64)1 << (eventNum - 1);

	this->func = (this->settings) & 1;
	this->width = (this->settings >> 4) & 0xF;
	this->width = (this->settings >> 8) & 0xF;

	this->lastEvState = 0xFF;

	BuildList();
	onExecute();

	return true;
}

int LineGod::onExecute() {
	u8 newEvState = 0;
	if (dFlagMgr_c::instance->flags & this->eventFlag)
		newEvState = 1;
	
	if (newEvState == this->lastEvState)
		return true;
	
	u16 x_bias = (BG_GM_ptr->_0x8FE64 / 16);
	u16 y_bias = -(BG_GM_ptr->_0x8FE6C / 16);
	
	
	u8 offState;
	if (this->func == LINEGOD_FUNC_ACTIVATE)
		offState = (newEvState == 1) ? 1 : 0;
	else
		offState = (newEvState == 1) ? 0 : 1;
	
	
	for (int i = 0; i < 8; i++) {
		if (this->ac[i] != 0) {
			BgActor *ac = this->ac[i];
			
			
			ac->EXTRA_off = offState;
			if (offState == 1 && ac->actor_id != 0) {
				fBase_c *assoc_ac = searchById(ac->actor_id);
				if (assoc_ac != 0)
					assoc_ac->Delete();
				ac->actor_id = 0;
			}
			
			u16 *tile = GetPointerToTile(BG_GM_ptr, (ac->x + x_bias) * 16, (ac->y + y_bias) * 16, 0, 0, 0);
			if (offState == 1)
				*tile = 0;
			else
				*tile = BgActorDefs[ac->def_id].tilenum;
			
		}
	}
	
	
	
	this->lastEvState = newEvState;
	return true;
}

void LineGod::BuildList() {
	for (int clearIdx = 0; clearIdx < 8; clearIdx++) {
		this->ac[clearIdx] = 0;
	}

	float gLeft = this->pos.x - (BG_GM_ptr->_0x8FE64 - fmod(BG_GM_ptr->_0x8FE64, 16));
	float gTop = this->pos.y - (BG_GM_ptr->_0x8FE6C - fmod(BG_GM_ptr->_0x8FE6C, 16));

	// 1 unit padding to avoid catching stuff that is not in our rectangle
	Vec grect1 = (Vec){
		gLeft + 1, gTop - (this->height * 16) + 1, 0
	};

	Vec grect2 = (Vec){
		gLeft + (this->width * 16) - 1, gTop - 1, 0
	};

	for (int i = 0; i < dBgActorManager->count; i++) {
		BgActor *ac = &dBgActorManager->array[i];

		// the Def width/heights are padded with 8 units on each side
		// except for one of the steep slopes, which differs for no reason

		BgActorDef *def = &BgActorDefs[ac->def_id];
		float aXCentre = (ac->x * 16) + def->x;
		float aYCentre = (-ac->y * 16) + def->y;

		float xDistToCentre = (def->width - 16) / 2;
		float yDistToCentre = (def->height - 16) / 2;

		Vec arect1 = (Vec){
			aXCentre - xDistToCentre, aYCentre - yDistToCentre, 0
		};
		
		Vec arect2 = (Vec){
			aXCentre + xDistToCentre, aYCentre + yDistToCentre, 0
		};

		if (RectanglesOverlap(&arect1, &arect2, &grect1, &grect2))
			AppendToList(ac);
	}
}

bool LineGod::AppendToList(BgActor *ac) {
	for (int search = 0; search < 8; search++) {
		if (this->ac[search] == 0) {
			this->ac[search] = ac;
			return true;
		}
	}

	return false;
}
//
// processed\../src/tilesetfixer.cpp
//

#include <common.h>
#include <game.h>

const char *GetTilesetName(void *cls, int areaNum, int slotNum);

void DoFixes(int areaNumber, int slotNumber);
void SwapObjData(u8 *data, int slotNumber);

extern "C" void *OriginalTilesetLoadingThing(void *, void *, int, int);

// Main hook
void *TilesetFixerHack(void *cls, void *heap, int areaNum, int layerNum) {
	if (layerNum == 0) {
		for (int i = 1; i < 4; i++) {
			DoFixes(areaNum, i);
		}
	}

	return OriginalTilesetLoadingThing(cls, heap, areaNum, layerNum);
}



// File format definitions
struct ObjLookupEntry {
	u16 offset;
	u8 width;
	u8 height;
};


void DoFixes(int areaNumber, int slotNumber) {
	// This is where it all starts
	const char *tsName = GetTilesetName(BGDatClass, areaNumber, slotNumber);

	if (tsName == 0 || tsName[0] == 0) {
		return;
	}


	char untHDname[64], untname[64];
	snprintf(untHDname, 64, "BG_unt/%s_hd.bin", tsName);
	snprintf(untname, 64, "BG_unt/%s.bin", tsName);

	u32 unt_hd_length;
	void *bg_unt_hd_data = DVD_GetFile(GetDVDClass2(), tsName, untHDname, &unt_hd_length);
	void *bg_unt = DVD_GetFile(GetDVDClass2(), tsName, untname);


	ObjLookupEntry *lookups = (ObjLookupEntry*)bg_unt_hd_data;

	int objCount = unt_hd_length / sizeof(ObjLookupEntry);

	for (int i = 0; i < objCount; i++) {
		// process each object
		u8 *thisObj = (u8*)((u32)bg_unt + lookups[i].offset);

		SwapObjData(thisObj, slotNumber);
	}
}


void SwapObjData(u8 *data, int slotNumber) {
	// rudimentary parser which will hopefully work

	while (*data != 0xFF) {
		u8 cmd = *data;

		if (cmd == 0xFE || (cmd & 0x80) != 0) {
			data++;
			continue;
		}

		if ((data[2] & 3) != 0) {
			data[2] &= 0xFC;
			data[2] |= slotNumber;
		}
		data += 3;
	}

}


//
// processed\../src/palaceDude.cpp
//

#include <game.h>
#include <stage.h>
#include "msgbox.h"
#include "boss.h" // for stopbgmmusic and crap
#include <profile.h>

const char *PalaceDudeFileList[] = {"RYOMRes5", 0};

class dPalaceDude_c : public dStageActor_c {
	public:
		static dActor_c *build();

		bool hasBeenActivated;
		bool hasExitedStage;
		int onExecute();
};

/*****************************************************************************/
// Glue Code
const SpriteData SpecialExitSpriteData = {ProfileId::AC_SWITCH_SET, 10, 10, 0, 0, 0x200, 0x200, 0, 0, 200, 200, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile SpecialExitProfile(&dPalaceDude_c::build, SpriteId::AC_SWITCH_SET, &SpecialExitSpriteData, ProfileId::WM_KINOBALLOON, ProfileId::AC_SWITCH_SET, "AC_SWITCH_SET", PalaceDudeFileList);

dActor_c *dPalaceDude_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dPalaceDude_c));
	dPalaceDude_c *c = new(buffer) dPalaceDude_c;
	return c;
}

extern char CurrentWorld, CurrentLevel;
extern "C" u32 AssembleScWorldMapSettings(u32 world_num, int level_num, int);

int dPalaceDude_c::onExecute() {
	if (dFlagMgr_c::instance->flags & spriteFlagMask) {
		if (!hasBeenActivated) {
//			OSReport("Activating Palace Dude\n");
			hasBeenActivated = true;

			int delay;
			if (!(settings & 0xF000000)) {
				delay = 270;
				StopBGMMusic();
				SaveBlock *save = GetSaveFile()->GetBlock(-1);
				GameMgrP->switchPalaceFlag |= (1 << (settings >> 28));
			} else {
				delay = 1020;
			}

			dMsgBoxManager_c::instance->showMessage(
				settings & 0xFFFFFF, // message ID
				false, // cannot cancel
				delay // delay
				);
		}
	}

	if (hasBeenActivated) {
		if (hasExitedStage)
			return true;
//		OSReport("Palace Dude is activated, %d\n", dMsgBoxManager_c::instance->visible);
		if (!dMsgBoxManager_c::instance->visible) {
//			OSReport("Exiting\n");
			if (settings & 0xF000000) {
				// replicate what opening cutscene does
				SaveBlock *save = GetSaveFile()->GetBlock(-1);
				save->onWorldDataFlag(0, 1);
				SaveFileInstance->prepareSave();
				SaveFileInstance->calcCRC();
				SaveFileInstance->startNandSave();

				save->offWorldDataFlag(0, 1);
				ActivateWipe(MARIO_WIPE);
				u32 wmsettings = AssembleScWorldMapSettings(0, 0, 5);
				DoSceneChange(ProfileId::WORLD_MAP, wmsettings, 0);
			} else {
				ExitStage(ProfileId::WORLD_MAP, 0, BEAT_LEVEL, MARIO_WIPE);
			}
			hasExitedStage = true;
		}
	}

	return true;

}

void enableWMSwitch() {
	GameMgrP->switchPalaceFlag |= (1 << 4);
}

void disableWMSwitch() {
	GameMgrP->switchPalaceFlag &= ~(1 << 4);
}

u8 getWMSwitch() {
	return (GameMgrP->switchPalaceFlag >> 4);
}

//
// processed\../src/eventblock.cpp
//

#include <common.h>
#include <game.h>
#include <profile.h>

// Patches MIST_INTERMITTENT (sprite 239)

class daEnEventBlock_c : public daEnBlockMain_c {
public:
	enum Mode {
		TOGGLE_EVENT = 0,
		SWAP_EVENTS = 1
	};

	TileRenderer tile;
	Physics::Info physicsInfo;

	u8 event1;
	u8 event2;
	Mode mode;

	void equaliseEvents();

	int onCreate();
	int onDelete();
	int onExecute();

	void calledWhenUpMoveExecutes();
	void calledWhenDownMoveExecutes();

	void blockWasHit(bool isDown);

	USING_STATES(daEnEventBlock_c);
	DECLARE_STATE(Wait);

	public: static dActor_c *build();
};


CREATE_STATE(daEnEventBlock_c, Wait);

const SpriteData eventBlockSpriteData = { ProfileId::EN_EVENT_BLOCK, 0, 0 , 0 , 0, 0x40, 0x10, 0, 0, 0, 0, 0 };
Profile eventBlockProfile(&daEnEventBlock_c::build, SpriteId::EN_EVENT_BLOCK, &eventBlockSpriteData, ProfileId::MIST_INTERMITTENT, ProfileId::EN_EVENT_BLOCK, "EN_EVENT_BLOCK", NULL, 0x2);

int daEnEventBlock_c::onCreate() {
	blockInit(pos.y);

	physicsInfo.x1 = -8;
	physicsInfo.y1 = 16;
	physicsInfo.x2 = 8;
	physicsInfo.y2 = 0;

	physicsInfo.otherCallback1 = &daEnBlockMain_c::OPhysicsCallback1;
	physicsInfo.otherCallback2 = &daEnBlockMain_c::OPhysicsCallback2;
	physicsInfo.otherCallback3 = &daEnBlockMain_c::OPhysicsCallback3;

	physics.setup(this, &physicsInfo, 3, currentLayerID);
	physics.flagsMaybe = 0x260;
	physics.callback1 = &daEnBlockMain_c::PhysicsCallback1;
	physics.callback2 = &daEnBlockMain_c::PhysicsCallback2;
	physics.callback3 = &daEnBlockMain_c::PhysicsCallback3;
	physics.addToList();

	TileRenderer::List *list = dBgGm_c::instance->getTileRendererList(0);
	list->add(&tile);

	tile.x = pos.x - 8;
	tile.y = -(16 + pos.y);
	tile.tileNumber = 0x97;

	mode = (Mode)((settings >> 16) & 0xF);
	event1 = ((settings >> 8) & 0xFF) - 1;
	event2 = (settings & 0xFF) - 1;

	equaliseEvents();

	doStateChange(&daEnEventBlock_c::StateID_Wait);

	return true;
}


int daEnEventBlock_c::onDelete() {
	TileRenderer::List *list = dBgGm_c::instance->getTileRendererList(0);
	list->remove(&tile);

	physics.removeFromList();

	return true;
}


int daEnEventBlock_c::onExecute() {
	acState.execute();
	physics.update();
	blockUpdate();

	tile.setPosition(pos.x-8, -(16+pos.y), pos.z);
	tile.setVars(scale.x);

	equaliseEvents();

	bool isActive = dFlagMgr_c::instance->active(event2);

	tile.tileNumber = (isActive ? 0x96 : 0x97);

	// now check zone bounds based on state
	if (acState.getCurrentState()->isEqual(&StateID_Wait)) {
		checkZoneBoundaries(0);
	}

	return true;
}


dActor_c *daEnEventBlock_c::build() {

	void *buffer = AllocFromGameHeap1(sizeof(daEnEventBlock_c));
	daEnEventBlock_c *c = new(buffer) daEnEventBlock_c;


	return c;
}


void daEnEventBlock_c::equaliseEvents() {
	if (mode != SWAP_EVENTS)
		return;

	bool f1 = dFlagMgr_c::instance->active(event1);
	bool f2 = dFlagMgr_c::instance->active(event2);

	if (!f1 && !f2) {
		dFlagMgr_c::instance->set(event1, 0, true, false, false);
	}

	if (f1 && f2) {
		dFlagMgr_c::instance->set(event2, 0, false, false, false);
	}
}


void daEnEventBlock_c::blockWasHit(bool isDown) {
	pos.y = initialY;

	if (mode == TOGGLE_EVENT) {
		if (dFlagMgr_c::instance->active(event2))
			dFlagMgr_c::instance->set(event2, 0, false, false, false);
		else
			dFlagMgr_c::instance->set(event2, 0, true, false, false);

	} else if (mode == SWAP_EVENTS) {
		if (dFlagMgr_c::instance->active(event1)) {
			dFlagMgr_c::instance->set(event1, 0, false, false, false);
			dFlagMgr_c::instance->set(event2, 0, true, false, false);
		} else {
			dFlagMgr_c::instance->set(event1, 0, true, false, false);
			dFlagMgr_c::instance->set(event2, 0, false, false, false);
		}
	}

	physics.setup(this, &physicsInfo, 3, currentLayerID);
	physics.addToList();
	
	doStateChange(&StateID_Wait);
}



void daEnEventBlock_c::calledWhenUpMoveExecutes() {
	if (initialY >= pos.y)
		blockWasHit(false);
}

void daEnEventBlock_c::calledWhenDownMoveExecutes() {
	if (initialY <= pos.y)
		blockWasHit(true);
}



void daEnEventBlock_c::beginState_Wait() {
}

void daEnEventBlock_c::endState_Wait() {
}

void daEnEventBlock_c::executeState_Wait() {
	int result = blockResult();

	if (result == 0)
		return;

	if (result == 1) {
		doStateChange(&daEnBlockMain_c::StateID_UpMove);
		anotherFlag = 2;
		isGroundPound = false;
	} else {
		doStateChange(&daEnBlockMain_c::StateID_DownMove);
		anotherFlag = 1;
		isGroundPound = true;
	}
}



//
// processed\../src/msgbox.cpp
//

#include <common.h>
#include <game.h>
#include <sfx.h>
#include "msgbox.h"
#include <profile.h>

const SpriteData MsgBoxManagerSpriteData = {ProfileId::AC_MSG_WINDOW, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile MsgBoxManagerProfile(&dMsgBoxManager_c::build, SpriteId::AC_MSG_WINDOW, &MsgBoxManagerSpriteData, ProfileId::EN_LIFT_ROTATION_HALF, ProfileId::AC_MSG_WINDOW, "AC_MSG_WINDOW", NULL, 0x2);

dMsgBoxManager_c *dMsgBoxManager_c::instance = 0;
dActor_c *dMsgBoxManager_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dMsgBoxManager_c));
	dMsgBoxManager_c *c = new(buffer) dMsgBoxManager_c;

	instance = c;
	return c;
}

#define ANIM_BOX_APPEAR 0
#define ANIM_BOX_DISAPPEAR 1

extern int MessageBoxIsShowing;

/*****************************************************************************/
// Events
int dMsgBoxManager_c::onCreate() {
	if (!layoutLoaded) {
		if (!layout.loadArc("msgbox.arc", false))
			return false;

		static const char *brlanNames[2] = {
			"BoxAppear.brlan",
			"BoxDisappear.brlan",
		};

		static const char *groupNames[2] = {
			"G_Box", "G_Box",
		};

		layout.build("MessageBox.brlyt");

		if (IsWideScreen()) {
			layout.layout.rootPane->scale.x = 0.7711f;
		}

		layout.loadAnimations(brlanNames, 2);
		layout.loadGroups(groupNames, (int[2]){0,1}, 2);
		layout.disableAllAnimations();

		layout.drawOrder = 140;

		layoutLoaded = true;
	}

	visible = false;

	return true;
}

int dMsgBoxManager_c::onExecute() {
	state.execute();

	layout.execAnimations();
	layout.update();

	return true;
}

int dMsgBoxManager_c::onDraw() {
	if (visible) {
		layout.scheduleForDrawing();
	}

	return true;
}

int dMsgBoxManager_c::onDelete() {
	instance = 0;

	MessageBoxIsShowing = false;
	if (canCancel && StageC4::instance)
		StageC4::instance->_1D = 0; // disable no-pause
	msgDataLoader.unload();

	return layout.free();
}

/*****************************************************************************/
// Load Resources
CREATE_STATE_E(dMsgBoxManager_c, LoadRes);

void dMsgBoxManager_c::executeState_LoadRes() {
	if (msgDataLoader.load("/Messages.bin")) {
		state.setState(&StateID_Wait);
	} else {
	}
}

/*****************************************************************************/
// Waiting
CREATE_STATE_E(dMsgBoxManager_c, Wait);

void dMsgBoxManager_c::executeState_Wait() {
	// null
}

/*****************************************************************************/
// Show Box
void dMsgBoxManager_c::showMessage(int id, bool canCancel, int delay) {
	if (!this) {
		OSReport("ADD A MESSAGE BOX MANAGER YOU MORON\n");
		return;
	}

	// get the data file
	header_s *data = (header_s*)msgDataLoader.buffer;

	const wchar_t *title = 0, *msg = 0;

	for (int i = 0; i < data->count; i++) {
		if (data->entry[i].id == id) {
			title = (const wchar_t*)((u32)data + data->entry[i].titleOffset);
			msg = (const wchar_t*)((u32)data + data->entry[i].msgOffset);
			break;
		}
	}

	if (title == 0) {
		OSReport("Message Box: Message %08x not found\n", id);
		return;
	}

	layout.findTextBoxByName("T_title")->SetString(title);
	layout.findTextBoxByName("T_msg")->SetString(msg);
	layout.findTextBoxByName("T_msgS")->SetString(msg);

	this->canCancel = canCancel;
	this->delay = delay;
	layout.findPictureByName("button")->SetVisible(canCancel);

	state.setState(&StateID_BoxAppearWait);
}


CREATE_STATE(dMsgBoxManager_c, BoxAppearWait);

void dMsgBoxManager_c::beginState_BoxAppearWait() {
	visible = true;
	MessageBoxIsShowing = true;
	StageC4::instance->_1D = 1; // enable no-pause
	layout.enableNonLoopAnim(ANIM_BOX_APPEAR);

	nw4r::snd::SoundHandle handle;
	PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_SYS_KO_DIALOGUE_IN, 1);
}

void dMsgBoxManager_c::executeState_BoxAppearWait() {
	if (!layout.isAnimOn(ANIM_BOX_APPEAR)) {
		state.setState(&StateID_ShownWait);
	}
}

void dMsgBoxManager_c::endState_BoxAppearWait() { }

/*****************************************************************************/
// Wait For Player To Finish
CREATE_STATE(dMsgBoxManager_c, ShownWait);

void dMsgBoxManager_c::beginState_ShownWait() { }
void dMsgBoxManager_c::executeState_ShownWait() {
	if (canCancel) {
		int nowPressed = Remocon_GetPressed(GetActiveRemocon());

		if (nowPressed & WPAD_TWO || nowPressed & WPAD_A)
			state.setState(&StateID_BoxDisappearWait);
	}

	if (delay > 0) {
		delay--;
		if (delay == 0)
			state.setState(&StateID_BoxDisappearWait);
	}
}
void dMsgBoxManager_c::endState_ShownWait() { }

/*****************************************************************************/
// Hide Box
CREATE_STATE(dMsgBoxManager_c, BoxDisappearWait);

void dMsgBoxManager_c::beginState_BoxDisappearWait() {
	layout.enableNonLoopAnim(ANIM_BOX_DISAPPEAR);

	nw4r::snd::SoundHandle handle;
	PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_SYS_DIALOGUE_OUT_AUTO, 1);
}

void dMsgBoxManager_c::executeState_BoxDisappearWait() {
	if (!layout.isAnimOn(ANIM_BOX_DISAPPEAR)) {
		state.setState(&StateID_Wait);

		for (int i = 0; i < 2; i++)
			layout.resetAnim(i);
		layout.disableAllAnimations();
	}
}

void dMsgBoxManager_c::endState_BoxDisappearWait() {
	visible = false;
	MessageBoxIsShowing = false;
	if (canCancel && StageC4::instance)
		StageC4::instance->_1D = 0; // disable no-pause
}



/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/


class daEnMsgBlock_c : public daEnBlockMain_c {
public:
	TileRenderer tile;
	Physics::Info physicsInfo;

	int onCreate();
	int onDelete();
	int onExecute();

	void calledWhenUpMoveExecutes();
	void calledWhenDownMoveExecutes();

	void blockWasHit(bool isDown);

	USING_STATES(daEnMsgBlock_c);
	DECLARE_STATE(Wait);

	static dActor_c *build();
};


CREATE_STATE(daEnMsgBlock_c, Wait);


int daEnMsgBlock_c::onCreate() {
	blockInit(pos.y);

	physicsInfo.x1 = -8;
	physicsInfo.y1 = 16;
	physicsInfo.x2 = 8;
	physicsInfo.y2 = 0;

	physicsInfo.otherCallback1 = &daEnBlockMain_c::OPhysicsCallback1;
	physicsInfo.otherCallback2 = &daEnBlockMain_c::OPhysicsCallback2;
	physicsInfo.otherCallback3 = &daEnBlockMain_c::OPhysicsCallback3;

	physics.setup(this, &physicsInfo, 3, currentLayerID);
	physics.flagsMaybe = 0x260;
	physics.callback1 = &daEnBlockMain_c::PhysicsCallback1;
	physics.callback2 = &daEnBlockMain_c::PhysicsCallback2;
	physics.callback3 = &daEnBlockMain_c::PhysicsCallback3;
	physics.addToList();

	TileRenderer::List *list = dBgGm_c::instance->getTileRendererList(0);
	list->add(&tile);

	tile.x = pos.x - 8;
	tile.y = -(16 + pos.y);
	tile.tileNumber = 0x98;

	doStateChange(&daEnMsgBlock_c::StateID_Wait);

	return true;
}


int daEnMsgBlock_c::onDelete() {
	TileRenderer::List *list = dBgGm_c::instance->getTileRendererList(0);
	list->remove(&tile);

	physics.removeFromList();

	return true;
}


int daEnMsgBlock_c::onExecute() {
	acState.execute();
	physics.update();
	blockUpdate();

	tile.setPosition(pos.x-8, -(16+pos.y), pos.z);
	tile.setVars(scale.x);

	// now check zone bounds based on state
	if (acState.getCurrentState()->isEqual(&StateID_Wait)) {
		checkZoneBoundaries(0);
	}

	return true;
}

const SpriteData MsgBoxSpriteData = {ProfileId::EN_MSG_BLOCK, 16, -16 , 0 , 0, 0x100, 0x100, 0, 0, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile MsgBoxProfile(&daEnMsgBlock_c::build, SpriteId::EN_MSG_BLOCK, &MsgBoxSpriteData, ProfileId::EN_BLUR, ProfileId::EN_MSG_BLOCK, "EN_MSG_BLOCK", NULL, 0x2);

dActor_c *daEnMsgBlock_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daEnMsgBlock_c));
	return new(buffer) daEnMsgBlock_c;
}


void daEnMsgBlock_c::blockWasHit(bool isDown) {
	pos.y = initialY;

	if (dMsgBoxManager_c::instance)
		dMsgBoxManager_c::instance->showMessage(settings);
	else
		Delete(false);

	physics.setup(this, &physicsInfo, 3, currentLayerID);
	physics.addToList();

	doStateChange(&StateID_Wait);
}



void daEnMsgBlock_c::calledWhenUpMoveExecutes() {
	if (initialY >= pos.y)
		blockWasHit(false);
}

void daEnMsgBlock_c::calledWhenDownMoveExecutes() {
	if (initialY <= pos.y)
		blockWasHit(true);
}



void daEnMsgBlock_c::beginState_Wait() {
}

void daEnMsgBlock_c::endState_Wait() {
}

void daEnMsgBlock_c::executeState_Wait() {
	int result = blockResult();

	if (result == 0)
		return;

	if (result == 1) {
		doStateChange(&daEnBlockMain_c::StateID_UpMove);
		anotherFlag = 2;
		isGroundPound = false;
	} else {
		doStateChange(&daEnBlockMain_c::StateID_DownMove);
		anotherFlag = 1;
		isGroundPound = true;
	}
}



//
// processed\../src/growup.cpp
//

#include <game.h>
#include <profile.h>

// 80a6a1c0
void newSpawnGoombaFromMegaGoomba(dEn_c *megaGoomba) {
    Vec childPos = megaGoomba->pos;
    u32 spriteTexValue = megaGoomba->settings >> 24 & 0xF;
    u32 backFenceThing = megaGoomba->appearsOnBackFence << 0x10;
    childPos.x += 4.0;
    dStageActor_c::create(ProfileId::EN_KURIBO, backFenceThing | (spriteTexValue << 24) | 4, &childPos, 0, 0);
    childPos.x -= 8.0;
    dStageActor_c::create(ProfileId::EN_KURIBO, backFenceThing | (spriteTexValue << 24) | 0x100004, &childPos, 0, 0);
}

// 80a6a260
void newSpawnGoombaFromMegaGoomba2(dEn_c *megaGoomba) {
    Vec childPos = megaGoomba->pos;
    u32 spriteTexValue = megaGoomba->settings >> 24 & 0xF;
    u32 backFenceThing = megaGoomba->appearsOnBackFence << 0x10;
    childPos.x += 4.0;
    dStageActor_c::create(ProfileId::EN_KURIBO, backFenceThing | (spriteTexValue << 24) | 5, &childPos, 0, 0);
    childPos.x -= 8.0;
    dStageActor_c::create(ProfileId::EN_KURIBO, backFenceThing | (spriteTexValue << 24) | 0x100005, &childPos, 0, 0);
}

// 80a5aa60
void newSpawnMegaGoombaFromLargeGoomba(dEn_c *largeGoomba) {
    Vec childPos = largeGoomba->pos;
    u32 spriteTexValue = largeGoomba->settings >> 24 & 0xF;
    u32 backFenceThing = largeGoomba->appearsOnBackFence << 0x10;
    childPos.x += 9.0;
    dStageActor_c::create(ProfileId::EN_MIDDLE_KURIBO, backFenceThing | (spriteTexValue << 24) | 0x10000000, &childPos, 0, 0);
    childPos.x -= 18.0;
    dStageActor_c::create(ProfileId::EN_MIDDLE_KURIBO, backFenceThing | (spriteTexValue << 24) | 0x10100000, &childPos, 0, 0);
}

// 80a5aaf0
void newSpawnGoombaFromLargeGoomba(dEn_c *largeGoomba) {
    Vec childPos[4];
    childPos[0] = (Vec){largeGoomba->pos.x + 8.0, largeGoomba->pos.y + 16.0, largeGoomba->pos.z};
    childPos[1] = (Vec){largeGoomba->pos.x - 8.0, largeGoomba->pos.y + 16.0, largeGoomba->pos.z};
    childPos[2] = (Vec){largeGoomba->pos.x + 8.0, largeGoomba->pos.y, largeGoomba->pos.z};
    childPos[3] = (Vec){largeGoomba->pos.x - 8.0, largeGoomba->pos.y, largeGoomba->pos.z};
    u32 spriteTexValue = largeGoomba->settings >> 24 & 0xF;
    u32 backFenceThing = largeGoomba->appearsOnBackFence << 0x10;
    dStageActor_c::create(ProfileId::EN_KURIBO, backFenceThing | (spriteTexValue << 24) | 5, &childPos[0], 0, 0);
    dStageActor_c::create(ProfileId::EN_KURIBO, backFenceThing | (spriteTexValue << 24) | 0x100005, &childPos[1], 0, 0);
    dStageActor_c::create(ProfileId::EN_KURIBO, backFenceThing | (spriteTexValue << 24) | 0x200005, &childPos[2], 0, 0);
    dStageActor_c::create(ProfileId::EN_KURIBO, backFenceThing | (spriteTexValue << 24) | 0x300005, &childPos[3], 0, 0);
}
//
// processed\../src/eventlooper.cpp
//

#include <common.h>
#include <game.h>
#include <profile.h>

class EventLooper : public dStageActor_c {
    u64 eventFlag;	// 0x3D0
	u64 eventActive;	// 0x3D0
	u8 delay;		// 0x3D4
	u8 delayCount;	// 0x3D7

    int onCreate();
    int onExecute();

    public: static dActor_c *build();
};

const SpriteData EventLooperSpriteData = {ProfileId::AC_EVENT_LOOPER, 8, 0xFFFFFFF0, 0, 0x10, 8, 0x10, 0, 0, 0, 0, 2};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile EventLooperProfile(&EventLooper::build, SpriteId::AC_EVENT_LOOPER, &EventLooperSpriteData, ProfileId::EN_HELPOS, ProfileId::AC_EVENT_LOOPER, "AC_EVENT_LOOPER");

dActor_c* EventLooper::build() {
    void* buffer = AllocFromGameHeap1(sizeof(EventLooper));
    return new(buffer) EventLooper;
}

int EventLooper::onCreate() {
    char eventStart	= (this->settings >> 24)	& 0xFF;
	char eventEnd	= (this->settings >> 16)	& 0xFF;

	// Putting all the events into the flag
	int i;
	u64 q = (u64)0;
	for(i=eventStart;i<(eventEnd+1);i++)
	{
		q = q | ((u64)1 << (i - 1));
	}
		
	this->eventFlag = q;
	
	this->delay		= (((this->settings) & 0xFF) + 1) * 10;
	this->delayCount = 0;
	
	char tmpEvent= (this->settings >> 8)	& 0xFF;
	if (tmpEvent == 0)
	{
		this->eventActive = (u64)0xFFFFFFFFFFFFFFFF;
	}
	else
	{
		this->eventActive = (u64)1 << (tmpEvent - 1);
		
	}
	

	if (dFlagMgr_c::instance->flags & this->eventActive)
	{
		u64 evState = (u64)1 << (eventStart - 1);
		dFlagMgr_c::instance->flags |= evState;
	}

	onExecute();
	
	return true;
}

int EventLooper::onExecute() {
    if ((dFlagMgr_c::instance->flags & this->eventActive) == 0)
		return true;

	// Waiting for the right moment
	if (this->delayCount < this->delay) 
	{

		this->delayCount = this->delayCount + 1;
		return true;
	}	
	
	// Reset the delay
	this->delayCount = 0;
	
	// Find which event(s) is/are on
	u64 evState = dFlagMgr_c::instance->flags & this->eventFlag;
	
	// Turn off the old events
	dFlagMgr_c::instance->flags = dFlagMgr_c::instance->flags & (~this->eventFlag);
	
	// Shift them right if they can, if not, reset!
	evState = evState << 1;
	if (evState < this->eventFlag)
	{
		dFlagMgr_c::instance->flags = dFlagMgr_c::instance->flags | evState;
	}
	
	else
	{
		char eventStart	= (this->settings >> 24)	& 0xFF;
		evState = (u64)1 << (eventStart - 1);
		dFlagMgr_c::instance->flags = dFlagMgr_c::instance->flags | evState;
	}

    return true;
}
//
// processed\../src/spritespawner.cpp
//

#include <game.h>
#include <profile.h>

class dSpriteSpawner_c : public dStageActor_c {
	public:
		static dActor_c *build();

		u64 classicEventOverride;
		u32 profileID;
		bool respawn;
		u32 childSettings;
		u32 childID;

		int onCreate();
		int onExecute();
};

/*****************************************************************************/
// Glue Code

const char *SpriteSpawnerFileList[] = {0};
const SpriteData SpriteSpawnerSpriteData = { ProfileId::AC_SPAWNER, 0x10, 0xFFFFFFF0, 0 , 0, 0x18, 0x18, 0, 0, 0, 0, 0 };
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile SpriteSpawnerProfile(&dSpriteSpawner_c::build, SpriteId::AC_SPAWNER, &SpriteSpawnerSpriteData, ProfileId::EN_BOYON, ProfileId::AC_SPAWNER, "AC_SPAWNER", SpriteSpawnerFileList);

dActor_c *dSpriteSpawner_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dSpriteSpawner_c));
	dSpriteSpawner_c *c = new(buffer) dSpriteSpawner_c;
	return c;
}


int dSpriteSpawner_c::onCreate() {
	char classicEventNum = (settings >> 28) & 0xF;
	classicEventOverride = (classicEventNum == 0) ? 0 : ((u64)1 << (classicEventNum - 1));

	profileID = ((settings >> 16) & 0x7FF);
	respawn = (settings >> 27) & 1;

	u16 tempSet = settings & 0xFFFF;
	childSettings =
		(tempSet & 3) | ((tempSet & 0xC) << 2) |
		((tempSet & 0x30) << 4) | ((tempSet & 0xC0) << 6) |
		((tempSet & 0x300) << 8) | ((tempSet & 0xC00) << 10) |
		((tempSet & 0x3000) << 12) | ((tempSet & 0xC000) << 14);
	#if defined(REGION_KW) //adjust actor id!
		if (profileID > 701) {
			profileID = profileID + 2;
		}
	#endif
	return true;
}


int dSpriteSpawner_c::onExecute() {
	u64 effectiveFlag = classicEventOverride | spriteFlagMask;

	if (dFlagMgr_c::instance->flags & effectiveFlag) {
		if (!childID) {
			dStageActor_c *newAc = dStageActor_c::create(profileID, childSettings, &pos, 0, 0);
			childID = newAc->id;
		}
	} else {
		if (respawn)
			return true;

		if (childID) {
			dStageActor_c *ac = (dStageActor_c*)fBase_c::searchById(childID);
			if (ac) {
				pos = ac->pos;
				ac->Delete(1);
			}
			childID = 0;
		}
	}

	if (respawn) {
		if (childID) {
			dStageActor_c *ac = (dStageActor_c*)fBase_c::searchById(childID);

			if (!ac) {
				dStageActor_c *newAc = dStageActor_c::create(profileID, childSettings, &pos, 0, 0);
				childID = newAc->id;
			}
		}
	}

	return true;

}


//
// processed\../src/spriteswapper.cpp
//

#include <common.h>
#include <game.h>
#include <profile.h>

class SpriteSpawnerTimed : public dStageActor_c {
public:
	int onCreate();
	int onExecute();

	static dActor_c *build();

	u64 eventFlag;	// 0x3D0
	u16 type;		// 0x3D4
	u32 inheritSet;	// 0x3D6
	u8 lastEvState;	// 0x3DA
	u32 timer;
};

const char *SpriteSwapperFileList[] = {0};
const SpriteData SpriteSwapperSpriteData = { ProfileId::AC_SPAWNER_TIMED, 0, 0, 0, 0, 4, 4, 0, 0, 0, 0, 8};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile SpriteSwapperProfile(&SpriteSpawnerTimed::build, SpriteId::AC_SPAWNER_TIMED, &SpriteSwapperSpriteData, ProfileId::EN_REMOCON_TORIMOCHI, ProfileId::AC_SPAWNER_TIMED, "AC_SPAWNER_TIMED", SpriteSwapperFileList);

dActor_c *SpriteSpawnerTimed::build() {
	void *buffer = AllocFromGameHeap1(sizeof(SpriteSpawnerTimed));
	return new(buffer) SpriteSpawnerTimed;
}



int SpriteSpawnerTimed::onCreate() {

	char eventNum	= (this->settings >> 28)	& 0xF;

	this->eventFlag = (u64)1 << (eventNum - 1);
	this->type		= (this->settings >> 16) & 0xFFF;
	
	short tempSet = this->settings & 0xFFFF;
	this->inheritSet = (tempSet & 3) | ((tempSet & 0xC) << 2) | ((tempSet & 0x30) << 4) | ((tempSet & 0xC0) << 6) | ((tempSet & 0x300) << 8) | ((tempSet & 0xC00) << 10) | ((tempSet & 0x3000) << 12) | ((tempSet & 0xC000) << 14);
	
	this->timer = 0;
	#if defined(REGION_KW) //adjust actor id!
		if (type > 701) {
			type = type + 2;
		}
	#endif
	return true;
}

int SpriteSpawnerTimed::onExecute() {

	if (dFlagMgr_c::instance->flags & this->eventFlag) {		 // If the event is on
		if (this->timer < 1) {						// If the timer is empty
			CreateActor(this->type, this->inheritSet, this->pos, 0, 0);
			this->timer = 120;
		}		

		this->timer--;
	}

	else {
		this->timer = 0;
	}

	return true;
}

//
// processed\../src/topman.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include <profile.h>

const char* TMarcNameList [] = {
	"topman",
	NULL	
};

class daTopman : public dEn_c {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;

	m3d::mdl_c bodyModel;

	m3d::anmChr_c chrAnimation;

	int timer;
	char damage;
	char isDown;
	float XSpeed;
	u32 cmgr_returnValue;
	bool isBouncing;
	char isInSpace;
	char fromBehind;
	char isWaiting;
	char backFire;
	int directionStore;

	public: static dActor_c *build();

	void bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate);
	void updateModelMatrices();
	bool calculateTileCollisions();

	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	// bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);

	void _vf148();
	void _vf14C();
	bool CreateIceActors();
	void addScoreWhenHit(void *other);

	USING_STATES(daTopman);
	DECLARE_STATE(Walk);
	DECLARE_STATE(Turn);
	DECLARE_STATE(Wait);
	DECLARE_STATE(KnockBack);
	DECLARE_STATE(Die);
};


const SpriteData TopmanSpriteData = {ProfileId::EN_TOPMAN, 8, -8 , 0 , 0, 0x100, 0x100, 0, 0, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile TopmanProfile(&daTopman::build, SpriteId::EN_TOPMAN, &TopmanSpriteData, ProfileId::TARZAN_ROPE, ProfileId::EN_TOPMAN, "EN_TOPMAN", TMarcNameList, 0x12);

dActor_c *daTopman::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daTopman));
	return new(buffer) daTopman;
}

///////////////////////
// Externs and States
///////////////////////
	extern "C" void *EN_LandbarrelPlayerCollision(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);

	//FIXME make this dEn_c->used...
	extern "C" char usedForDeterminingStatePress_or_playerCollision(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther, int unk1);
	extern "C" int SmoothRotation(short* rot, u16 amt, int unk2);


	CREATE_STATE(daTopman, Walk);
	CREATE_STATE(daTopman, Turn);
	CREATE_STATE(daTopman, Wait);
	CREATE_STATE(daTopman, KnockBack);
	CREATE_STATE(daTopman, Die);

	// 	begoman_attack2"	// wobble back and forth tilted forwards
	// 	begoman_attack3"	// Leaned forward, antennae extended
	// 	begoman_damage"		// Bounces back slightly
	// 	begoman_damage2"	// Stops spinning and wobbles to the ground like a top
	// 	begoman_stand"		// Stands still, waiting
	// 	begoman_wait"		// Dizzily Wobbles
	// 	begoman_wait2"		// spins around just slightly
	// 	begoman_attack"		// Rocks backwards, and then attacks to an upright position, pulsing out his antennae


////////////////////////
// Collision Functions
////////////////////////

	// Collision callback to help shy guy not die at inappropriate times and ruin the dinner

	void daTopman::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {

		char hitType;
		hitType = usedForDeterminingStatePress_or_playerCollision(this, apThis, apOther, 0);

		if(hitType == 1 || hitType == 2) {	// regular jump or mini jump
			this->_vf220(apOther->owner);
		} 
		else if(hitType == 3) {	// spinning jump or whatever?
			this->_vf220(apOther->owner);
		} 
		else if(hitType == 0) {
			EN_LandbarrelPlayerCollision(this, apThis, apOther);
			if (this->pos.x > apOther->owner->pos.x) {
				this->backFire = 1;
			}
			else {
				this->backFire = 0;
			}
			doStateChange(&StateID_KnockBack);
		} 

		// fix multiple player collisions via megazig
		deathInfo.isDead = 0;
		this->flags_4FC |= (1<<(31-7));
		this->counter_504[apOther->owner->which_player] = 0;
	}

	void daTopman::yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
		this->playerCollision(apThis, apOther);
	}

	bool daTopman::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) {
		this->dEn_c::playerCollision(apThis, apOther);
		this->_vf220(apOther->owner);

		deathInfo.isDead = 0;
		this->flags_4FC |= (1<<(31-7));
		this->counter_504[apOther->owner->which_player] = 0;
		return true;
	}

	bool daTopman::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
		this->collisionCatD_Drill(apThis, apOther);
		return true;
	}

	bool daTopman::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) {
		this->collisionCatD_Drill(apThis, apOther);
		return true;
	}

	bool daTopman::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
		backFire = apOther->owner->direction ^ 1;
		// doStateChange(&StateID_KnockBack);
		doStateChange(&StateID_Die);
		return true;
	}

	bool daTopman::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther){
		doStateChange(&StateID_Die);
		return true;
	}

	bool daTopman::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
		doStateChange(&StateID_Die);
		return true;
	}

	bool daTopman::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther){
		backFire = apOther->owner->direction ^ 1;
		doStateChange(&StateID_KnockBack);
		return true;
	}

	bool daTopman::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther){
		backFire = apOther->owner->direction ^ 1;
		doStateChange(&StateID_KnockBack);
		return true;
	}

	bool daTopman::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
		backFire = apOther->owner->direction ^ 1;
		doStateChange(&StateID_KnockBack);
		return true;
	}

	// void daTopman::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) {
	// 	doStateChange(&StateID_DieFall);
	// }

	// These handle the ice crap
	void daTopman::_vf148() {
		dEn_c::_vf148();
		doStateChange(&StateID_Die);
	}
	void daTopman::_vf14C() {
		dEn_c::_vf14C();
		doStateChange(&StateID_Die);
	}

	DoSomethingCool my_struct;

	extern "C" void sub_80024C20(void);
	extern "C" void __destroy_arr(void*, void(*)(void), int, int);
	//extern "C" __destroy_arr(struct DoSomethingCool, void(*)(void), int cnt, int bar);

	bool daTopman::CreateIceActors()
	{
	    struct DoSomethingCool my_struct = { 0, this->pos, {2.5, 2.5, 2.5}, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
	    this->frzMgr.Create_ICEACTORs( (void*)&my_struct, 1 );
	    __destroy_arr( (void*)&my_struct, sub_80024C20, 0x3C, 1 );
	    return true;
	}

	void daTopman::addScoreWhenHit(void *other) {}


bool daTopman::calculateTileCollisions() {
	// Returns true if sprite should turn, false if not.

	HandleXSpeed();
	HandleYSpeed();
	doSpriteMovement();

	cmgr_returnValue = collMgr.isOnTopOfTile();
	collMgr.calculateBelowCollisionWithSmokeEffect();

	if (isBouncing) {
		stuffRelatingToCollisions(0.1875f, 1.0f, 0.5f);
		if (speed.y != 0.0f)
			isBouncing = false;
	}

	float xDelta = pos.x - last_pos.x;
	if (xDelta >= 0.0f)
		direction = 0;
	else
		direction = 1;

	if (collMgr.isOnTopOfTile()) {
		// Walking into a tile branch

		if (cmgr_returnValue == 0)
			isBouncing = true;

		if (speed.x != 0.0f) {
			//playWmEnIronEffect();
		}

		speed.y = 0.0f;

		// u32 blah = collMgr.s_80070760();
		// u8 one = (blah & 0xFF);
		// static const float incs[5] = {0.00390625f, 0.0078125f, 0.015625f, 0.0234375f, 0.03125f};
		// x_speed_inc = incs[one];
		max_speed.x = (direction == 1) ? -0.8f : 0.8f;
	} else {
		x_speed_inc = 0.0f;
	}

	// Bouncing checks
	if (_34A & 4) {
		Vec v = (Vec){0.0f, 1.0f, 0.0f};
		collMgr.pSpeed = &v;

		if (collMgr.calculateAboveCollision(collMgr.outputMaybe))
			speed.y = 0.0f;

		collMgr.pSpeed = &speed;

	} else {
		if (collMgr.calculateAboveCollision(collMgr.outputMaybe))
			speed.y = 0.0f;
	}

	collMgr.calculateAdjacentCollision(0);

	// Switch Direction
	if (collMgr.outputMaybe & (0x15 << direction)) {
		if (collMgr.isOnTopOfTile()) {
			isBouncing = true;
		}
		return true;
	}
	return false;
}

void daTopman::bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate) {
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr(name);
	this->chrAnimation.bind(&this->bodyModel, anmChr, unk);
	this->bodyModel.bindAnim(&this->chrAnimation, unk2);
	this->chrAnimation.setUpdateRate(rate);
}

int daTopman::onCreate() {

	this->deleteForever = true;
	
	// Model creation	
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	this->resFile.data = getResource("topman", "g3d/begoman_spike.brres");
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("begoman");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&this->bodyModel, 0);


	// Animations start here
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr("begoman_wait");
	this->chrAnimation.setup(mdl, anmChr, &this->allocator, 0);

	allocator.unlink();

	// Stuff I do understand
	this->scale = (Vec){0.2, 0.2, 0.2};

	// this->pos.y = this->pos.y + 30.0; // X is vertical axis
	this->rot.x = 0; // X is vertical axis
	this->rot.y = 0xD800; // Y is horizontal axis
	this->rot.z = 0; // Z is ... an axis >.>
	this->direction = 1; // Heading left.
	
	this->speed.x = 0.0;
	this->speed.y = 0.0;
	this->max_speed.x = 0.8;
	this->x_speed_inc = 0.0;
	this->XSpeed = 0.8;

	this->isInSpace = this->settings & 0xF;
	this->isWaiting = (this->settings >> 4) & 0xF;
	this->fromBehind = 0;

	ActivePhysics::Info HitMeBaby;

	HitMeBaby.xDistToCenter = 0.0;
	HitMeBaby.yDistToCenter = 12.0;

	HitMeBaby.xDistToEdge = 14.0;
	HitMeBaby.yDistToEdge = 12.0;		

	HitMeBaby.category1 = 0x3;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x4F;
	HitMeBaby.bitfield2 = 0xffbafffe;
	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();


	// Tile collider

	// These fucking rects do something for the tile rect
	spriteSomeRectX = 28.0f;
	spriteSomeRectY = 32.0f;
	_320 = 0.0f;
	_324 = 16.0f;

	static const lineSensor_s below(12<<12, 4<<12, 0<<12);
	static const pointSensor_s above(0<<12, 12<<12);
	static const lineSensor_s adjacent(6<<12, 9<<12, 14<<12);

	collMgr.init(this, &below, &above, &adjacent);
	collMgr.calculateBelowCollisionWithSmokeEffect();

	cmgr_returnValue = collMgr.isOnTopOfTile();

	if (collMgr.isOnTopOfTile())
		isBouncing = false;
	else
		isBouncing = true;


	// State Changers
	bindAnimChr_and_setUpdateRate("begoman_wait2", 1, 0.0, 1.0); 
	if (this->isWaiting == 0) {
		doStateChange(&StateID_Walk); }
	else {
		doStateChange(&StateID_Wait); }

	this->onExecute();
	return true;
}

int daTopman::onDelete() {
	return true;
}

int daTopman::onExecute() {
	acState.execute();
	updateModelMatrices();
	
	float rect[] = {0.0, 0.0, 38.0, 38.0};
	int ret = this->outOfZone(this->pos, (float*)&rect, this->currentZoneID);
	if(ret) {
		this->Delete(1);
	}
	return true;
}

int daTopman::onDraw() {
	bodyModel.scheduleForDrawing();

	return true;
}

void daTopman::updateModelMatrices() {
	matrix.translation(pos.x, pos.y - 2.0, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}


///////////////
// Walk State
///////////////
	void daTopman::beginState_Walk() {
		this->max_speed.x = (this->direction) ? -this->XSpeed : this->XSpeed;
		this->speed.x = (direction) ? -0.8f : 0.8f;

		this->max_speed.y = (this->isInSpace) ? -2.0 : -4.0;
		this->speed.y = 	(this->isInSpace) ? -2.0 : -4.0;
		this->y_speed_inc = (this->isInSpace) ? -0.09375 : -0.1875;
	}
	void daTopman::executeState_Walk() { 

		if (!this->isOutOfView()) {
			nw4r::snd::SoundHandle *handle = PlaySound(this, SE_BOSS_JR_CROWN_JR_RIDE);
			if (handle)
				handle->SetVolume(0.5f, 0); 
		}
	
		bool ret = calculateTileCollisions();
		if (ret) {
			doStateChange(&StateID_Turn);
		}
		bodyModel._vf1C();

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}
	}
	void daTopman::endState_Walk() { this->timer += 1; }


///////////////
// Turn State
///////////////
	void daTopman::beginState_Turn() {
		this->direction ^= 1;
		this->speed.x = 0.0;
	}
	void daTopman::executeState_Turn() { 

		bodyModel._vf1C();
		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}

		u16 amt = (this->direction == 0) ? 0x2800 : 0xD800;
		int done = SmoothRotation(&this->rot.y, amt, 0x800);

		if(done) {
			this->doStateChange(&StateID_Walk);
		}
	}
	void daTopman::endState_Turn() { }


///////////////
// Wait State
///////////////
	void daTopman::beginState_Wait() {
		this->max_speed.x = 0;
		this->speed.x = 0;

		this->max_speed.y = (this->isInSpace) ? -2.0 : -4.0;
		this->speed.y = 	(this->isInSpace) ? -2.0 : -4.0;
		this->y_speed_inc = (this->isInSpace) ? -0.09375 : -0.1875;
	}
	void daTopman::executeState_Wait() { 

		if (!this->isOutOfView()) {
			nw4r::snd::SoundHandle *handle = PlaySound(this, SE_BOSS_JR_CROWN_JR_RIDE);
			if (handle)
				handle->SetVolume(0.5f, 0); 
		}
	
		bool ret = calculateTileCollisions();
		if (ret) {
			doStateChange(&StateID_Turn);
		}

		bodyModel._vf1C();
		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}
	}
	void daTopman::endState_Wait() { }


///////////////
// Die State
///////////////
	void daTopman::beginState_Die() {
		dEn_c::dieFall_Begin();

		bindAnimChr_and_setUpdateRate("begoman_damage2", 1, 0.0, 1.0); 
		this->timer = 0;
	}
	void daTopman::executeState_Die() { 

		bodyModel._vf1C();

		PlaySound(this, SE_EMY_MECHAKOOPA_DAMAGE);
		if(this->chrAnimation.isAnimationDone()) {
			this->kill();
			this->Delete(this->deleteForever);
		}
	}
	void daTopman::endState_Die() { }


///////////////
// Knockback State
///////////////
	void daTopman::beginState_KnockBack() {
		bindAnimChr_and_setUpdateRate("begoman_damage", 1, 0.0, 0.75); 

		directionStore = direction;
		speed.x = (backFire) ? XSpeed*5.0f : XSpeed*-5.0f;
		max_speed.x = speed.x;
	}
	void daTopman::executeState_KnockBack() { 

		bool ret = calculateTileCollisions();
		this->speed.x = this->speed.x / 1.1;

		bodyModel._vf1C();
		if(this->chrAnimation.isAnimationDone()) {
			if (this->isWaiting == 0) {
				OSReport("Done being knocked back, going back to Walk state\n");
				doStateChange(&StateID_Walk); }
			else {
				OSReport("Done being knocked back, going back to Wait state\n");
				doStateChange(&StateID_Wait); }
		}

	}
	void daTopman::endState_KnockBack() { 
		direction = directionStore;
		bindAnimChr_and_setUpdateRate("begoman_wait2", 1, 0.0, 1.0); 
	}
	

//
// processed\../src/bossMegaGoomba.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include "boss.h"
#include <profile.h>

extern "C" void *StageScreen;

const char* MGarcNameList [] = {
	"kuriboBig",
	"kuriboBoss",
	NULL	
};

class daMegaGoomba_c : public dEn_c {
	public:
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;
	m3d::mdl_c bodyModel;
	m3d::anmChr_c animationChr;

	float timer;
	float dying;

	lineSensor_s belowSensor;
	lineSensor_s adjacentSensor;

	ActivePhysics leftTrapAPhysics, rightTrapAPhysics;
	ActivePhysics stalkAPhysics;

	HermiteKey keysX[0x10];
	unsigned int Xkey_count;
	HermiteKey keysY[0x10];
	unsigned int Ykey_count;

	char life;
	bool already_hit;

	float XSpeed;
	float JumpHeight;
	float JumpDist;
	float JumpTime;

	char isBigBoss;
	char isPanic;

	bool takeHit(char count);

	void bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate);
	
	void dieFall_Begin();
	void dieFall_Execute();
	static dActor_c *build();

	void setupBodyModel();
	void setupCollision();

	void updateModelMatrices();

	void stunPlayers();
	void unstunPlayers();

	bool hackOfTheCentury;

	bool playerStunned[4];

	void removeMyActivePhysics();
	void addMyActivePhysics();

	int tryHandleJumpedOn(ActivePhysics *apThis, ActivePhysics *apOther);

	void spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat11_PipeCannon(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	void addScoreWhenHit(void *other);
	bool _vf120(ActivePhysics *apThis, ActivePhysics *apOther);
	bool _vf110(ActivePhysics *apThis, ActivePhysics *apOther);
	bool _vf108(ActivePhysics *apThis, ActivePhysics *apOther);

	void powBlockActivated(bool isNotMPGP);

	void dieOther_Begin();
	void dieOther_Execute();
	void dieOther_End();

	USING_STATES(daMegaGoomba_c);
	DECLARE_STATE(Shrink);
	DECLARE_STATE(Walk);
	DECLARE_STATE(Turn);
};

const SpriteData MegaGoombaSpriteData = {ProfileId::EN_GIGA_GOOMBA, -24, -16, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 2};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile MegaGoombaProfile(&daMegaGoomba_c::build, SpriteId::EN_GIGA_GOOMBA, &MegaGoombaSpriteData, ProfileId::AC_BLOCK_GROUP, ProfileId::EN_GIGA_GOOMBA, "EN_GIGA_GOOMBA", MGarcNameList, 0x18);

dActor_c *daMegaGoomba_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daMegaGoomba_c));
	return new(buffer) daMegaGoomba_c;
}


void daMegaGoomba_c::removeMyActivePhysics() {
	aPhysics.removeFromList();
	stalkAPhysics.removeFromList();
	leftTrapAPhysics.removeFromList();
	rightTrapAPhysics.removeFromList();
}

void daMegaGoomba_c::addMyActivePhysics() {
	aPhysics.addToList();
	stalkAPhysics.addToList();
	leftTrapAPhysics.addToList();
	rightTrapAPhysics.addToList();
}


void setNewActivePhysicsRect(daMegaGoomba_c *actor, Vec *scale) {
	float amtX = scale->x * 0.5f;
	float amtY = scale->y * 0.5f;

	actor->belowSensor.flags = SENSOR_LINE;
	actor->belowSensor.lineA = s32((amtX * -28.0f) * 4096.0f);
	actor->belowSensor.lineB = s32((amtX * 28.0f) * 4096.0f);
	actor->belowSensor.distanceFromCenter = 0;

	actor->adjacentSensor.flags = SENSOR_LINE;
	actor->adjacentSensor.lineA = s32((amtY * 4.0f) * 4096.0f);
	actor->adjacentSensor.lineB = s32((amtY * 32.0f) * 4096.0f);
	actor->adjacentSensor.distanceFromCenter = s32((amtX * 46.0f) * 4096.0f);

	u8 cat1 = 3, cat2 = 0;
	u32 bitfield1 = 0x6f, bitfield2 = 0xffbafffe;

	ActivePhysics::Info info = {
		0.0f, amtY*57.0f, amtX*20.0f, amtY*31.0f,
		cat1, cat2, bitfield1, bitfield2, 0, &dEn_c::collisionCallback};
	actor->aPhysics.initWithStruct(actor, &info);

	// Original trapezium was -12,12 to -48,48
	ActivePhysics::Info left = {
		amtX*-32.0f, amtY*55.0f, amtX*12.0f, amtY*30.0f,
		cat1, cat2, bitfield1, bitfield2, 0, &dEn_c::collisionCallback};
	actor->leftTrapAPhysics.initWithStruct(actor, &left);
	actor->leftTrapAPhysics.trpValue0 = amtX * 12.0f;
	actor->leftTrapAPhysics.trpValue1 = amtX * 12.0f;
	actor->leftTrapAPhysics.trpValue2 = amtX * -12.0f;
	actor->leftTrapAPhysics.trpValue3 = amtX * 12.0f;
	actor->leftTrapAPhysics.collisionCheckType = 3;

	ActivePhysics::Info right = {
		amtX*32.0f, amtY*55.0f, amtX*12.0f, amtY*30.0f,
		cat1, cat2, bitfield1, bitfield2, 0, &dEn_c::collisionCallback};
	actor->rightTrapAPhysics.initWithStruct(actor, &right);
	actor->rightTrapAPhysics.trpValue0 = amtX * -12.0f;
	actor->rightTrapAPhysics.trpValue1 = amtX * -12.0f;
	actor->rightTrapAPhysics.trpValue2 = amtX * -12.0f;
	actor->rightTrapAPhysics.trpValue3 = amtX * 12.0f;
	actor->rightTrapAPhysics.collisionCheckType = 3;

	ActivePhysics::Info stalk = {
		0.0f, amtY*12.0f, amtX*28.0f, amtY*12.0f,
		cat1, cat2, bitfield1, bitfield2, 0, &dEn_c::collisionCallback};
	actor->stalkAPhysics.initWithStruct(actor, &stalk);

}


//FIXME make this dEn_c->used...
extern "C" int SomeStrangeModification(dStageActor_c* actor);
extern "C" void DoStuffAndMarkDead(dStageActor_c *actor, Vec vector, float unk);
extern "C" int SmoothRotation(short* rot, u16 amt, int unk2);

void daMegaGoomba_c::powBlockActivated(bool isNotMPGP) {
}

CREATE_STATE(daMegaGoomba_c, Shrink);
CREATE_STATE(daMegaGoomba_c, Walk);
CREATE_STATE(daMegaGoomba_c, Turn);


//TODO better fix for possible bug with sign (ex. life=120; count=-9;)
bool daMegaGoomba_c::takeHit(char count) {
	OSReport("Taking a hit!\n");
	if(!this->already_hit) {
		int c = count;
		int l = this->life;
		if(l - c > 127) {
			c = 127 - l;
		}
		this->life -= c;
		// this->XSpeed += 0.10;

		// float rate = this->animationChr.getUpdateRate();
		// this->animationChr.setUpdateRate(rate+0.05);
		this->JumpHeight += 12.0;
		this->JumpDist += 12.0;
		this->JumpTime += 5.0;
		doStateChange(&StateID_Shrink);
		this->already_hit = true;
	}
	return (life <= 0) ? true : false;
}

#define ACTIVATE	1
#define DEACTIVATE	0

extern "C" void *EN_LandbarrelPlayerCollision(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);
void daMegaGoomba_c::spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
	//HE'S TOO BADASS TO STOP FOR SMALLER GOOMBAS
	#if 0
		float me = apThis->firstFloatArray[3];
		if(((this->direction == 1) && (me > 0.0)) || ((this->direction == 0) && (me < 0.0))) {
			dStateBase_c* state = this->acState.getCurrentState();
			if(!state->isEqual(&StateID_Turn)) {
				doStateChange(&StateID_Turn);
			}
		}
	#endif
}
void daMegaGoomba_c::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) { 
	if (apThis == &stalkAPhysics) {
		dEn_c::playerCollision(apThis, apOther);
		return;
	}

	/* * * * * * * * * * * * * * * * * * * * *
	 * 0=normal??,1=dontHit,2=dontKill
	 * daEnBrosBase_c ::player = 0
	 * daEnBrosBase_c::yoshi   = 0
	 * daEnPipePirahna::player = 1
	 * daEnPipePirahna::yoshi  = 1
	 * daEnKuriboBase_c::player = 0
	 * daEnKuriboBase_c::yoshi  = 0
	 * daEnLargeKuribo_c::player = 0
	 * daEnLargeKuribo_c::yoshi  = 2
	 * daEnNokonoko_c::player = 0
	 * daEnNokonoko_c::yoshi  = 0
	 * daEnSubBoss_c     = 2
	 *
	 * * * * * * * * * * * * * * * * * * * * */
	//FIXME rename and make part of dStageActor_c
	//unk=0 does _vfs, unk=1 does playSeCmnStep
	//char ret = usedForDeterminingStatePress_or_playerCollision(this, apThis, apOther, 0);

	if (tryHandleJumpedOn(apThis, apOther) == 0) {
		this->dEn_c::playerCollision(apThis, apOther);
		this->_vf220(apOther->owner);
		this->counter_504[apOther->owner->which_player] = 180;
	}
}

int daMegaGoomba_c::tryHandleJumpedOn(ActivePhysics *apThis, ActivePhysics *apOther) {
	float saveBounce = EnemyBounceValue;
	EnemyBounceValue = 5.2f;

	char ret = usedForDeterminingStatePress_or_playerCollision(this, apThis, apOther, 2);

	EnemyBounceValue = saveBounce;

	if(ret == 1 || ret == 3) {
		apOther->someFlagByte |= 2;
		if(this->takeHit(1)) {
			// kill me
			VEC2 eSpeed = {speed.x, speed.y};
			killWithSpecifiedState(apOther->owner, &eSpeed, &dEn_c::StateID_DieOther);
		}
	}

	return ret;
}
bool daMegaGoomba_c::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) { 
	if (this->counter_504[apOther->owner->which_player] > 0) { return false; }
	VEC2 eSpeed = {speed.x, speed.y};
	killWithSpecifiedState(apOther->owner, &eSpeed, &dEn_c::StateID_DieOther);
	return true;
}
bool daMegaGoomba_c::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) { 
	return collisionCat7_GroundPound(apThis, apOther);
}

bool daMegaGoomba_c::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
	return false;
}
bool daMegaGoomba_c::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) {
	return false;
}
extern "C" void dAcPy_vf3F8(void* player, dEn_c* monster, int t);
bool daMegaGoomba_c::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther) {
	if (tryHandleJumpedOn(apThis, apOther) == 0) {
		dAcPy_vf3F8(apOther->owner, this, 3);
		this->counter_504[apOther->owner->which_player] = 0xA;
	}
	return true;
}
bool daMegaGoomba_c::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
	if(this->takeHit(1))
		doStateChange(&StateID_DieFall);
	return true;
}
bool daMegaGoomba_c::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther) {
	if(this->takeHit(1))
		doStateChange(&StateID_DieFall);
	return true;
}
bool daMegaGoomba_c::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) {
	return collisionCat7_GroundPound(apThis, apOther);
}
bool daMegaGoomba_c::collisionCat11_PipeCannon(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true;
}
bool daMegaGoomba_c::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true;
}
bool daMegaGoomba_c::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther) {
	if(this->takeHit(1))
		doStateChange(&StateID_DieFall);
	return true;
}
void daMegaGoomba_c::addScoreWhenHit(void *other) {}
bool daMegaGoomba_c::_vf120(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true; // Replicate existing broken behaviour
}
bool daMegaGoomba_c::_vf110(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true; // Replicate existing broken behaviour
}
bool daMegaGoomba_c::_vf108(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true; // Replicate existing broken behaviour
}

void daMegaGoomba_c::bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate) {
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr(name);
	this->animationChr.bind(&this->bodyModel, anmChr, unk);
	this->bodyModel.bindAnim(&this->animationChr, unk2);
	this->animationChr.setUpdateRate(rate);
}

void daMegaGoomba_c::dieFall_Begin() {
	this->dEn_c::dieFall_Begin();
	PlaySound(this, SE_EMY_KURIBO_L_DAMAGE_03);
}
void daMegaGoomba_c::dieFall_Execute() {
	
	this->timer = this->timer + 1.0;
	
	this->dying = this->dying + 0.15;
	
	this->pos.x = this->pos.x + 0.15;
	this->pos.y = this->pos.y + ((-0.2 * (this->dying*this->dying)) + 5);
	
	this->dEn_c::dieFall_Execute();
}

void daMegaGoomba_c::setupBodyModel() {
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	this->resFile.data = getResource("kuriboBoss", "g3d/kuriboBoss.brres");
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("kuriboBig");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&bodyModel, 0);

	bool ret;
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr("walk");
	ret = this->animationChr.setup(mdl, anmChr, &this->allocator, 0);
	this->bindAnimChr_and_setUpdateRate("walk", 1, 0.0, 0.2);

	allocator.unlink();
}

void daMegaGoomba_c::setupCollision() {
	//POINTLESS WITH GROWTH
	this->scale.x = this->scale.y = this->scale.z = 0.666;

	this->collMgr.init(this, &belowSensor, 0, &adjacentSensor);

	char foo = this->appearsOnBackFence;
	this->pos_delta2.x = 0.0;
	this->pos_delta2.y = 16.0;
	this->pos_delta2.z = 0.0;

	this->pos.z = (foo == 0) ? 1500.0 : -2500.0;

	this->_518 = 2;

	//NOT NEEDED
	//this->doStateChange(&StateID_Walk);
}

int daMegaGoomba_c::onCreate() {
	/*80033230 daEnLkuribo_c::onCreate()*/
	this->setupBodyModel();
	this->max_speed.y = -4.0;
	this->direction = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);
	this->rot.y = (this->direction) ? 0xE000 : 0x2000;
	this->_518 = 2;

	isBigBoss = this->settings & 0xF;
	this->animationChr.setCurrentFrame(69.0);

	aPhysics.addToList();
	stalkAPhysics.addToList();
	leftTrapAPhysics.addToList();
	rightTrapAPhysics.addToList();

	this->_120 |= 0x200;

	this->_36D = 0;
	this->setupCollision();

	//HOMEMADE//
	speed.y = 0.0;
	dying = 0.0;
	rot.x = rot.z = 0;
	life = 3;
	already_hit = false;
	this->x_speed_inc = 0.1;
	this->pos.y -= 16.0;

	// 2.0 is good final speed
	this->XSpeed = 0.2;
	this->JumpHeight = 48.0;
	this->JumpDist = 64.0;
	this->JumpTime = 50.0;

	// doStateChange(&StateID_Grow);

	scale.x = 4.0f;
	scale.y = 4.0f;
	scale.z = 4.0f;
	setNewActivePhysicsRect(this, &this->scale);
	doStateChange(&StateID_Walk);

	this->onExecute();
	return true;
}

int daMegaGoomba_c::onDelete() {
	unstunPlayers();
	return true;
}

int daMegaGoomba_c::onExecute() {
	//80033450
	acState.execute();
	if (!hackOfTheCentury) {
		hackOfTheCentury = true;
	} else {
		checkZoneBoundaries(0);
	}
	updateModelMatrices();

	return true;
}

int daMegaGoomba_c::onDraw() {
	bodyModel.scheduleForDrawing();
	return true;
}


void daMegaGoomba_c::updateModelMatrices() {
	// This won't work with wrap because I'm lazy.
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}



// Shrink State
void daMegaGoomba_c::beginState_Shrink() {
	this->timer = 1.0;
	Xkey_count = 4;
	keysX[0] = (HermiteKey){  0.0, this->scale.y,        0.5 };
	keysX[1] = (HermiteKey){ 10.0, this->scale.y - 0.75, 0.5 };
	keysX[2] = (HermiteKey){ 20.0, this->scale.y - 0.35, 0.5 };
	keysX[3] = (HermiteKey){ 39.0, this->scale.y - 0.75, 0.5 };

	// disable being hit
	Vec tempVec = (Vec){0.0, 0.0, 0.0};
	setNewActivePhysicsRect(this,  &tempVec );
}
void daMegaGoomba_c::executeState_Shrink() { 
	this->timer += 1.0;
	
	float modifier = GetHermiteCurveValue(this->timer, this->keysX, Xkey_count);
	this->scale = (Vec){modifier, modifier, modifier};

	if(this->timer == 2.0)
		PlaySound(this, SE_EMY_KURIBO_L_DAMAGE_02);

	if (this->timer > 40.0) { doStateChange(&StateID_Walk); }
}
void daMegaGoomba_c::endState_Shrink() {
	// enable being hit
	setNewActivePhysicsRect(this, &this->scale);
	this->already_hit = false;
}



// Turn State
void daMegaGoomba_c::beginState_Turn() {
	this->direction ^= 1;
	this->speed.x = 0.0;
}
void daMegaGoomba_c::executeState_Turn() { 
	this->bodyModel._vf1C();

	this->HandleYSpeed();
	this->doSpriteMovement();

	/*this->_vf2D0();	//nullsub();*/
	int ret = SomeStrangeModification(this);

	if(ret & 1)
		this->speed.y = 0.0;
	if(ret & 4)
		this->pos.x = this->last_pos.x;
	DoStuffAndMarkDead(this, this->pos, 1.0);
	u16 amt = (this->direction == 0) ? 0x2000 : 0xE000;
	int done = SmoothRotation(&this->rot.y, amt, 0x80);
	if(done) {
		this->doStateChange(&StateID_Walk);
	}

	int frame = (int)(this->animationChr.getCurrentFrame() * 5.0);
	if ((frame == 100) || (frame == 325) || (frame == 550) || (frame == 775)) {
		ShakeScreen(StageScreen, 0, 1, 0, 0);
		stunPlayers();
		PlaySound(this, SE_BOSS_MORTON_GROUND_SHAKE);
	}

	if (isBigBoss) {
		if ((frame == 250) || (frame == 500) || (frame == 700) || (frame == 900))
			unstunPlayers();
	}
	else {
		if ((frame == 200) || (frame == 425) || (frame == 650) || (frame == 875))
			unstunPlayers();
	}
}
void daMegaGoomba_c::endState_Turn() {
	this->max_speed.x = (this->direction) ? -this->XSpeed : this->XSpeed;
}


// Walk State
void daMegaGoomba_c::beginState_Walk() {
	//inline this piece of code
	//YOU SUCK, WHOEVER ADDED THIS LINE OF CODE AND MADE ME SPEND AGES
	//HUNTING DOWN WHAT WAS BREAKING TURNING. -Treeki
	//this->direction = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);
	this->speed.x = this->speed.z = 0.0;
	this->max_speed.x = (this->direction) ? -this->XSpeed : this->XSpeed;
	this->speed.y = -4.0;
	this->y_speed_inc = -0.1875;
}
void daMegaGoomba_c::executeState_Walk() { 
	/* 800345e0 - daEnLkuribo_c::executeState_Walk() */
	this->bodyModel._vf1C();
	//HOMEMADE//
	this->HandleXSpeed();
	this->HandleYSpeed();
	this->doSpriteMovement();
	u16 amt = (this->direction == 0) ? 0x2000 : 0xE000;
	SmoothRotation(&this->rot.y, amt, 0x200);
	/*this->_vf2D0();	//nullsub();*/
	int ret = SomeStrangeModification(this);
	if(ret & 1)
		this->speed.y = 0.0;
	u32 bitfield = this->collMgr.outputMaybe;
	if(bitfield & (0x15<<this->direction)) {
		this->pos.x = this->last_pos.x;
		this->doStateChange(&StateID_Turn);
		//this->acState.setField10ToOne();
	}
	/*u32 bitfield2 = this->collMgr.adjacentTileProps[this->direction];
	if(bitfield2) {
		this->doStateChange(&StateID_Turn);
	}*/
	DoStuffAndMarkDead(this, this->pos, 1.0);


	int frame = (int)(this->animationChr.getCurrentFrame() * 5.0);
	if ((frame == 100) || (frame == 325) || (frame == 550) || (frame == 775)) {
		ShakeScreen(StageScreen, 0, 1, 0, 0);
		stunPlayers();
		PlaySound(this, SE_BOSS_MORTON_GROUND_SHAKE);
	}

	if (isBigBoss) {
		if ((frame == 250) || (frame == 500) || (frame == 700) || (frame == 900))
			unstunPlayers();
	}
	else {
		if ((frame == 200) || (frame == 425) || (frame == 650) || (frame == 875))
			unstunPlayers();
	}

	if(this->animationChr.isAnimationDone()) {
		this->animationChr.setCurrentFrame(0.0);

		int new_dir = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, pos);
		if(this->direction != new_dir)
			doStateChange(&StateID_Turn);
	}
}
void daMegaGoomba_c::endState_Walk() { }





extern "C" void stunPlayer(void *, int);
extern "C" void unstunPlayer(void *);

void daMegaGoomba_c::stunPlayers() {
	for (int i = 0; i < 4; i++) {
		playerStunned[i] = false;

		dStageActor_c *player = GetSpecificPlayerActor(i);
		if (player) {
			if (player->collMgr.isOnTopOfTile() && player->currentZoneID == currentZoneID) {
				stunPlayer(player, 1);
				playerStunned[i] = true;
			}
		}
	}
}

void daMegaGoomba_c::unstunPlayers() {
	for (int i = 0; i < 4; i++) {
		dStageActor_c *player = GetSpecificPlayerActor(i);
		if (player && playerStunned[i]) {
			unstunPlayer(player);
		}
	}
}



void daMegaGoomba_c::dieOther_Begin() {
	animationChr.bind(&bodyModel, resFile.GetResAnmChr("damage"), true);
	bodyModel.bindAnim(&animationChr, 2.0f);
	speed.x = speed.y = speed.z = 0.0f;
	removeMyActivePhysics();

	PlaySound(this, SE_EMY_KURIBO_L_SPLIT_HPDP);

	rot.y = 0;
	counter_500 = 60;
}

void daMegaGoomba_c::dieOther_End() {
	dEn_c::dieOther_End();
}

void daMegaGoomba_c::dieOther_Execute() {
	bodyModel._vf1C();
	if (counter_500 == 0) {
		SpawnEffect("Wm_ob_icebreaksmk", 0, &pos, &(S16Vec){0,0,0}, &(Vec){5.0f, 5.0f, 5.0f});
		Delete(1);
	}
}


//
// processed\../src/bossFuzzyBear.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include <stage.h>
#include "boss.h"
#include <profile.h>


class daFuzzyBear_c : public daBoss {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;
	nw4r::g3d::ResFile resFile;
	m3d::anmChr_c animationChr;

	int timer;
	char BigBossFuzzyBear;
	float Baseline;
	float AreaWidthLeft;
	float AreaWidthRight;
	float LaunchSpeedShort;
	float LaunchSpeedHigh;
	char dying;
	float storeSpeed;
	Vec initialPos;
	char RolyBounces;
	Vec RolyPos;
	char falldown;
	char damage;
	char roly;
	char isInvulnerable;

	public: static dActor_c *build();

	void bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate);
	void setupBodyModel();
	void updateModelMatrices();

	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);

	USING_STATES(daFuzzyBear_c);
	DECLARE_STATE(Grow);
	DECLARE_STATE(Bounce);
	// DECLARE_STATE(Needles);
	//DECLARE_STATE(Spray);
	DECLARE_STATE(RolyPoly);
	DECLARE_STATE(Wait);
	DECLARE_STATE(Outro);
};

const char* FuzzyBearNameList[] = {"chorobon", NULL};
const SpriteData FuzzyBearSpriteData = {ProfileId::EN_BOSS_FUZZY, 8, 0xFFFFFFF8, 0, 0, 0x10, 0x10, 0, 0, 0, 0, 2};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile FuzzyBearProfile(&daFuzzyBear_c::build, SpriteId::EN_BOSS_FUZZY, &FuzzyBearSpriteData, ProfileId::WALLINSECT_MGR, ProfileId::EN_BOSS_FUZZY, "EN_BOSS_FUZZY", FuzzyBearNameList, 0x8);

dActor_c *daFuzzyBear_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daFuzzyBear_c));
	return new(buffer) daFuzzyBear_c;
}



CREATE_STATE(daFuzzyBear_c, Grow);
CREATE_STATE(daFuzzyBear_c, Bounce);
// CREATE_STATE(daFuzzyBear_c, Needles);
//CREATE_STATE(daFuzzyBear_c, Spray);
CREATE_STATE(daFuzzyBear_c, RolyPoly);
CREATE_STATE(daFuzzyBear_c, Wait);
CREATE_STATE(daFuzzyBear_c, Outro);



void daFuzzyBear_c::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) { DamagePlayer(this, apThis, apOther); }
void daFuzzyBear_c::yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther) { DamagePlayer(this, apThis, apOther); }
bool daFuzzyBear_c::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true; // added by skawo request

	if (this->isInvulnerable == 1) { return true; }

	this->timer = 0;
	PlaySound(this, SE_BOSS_KOOPA_FIRE_DISAPP);

	SpawnEffect("Wm_mr_fireball_hit", 0, &apOther->owner->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
	this->damage++;
	if (this->damage > 14) { doStateChange(&StateID_Outro); }
	return true;
}
bool daFuzzyBear_c::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
	apOther->someFlagByte |= 2;

	dActor_c *block = apOther->owner;
	dEn_c *mario = (dEn_c*)block;

	mario->speed.y = -mario->speed.y;
	mario->pos.y += mario->speed.y;

	if (mario->direction == 0) { mario->speed.x = 4.0; }
	else					  { mario->speed.x = -4.0; }

	mario->doSpriteMovement();
	mario->doSpriteMovement();
	return true;
}
bool daFuzzyBear_c::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) {
	this->counter_504[apOther->owner->which_player] = 0;
	return this->collisionCat9_RollingObject(apThis, apOther);
}
bool daFuzzyBear_c::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {

	dActor_c *block = apOther->owner;
	dEn_c *blah = (dEn_c*)block;

	//OSReport("Fuzzy was hit by an actor %d (%p); its field 12C is %x\n", block->profileId, block, blah->_12C);
	if (block->profileId == ProfileId::AC_LIGHT_BLOCK) {
		//OSReport("It's a light block, and its state is %s\n", blah->acState.getCurrentState()->getName());
		if (blah->_12C & 3 || strcmp(blah->acState.getCurrentState()->getName(), "daLightBlock_c::StateID_Throw")) {
			//OSReport("Ignoring this!\n");
			return true;
		}
	}

	if (blah->direction == 0) { blah->direction = 1; this->roly = 1; }
	else					  { blah->direction = 0; this->roly = 0; }

	blah->speed.x = -blah->speed.x;
	blah->pos.x += blah->speed.x;

	if (blah->speed.y < 0) {
		blah->speed.y = -blah->speed.y; }

	blah->doSpriteMovement();
	blah->doSpriteMovement();

	if (this->isInvulnerable == 1) {

		if (blah->direction == 0) { blah->direction = 1; }
		else					  { blah->direction = 0; }

		return true;
	}

	this->pos.x += blah->speed.x;

	this->timer = 0;
	this->damage = this->damage + 5;


	PlaySound(this, SE_EMY_BLOW_PAKKUN_DOWN);
	SpawnEffect("Wm_mr_kickhit", 0, &blah->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});

	if (this->damage > 14) { doStateChange(&StateID_Outro); }
	else { doStateChange(&StateID_RolyPoly); }
	return true;
}
bool daFuzzyBear_c::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {

	if (this->isInvulnerable == 1) { return true; }

	dActor_c *block = apOther->owner;
	dEn_c *blah = (dEn_c*)block;

	if (blah->direction == 0) { blah->direction = 1; this->roly = 1; }
	else					  { blah->direction = 0; this->roly = 0; }

	PlaySound(this, SE_EMY_BIG_PAKKUN_DAMAGE_1);
	this->timer = 0;
	this->damage += 5;

	SpawnEffect("Wm_mr_kick_glow", 0, &apOther->owner->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});

	if (this->damage > 14) { doStateChange(&StateID_Outro); }
	else { doStateChange(&StateID_RolyPoly); }
	return true;
}

bool daFuzzyBear_c::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) {
	return false;
}
bool daFuzzyBear_c::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true;
}
bool daFuzzyBear_c::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
	return true;
}




void daFuzzyBear_c::bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate) {
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr(name);
	this->animationChr.bind(&this->bodyModel, anmChr, unk);
	this->bodyModel.bindAnim(&this->animationChr, unk2);
	this->animationChr.setUpdateRate(rate);
}


void daFuzzyBear_c::setupBodyModel() {
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	this->resFile.data = getResource("chorobon", "g3d/chorobon.brres");
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("chorobon");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&bodyModel, 0);

	bool ret;
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr("run");
	ret = this->animationChr.setup(mdl, anmChr, &this->allocator, 0);

	allocator.unlink();
}


int daFuzzyBear_c::onCreate() {

	setupBodyModel();


	this->BigBossFuzzyBear = this->settings >> 28;
	this->scale = (Vec){1.0, 1.0, 1.0};


	ActivePhysics::Info HitMeBaby;
	HitMeBaby.xDistToCenter = 0.0;
	HitMeBaby.yDistToCenter = 0.0;

	if (BigBossFuzzyBear == 0) {
		HitMeBaby.xDistToEdge = 30.0;
		HitMeBaby.yDistToEdge = 30.0; }
	else {
		HitMeBaby.xDistToEdge = 35.0;
		HitMeBaby.yDistToEdge = 35.0; }

	HitMeBaby.category1 = 0x3;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x4F;
	HitMeBaby.bitfield2 = 0x8028E;
	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &dEn_c::collisionCallback;


	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();


	this->pos.y = this->pos.y + 6;
	this->rot.x = 0; // X is vertical axis
	this->rot.y = 0; // Y is horizontal axis
	this->rot.z = 0; // Z is ... an axis >.>
	this->direction = 0; // Heading left.

	pos.z = 3000.0f;

	this->speed.x = 0;
	this->LaunchSpeedShort = ((this->settings >> 20) & 0xF) * 10.0;
	this->LaunchSpeedHigh = ((this->settings >> 24) & 0xF) * 10.0;

	this->AreaWidthRight = this->settings & 0xFF;
	this->AreaWidthLeft = (this->settings >> 8) & 0xFF;

	this->initialPos = this->pos;
	this->storeSpeed = 0;
	this->falldown = 0;
	this->roly = 0;
	this->damage = 0;
	this->isInvulnerable = 0;
	this->dying = 0;
	this->disableEatIn();


	bindAnimChr_and_setUpdateRate("run", 1, 0.0, 1.0);

	doStateChange(&StateID_Grow);

	this->onExecute();
	return true;
}

int daFuzzyBear_c::onDelete() {
	return true;
}

int daFuzzyBear_c::onExecute() {
	acState.execute();
	updateModelMatrices();

	if(this->animationChr.isAnimationDone())
		this->animationChr.setCurrentFrame(0.0);

	return true;
}


int daFuzzyBear_c::onDraw() {
	bodyModel.scheduleForDrawing();
	bodyModel._vf1C();
	return true;
}


void daFuzzyBear_c::updateModelMatrices() {
	// This won't work with wrap because I'm lazy.
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}


// Grow State

void daFuzzyBear_c::beginState_Grow() {
	this->timer = 0;

	SetupKameck(this, Kameck);
	this->scale = (Vec){1.0, 1.0, 1.0};
}

void daFuzzyBear_c::executeState_Grow() {

	this->timer += 1;

	bool ret;
	if (BigBossFuzzyBear == 1) {
		ret = GrowBoss(this, Kameck, 1.0, 3.0, 25, this->timer); }
	else {
		ret = GrowBoss(this, Kameck, 1.0, 2.5, 18, this->timer); }

	if (ret) { doStateChange(&StateID_Bounce);	}

}
void daFuzzyBear_c::endState_Grow() {
	this->Baseline = this->pos.y;

	CleanupKameck(this, Kameck);
}



// Bounce State

void daFuzzyBear_c::beginState_Bounce() {

	if (this->direction == 0) { this->speed.x = 1.0; }
	else 					 { this->speed.x = -1.0; }

	if (this->storeSpeed != 0) { this->speed.x = this->storeSpeed; }

	this->timer = 20;
}
void daFuzzyBear_c::executeState_Bounce() {

	float wallDistance, scaleDown, scaleUp, scaleBase;

	if (BigBossFuzzyBear == 0) {
		wallDistance = 32.0;
		scaleDown = 24.0;
		scaleUp = 10.0;
		scaleBase = 2.5;
	}
	else {
		wallDistance = 38.0;
		scaleDown = 32.0;
		scaleUp = 12.0;
		scaleBase = 3.0;
	}


	if (this->falldown == 1) { this->speed.x = 0; this->timer = 0; }


	// Check for walls

	if (this->pos.x <= this->initialPos.x - ((17 * 16.0) + wallDistance))  { // Hit left wall, head right.
		this->speed.x = -this->speed.x;
		this->direction = 1;
		this->pos.x = this->pos.x + 1.0; }

	if (this->pos.x >= this->initialPos.x + ((7.5 * 16.0) - wallDistance))  { // Hit right wall, head left.
		this->speed.x = -this->speed.x;
		this->direction = 0;
		this->pos.x = this->pos.x - 1.0; }


	// Check if we're on the ground.

	if (this->pos.y < this->Baseline) {

		this->falldown = 0;

		this->timer = this->timer + 1;
		if (this->speed.x != 0) {
			this->storeSpeed = this->speed.x; }
		this->speed.x = 0;
		this->speed.y = 0;


		if (this->timer < 10) {
			float modifier;
			modifier = scaleBase - (this->timer * 0.1);

			this->scale.y = modifier;
			this->pos.y = this->pos.y + (scaleDown/10.0);
			if (this->pos.y > this->Baseline) { this->pos.y = this->Baseline - 1.0; }
		}
		else if (this->timer == 10) {
			Vec tempPos = (Vec){this->pos.x, this->pos.y - wallDistance, 5500.0};
			SpawnEffect("Wm_mr_beachlandsmk", 0, &tempPos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		}
		else {
			float modifier;
			modifier = (scaleBase - 1.0) + ((this->timer - 10) * 0.1);

			this->scale.y = modifier;
			this->pos.y = this->pos.y + (scaleUp/10.0);
			if (this->pos.y > this->Baseline) { this->pos.y = this->Baseline - 1.0; }
			PlaySound(this, SE_PLY_JUMPDAI);
		}

		if (this->timer > 20) {

			int randChoice;

			randChoice = GenerateRandomNumber(5);
			if (randChoice == 0) { doStateChange(&StateID_Wait); }

			randChoice = GenerateRandomNumber(4);
			if (randChoice == 0) { this->speed.y = 8.0; }
			else { this->speed.y = 6.0; }

			this->timer = 0;
			this->pos.y = this->Baseline + 1;

			this->speed.x = this->storeSpeed;
		 }
	}

	else { this->speed.y = this->speed.y - 0.1; } // Gravity


	this->HandleXSpeed();
	this->HandleYSpeed();

	this->UpdateObjectPosBasedOnSpeedValuesReal();

}

void daFuzzyBear_c::endState_Bounce() { }





// Needles State - shoots out some black icicles

// void daFuzzyBear_c::beginState_Needles() {
// 	this->timer = 0;
// 	this->speed.y = 0;
// 	this->speed.x = 0;
// 	OSReport("Fuzzy Needle State Begin");
// }
// void daFuzzyBear_c::executeState_Needles() {
// 	float origScale;

// 	this->speed.y = 0;
// 	this->speed.x = 0;

// 	if (BigBossFuzzyBear == 0) {
// 		origScale = 2.5;
// 	}
// 	else {
// 		origScale = 3.0;
// 	}

// 	this->timer = this->timer + 1;
// 	OSReport("Needle Timer: %d", this->timer);

// 	if (this->timer <= 120) {
// 		this->scale.y = (sin(this->timer * 3.14 / 5.0) / 2.0) + origScale; // 3 shakes per second, exactly 24 shakes overall
// 		this->scale.x = (sin(this->timer * 3.14 / 5.0) / 2.0) + origScale; // 3 shakes per second, exactly 24 shakes overall

// 		if (this->timer == 30) {
// 			dStageActor_c *spawner = CreateActor(339, 0, this->pos, 0, 0);
// 			spawner->speed.x = -6.0;
// 			spawner->speed.y = 0.0;
// 			spawner->scale = (Vec){1.0, 1.0, 1.0};
// 		}

// 		if (this->timer == 45) {
// 			dStageActor_c *spawner = CreateActor(339, 0, this->pos, 0, 0);
// 			spawner->speed.x = 6.0;
// 			spawner->speed.y = 6.0;
// 			spawner->scale = (Vec){1.0, 1.0, 1.0};
// 		}

// 		if (this->timer == 60) {
// 			dStageActor_c *spawner = CreateActor(339, 0, this->pos, 0, 0);
// 			spawner->speed.x = 0.0;
// 			spawner->speed.y = 6.0;
// 			spawner->scale = (Vec){1.0, 1.0, 1.0};
// 		}

// 		if (this->timer == 75) {
// 			dStageActor_c *spawner = CreateActor(339, 0, this->pos, 0, 0);
// 			spawner->speed.x = -6.0;
// 			spawner->speed.y = 6.0;
// 			spawner->scale = (Vec){1.0, 1.0, 1.0};
// 		}

// 		if (this->timer == 90) {
// 			dStageActor_c *spawner = CreateActor(339, 0, this->pos, 0, 0);
// 			spawner->speed.x = -6.0;
// 			spawner->speed.y = 0.0;
// 			spawner->scale = (Vec){1.0, 1.0, 1.0};
// 		}
// 	}
// 	else { doStateChange(&StateID_Bounce); }

// 	this->HandleXSpeed();
// 	this->HandleYSpeed();

// 	this->UpdateObjectPosBasedOnSpeedValuesReal();

// }
// void daFuzzyBear_c::endState_Needles() { OSReport("Fuzzy Needle State End"); }

// Spray State - jumps in the air and shakes out some small fuzzies

/*void daFuzzyBear_c::beginState_Spray() {
	this->timer = 0;
	this->speed.y = 7.0;
	this->speed.x = 0.0;
}
void daFuzzyBear_c::executeState_Spray() {

	this->speed.x = 0.0;

	if (this->speed.y < 1.0) {
		this->speed.y = 0;

		if (this->timer < 120) {

			this->rot.y = sin(this->timer * 3.14 / 5) * 4000; // 3 shakes per second, exactly 24 shakes overall

			int randChoice;
			randChoice = GenerateRandomNumber(18); // 1.3 Fuzzies per second, 6 fuzzies overall

			if (randChoice == 0) {
				int randChoiceX, randChoiceY;
				randChoiceX = GenerateRandomNumber(92);
				randChoiceY = GenerateRandomNumber(48);

				float xa, ya;
				xa = randChoiceX - 48.0;
				ya = randChoiceY - 24.0;

				CreateActor(144, 0, (Vec){this->pos.x + xa, this->pos.y + ya, this->pos.z}, 0, 0);
			}
		}

		else { doStateChange(&StateID_Bounce); }

		this->timer = this->timer + 1;

	}

	else { this->speed.y = this->speed.y - 0.1; } // Gravity


	this->HandleXSpeed();
	this->HandleYSpeed();

	this->UpdateObjectPosBasedOnSpeedValuesReal();

}
void daFuzzyBear_c::endState_Spray() {
	this->rot.y = 0;
	this->timer = 20;
	this->falldown = 1;
}*/


// Roly Poly State - Rolls from left to right, bounces off both walls, and returns to original position.

void daFuzzyBear_c::beginState_RolyPoly() {

	this->isInvulnerable = 1;

	if (this->roly == 1) {
		this->direction = 1;
		this->speed.x = 12.0; }
	else 				 {
		this->direction = 0;
		this->speed.x = -12.0; }

	this->speed.y = 0;
	this->RolyBounces = 0;
	this->RolyPos = this->pos;

	if (BigBossFuzzyBear == 0) {
		this->scale = (Vec){2.5, 2.5, 2.5};
	}
	else {
		this->scale = (Vec){3.0, 3.0, 3.0};
	}

	this->timer = 0;
}
void daFuzzyBear_c::executeState_RolyPoly() {
	float wallDistance, scaleDown, scaleUp;

	PlaySound(this, SE_OBJ_TEKKYU_G_CRASH);

	if (this->pos.y > this->Baseline) { this->pos.y -= 2.0; }
	else {
		this->pos.y = this->Baseline - 1.0;

		Vec tempPos = (Vec){this->pos.x, this->pos.y - 34.0, 5500.0};

		if (this->timer & 0x1) {
			SpawnEffect("Wm_ob_icehitsmk", 0, &tempPos, &(S16Vec){0,0,0}, &(Vec){0.4, 0.4, 0.4});
		}
	 }

	if (this->direction == 0) { // is even
		this->pos.x = this->pos.x - 3.0; }
	else { // is odd
		this->pos.x = this->pos.x + 3.0; }

	if (BigBossFuzzyBear == 0) {
		wallDistance = 38.0;
	}
	else {
		wallDistance = 50.0;
	}

	this->timer += 1;

	if (this->pos.x <= this->initialPos.x - ((17 * 16.0) + wallDistance))  { // Hit left wall, head right.
		this->speed.x = -this->speed.x;
		this->direction = 1;
		this->pos.x = this->pos.x + 1.0;
		this->RolyBounces = this->RolyBounces + 1;
		}

	if (this->pos.x >= this->initialPos.x + ((7.5 * 16.0) - wallDistance))  { // Hit right wall, head left.
		this->speed.x = -this->speed.x;
		this->direction = 0;
		this->pos.x = this->pos.x - 1.0;
		this->RolyBounces = this->RolyBounces + 1;
		}


	if (this->direction == 1) { this->rot.z = this->rot.z - 0x400; }
	else 					  { this->rot.z = this->rot.z + 0x400; }

	if (this->RolyBounces == 2) {
		if ((this->pos.x > this->RolyPos.x -20.0) && (this->pos.x < this->RolyPos.x + 20.0)) {
			this->speed.x = 0;
			if (this->rot.z == 0) { doStateChange(&StateID_Bounce); } }
	}



//	this->HandleXSpeed();
//	this->HandleYSpeed();

//	this->doSpriteMovement();
//	this->UpdateObjectPosBasedOnSpeedValuesReal();

 }
void daFuzzyBear_c::endState_RolyPoly() {
	this->rot.z = 0;
	this->isInvulnerable = 0;
	this->timer = 0;
}





void daFuzzyBear_c::beginState_Wait() { this->timer = 0;}
void daFuzzyBear_c::executeState_Wait() {

	this->timer = this->timer + 1;

	if (this->timer > 60) {
		doStateChange(&StateID_Bounce);
		//int randChoice;

		//if (BigBossFuzzyBear == 1) { doStateChange(&StateID_Spray); }
		//else 					   { doStateChange(&StateID_Bounce); }
	}
}
void daFuzzyBear_c::endState_Wait() { }



void daFuzzyBear_c::beginState_Outro() {
	OutroSetup(this);
}
void daFuzzyBear_c::executeState_Outro() {

	if (this->dying == 1) {
		if (this->timer > 180) {
			ExitStage(ProfileId::WORLD_MAP, 0, BEAT_LEVEL, MARIO_WIPE);
		}
		if (this->timer == 60) { PlayerVictoryCries(this); }

		this->timer += 1;
		return;
	}

	bool ret;
	ret = ShrinkBoss(this, &this->pos, 2.75, this->timer);

	if (ret == true) 	{
		BossExplode(this, &this->pos);
		this->dying = 1;
		this->timer = 0;
	}

	this->timer += 1;

}
void daFuzzyBear_c::endState_Outro() { }






//
// processed\../src/bossThwompaDomp.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include <stage.h>
#include "boss.h"
#include <profile.h>

// Externs
	extern "C" int posIsInZone(Vec,float*,float*,u8 zone);
	extern "C" void* ScreenPositionClass;
	extern "C" int SpawnThwompEffects(dEn_c *);

	extern "C" void* SoundRelatedClass;
	extern "C" Vec ConvertStagePositionIntoScreenPosition__Maybe(Vec);
	extern "C" void AnotherSoundRelatedFunction(void*,SFX,Vec,int);


class daEnMegaDosun_c : public daBoss {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	public: static dActor_c *build();

	mHeapAllocator_c allocator;		// _524

	nw4r::g3d::ResFile resFile;		// _540
	m3d::mdl_c bodyModel;			// _544
	m3d::anmVis_c anmVis;			// _584

	lineSensor_s belowSensor;
	float shakePosXoffset;			// _5CC shakePosXoffset
	u16 puruMoveCounter;			// _5D8
	u16 shakeIndex;					// _5DA 0=shake,1=normal
	u32 countdownTimer;				// _5DC

	int timer;
	char notFalling;
	char dying;
	float leftBuffer;
	float rightBuffer;
	float topBuffer;
	bool isOutofScreen;
	Vec OutOfScreenPosition;

	void setupBodyModel();

	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);

	void powBlockActivated(bool isNotMPGP);

	USING_STATES(daEnMegaDosun_c);
	DECLARE_STATE(UpWait);
	DECLARE_STATE(DownMoveWait);
	DECLARE_STATE(PuruMove);
	DECLARE_STATE(DownMove);
	DECLARE_STATE(DownWait);
	DECLARE_STATE(UpMove);
	DECLARE_STATE(Grow);
	DECLARE_STATE(Outro);
};

// States
	CREATE_STATE(daEnMegaDosun_c, UpWait);
	CREATE_STATE(daEnMegaDosun_c, DownMoveWait);
	CREATE_STATE(daEnMegaDosun_c, PuruMove);
	CREATE_STATE(daEnMegaDosun_c, DownMove);
	CREATE_STATE(daEnMegaDosun_c, DownWait);
	CREATE_STATE(daEnMegaDosun_c, UpMove);
	CREATE_STATE(daEnMegaDosun_c, Grow);
	CREATE_STATE(daEnMegaDosun_c, Outro);

const char* ThwompaDompNameList[] = {"dossun", NULL};
const SpriteData ThwompaDompSpriteData = {ProfileId::EN_BOSS_THWOMP, 0, 0, 0, 0xFFFFFFC0, 0x10, 0x60, 0, 0, 0, 0, 2};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile ThwompaDompProfile(&daEnMegaDosun_c::build, SpriteId::EN_BOSS_THWOMP, &ThwompaDompSpriteData, ProfileId::EN_GHOST_JUGEM, ProfileId::EN_BOSS_THWOMP, "EN_BOSS_THWOMP", ThwompaDompNameList, 0x8);

dActor_c *daEnMegaDosun_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daEnMegaDosun_c));
	return new(buffer) daEnMegaDosun_c;
}

void daEnMegaDosun_c::powBlockActivated(bool isNotMPGP) { }

// Collisions

	void daEnMegaDosun_c::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
		DamagePlayer(this, apThis, apOther);
	}
	bool daEnMegaDosun_c::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
		return true;
	}
	bool daEnMegaDosun_c::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) {
		return false;
	}
	bool daEnMegaDosun_c::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
		DamagePlayer(this, apThis, apOther);
		return true;
	}
	bool daEnMegaDosun_c::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
		return true;
	}
	bool daEnMegaDosun_c::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
		return true;
	}
	bool daEnMegaDosun_c::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther) {
		return true;
	}
	bool daEnMegaDosun_c::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther) {
		DamagePlayer(this, apThis, apOther);
		return true;
	}


void daEnMegaDosun_c::setupBodyModel() {
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	this->resFile.data = getResource("dossun", "g3d/t00.brres");
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("dossun_big");
	bodyModel.setup(mdl, &allocator, 0x60, 1, 0);
	SetupTextures_Enemy(&bodyModel, 0);

	nw4r::g3d::ResAnmVis anmRes = this->resFile.GetResAnmVis("dossun_big");
	this->anmVis.setup(mdl, anmRes, &this->allocator, 0);
	this->anmVis.bind(&bodyModel, anmRes, 1);

	allocator.unlink();
}

int daEnMegaDosun_c::onCreate() {

	this->setupBodyModel();

	this->_36D = 0;			// byte

	this->frzMgr.setSomething(1,1,1);	//@0x809f5c5c

	this->pos.y -= 21.0;
	this->pos.z = -280.0;		// behind layer1 (hides spikes)

	belowSensor.flags =
		SENSOR_10000000 | SENSOR_1000000 | SENSOR_BREAK_BRICK |
		SENSOR_BREAK_BLOCK | SENSOR_100 | SENSOR_LINE;
	belowSensor.lineA = -31 << 12;
	belowSensor.lineB = 31 << 12;
	belowSensor.distanceFromCenter = 5 << 12;

	ActivePhysics::Info hm;
	hm.xDistToCenter = 0.0;
	hm.yDistToCenter = 41.0;
	hm.xDistToEdge = 36.0;
	hm.yDistToEdge = 38.0;
	hm.category1 = 0x03;
	hm.category2 = 0x00;
	hm.bitfield1 = 0x0000004F;
	hm.bitfield2 = 0x0008820E;
	hm.unkShort1C = 0x0100;
	hm.callback = &dEn_c::collisionCallback;
	this->aPhysics.initWithStruct(this, &hm);

	lineSensor_s aboveSensor(-31 << 12, 31 << 12, -31 << 12);
	this->collMgr.init(this, &belowSensor, &aboveSensor, 0);

	this->pos_delta2.x = 0.0;
	this->pos_delta2.y = 36.0;
	this->pos_delta2.z = 0.0;
	this->_320 = 0.0;
	this->_324 = 48.0;

	this->aPhysics.addToList();

	this->scale.x = 1.0;
	this->scale.y = 1.0;
	this->scale.z = 1.0;
	this->max_speed.x = 0.0;
	this->max_speed.y = -8.0;
	this->max_speed.z = 0.0;
	this->y_speed_inc = -0.25;
	this->rot.x = 0;
	this->rot.y = 0;
	this->rot.z = 0;
	this->notFalling = 0;
	this->direction = 0;
	this->countdownTimer = 0;
	this->isOutofScreen = false;

	// Measured in half tiles
	this->leftBuffer	= this->pos.x - (((float)((this->settings >> 24) & 0xFF) - 5.0) * 8.0);  //nyb 5-6 LEFT
	this->rightBuffer	= this->pos.x + (((float)((this->settings >> 16) & 0xFF) - 3.0) * 8.0);  //nyb 7-8 RIGHT
	this->topBuffer		= this->pos.y + (((float)((this->settings >> 8) & 0xFF) - 8.0) * 8.0);   //nyb 9-10 TOP


	// Boss Thwomp settings
	//
	//	nybble 5-6 		- Left Buffer in half tiles (minimum is 5 due to thwomp width)
	//	nybble 7-8 		- Left Buffer in half tiles (minimum is 3 due to thwomp width)
	//	nybble 9-10		- Top Buffer in half tiles (minimum is 8 due to thwomp height)
	//


	this->doStateChange(&StateID_Grow);

	this->onExecute();
	return true;
}

int daEnMegaDosun_c::onExecute() {
	acState.execute();

	if (this->isOutofScreen == false) {
		float rect[] = {this->_320, this->_324, this->spriteSomeRectX, this->spriteSomeRectY};
		int ret = this->outOfZone(this->pos, (float*)&rect, this->currentZoneID);
		if(ret) {
			this->OutOfScreenPosition = this->pos;

			this->isOutofScreen = true;
			doStateChange(&StateID_Outro);
		}
	}

	return true;
}

int daEnMegaDosun_c::onDraw() {
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);

	bodyModel.scheduleForDrawing();
	return true;
}

int daEnMegaDosun_c::onDelete() {
	return true;
}


// Grow State

	void daEnMegaDosun_c::beginState_Grow() {
		this->scale = (Vec){0.5, 0.5, 0.5};
		this->timer = 0;

		SetupKameck(this, Kameck);
	}

	void daEnMegaDosun_c::executeState_Grow() {

		bool ret;
		ret = GrowBoss(this, Kameck, 0.5, 1.0, 0, this->timer);

		if (ret) {
			PlaySound(this, SE_EMY_BIG_DOSSUN);
			doStateChange(&StateID_UpMove);
		}
		this->timer += 1;
	}
	void daEnMegaDosun_c::endState_Grow() {
		CleanupKameck(this, Kameck);
	}

// StateID_UpWait
	void daEnMegaDosun_c::beginState_UpWait() {
		belowSensor.flags =
			SENSOR_10000000 | SENSOR_1000000 | SENSOR_BREAK_BRICK |
			SENSOR_BREAK_BLOCK | SENSOR_100 | SENSOR_LINE;
		this->timer = 0;
	}
	void daEnMegaDosun_c::executeState_UpWait() {
		if(this->countdownTimer != 0) {
			this->countdownTimer--;
			return;
		}

		if (this->pos.x > this->rightBuffer) {
			SpawnEffect("Wm_en_dossunfall02", 0, &(Vec){this->pos.x + 38.0, this->pos.y + 32.0, 5500.0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
			PlaySoundAsync(this, SE_OBJ_TEKKYU_G_CRASH);

			this->direction = 0;
		}

		if (this->pos.x < this->leftBuffer) {
			SpawnEffect("Wm_en_dossunfall02", 0, &(Vec){this->pos.x - 40.0, this->pos.y + 32.0, 5500.0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
			PlaySoundAsync(this, SE_OBJ_TEKKYU_G_CRASH);

			this->direction = 1;
		}

		this->pos.x += (direction) ? 1.2 : -1.2;

		if (this->notFalling == 0) {
			if(this->CheckIfPlayerBelow(40.0, 256.0)) {
				this->doStateChange(&StateID_DownMoveWait);
				this->speed.y = 0.0;
			}
		}

		if (this->timer == 30) {
			this->notFalling = 0;
		}

		this->timer += 1;
	}
	void daEnMegaDosun_c::endState_UpWait() {
		this->notFalling = 1;
		return;
	}

// StateID_DownMoveWait
	void daEnMegaDosun_c::beginState_DownMoveWait() {
		this->anmVis.playState = 1;
		this->bodyModel.bindAnim(&this->anmVis, 0.5);
	}
	void daEnMegaDosun_c::executeState_DownMoveWait() {
		if(this->anmVis.isAnimationDone())
			this->doStateChange(&StateID_PuruMove);
		this->anmVis.process();
	}
	void daEnMegaDosun_c::endState_DownMoveWait() {
		return;
	}

// StateID_PuruMove
	void daEnMegaDosun_c::beginState_PuruMove() {
		this->puruMoveCounter = 8;
		this->shakeIndex = 0;
	}
	void daEnMegaDosun_c::executeState_PuruMove() {
		if(this->puruMoveCounter == 0) {
			this->shakePosXoffset = 0.0;
			this->doStateChange(&StateID_DownMove);
			return;
		}

		this->puruMoveCounter--;
		if((this->puruMoveCounter & 2) == 0)
			return;

		float _array[] = {2.0, 0.0};
		this->shakeIndex ^= 1;
		this->shakePosXoffset = _array[this->shakeIndex];
	}
	void daEnMegaDosun_c::endState_PuruMove() {
		return;
	}

// StateID_DownMove
	void daEnMegaDosun_c::beginState_DownMove() {
		this->speed.y = 0.0;
	}
	void daEnMegaDosun_c::executeState_DownMove() {
		this->HandleYSpeed();
		this->UpdateObjectPosBasedOnSpeedValuesReal();

		//FIXME what do I do? - bottom detection
		int ret = this->collMgr.calculateBelowCollisionWithSmokeEffect();
		if(!ret)
			return;

		if(!(ret & 0x400000)) {
			this->doStateChange(&StateID_DownWait);
			this->countdownTimer = 0x40;
			this->speed.y = 0.0;
			ShakeScreen(ScreenPositionClass, 0, 1, 0, 0);
			PlaySoundAsync(this, SE_EMY_BIG_DOSSUN);
		}
		else {
			belowSensor.flags = SENSOR_LINE;
			this->speed.y = 0.0;
			ShakeScreen(ScreenPositionClass, 0, 1, 0, 0);
			this->collMgr.clear2();
			PlaySoundAsync(this, SE_EMY_BIG_DOSSUN);
		}

		SpawnThwompEffects(this);
		Vec p = ConvertStagePositionIntoScreenPosition__Maybe(this->pos);
		AnotherSoundRelatedFunction(SoundRelatedClass, SE_EMY_BIG_DOSSUN, p, 0);
		//SoundRelatedClass.AnotherSoundRelatedFunction(SE_EMY_BIG_DOSSUN, p, 0);
	}
	void daEnMegaDosun_c::endState_DownMove() {
		return;
	}

// StateID_DownWait
	void daEnMegaDosun_c::beginState_DownWait() {
		return;
	}
	void daEnMegaDosun_c::executeState_DownWait() {
		if(this->countdownTimer == 0) {
			this->doStateChange(&StateID_UpMove);
		}
		else {
			this->countdownTimer--;
			if(this->countdownTimer == 0x20) {
				this->anmVis.playState = 3;
			}
		}

		this->anmVis.process();
	}
	void daEnMegaDosun_c::endState_DownWait() {
		return;
	}

// StateID_UpMove
	void daEnMegaDosun_c::beginState_UpMove() {
		this->collMgr.clear2();
	}
	void daEnMegaDosun_c::executeState_UpMove() {
		// this->speed.y = 0.0;
		// this->UpdateObjectPosBasedOnSpeedValuesReal();

		if (this->pos.y > this->topBuffer) {
			this->doStateChange(&StateID_UpWait);
			PlaySoundAsync(this, SE_OBJ_TEKKYU_L_CRASH);
			this->countdownTimer = 0xc;
		}
		else {
			this->pos.y += 1.5;
		}
	}
	void daEnMegaDosun_c::endState_UpMove() {
		return;
	}

// Outro
	void daEnMegaDosun_c::beginState_Outro() {
		OutroSetup(this);
		this->timer = 0;

		this->speed.y = 0.0;
		this->y_speed_inc = 0.0;
	}
	void daEnMegaDosun_c::executeState_Outro() {

		this->pos.y = this->OutOfScreenPosition.y + 280.0;

		if (this->timer == 0) {

			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_EMY_BIG_DOSSUN_DEAD, 1);

			SpawnEffect("Wm_mr_stockitemuse_b", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
			SpawnEffect("Wm_mr_stockitemuse_c", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
		}

		if (this->timer == 60) {
			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, STRM_BGM_SHIRO_BOSS_CLEAR, 1);
			BossGoalForAllPlayers();
		}

		if (this->timer == 120) {

			PlayerVictoryCries(this);
		}

		if (this->timer > 240) {
			ExitStage(ProfileId::WORLD_MAP, 0, BEAT_LEVEL, MARIO_WIPE);
		}

		this->timer += 1;
	}
	void daEnMegaDosun_c::endState_Outro() { }

//
// processed\../src/bossRamboo.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include <stage.h>
#include "boss.h"
#include "player.h"
#include <profile.h>

class daRamboo_c : public daBoss {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;
	m3d::mdl_c hideModel;
	m3d::mdl_c fogModel;

	nw4r::g3d::ResFile resFile;
	m3d::anmChr_c anmFog;
	m3d::anmChr_c anmA;
	m3d::anmChr_c anmB;

	nw4r::g3d::ResAnmTexSrt resTexSrt;
	m3d::anmTexSrt_c fogSrt;

	int timer;
	int ytimer;
	char Hiding;
	char dying;
	float Baseline;
	bool fleeFast;

	u64 eventFlag;

	public: static dActor_c *build();

	void bindAnimChr_and_setUpdateRates(const char* name, m3d::anmChr_c &animationChr, m3d::mdl_c &model, float rate);
	void setupModels();
	void updateModelMatrices();

	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);


	USING_STATES(daRamboo_c);
	DECLARE_STATE(Grow);
	DECLARE_STATE(Advance);
	DECLARE_STATE(Wait);
	DECLARE_STATE(Flee);
	DECLARE_STATE(Outro);
};

const char* RambooNameList[] = {"teresa", NULL};
const SpriteData RambooSpriteData = {ProfileId::EN_BOSS_BOO, 8, 0xFFFFFFF0, 0, 0x10, 0x10, 0x10, 0x10, 0, 0x10, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile RambooProfile(&daRamboo_c::build, SpriteId::EN_BOSS_BOO, &RambooSpriteData, ProfileId::EN_IWAO, ProfileId::EN_BOSS_BOO, "EN_BOSS_BOO", RambooNameList, 0x8);

dActor_c *daRamboo_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daRamboo_c));
	return new(buffer) daRamboo_c;
}


CREATE_STATE(daRamboo_c, Grow);
CREATE_STATE(daRamboo_c, Advance);
CREATE_STATE(daRamboo_c, Wait);
CREATE_STATE(daRamboo_c, Flee);
CREATE_STATE(daRamboo_c, Outro);

extern "C" void *EN_LandbarrelPlayerCollision(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);

void daRamboo_c::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
	EN_LandbarrelPlayerCollision(this, apThis, apOther);
	DamagePlayer(this, apThis, apOther);

	fleeFast = false;
	doStateChange(&StateID_Flee);
}
bool daRamboo_c::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
	SpawnEffect("Wm_en_obakedoor_sm", 0, &apOther->owner->pos, &(S16Vec){0,0,0}, &(Vec){0.5, 0.5, 0.5});
	return true;
}
bool daRamboo_c::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) {
	return false;
}
bool daRamboo_c::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {

	if (apOther->owner->profileId == ProfileId::AC_LIGHT_BLOCK) { // Check if it's a glow block
		dEn_c *blah = (dEn_c*)apOther->owner;
		if (blah->_12C & 3 || strcmp(blah->acState.getCurrentState()->getName(), "daLightBlock_c::StateID_Throw")) {
			return true;
		}

		SpawnEffect("Wm_en_obakedoor_sm", 0, &apOther->owner->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		SpawnEffect("Wm_mr_yoshistep", 0, &apOther->owner->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});

		fleeFast = true;
		doStateChange(&StateID_Flee);
		//FIXME changed to dStageActor_c::Delete(u8) from fBase_c::Delete(void)
		apOther->owner->Delete(1);
		return true;
	}
	return false;
}
bool daRamboo_c::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
	return collisionCat1_Fireball_E_Explosion(apThis, apOther);
}
bool daRamboo_c::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
	return true;
}
bool daRamboo_c::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
	return true;
}




void daRamboo_c::bindAnimChr_and_setUpdateRates(const char* name, m3d::anmChr_c &animationChr, m3d::mdl_c &model, float rate) {
	nw4r::g3d::ResAnmChr anmChr = resFile.GetResAnmChr(name);
	animationChr.bind(&model, anmChr, 1);
	model.bindAnim(&animationChr, 0.0);
	animationChr.setUpdateRate(rate);
}


void daRamboo_c::setupModels() {
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	this->resFile.data = getResource("teresa", "g3d/teresa.brres");
	bool ret;

	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("fog");
	this->fogModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&this->fogModel, 0);

	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr("fog");
	ret = this->anmFog.setup(mdl, anmChr, &this->allocator, 0);


	nw4r::g3d::ResMdl mdlB = this->resFile.GetResMdl("teresaA");
	this->bodyModel.setup(mdlB, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&this->bodyModel, 0);

	nw4r::g3d::ResAnmChr anmChrC = this->resFile.GetResAnmChr("shay_teresaA");
	ret = this->anmA.setup(mdlB, anmChrC, &this->allocator, 0);


	nw4r::g3d::ResMdl mdlC = this->resFile.GetResMdl("teresaB");
	this->hideModel.setup(mdlC, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&this->hideModel, 0);

	nw4r::g3d::ResAnmChr anmChrE = this->resFile.GetResAnmChr("shay_teresaB");
	ret = this->anmB.setup(mdlC, anmChrE, &this->allocator, 0);

	nw4r::g3d::ResAnmTexSrt anmSrt = this->resFile.GetResAnmTexSrt("fog");
	this->resTexSrt = anmSrt;
	//setup(ResMdl mdl, ResAnmTexSrt anmSrt, mAllocator* allocator, void* NULL, int count);
	ret = this->fogSrt.setup(mdl, anmSrt, &this->allocator, 0, 1);
	//setEntryByte34(char toSet, int which);
	this->fogSrt.setEntryByte34(0, 0);

	allocator.unlink();
}



int daRamboo_c::onCreate() {

	setupModels();


	this->scale = (Vec){2.0, 2.0, 2.0};

	this->aPhysics.collisionCheckType = 1;

	ActivePhysics::Info HitMeBaby;
	HitMeBaby.xDistToCenter = 160.0;
	HitMeBaby.yDistToCenter = 80.0;

	HitMeBaby.xDistToEdge = 132.0;
	HitMeBaby.yDistToEdge = 132.0;

	HitMeBaby.category1 = 0x3;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x4F;
	HitMeBaby.bitfield2 = 0x80222;
	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &dEn_c::collisionCallback;


	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();

	this->Baseline = this->pos.y;
	this->rot.x = 0; // X is vertical axis
	this->rot.y = 0xE000; // Y is horizontal axis
	this->rot.z = 0; // Z is ... an axis >.>
	this->direction = 0; // Heading left.
	this->Hiding = 1;
	this->dying = 0;

	this->speed.x = 0.0;
	this->ytimer = 0;
	this->pos.z = 3300.0;

	char eventNum	= (this->settings >> 16) & 0xFF;

	this->eventFlag = (u64)1 << (eventNum - 1);

	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr("fog");
	this->anmFog.bind(&this->fogModel, anmChr, 1);
	this->fogModel.bindAnim(&this->anmFog, 0.0);
	this->anmFog.setUpdateRate(1.0);

	nw4r::g3d::ResAnmTexSrt anmSrt = this->resFile.GetResAnmTexSrt("fog");
	//bindEntry(mdl_c* model, ResAnmTexSrt anmSrt, int which, int playState?);
	this->fogSrt.bindEntry(&this->fogModel, anmSrt, 0, 1);
	this->fogModel.bindAnim(&this->fogSrt, 1.0);
	//setFrameForEntry(float frame, int which);
	this->fogSrt.setFrameForEntry(1.0, 0);
	//setUpdateRateForEntry(float rate, int which);
	this->fogSrt.setUpdateRateForEntry(1.0, 0);

	doStateChange(&StateID_Grow);

	this->onExecute();
	return true;
}

int daRamboo_c::onDelete() {
	return true;
}

int daRamboo_c::onExecute() {
	acState.execute();
	updateModelMatrices();

	this->fogModel._vf1C();

	if(this->anmFog.isAnimationDone())
		this->anmFog.setCurrentFrame(0.0);

	this->fogSrt.process();
	if(this->fogSrt.isEntryAnimationDone(0))
		this->fogSrt.setFrameForEntry(1.0, 0);

	if (dFlagMgr_c::instance->flags & this->eventFlag) {
		dFlagMgr_c::instance->flags = dFlagMgr_c::instance->flags && this->eventFlag;
		doStateChange(&StateID_Outro);
	}

	return true;
}

int daRamboo_c::onDraw() {
	fogModel.scheduleForDrawing();

	if (this->Hiding == 0) {
		bodyModel.scheduleForDrawing(); }
	else {
		hideModel.scheduleForDrawing(); }
	return true;
}


void daRamboo_c::updateModelMatrices() {
	// This won't work with wrap because I'm lazy.
	matrix.translation(pos.x + 160.0, pos.y + (scale.x * 12.0) - 80.0, pos.z);

	fogModel.setDrawMatrix(matrix);
	fogModel.setScale(&scale);
	fogModel.calcWorld(false);

	matrix.translation(pos.x + 160.0, pos.y - 80.0, pos.z + 200.0);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	if (this->Hiding == 0) {
		bodyModel.setDrawMatrix(matrix);
		bodyModel.setScale(&scale);
		bodyModel.calcWorld(false); }
	else {
		hideModel.setDrawMatrix(matrix);
		hideModel.setScale(&scale);
		hideModel.calcWorld(false); }
}


// Grow State

void daRamboo_c::beginState_Grow() {
	this->timer = 0;
	bindAnimChr_and_setUpdateRates("begin_boss_b", anmB, hideModel, 1.0f);
	PlaySound(this, SE_EMY_TERESA);

	SetupKameck(this, Kameck);
}

void daRamboo_c::executeState_Grow() {
	this->timer += 1;

	bool ret;
	ret = GrowBoss(this, Kameck, 1.0, 15.0, 0, this->timer);

	if (timer == 450) {
		Hiding = false;
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_EMY_CS_TERESA_BRING_IT, 1);
		bindAnimChr_and_setUpdateRates("begin_boss", anmA, bodyModel, 1.0f);
	}

	if (Hiding)
		hideModel._vf1C();
	else
		bodyModel._vf1C();
	if (ret && anmA.isAnimationDone()) {
		Hiding = 0;
		doStateChange(&StateID_Advance);
	}
}
void daRamboo_c::endState_Grow() {
	this->Baseline = this->pos.y;

	CleanupKameck(this, Kameck);
}



float RightmostPlayerPos() {
	dStageActor_c* current = 0;
	//The fuck you doing here? --Treeki
	//current is set to nothing, you can't store a thing there...
	//current->pos.x = 0.0;

	for(char ii = 0; ii < 4; ii++) {
		dStageActor_c* player = GetSpecificPlayerActor(ii);
		if(!player) {
			continue;
		}
				// actor->pos.x, actor->pos.y, actor->pos.z,
				// player->pos.x, player->pos.y, player->pos.z);
		if(current == 0 || player->pos.x > current->pos.x) {
			current = player;
		}
	}
	return current->pos.x;
}


// Advance State

void daRamboo_c::beginState_Advance() {
	this->speed.y = 0;
	this->speed.z = 0;
	this->timer = 0;

	bindAnimChr_and_setUpdateRates("wait", anmA, bodyModel, 1.0f);

}
void daRamboo_c::executeState_Advance() {

	this->bodyModel._vf1C();

	if (this->anmA.isAnimationDone()) {
		this->anmA.setCurrentFrame(0.0); }

	float px = RightmostPlayerPos();

	if ((px - 132.0) < this->pos.x) {
		this->pos.x -= this->timer / 28.0; }
	else {
		this->pos.x = (px - 132.0); }

	this->pos.y = this->Baseline + sin(this->ytimer * 3.14 / 192) * 36;


	if (this->timer >= 32) { this->timer = 31; }
	if (this->ytimer >= 384) { this->ytimer = 0; }

	PlaySound(this, SE_EMY_TERESA);

	this->timer += 1;
	this->ytimer += 1;
}

void daRamboo_c::endState_Advance() {  }





// Wait State

void daRamboo_c::beginState_Wait() {

	this->timer = 0;
	PlaySound(this, SE_EMY_TERESA_STOP);

}
void daRamboo_c::executeState_Wait() {

	if (this->timer < 90) {
		this->hideModel._vf1C(); }

	if (this->timer > 55) {
		this->bodyModel._vf1C(); }


	if (this->timer == 70)  {
		this->Hiding = 0;

		bindAnimChr_and_setUpdateRates("shay_teresaA", anmA, bodyModel, 1.0f);
	}


	if (this->timer == 55)  {
		bindAnimChr_and_setUpdateRates("shay_teresaB", anmB, hideModel, 1.0f);
	}



	if (this->anmB.isAnimationDone()) {
		PlaySound(this, SE_EMY_CS_TERESA_BEAT_YOU);
		doStateChange(&StateID_Advance);
	}

	this->timer += 1;

}

void daRamboo_c::endState_Wait() {

	this->Hiding = 0;

	bindAnimChr_and_setUpdateRates("shay_teresaA", anmA, bodyModel, 1.0f);
}





// Flee State

void daRamboo_c::beginState_Flee() {

	this->timer = 0;

}
void daRamboo_c::executeState_Flee() {

	this->hideModel._vf1C();

	if (this->timer == 10) {
		this->Hiding = 1;

		bindAnimChr_and_setUpdateRates("shay_teresaB_wait", anmB, hideModel, 1.0f);
	}

	this->pos.x += (60 - this->timer) / (fleeFast ? 8 : 25);


	if ((this->timer > 60) && (this->anmB.isAnimationDone())) {
		doStateChange(&StateID_Wait);
	}

	this->timer += 1;
}

void daRamboo_c::endState_Flee() {
}




void daRamboo_c::beginState_Outro() {

	bindAnimChr_and_setUpdateRates("DEATH", anmB, hideModel, 1.0f);
	Hiding = true;

	this->timer = 0;
	this->rot.x = 0x0; // X is vertical axis
	this->rot.y = 0xE000; // Y is horizontal axis
	this->rot.z = 0x0; // Z is ... an axis >.>

	OutroSetup(this);
}
void daRamboo_c::executeState_Outro() {
	hideModel._vf1C();
	if (this->anmB.isAnimationDone())
		this->anmB.setCurrentFrame(0.0);

	if (this->dying == 1) {
		if (this->timer > 180) {
			ExitStage(ProfileId::WORLD_MAP, 0, BEAT_LEVEL, MARIO_WIPE);
		}

		if (this->timer == 60) {
			PlayerVictoryCries(this);
		}

		this->timer = timer + 1;
		return;
	}

	bool ret;
	Vec tempPos = (Vec){this->pos.x + 160.0, this->pos.y + 80.0, 5500.0};
	ret = ShrinkBoss(this, &tempPos, 0.0, this->timer);

	if (timer >= 118) {
		BossExplode(this, &tempPos);
		this->dying = 1;
		this->timer = 0;
	}
	else if (timer == 20) {
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_EMY_BIG_TERESA_DEAD, 1);
	}

	timer = timer + 1;
}
void daRamboo_c::endState_Outro() { }



//
// processed\../src/bossBalboaWrench.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include <stage.h>
#include "boss.h"
#include <profile.h>
extern "C" void dAcPy_vf3F8(void* player, dEn_c* monster, int t);

class daBalboa_c : public daBoss {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;
	m3d::mdl_c spikesModel;

	nw4r::g3d::ResFile resFile;
	m3d::anmChr_c animationChr;

	int timer;
	int damage;
	float Baseline;
	float dying;
	Vec PopUp [3];
	char throwCount;
	char throwMax;
	float throwRate;
	char upsideDown;
	int isBigBoss;
	char isRevenging;
	int spinner;

	ActivePhysics spikeCollision;
	float spikeOffset;
	bool spikeGoingUp, spikeGoingDown;

	public: static dActor_c *build();

	void setupModels();
	void updateModelMatrices();
	void bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate);

	bool prePlayerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);

	void addScoreWhenHit(void *other);

	USING_STATES(daBalboa_c);
	DECLARE_STATE(Grow);
	DECLARE_STATE(ManholeUp);
	DECLARE_STATE(HeadPoke);
	DECLARE_STATE(AllOut);
	DECLARE_STATE(ThrowWrench);
	DECLARE_STATE(BackDown);
	DECLARE_STATE(Outro);
	DECLARE_STATE(Damage);
	DECLARE_STATE(RevengeUp);
	DECLARE_STATE(Revenge);
};

const char* BalboaWrenchNameList[] = {"choropoo","lift_zen", NULL};
const SpriteData BalboaWrenchSpriteData = {ProfileId::EN_BOSS_ROCKY, 0, 0xFFFFFFF8, 0, 0xFFFFFFB0, 0xA0, 0x50, 0, 0, 0, 0, 8};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile BalboaWrenchProfile(&daBalboa_c::build, SpriteId::EN_BOSS_ROCKY, &BalboaWrenchSpriteData, ProfileId::AC_LIFT_ICE_SPRING, ProfileId::EN_BOSS_ROCKY, "EN_BOSS_ROCKY", BalboaWrenchNameList, 0x8);

dActor_c *daBalboa_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daBalboa_c));
	return new(buffer) daBalboa_c;
}

// Externs

	CREATE_STATE(daBalboa_c, Grow);
	CREATE_STATE(daBalboa_c, ManholeUp);
	CREATE_STATE(daBalboa_c, HeadPoke);
	CREATE_STATE(daBalboa_c, AllOut);
	CREATE_STATE(daBalboa_c, ThrowWrench);
	CREATE_STATE(daBalboa_c, BackDown);
	CREATE_STATE(daBalboa_c, Outro);
	CREATE_STATE(daBalboa_c, Damage);
	CREATE_STATE(daBalboa_c, RevengeUp);
	CREATE_STATE(daBalboa_c, Revenge);

// Collisions
	void balbieCollisionCallback(ActivePhysics *apThis, ActivePhysics *apOther);

	void balbieCollisionCallback(ActivePhysics *apThis, ActivePhysics *apOther) {
		if (apOther->owner->profileId != ProfileId::EN_BOSS_WRENCH) {
			dEn_c::collisionCallback(apThis, apOther);
		}
	}

	void daBalboa_c::addScoreWhenHit(void *other) {}

bool daBalboa_c::prePlayerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
	if (apOther->owner->stageActorType == 1) {
		if (apOther->info.category2 == 7) {
			if (collisionCat7_GroundPound(apThis, apOther))
				return true;
		}
	}

	return dEn_c::prePlayerCollision(apThis, apOther);
}

	void daBalboa_c::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {

		char ret = usedForDeterminingStatePress_or_playerCollision(this, apThis, apOther, 0);

		if(ret == 0) {
			this->dEn_c::playerCollision(apThis, apOther);
			this->_vf220(apOther->owner);
		}

		//FIXME hack to make multiple playerCollisions work
		deathInfo.isDead = 0;
		this->flags_4FC |= (1<<(31-7));
		this->counter_504[apOther->owner->which_player] = 0;
	}

	bool daBalboa_c::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {

		dActor_c *block = apOther->owner;
		dEn_c *mario = (dEn_c*)block;

		SpawnEffect("Wm_en_vshit", 0, &mario->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});

		mario->speed.y = -mario->speed.y;
		mario->pos.y += mario->speed.y;

		if (mario->direction == 0) { mario->speed.x = 4.0; }
		else					  { mario->speed.x = -4.0; }

		mario->doSpriteMovement();
		mario->doSpriteMovement();

		if (isRevenging) {
			_vf220(apOther->owner);
		} else {
			this->damage -= 1;

			apOther->someFlagByte |= 2;

			PlaySoundAsync(this, SE_EMY_PENGUIN_DAMAGE);

			doStateChange(&StateID_Damage);
		}

		return true;
	}
	bool daBalboa_c::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) {
		return collisionCat7_GroundPound(apThis, apOther);
	}

	bool daBalboa_c::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
		return true;
	}
	bool daBalboa_c::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) {
		return false;
	}
	bool daBalboa_c::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
		return true;
	}
	bool daBalboa_c::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
		return true;
	}
	bool daBalboa_c::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther) {
		dAcPy_vf3F8(apOther->owner, this, 3);
		return true;
	}


void daBalboa_c::setupModels() {
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	nw4r::g3d::ResMdl mdl;
	nw4r::g3d::ResAnmChr anmChr;

	this->resFile.data = getResource("choropoo", "g3d/choropoo.brres");

	mdl = this->resFile.GetResMdl("choropoo");
	this->bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&this->bodyModel, 0);

	anmChr = this->resFile.GetResAnmChr("throw_1"); // 11
	this->animationChr.setup(mdl, anmChr, &this->allocator, 0);

	nw4r::g3d::ResFile togeRes;
	togeRes.data = getResource("lift_zen", "g3d/t01.brres");
	mdl = togeRes.GetResMdl("lift_togeU");
	spikesModel.setup(mdl, &allocator, 0, 1, 0);

	// throw_1 // 11
	// throw_2 // 75
	// throw_3 // 33
	// throw_4_left_hand // 87
	// throw_4_right_hand // 87
	// throw_5 // 23

	allocator.unlink();
}

// Animation Order...
// AppearLittle - Throw One, sound 0x21F
// Search - Throw two
// AppearFull - Throw 3 and sound 0x220
// Attack - Throw 4
// Disappear - Throw 5


void daBalboa_c::bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate) {
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr(name);
	this->animationChr.bind(&this->bodyModel, anmChr, unk);
	this->bodyModel.bindAnim(&this->animationChr, unk2);
	this->animationChr.setUpdateRate(rate);
}

int daBalboa_c::onCreate() {

	setupModels();

	this->scale = (Vec){1.0, 1.0, 1.0};
	this->isBigBoss = (this->settings >> 28);

	ActivePhysics::Info HitMeBaby;
	HitMeBaby.xDistToCenter = 0.0;
	HitMeBaby.yDistToCenter = 27.0;

	HitMeBaby.xDistToEdge = 18.0;
	HitMeBaby.yDistToEdge = 24.0;

	HitMeBaby.category1 = 0x3;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x4F;
	HitMeBaby.bitfield2 = 0xFFBAFFFE;
	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &balbieCollisionCallback;


	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();

	ActivePhysics::Info spikeInfo = {
		0.0f, 0.0f, 16.0f, 16.0f,
		3, 0, 0x4F, 0xFFBAFFFE, 0, &dEn_c::collisionCallback};
	spikeCollision.initWithStruct(this, &spikeInfo);
	spikeCollision.trpValue0 = 0.0f;
	spikeCollision.trpValue1 = 0.0f;
	spikeCollision.trpValue2 = -16.0f;
	spikeCollision.trpValue3 = 16.0f;
	spikeCollision.collisionCheckType = 3;

	this->rot.x = 0; // X is vertical axis
	this->rot.y = 0xE000; // Y is horizontal axis
	this->rot.z = 0; // Z is ... an axis >.>
	this->upsideDown = 0;
	this->direction = 0; // Heading left.
	this->pos.z = -800.0;
	this->pos.y -= 8.0;
	this->damage = 3;
	this->isRevenging = 0;

	this->PopUp[0] = (Vec){this->pos.x, this->pos.y - 54.0, this->pos.z};
	this->PopUp[1] = (Vec){this->pos.x - 224.0, this->pos.y - 54.0, this->pos.z};
	this->PopUp[2] = (Vec){this->pos.x - 112.0, this->pos.y - 22.0, this->pos.z};
	this->PopUp[3] = (Vec){this->pos.x - 112.0, this->pos.y - 22.0, this->pos.z};


	doStateChange(&StateID_Grow);

	this->onExecute();
	return true;
}

int daBalboa_c::onDelete() {
	return true;
}

int daBalboa_c::onExecute() {
	acState.execute();
	updateModelMatrices();

	if (spikeGoingUp) {
		spikeOffset += 2.5f;
		if (spikeOffset >= 48.0f) {
			spikeOffset = 48.0f;
			spikeGoingUp = false;
		}
	} else if (spikeGoingDown) {
		spikeOffset -= 2.5f;
		if (spikeOffset <= 0.0f) {
			spikeOffset = 0.0f;
			spikeGoingDown = false;
		}
	}
	spikeCollision.info.yDistToCenter = 16.0f + spikeOffset;

	bodyModel._vf1C();

	return true;
}

int daBalboa_c::onDraw() {

	bodyModel.scheduleForDrawing();
	if (spikeOffset > 0.0f)
		spikesModel.scheduleForDrawing();

	return true;
}

void daBalboa_c::updateModelMatrices() {
	// This won't work with wrap because I'm lazy.
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);

	mMtx spikeMatrix;
	VEC3 spikeScale = {2.0f,1.8f,2.0f};
	spikeMatrix.translation(pos.x, pos.y + spikeOffset, pos.z);
	spikesModel.setDrawMatrix(spikeMatrix);
	spikesModel.setScale(&spikeScale);
	spikesModel.calcWorld(false);
}

// Grow State

	void daBalboa_c::beginState_Grow() {
		this->timer = 0;

		SetupKameck(this, Kameck);

		bindAnimChr_and_setUpdateRate("begin_boss", 1, 0.0, 0.6);
	}

	void daBalboa_c::executeState_Grow() {

		if(this->animationChr.isAnimationDone())
			this->animationChr.setCurrentFrame(0.0);

		this->timer += 1;

		bool ret;
		ret = GrowBoss(this, Kameck, 1.0, 2.25, 0, this->timer);

		if (ret) {
			PlaySound(this, SE_EMY_CHOROPU_BOUND);
			doStateChange(&StateID_BackDown);
		}
	}
	void daBalboa_c::endState_Grow() {
		CleanupKameck(this, Kameck);
	}


// ManholeUp State

	void daBalboa_c::beginState_ManholeUp() {

		bindAnimChr_and_setUpdateRate("throw_1", 1, 0.0, 1.0);

		this->timer = 0;

		int randChoice;
		randChoice = GenerateRandomNumber(3);

		this->pos = this->PopUp[randChoice];



		if 		(randChoice == 0) { // On the left side!
			this->rot.y = 0xE000;
			this->rot.z = 0;
			this->upsideDown = 0;
			this->direction = 0; }

		else if (randChoice == 1) {	// On the right side!
			this->rot.y = 0x2000;
			this->rot.z = 0;
			this->upsideDown = 0;
			this->direction = 1; }

		// else if (randChoice == 2) {	// On the right ceiling!
		// 	this->rot.y = 0xE000;
		// 	this->rot.z = 0x8000;
		// 	this->upsideDown = 1;
		// 	this->direction = 0; }

		// else if (randChoice == 3) {	// On the left ceiling!
		// 	this->rot.y = 0x2000;
		// 	this->rot.z = 0x8000;
		// 	this->upsideDown = 1;
		// 	this->direction = 1; }

		else if (randChoice == 2) {	// In the Center!
			char Pdir = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);

			if (Pdir == 1) {
				this->rot.y = 0xE000;
				this->direction = 0; }
			else {
				this->rot.y = 0x2000;
				this->direction = 1; }
		}

		PlaySound(this, 0x21F);
	}

	void daBalboa_c::executeState_ManholeUp() {

		if (this->timer > 51) {
			doStateChange(&StateID_HeadPoke);
		}
		if (this->timer > 11) { }
		else {
			this->pos.y += 0.8182; // Height is 54 pixels, move up 9 pixels.
		}

		this->timer += 1;
	}
	void daBalboa_c::endState_ManholeUp() { }


// HeadPoke State

	void daBalboa_c::beginState_HeadPoke() {

		bindAnimChr_and_setUpdateRate("throw_2", 1, 0.0, 1.0);

		this->timer = 0;
	}

	void daBalboa_c::executeState_HeadPoke() {

		this->pos.y += 0.24; // Height is 54 pixels, move up 18 pixels.

		if(this->animationChr.isAnimationDone()) {
			doStateChange(&StateID_AllOut); }

	}
	void daBalboa_c::endState_HeadPoke() { }


// AllOut State

	void daBalboa_c::beginState_AllOut() {

		bindAnimChr_and_setUpdateRate("throw_3", 1, 0.0, 1.0);

		this->timer = 0;

		PlaySound(this, 0x220);
	}

	void daBalboa_c::executeState_AllOut() {


		this->pos.y += 0.8182; // Height is 54 pixels, move up 27 pixels.

		if(this->animationChr.isAnimationDone()) {
			doStateChange(&StateID_ThrowWrench);
		}
	}
	void daBalboa_c::endState_AllOut() { }


// ThrowWrench State

	void daBalboa_c::beginState_ThrowWrench() {

		this->throwCount = 0;
		if (this->isBigBoss == 1) {
			throwMax = 6;
			throwRate = 3.0;
		}
		else {
			throwMax = 4;
			throwRate = 2.0;
		}
		bindAnimChr_and_setUpdateRate("throw_4_right_hand", 1, 0.0, throwRate);
	}

	void daBalboa_c::executeState_ThrowWrench() {

		float frame = this->animationChr.getCurrentFrame();
		if (frame == 54.0) {
			u32 settings;
			u8 up = this->upsideDown;
			u8 throwc = this->throwCount;
			u8 dir;

			if (this->direction) { dir = 0; }
			else 				 { dir = 1; }

			settings = (dir) | (up << 1);
			settings = settings | (throwc & 1 << 8);

			if (this->isBigBoss == 1) { settings = settings | 0x10; }

			CreateActor(ProfileId::EN_BOSS_WRENCH, settings, this->pos, 0, 0);
		}

		if(this->animationChr.isAnimationDone()) {
			this->throwCount += 1;

			if (this->throwCount & 1) {
				bindAnimChr_and_setUpdateRate("throw_4_left_hand", 1, 0.0, throwRate);
			}
			else {
				bindAnimChr_and_setUpdateRate("throw_4_right_hand", 1, 0.0, throwRate);
			}
		}

		if (this->throwCount > throwMax) {
			doStateChange(&StateID_BackDown); }
	}
	void daBalboa_c::endState_ThrowWrench() { }


// BackDown State

	void daBalboa_c::beginState_BackDown() {

		bindAnimChr_and_setUpdateRate("throw_5", 1, 0.0, 1.0);

		this->timer = 0;

		PlaySound(this, 0x221);

		SpawnEffect("Wm_mr_sanddive_out", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){2.0, 1.0, 1.0});
		SpawnEffect("Wm_mr_sanddive_smk", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){2.0, 1.0, 1.0});
	}

	void daBalboa_c::executeState_BackDown() {

		if (this->timer < 60) {
			this->pos.y -= 2.0;  // Height is 54 pixels, move down
		}

		if (this->timer > 90) {
			doStateChange(&StateID_ManholeUp); }

		this->timer += 1;

	}
	void daBalboa_c::endState_BackDown() { }


// Outro

	void daBalboa_c::beginState_Outro() {

		bindAnimChr_and_setUpdateRate("dead", 1, 0.0, 1.0);

		OutroSetup(this);
		this->timer = 0;
		this->rot.x = 0x0; // X is vertical axis
		this->rot.z = 0x0; // Z is ... an axis >.>

	}
	void daBalboa_c::executeState_Outro() {

		if(this->animationChr.isAnimationDone())
			this->animationChr.setCurrentFrame(0.0);

		if (this->dying == 1) {
			if (this->timer > 180) { ExitStage(ProfileId::WORLD_MAP, 0, BEAT_LEVEL, MARIO_WIPE); }
			if (this->timer == 60) { PlayerVictoryCries(this); }

			this->timer += 1;
			return;
		}

		bool ret;
		ret = ShrinkBoss(this, &this->pos, 2.25, this->timer);
		this->pos.y -= 0.02;

		if (ret == true) 	{
			BossExplode(this, &this->pos);
			this->dying = 1;
			this->timer = 0;
		}
		else 		{ PlaySound(this, SE_EMY_CHOROPU_SIGN); }

		this->timer += 1;

	}
	void daBalboa_c::endState_Outro() { }


// Damage

	void daBalboa_c::beginState_Damage() {

		bindAnimChr_and_setUpdateRate("dead", 1, 0.0, 0.5);

		this->timer = 0;
		this->removeMyActivePhysics();
	}
	void daBalboa_c::executeState_Damage() {

		if (this->timer > 6) { doStateChange(&StateID_RevengeUp); }

		if(this->animationChr.isAnimationDone()) {
			this->animationChr.setCurrentFrame(0.0);

			this->timer += 1;
		}

		if (this->timer > 3) {
			this->pos.y -= 5.0; // Height is 54 pixels, move down
		}
		else if (this->timer > 2) {
			if (this->damage == 0) {
				StopBGMMusic();
				doStateChange(&StateID_Outro);
			}
			this->pos.y -= 3.5; // Height is 54 pixels, move down
		}
		else if (this->timer > 1) {
			this->pos.y -= 1.0; // Height is 54 pixels, move down
		}
		else if (this->timer > 0) {
			this->pos.y += 1.0; // Height is 54 pixels, move down
		}
		else {
			this->pos.y += 3.5; // Height is 54 pixels, move down
		}

	}
	void daBalboa_c::endState_Damage() {
		this->addMyActivePhysics();
	}


// Revenge Up

	void daBalboa_c::beginState_RevengeUp() {

		this->pos = this->PopUp[2];
		this->rot.y = 0;

		isRevenging = 1;
		bindAnimChr_and_setUpdateRate("throw_3", 1, 0.0, 1.0);
		spikeGoingUp = true;
		spikeCollision.addToList();

		PlaySound(this, 0x220);
	}
	void daBalboa_c::executeState_RevengeUp() {

		this->pos.y += 1.6363; // Height is 54 pixels, move up 27 pixels.

		if(this->animationChr.isAnimationDone()) {
			doStateChange(&StateID_Revenge);
		}

	}
	void daBalboa_c::endState_RevengeUp() { }


// Revenge

	void daBalboa_c::beginState_Revenge() {
		spinner = 0;

		this->throwCount = 0;
		if (this->isBigBoss == 1) {
			throwMax = 16;
			throwRate = 5.0;
		}
		else {
			throwMax = 12;
			throwRate = 3.0;
		}
		bindAnimChr_and_setUpdateRate("throw_4_right_hand", 1, 0.0, throwRate);
	}
	void daBalboa_c::executeState_Revenge() {

		float frame = this->animationChr.getCurrentFrame();

		rot.y = 16384.0 * (frame / 87.0) + (16384.0 * spinner);

		if (frame == 60.0) {
			u32 settings;
			u8 up = this->upsideDown;
			u8 throwc = this->throwCount;
			u8 dir;

			if (spinner < 2)	 { dir = 0; }
			else 				 { dir = 1; }

			settings = (dir) | (up << 1);
			settings = settings | (throwc & 1 << 8);

			if (this->isBigBoss == 1) { settings = settings | 0x10; }

			CreateActor(ProfileId::EN_BOSS_WRENCH, settings, this->pos, 0, 0);
		}

		if(this->animationChr.isAnimationDone()) {
			this->throwCount += 1;
			spinner += 1;
			if (spinner == 4) { spinner = 0; }

			if (this->throwCount & 1) {
				bindAnimChr_and_setUpdateRate("throw_4_left_hand", 1, 0.0, throwRate);
			}
			else {
				bindAnimChr_and_setUpdateRate("throw_4_right_hand", 1, 0.0, throwRate);
			}
		}

		if (this->throwCount > throwMax) {
			doStateChange(&StateID_BackDown); }

	}
	void daBalboa_c::endState_Revenge() {
			isRevenging = 0;
			spikeGoingDown = true;
			spikeCollision.removeFromList();
	}
//
// processed\../src/bossWrenchThrow.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include "boss.h"
#include <profile.h>

class daWrench : public dEn_c {
	int onCreate();
	int onExecute();
	int onDelete();
	int onDraw();

	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;

	int timer;
	char Kaboom;
	char direction;
	char front;
	float ymod;
	int lifespan;
	u32 cmgr_returnValue;

	public: static dActor_c *build();

	void updateModelMatrices();
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);


	USING_STATES(daWrench);
	DECLARE_STATE(Straight);
	DECLARE_STATE(Kaboom);

};

CREATE_STATE(daWrench, Straight);
CREATE_STATE(daWrench, Kaboom);


extern "C" void *PlayWrenchSound(dEn_c *);


void daWrench::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) { DamagePlayer(this, apThis, apOther); }

bool daWrench::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true;
}
bool daWrench::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) { 
	return false; 
}
bool daWrench::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true;
}
bool daWrench::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
	SpawnEffect("Wm_ob_cmnboxgrain", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.5, 0.5, 0.5});

	PlaySoundAsync(this, SE_BOSS_JR_FLOOR_BREAK);
	this->Delete(1);
	return true;
}
bool daWrench::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true;
}
bool daWrench::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) { 
	this->_vf220(apOther->owner);

	SpawnEffect("Wm_ob_cmnboxgrain", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.5, 0.5, 0.5});

	PlaySoundAsync(this, SE_BOSS_JR_FLOOR_BREAK);
	this->Delete(1);
	return true;
}

const char* WrenchThrowNameList[] = {"choropoo", NULL};
const SpriteData WrenchThrowSpriteData = {ProfileId::EN_BOSS_WRENCH, 8, 0xFFFFFFE0, 0, 0x10, 8, 0x18, 0, 0, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile WrenchThrowProfile(&daWrench::build, SpriteId::EN_BOSS_WRENCH, &WrenchThrowSpriteData, ProfileId::EN_GAKE_NOKO, ProfileId::EN_BOSS_WRENCH, "EN_BOSS_WRENCH", WrenchThrowNameList, 0x20);

dActor_c *daWrench::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daWrench));
	return new(buffer) daWrench;
}


int daWrench::onCreate() {
	
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	nw4r::g3d::ResFile rf(getResource("choropoo", "g3d/choropoo.brres"));
	bodyModel.setup(rf.GetResMdl("spanner"), &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&bodyModel, 0);

	allocator.unlink();
	
	
	this->direction = this->settings & 0xF;
	this->Kaboom = (this->settings >> 4) & 0xF;
	this->front = (this->settings >> 8) & 0xF;
	
	ActivePhysics::Info HitMeBaby;
	
	if (this->Kaboom == 0) {
		HitMeBaby.xDistToCenter = 0.0;
		HitMeBaby.yDistToCenter = 0.0;
		HitMeBaby.xDistToEdge = 5.0;
		HitMeBaby.yDistToEdge = 5.0;
	
		this->scale.x = 1.25;
		this->scale.y = 1.25;
		this->scale.z = 1.25;
	}
	
	else {
		HitMeBaby.xDistToCenter = 0.0;
		HitMeBaby.yDistToCenter = 0.0;
		HitMeBaby.xDistToEdge = 8.0;
		HitMeBaby.yDistToEdge = 8.0;
	
		this->scale.x = 2.0;
		this->scale.y = 2.0;
		this->scale.z = 2.0;
	}
	
	HitMeBaby.category1 = 0x3;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x47;
	HitMeBaby.bitfield2 = 0xFFFFFFFF;
	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();


	spriteSomeRectX = 5.0f;
	spriteSomeRectY = 5.0f;
	_320 = 0.0f;
	_324 = 5.0f;

	// These structs tell stupid collider what to collide with - these are from koopa troopa
	static const lineSensor_s below(12<<12, 4<<12, 0<<12);
	static const pointSensor_s above(0<<12, 12<<12);
	static const lineSensor_s adjacent(6<<12, 9<<12, 6<<12);

	collMgr.init(this, &below, &above, &adjacent);
	collMgr.calculateBelowCollisionWithSmokeEffect();

	cmgr_returnValue = collMgr.isOnTopOfTile();


	if (this->direction == 0) 	   { // Ground Facing Left
		this->pos.x -= 0.0; // -32 to +32
		this->pos.y += 36.0;
		this->rot.z = 0x2000;
	}
	else if (this->direction == 1) { // Ground Facing Right
		this->pos.x += 0.0; // +32 to -32
		this->pos.y += 36.0;
		this->rot.z = 0xE000;
	}
	if (this->front == 1) { this->pos.z = -1804.0; }
	else 				  { this->pos.z =  3300.0; }

	
	if (this->Kaboom) {
		doStateChange(&StateID_Kaboom); }
	else {
		doStateChange(&StateID_Straight); }
	
	this->onExecute();
	return true;
}


int daWrench::onDelete() {
	return true;
}

int daWrench::onDraw() {
	bodyModel.scheduleForDrawing();
	return true;
}


void daWrench::updateModelMatrices() {
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}


int daWrench::onExecute() {
	acState.execute();
	updateModelMatrices();

	float rect[] = {this->_320, this->_324, this->spriteSomeRectX, this->spriteSomeRectY};
	int ret = this->outOfZone(this->pos, (float*)&rect, this->currentZoneID);
	if(ret) {
		this->Delete(1);
	}

	return true;
}


void daWrench::beginState_Kaboom() { 
	float rand = (float)GenerateRandomNumber(10) * 0.4;

	if (this->direction == 0) { // directions 1 spins clockwise, fly rightwards
		speed.x = 1.0 + rand; 
	}
	else {						// directions 0 spins anti-clockwise, fly leftwards
		speed.x = -1.0 - rand; 
	}

	speed.y = 6.0;
}
void daWrench::executeState_Kaboom() { 

	speed.y = speed.y - 0.01875;

	HandleXSpeed();
	HandleYSpeed();
	doSpriteMovement();

	cmgr_returnValue = collMgr.isOnTopOfTile();
	collMgr.calculateBelowCollisionWithSmokeEffect();

	if (collMgr.isOnTopOfTile()) {
		// hit the ground
		PlaySoundAsync(this, SE_BOSS_JR_BOMB_BURST);

		SpawnEffect("Wm_en_burst_s", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.75, 0.75, 0.75});
		SpawnEffect("Wm_mr_wirehit", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.25, 1.25, 1.25});
		this->Delete(1);
	}
	if (collMgr.outputMaybe & (0x15 << direction)) {
		// hit the wall
		PlaySoundAsync(this, SE_BOSS_JR_BOMB_BURST);
 
		if (this->direction == 0) { // directions 1 spins clockwise, fly rightwards
			SpawnEffect("Wm_en_burst_s", 0, &this->pos, &(S16Vec){0,0x4000,0}, &(Vec){0.75, 0.75, 0.75});
			SpawnEffect("Wm_mr_wirehit", 0, &this->pos, &(S16Vec){0,0x4000,0}, &(Vec){1.25, 1.25, 1.25});
		}
		else {						// directions 0 spins anti-clockwise, fly leftwards
			SpawnEffect("Wm_en_burst_s", 0, &this->pos, &(S16Vec){0,0xE000,0}, &(Vec){0.75, 0.75, 0.75});
			SpawnEffect("Wm_mr_wirehit", 0, &this->pos, &(S16Vec){0,0xE000,0}, &(Vec){1.25, 1.25, 1.25});
		}

		this->Delete(1);
	}

	if (this->direction == 1) { // directions 1 spins clockwise, fly rightwards
		this->rot.z -= 0x1000; }
	else {						// directions 0 spins anti-clockwise, fly leftwards
		this->rot.z += 0x1000; }	
	
	PlayWrenchSound(this);

}
void daWrench::endState_Kaboom() { }



void daWrench::beginState_Straight() { 
	float rand = (float)GenerateRandomNumber(10) * 0.4;

	if (this->direction == 0) { // directions 1 spins clockwise, fly rightwards
		speed.x = 1.0 + rand; 
	}
	else {						// directions 0 spins anti-clockwise, fly leftwards
		speed.x = -1.0 - rand; 
	}

	speed.y = 6.0;
}
void daWrench::executeState_Straight() { 

	speed.y = speed.y - 0.01875;

	HandleXSpeed();
	HandleYSpeed();
	doSpriteMovement();

	cmgr_returnValue = collMgr.isOnTopOfTile();
	collMgr.calculateBelowCollisionWithSmokeEffect();

	if (collMgr.isOnTopOfTile()) {
		// hit the ground
		PlaySoundAsync(this, SE_BOSS_JR_FLOOR_BREAK);

		SpawnEffect("Wm_en_burst_s", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.75, 0.75, 0.75});
		this->Delete(1);
	}
	if (collMgr.outputMaybe & (0x15 << direction)) {
		// hit the wall
		PlaySoundAsync(this, SE_BOSS_JR_FLOOR_BREAK);

		SpawnEffect("Wm_en_burst_s", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.75, 0.75, 0.75});
		this->Delete(1);
	}

	if (this->direction == 1) { // directions 1 spins clockwise, fly rightwards
		this->rot.z -= 0x1000; }
	else {						// directions 0 spins anti-clockwise, fly leftwards
		this->rot.z += 0x1000; }	
	
	PlayWrenchSound(this);

}
void daWrench::endState_Straight() { }
//
// processed\../src/bossSamurshai.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include "boss.h"
#include <profile.h>

extern "C" void *SoundRelatedClass;
extern "C" void *MapSoundPlayer(void *SoundRelatedClass, int soundID, int unk);
extern "C" void dAcPy_vf3F8(void* player, dEn_c* monster, int t);

void ChucksAndKnucks(ActivePhysics *apThis, ActivePhysics *apOther);

class daSamurshai : public daBoss {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;
	m3d::mdl_c bodyModel;
	m3d::anmChr_c chrAnimation;

	mEf::es2 effect;

	int isBigBoss;
	int jumpCounter;
	char isDown;
	Vec initialPos;
	float XSpeed;
	u32 cmgr_returnValue;
	dStageActor_c *chosenOne;
	bool topHurts;
	bool slowDown;
	bool isBouncing;
	bool walkStateIsCharging;
	float amountCharged;

	ActivePhysics Chuckles;
	ActivePhysics Knuckles;

	public: static dActor_c *build();

	void bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate);
	void updateModelMatrices();
	bool calculateTileCollisions();

	void powBlockActivated(bool isNotMPGP);

	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);

	void addScoreWhenHit(void *other);
	int randomPlayer();

	bool isNearWall();

	USING_STATES(daSamurshai);

	DECLARE_STATE(Intro);
	DECLARE_STATE(Walk);
	DECLARE_STATE(Turn);
	DECLARE_STATE(Chop);
	DECLARE_STATE(ChargeSlash);
	DECLARE_STATE(Uppercut);
	DECLARE_STATE(SpinAttack);
	DECLARE_STATE(Damage);
	DECLARE_STATE(Outro);
};

const char* SSarcNameList [] = {"Shynja", NULL};
const SpriteData SamurshaiSpriteData = {ProfileId::EN_BOSS_SHYGUY, 0x10, 0x10, 0, 0, 0x40, 0x40, 0, 0, 0x40, 0x40, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile SamurshaiProfile(&daSamurshai::build, SpriteId::EN_BOSS_SHYGUY, &SamurshaiSpriteData, ProfileId::WM_PUKU, ProfileId::EN_BOSS_SHYGUY, "EN_BOSS_SHYGUY", SSarcNameList, 0x8);

dActor_c *daSamurshai::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daSamurshai));
	return new(buffer) daSamurshai;
}

///////////////////////
// Externs and States
///////////////////////
	extern "C" int SmoothRotation(short* rot, u16 amt, int unk2);

	CREATE_STATE(daSamurshai, Intro);
	CREATE_STATE(daSamurshai, Walk);
	CREATE_STATE(daSamurshai, Turn);
	CREATE_STATE(daSamurshai, Chop);
	CREATE_STATE(daSamurshai, ChargeSlash);
	CREATE_STATE(daSamurshai, Uppercut);
	CREATE_STATE(daSamurshai, SpinAttack);
	CREATE_STATE(daSamurshai, Damage);
	CREATE_STATE(daSamurshai, Outro);


////////////////////////
// Collision Functions
////////////////////////

	void ChucksAndKnucks(ActivePhysics *apThis, ActivePhysics *apOther) {
		if (((dEn_c*)apOther->owner)->profileId == ProfileId::PLAYER)
			((dEn_c*)apThis->owner)->_vf220(apOther->owner);
	}

	void daSamurshai::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {

		char hitType = 0;
		// this is shit code
		dStateBase_c *whatState = acState.getCurrentState();
		if (whatState == &StateID_Damage) {
			// nothing
		} else if (whatState == &StateID_Walk && walkStateIsCharging) {
			// also nothing
		} else {
			hitType = usedForDeterminingStatePress_or_playerCollision(this, apThis, apOther, 2);
		}

		if (hitType == 2) {
			// Mini jump
			apOther->someFlagByte |= 2;
		} else if (hitType > 0) {
			apOther->someFlagByte |= 2;
			if (this->isDown == 0) {
				this->playEnemyDownSound1();
				damage += 5;
				if (damage >= 15) { doStateChange(&StateID_Outro); }
				else { doStateChange(&StateID_Damage); }
			}
		}
		else {
			this->dEn_c::playerCollision(apThis, apOther);
			this->_vf220(apOther->owner);
		}

		deathInfo.isDead = 0;
		this->flags_4FC |= (1<<(31-7));
		this->counter_504[apOther->owner->which_player] = 0;
	}

	void daSamurshai::yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther) { this->playerCollision(apThis, apOther); }
	bool daSamurshai::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) {
		return collisionCat7_GroundPound(apThis, apOther);
	}
	bool daSamurshai::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
		apOther->someFlagByte |= 2;

		if (this->isDown == 0) {
			damage += 5;
			if (damage >= 15) { doStateChange(&StateID_Outro); }
			else { doStateChange(&StateID_Damage); }
		}

		deathInfo.isDead = 0;
		this->flags_4FC |= (1<<(31-7));
		this->counter_504[apOther->owner->which_player] = 5;
		bouncePlayerWhenJumpedOn(apOther->owner);
		return true;
	}
	bool daSamurshai::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) {
		return this->collisionCat7_GroundPound(apThis, apOther);
	}
	bool daSamurshai::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
		if (this->isDown == 0) {
			damage += 3;
			if (damage >= 15) { doStateChange(&StateID_Outro); }
			else { doStateChange(&StateID_Damage); }
		}
		return true;
	}
	bool daSamurshai::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther){
		return true;
	}
	bool daSamurshai::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther){
		dAcPy_vf3F8(apOther->owner, this, 3);

		deathInfo.isDead = 0;
		this->flags_4FC |= (1<<(31-7));
		this->counter_504[apOther->owner->which_player] = 0;
		return true;
	}
	bool daSamurshai::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther){
		//damage += 4;
		//SpawnEffect("Wm_mr_fireball_hit", 0, &apOther->owner->pos, &apOther->owner->rot, &apOther->owner->scale);
		//PlaySoundAsync(this, SE_OBJ_FIREBALL_DISAPP);
		//if (damage >= 15) { doStateChange(&StateID_Outro); }
		return true;
	}
	bool daSamurshai::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
		//damage += 1;
		//SpawnEffect("Wm_mr_fireball_hit", 0, &apOther->owner->pos, &apOther->owner->rot, &apOther->owner->scale);
		//PlaySoundAsync(this, SE_OBJ_FIREBALL_DISAPP);
		//if (damage >= 15) { doStateChange(&StateID_Outro); }
		return true;
	}
	bool daSamurshai::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) {
		return true;
	}
	bool daSamurshai::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
		//damage += 2;
		//this->spawnHitEffectAtPosition((Vec2){apOther->owner->pos.x, apOther->owner->pos.y});
		//if (damage >= 15) { doStateChange(&StateID_Outro); }
		return true;
	}


	void daSamurshai::addScoreWhenHit(void *other) { }
	void daSamurshai::powBlockActivated(bool isNotMPGP) { }

	bool daSamurshai::calculateTileCollisions() {
		// Returns true if sprite should turn, false if not.

		HandleXSpeed();
		HandleYSpeed();
		doSpriteMovement();

		cmgr_returnValue = collMgr.isOnTopOfTile();
		collMgr.calculateBelowCollisionWithSmokeEffect();

		if (isBouncing) {
			stuffRelatingToCollisions(0.1875f, 1.0f, 0.5f);
			if (speed.y != 0.0f)
				isBouncing = false;
		}

		if (collMgr.isOnTopOfTile()) {
			// Walking into a tile branch

			if (cmgr_returnValue == 0)
				isBouncing = true;

			speed.y = 0.0f;
		}

		// Bouncing checks
		if (_34A & 4) {
			Vec v = (Vec){0.0f, 1.0f, 0.0f};
			collMgr.pSpeed = &v;

			if (collMgr.calculateAboveCollision(collMgr.outputMaybe))
				speed.y = 0.0f;

			collMgr.pSpeed = &speed;

		} else {
			if (collMgr.calculateAboveCollision(collMgr.outputMaybe))
				speed.y = 0.0f;
		}

		collMgr.calculateAdjacentCollision(0);

		// Switch Direction
		if (collMgr.outputMaybe & (0x15 << direction)) {
			if (collMgr.isOnTopOfTile()) {
				isBouncing = true;
			}
			pos.x += direction ? 2.0 : -2.0;
			return true;
		}
		return false;
	}

void daSamurshai::bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate) {
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr(name);
	this->chrAnimation.bind(&this->bodyModel, anmChr, unk);
	this->bodyModel.bindAnim(&this->chrAnimation, unk2);
	this->chrAnimation.setUpdateRate(rate);
}

int daSamurshai::onCreate() {

	isBigBoss = settings & 0xF;

	// Model Setup
		allocator.link(-1, GameHeaps[0], 0, 0x20);

		this->resFile.data = getResource("Shynja", "g3d/Shynja.brres");
		nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("Shynja");
		bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
		SetupTextures_Boss(&this->bodyModel, 0);

		// Animations start here
		nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr("c18_IDLE_R");
		this->chrAnimation.setup(mdl, anmChr, &this->allocator, 0);

		allocator.unlink();

	// Character Setup

		scale = (Vec){25.0, 25.0, 25.0};

		pos.y = pos.y - 16.0 * 3.0;
		rot.x = 0; // X is vertical axis
		rot.y = 0xD800; // Y is horizontal axis
		rot.z = 0; // Z is ... an axis >.>
		direction = 1; // Heading left.

		speed.x = 0.0;
		speed.y = 0.0;
		XSpeed = 2.5;
		max_speed.x = 50.0;
		initialPos = pos;
		topHurts = false;

	// Physics
		ActivePhysics::Info HitMeBaby;

		HitMeBaby.xDistToCenter = 0.0;
		HitMeBaby.yDistToCenter = 15.0;

		HitMeBaby.xDistToEdge = 13.0;
		HitMeBaby.yDistToEdge = 15.0;

		HitMeBaby.category1 = 0x3;
		HitMeBaby.category2 = 0x0;
		HitMeBaby.bitfield1 = 0x4F;
		HitMeBaby.bitfield2 = 0xffbafffe;
		HitMeBaby.unkShort1C = 0;
		HitMeBaby.callback = &dEn_c::collisionCallback;

		this->aPhysics.initWithStruct(this, &HitMeBaby);
		this->aPhysics.addToList();

	// Tile collider

		// These fucking rects do something for the tile rect
		spriteSomeRectX = 48.0f;
		spriteSomeRectY = 36.0f;
		_320 = 0.0f;
		_324 = 18.0f;

		// These structs tell stupid collider what to collide with - these are from koopa troopa
		static const lineSensor_s below(-0<<12, 0<<12, 0<<12);
		static const pointSensor_s above(0<<12, 12<<12);
		static const lineSensor_s adjacent(6<<12, 9<<12, 6<<12);

		collMgr.init(this, &below, &above, &adjacent);
		collMgr.calculateBelowCollisionWithSmokeEffect();

		cmgr_returnValue = collMgr.isOnTopOfTile();

		if (collMgr.isOnTopOfTile())
			isBouncing = false;
		else
			isBouncing = true;

	// Sword Physics
		// Chuckles is left, Knuckles is Right
		ActivePhysics::Info iChuckles;
		ActivePhysics::Info iKnuckles;

		iChuckles.xDistToCenter = -27.0;
		iChuckles.yDistToCenter = 8.0;
		iChuckles.xDistToEdge   = 27.0;
		iChuckles.yDistToEdge   = 6.0;

		iKnuckles.xDistToCenter = 27.0;
		iKnuckles.yDistToCenter = 8.0;
		iKnuckles.xDistToEdge   = 27.0;
		iKnuckles.yDistToEdge   = 6.0;

		iKnuckles.category1  = iChuckles.category1  = 0x3;		iKnuckles.category2  = iChuckles.category2  = 0x0;
		iKnuckles.bitfield1  = iChuckles.bitfield1  = 0x4F;
		iKnuckles.bitfield2  = iChuckles.bitfield2  = 0x6;
		iKnuckles.unkShort1C = iChuckles.unkShort1C = 0x0;
		iKnuckles.callback   = iChuckles.callback   = ChucksAndKnucks;

		Chuckles.initWithStruct(this, &iChuckles);
		Knuckles.initWithStruct(this, &iKnuckles);

	doStateChange(&StateID_Intro);

	this->onExecute();
	return true;
}

int daSamurshai::onDelete() {
	return true;
}
int daSamurshai::onExecute() {
	acState.execute();
	updateModelMatrices();

	return true;
}
int daSamurshai::onDraw() {
	bodyModel.scheduleForDrawing();
	bodyModel._vf1C();

	return true;
}
void daSamurshai::updateModelMatrices() {
	// This won't work with wrap because I'm lazy.
	matrix.translation(pos.x, pos.y + 0.0, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}


///////////////
// Intro State
///////////////
	void daSamurshai::beginState_Intro() {
		this->timer = 0;

		// Stop the BGM Music
		StopBGMMusic();

		// Set the necessary Flags and make Mario enter Demo Mode
		dStage32C_c::instance->freezeMarioBossFlag = 1;
		WLClass::instance->_4 = 4;
		WLClass::instance->_8 = 0;

		MakeMarioEnterDemoMode();

		// Make sure to use the correct position
		Vec KamekPos = (Vec){pos.x - 124.0, pos.y + 104.0, 3564.0};
		S16Vec KamekRot = (S16Vec){0, 0, 0};

		rot.y = 0x2800; // Y is horizontal axis
		speed.x = 0.0;
		speed.y = 0.0;

		pos.x = pos.x - 224.0;
		pos.y = pos.y + 320.0;

		// Create And use Kameck
		Kameck = (daKameckDemo*)createChild(ProfileId::KAMECK_FOR_CASTLE_DEMO, (dStageActor_c*)this, 0, &KamekPos, &KamekRot, 0);
		Kameck->doStateChange(&daKameckDemo::StateID_DemoSt);
		Kameck->pos.x = Kameck->pos.x - 32.0;
	}

	void daSamurshai::executeState_Intro() {
		this->timer += 1;

		OSReport("Timer: %d", timer);
		if (timer == 230) { bindAnimChr_and_setUpdateRate("c18_INTRO", 1, 0.0, 1.0); }

		if ((timer > 220) && (timer < 240)) {
			pos.x += (224.0 / 20.0);
			pos.y -= (320.0 / 20.0);
		}

		if (timer == 230) {
			SpawnEffect("Wm_en_hanapetal", 0, &pos, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
			SpawnEffect("Wm_ob_itemget_ring", 0, &(Vec){pos.x, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){8.0, 0.1, 1.5});
			MapSoundPlayer(SoundRelatedClass, SE_OBJ_WOOD_BOX_BREAK, 1);
			MapSoundPlayer(SoundRelatedClass, SE_BOSS_KAMECK_DOWN, 1);
			this->Kameck->doStateChange(&daKameckDemo::StateID_DieFall);
		}

		if ((timer > 230) && (timer < 350)) {
			Kameck->pos.x += (200.0 / 120.0);
			Kameck->pos.y -= (260.0 / 120.0);
		}

		int done = 0;
		if ((timer > 330) && (done == 0)) {
			u16 amt = (this->direction == 0) ? 0x2800 : 0xD800;
			done = SmoothRotation(&this->rot.y, amt, 0x2000);
		}

		if (timer == 400) { bindAnimChr_and_setUpdateRate("c18_IDLE_R", 1, 0.0, 1.0); }

		if (timer == 500) {
			MapSoundPlayer(SoundRelatedClass, SE_BOSS_WENDY_RING_BOUND, 1);
			walkStateIsCharging = false;
			doStateChange(&StateID_Walk);
		}
	}
	void daSamurshai::endState_Intro() {
		CleanupKameck(this, Kameck);

		rot.y = 0xD800; // Y is horizontal axis
		direction = 1; // Heading left.
		XSpeed = 2.0;
		max_speed.x = 50.0;
	}

///////////////
// Walk State
///////////////
	int daSamurshai::randomPlayer() {
		int players[4];
		int playerCount = 0;

		for (int i = 0; i < 4; i++) {
			if (Player_Active[i] != 0 && Player_Lives[Player_ID[i]] > 0) {
				players[playerCount] = i;
				playerCount++;
			}
		}
		return players[MakeRandomNumber(playerCount)];
	}

	void daSamurshai::beginState_Walk() {
		Chuckles.removeFromList();
		Knuckles.removeFromList();

		bindAnimChr_and_setUpdateRate(walkStateIsCharging ? "c18_CHARGE" : "c18_RUNNING", 1, 0.0, 0.5);
		chosenOne = GetSpecificPlayerActor(this->randomPlayer());

		speed.x = (this->direction) ? -this->XSpeed : this->XSpeed;
		if (walkStateIsCharging)
			speed.x *= 1.7f;

		this->max_speed.y = -4.0;
		this->speed.y = -4.0;
		this->y_speed_inc = -0.1875;

		OSReport("Speed: %f / %f", speed.x, max_speed.x);
	}
	void daSamurshai::executeState_Walk() {
		MapSoundPlayer(SoundRelatedClass, SE_EMY_MOUSE_WALK, 1);

		float xDistance = pos.x - chosenOne->pos.x;
		float yDistance = pos.y - chosenOne->pos.y;

		// OSReport("Distance: %f, %f", xDistance, yDistance);
		if (!walkStateIsCharging && (xDistance >  64.0) && (direction == 0)) { doStateChange(&StateID_Turn); }
		if (!walkStateIsCharging && (xDistance < -64.0) && (direction == 1)) { doStateChange(&StateID_Turn); }

		if (xDistance < 0.0) { xDistance = -xDistance; }

		if (walkStateIsCharging) {
			amountCharged += abs(speed.x);

			// should we stop charging?
			if (amountCharged > 480.0f && !isNearWall()) {
				speed.x = (this->direction) ? -this->XSpeed : this->XSpeed;
				doStateChange(&StateID_Uppercut);
			}
		}

		// Condition for Chop
		if (!walkStateIsCharging && xDistance < 32.0) { doStateChange(&StateID_Chop); }

		// Condition For Charge Slash
		if (!walkStateIsCharging && isBigBoss) {
			if ((xDistance < 96.0) && (xDistance > 64.0)) {
				int charge = MakeRandomNumber(100);
				if (charge > 95) { doStateChange(&StateID_ChargeSlash); }
			}
		}

		// Aerial Attacks!
		if (!walkStateIsCharging && yDistance < -24.0) {

			// Condition For Spin Attack
			// if (xDistance < 32.0) { doStateChange(&StateID_SpinAttack); }

			// Condition for Uppercut
			if ((xDistance > 48.0) && (xDistance < 64.0) && !isNearWall())
				doStateChange(&StateID_Uppercut);
		}

		bool ret = calculateTileCollisions();
		if (ret) {
			doStateChange(&StateID_Turn);
		}

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}
	}
	void daSamurshai::endState_Walk() { }

///////////////
// Turn State
///////////////
	void daSamurshai::beginState_Turn() {
		bindAnimChr_and_setUpdateRate("c18_RUNNING", 1, 0.0, 0.5);
		this->speed.x = (direction) ? 0.5f : -0.5f;
		this->direction ^= 1;
		x_speed_inc = 0.0;
	}
	void daSamurshai::executeState_Turn() {

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}

		u16 amt = (this->direction == 0) ? 0x2800 : 0xD800;
		int done = SmoothRotation(&this->rot.y, amt, 0x1000);

		if(done) {
			this->doStateChange(&StateID_Walk);
		}
	}
	void daSamurshai::endState_Turn() { }

///////////////
// Chop State
///////////////
	void daSamurshai::beginState_Chop() {
		bindAnimChr_and_setUpdateRate("c18_H_CUT_R", 1, 0.0, 1.0);
		chrAnimation.setCurrentFrame(0.0);
		timer = 0;

	}
	void daSamurshai::executeState_Chop() {

		speed.x = speed.x / 1.5;

		if (chrAnimation.getCurrentFrame() == 15.0) {
			MapSoundPlayer(SoundRelatedClass, SE_EMY_CRASHER_PUNCH, 1);
			if (this->direction == 1) {
				SpawnEffect("Wm_ob_itemget_ring", 0, &(Vec){pos.x - 18.0, pos.y + 16.0, pos.z-200.0}, &(S16Vec){0,0,0}, &(Vec){2.5, 0.5, 1.5});
				Chuckles.addToList();
			}
			else {
				SpawnEffect("Wm_ob_itemget_ring", 0, &(Vec){pos.x + 18.0, pos.y + 16.0, pos.z-200.0}, &(S16Vec){0,0,0}, &(Vec){2.5, 0.5, 1.5});
				Knuckles.addToList();
			}
		}

		if (chrAnimation.getCurrentFrame() == 20.0) {
			MapSoundPlayer(SoundRelatedClass, SE_OBJ_WOOD_BOX_BREAK, 1);
			if (this->direction == 1) {
				SpawnEffect("Wm_en_hit", 0, &(Vec){pos.x - 38.0, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
				SpawnEffect("Wm_en_hanapetal", 0, &(Vec){pos.x - 38.0, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
				Chuckles.removeFromList();
			}
			else {
				SpawnEffect("Wm_en_hit", 0, &(Vec){pos.x + 38.0, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
				SpawnEffect("Wm_en_hanapetal", 0, &(Vec){pos.x + 38.0, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
				Knuckles.removeFromList();
			}
		}

		if(this->chrAnimation.isAnimationDone()) {
			timer += 1;
			if (timer > 45) {
				walkStateIsCharging = false;
				doStateChange(&StateID_Walk);
			}
		}
	}
	void daSamurshai::endState_Chop() { }

///////////////
// ChargeSlash State
///////////////
	void daSamurshai::beginState_ChargeSlash() {
		timer = 0;
		slowDown = false;
		topHurts = false;
		speed.x = 0.0;
	}
	void daSamurshai::executeState_ChargeSlash() {

		// End if the animation is finally over
		if ((chrAnimation.isAnimationDone()) && (slowDown) ) {
			walkStateIsCharging = false;
			doStateChange(&StateID_Walk);
			return;
		}

		// What to do if he hits a wall
		bool ret = calculateTileCollisions();
		if (ret) {
			OSReport("Hit the wall");
			bindAnimChr_and_setUpdateRate("c18_R_BLOCK_BREAK_R", 1, 0.0, 1.0);
			speed.x = (direction) ? 0.5f : -0.5f;
			topHurts = false;
			slowDown = true;
			timer = 500;
		}

		if (timer == 500) { speed.x = speed.x / 1.05; return; }

		// Begin the charge effect
		if (timer == 0) { bindAnimChr_and_setUpdateRate("c18_OB_IDLE_R", 1, 0.0, 0.5);
			if (direction == 1)
				SpawnEffect("Wm_ob_keyget02_lighit", 0, &(Vec){pos.x + 7.0, pos.y + 14.0, pos.z - 5500.0}, &(S16Vec){0,0,0}, &(Vec){0.8, 0.8, 0.8});
			else
				SpawnEffect("Wm_ob_keyget02_lighit", 0, &(Vec){pos.x - 7.0, pos.y + 14.0, pos.z + 5500.0}, &(S16Vec){0,0,0}, &(Vec){0.8, 0.8, 0.8});
		}

		// Start to cut
		if (timer == 60) { bindAnimChr_and_setUpdateRate("c18_H_CUT_R", 1, 0.0, 1.0); }

		// After enough charging, speed on!
		if (timer == 70) { speed.x = (direction) ? -16.0f : 16.0f; chrAnimation.setUpdateRate(0.0); }

		// He should not be able to be hurt for a while
		if (timer == 72) { topHurts = true; }

		OSReport("Speed: %f @ %d", speed.x, timer);
		float absSpeed;
		if (speed.x < 0.0) { absSpeed = -speed.x; }
		else			   { absSpeed =  speed.x; }

		// Can be bopped again when he gets slow enough
		if (absSpeed < 1.0) { topHurts = false; chrAnimation.setUpdateRate(1.0); }

		// During the dash
		if (absSpeed > 0.0) {
			// Slow that horsey down, tiger
			if (slowDown) { speed.x = speed.x / 1.5; return; }

			effect.spawn("Wm_mr_p_iceslip", 0, &(Vec){pos.x, pos.y+8.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
			SpawnEffect("Wm_en_hanapetal", 0, &pos, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
			SpawnEffect("Wm_ob_itemget_ring", 0, &(Vec){pos.x, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){4.0, 0.1, 1.5});

			if (timer == 75) { slowDown = true; }
			// Positive if Mario is left of Samurai, negative if he is to the right
			// float xDistance = pos.x - chosenOne->pos.x;

			// // direction 1 is going left, direction 0 is going right
			// if ((xDistance > 0) && (direction == 0)) {
			// 	SpawnEffect("Wm_ob_itemget_ring", 0, &(Vec){pos.x, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){4.0, 0.1, 1.5});
			// 	slowDown = true; }

			// if ((xDistance < 0) && (direction == 1)) {
			// 	SpawnEffect("Wm_ob_itemget_ring", 0, &(Vec){pos.x, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){4.0, 0.1, 1.5});
			// 	slowDown = true; }
		}

		this->timer += 1;
	}
	void daSamurshai::endState_ChargeSlash() {
		slowDown = false;
	}

///////////////
// Uppercut State
///////////////
	void daSamurshai::beginState_Uppercut() {
		bindAnimChr_and_setUpdateRate("c18_H_SHOT_R", 1, 0.0, 2.0);
		slowDown = false;
		timer = 0;
	}
	void daSamurshai::executeState_Uppercut() {

		if ((slowDown) && (this->chrAnimation.isAnimationDone())) {
			timer++;
			if (timer > 45) {
				walkStateIsCharging = false;
				doStateChange(&StateID_Walk);
			}
		}

		if (slowDown) {
			return;
		}

		if (this->chrAnimation.getCurrentFrame() == 34.0) {
			topHurts = true;
			MapSoundPlayer(SoundRelatedClass, SE_EMY_CRASHER_PUNCH, 1);
			MapSoundPlayer(SoundRelatedClass, SE_BOSS_CMN_JUMP_M, 1);

			speed.y = 4.0;
			y_speed_inc = -0.1875;

			if (this->direction == 1) {
				effect.spawn("Wm_ob_itemget_ring", 0, &(Vec){pos.x - 48.0, pos.y + 32.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){0.5, 1.5, 1.5});
				Chuckles.addToList();
			}
			else {
				effect.spawn("Wm_ob_itemget_ring", 0, &(Vec){pos.x + 48.0, pos.y + 32.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){0.5, 1.5, 1.5});
				Knuckles.addToList();
			}
		}

		if (this->chrAnimation.getCurrentFrame() == 64.0) {
			if (topHurts) {
				if (this->direction == 1) {
					SpawnEffect("Wm_en_hit", 0, &(Vec){pos.x - 38.0, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
					SpawnEffect("Wm_en_hanapetal", 0, &(Vec){pos.x - 38.0, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
					Chuckles.removeFromList();
				}
				else {
					SpawnEffect("Wm_en_hit", 0, &(Vec){pos.x + 38.0, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
					SpawnEffect("Wm_en_hanapetal", 0, &(Vec){pos.x + 38.0, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
					Knuckles.removeFromList();
				}

				MapSoundPlayer(SoundRelatedClass, SE_OBJ_WOOD_BOX_BREAK, 1);
				topHurts = false;
			}
		}

		if ((this->chrAnimation.getCurrentFrame() > 34.0) && (speed.y == 0)) {
			speed.x = 0.0f;
		}

		if ((this->chrAnimation.isAnimationDone()) && (speed.y == 0.0)) {
			bindAnimChr_and_setUpdateRate("c18_DIVING_STEAL_R", 1, 0.0, 1.0);
			slowDown = true;
		}

		bool ret = calculateTileCollisions();
	}
	void daSamurshai::endState_Uppercut() { slowDown = false; }

///////////////
// SpinAttack State
///////////////
	void daSamurshai::beginState_SpinAttack() {
		bindAnimChr_and_setUpdateRate("c18_NORMAL_STEAL_R", 1, 0.0, 1.0);
	}
	void daSamurshai::executeState_SpinAttack() {

		if((int)this->chrAnimation.getCurrentFrame() == 20) {
			topHurts = true;
			PlaySoundAsync(this, SE_EMY_CRASHER_PUNCH);

			speed.y = 3.0;
			y_speed_inc = -0.1875;

			if (this->direction == 1) { Chuckles.addToList(); }
			else { Knuckles.addToList(); }
		}

		if (((int)chrAnimation.getCurrentFrame() > 20) && ((int)this->chrAnimation.getCurrentFrame() < 60)) {
			scale = (Vec){1.0, 1.0, 1.0};
			if (this->direction == 1) {
				effect.spawn("Wm_mr_spinjump", 0, &(Vec){pos.x - 18.0, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &scale);
			}
			else {
				effect.spawn("Wm_mr_spinjump", 0, &(Vec){pos.x + 18.0, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &scale);
			}
		}

		if((int)this->chrAnimation.getCurrentFrame() == 65) {
			topHurts = false;
			PlaySoundAsync(this, SE_EMY_CRASHER_PUNCH);

			if (this->direction == 1) { Chuckles.removeFromList(); }
			else { Knuckles.removeFromList(); }
		}

		if ((this->chrAnimation.isAnimationDone()) && (speed.y == 0.0)) {
			walkStateIsCharging = false;
			doStateChange(&StateID_Walk);
		}

		bool ret = calculateTileCollisions();

	}
	void daSamurshai::endState_SpinAttack() {
	}

///////////////
// Damage State
///////////////
	void daSamurshai::beginState_Damage() {
		bindAnimChr_and_setUpdateRate("c18_L_DMG_F_1_R", 1, 0.0, 1.0);

		this->max_speed.x = 0;
		this->speed.x = 0;
		this->x_speed_inc = 0;

		this->max_speed.y = -2.0;
		this->speed.y = -2.0;
		this->y_speed_inc = -0.1875;

		this->timer = 0;
		this->isDown = 1;

		Chuckles.removeFromList();
		Knuckles.removeFromList();
		aPhysics.removeFromList();

		SpawnEffect("Wm_ob_switch", 0, &(Vec){pos.x, pos.y + 16.0, pos.z}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		MapSoundPlayer(SoundRelatedClass, SE_BOSS_CMN_DAMAGE_DEF, 1);
	}
	void daSamurshai::executeState_Damage() {
		calculateTileCollisions();

		effect.spawn("Wm_en_spindamage", 0, &(Vec){pos.x, pos.y + 40.0, 0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});

		if (this->chrAnimation.isAnimationDone()) {
			if 		(timer == 0) { bindAnimChr_and_setUpdateRate("c18_L_DMG_F_3_R", 1, 0.0, 1.0); timer = 1; }
			else if (timer == 1) { bindAnimChr_and_setUpdateRate("c18_L_DMG_F_4_R", 1, 0.0, 1.0); timer = 2; }
			else if (timer == 2) {
				walkStateIsCharging = true;
				amountCharged = 0.0f;
				doStateChange(&StateID_Walk);
			}
		}
	}
	void daSamurshai::endState_Damage() {
		aPhysics.addToList();

		this->isDown = 0;
		this->rot.y = (direction) ? 0xD800 : 0x2800;
	}

///////////////
// Outro State
///////////////
	void daSamurshai::beginState_Outro() {

		bindAnimChr_and_setUpdateRate("c18_SP_BLOCK_R", 1, 0.0, 1.0);
		OutroSetup(this);
		aPhysics.removeFromList();

		this->max_speed.x = 0;
		this->speed.x = 0;
		this->x_speed_inc = 0;

		this->max_speed.y = -2.0;
		this->speed.y = -2.0;
		this->y_speed_inc = -0.1875;

		this->timer = 0;
		this->isDown = 1;

		Chuckles.removeFromList();
		Knuckles.removeFromList();
		MapSoundPlayer(SoundRelatedClass, SE_BOSS_CMN_DAMAGE_LAST, 1);

	}
	void daSamurshai::executeState_Outro() {
		calculateTileCollisions();

		if (this->dying == 1) {

			if (this->timer > 180) { ExitStage(ProfileId::WORLD_MAP, 0, BEAT_LEVEL, MARIO_WIPE); }
			if (this->timer == 60) { PlayerVictoryCries(this); }

			this->timer += 1;
			return;
		}

		if ((chrAnimation.getCurrentFrame() == 41.0) || (chrAnimation.getCurrentFrame() == 62.0)) {
			SpawnEffect("Wm_en_landsmoke_s", 0, &(Vec){pos.x, pos.y - 8.0, pos.z + 500.0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		}

		if (chrAnimation.isAnimationDone()) {
			SpawnEffect("Wm_ob_cmnshotstar", 0, &(Vec){pos.x + 8.0, pos.y - 8.0, pos.z + 500.0}, &(S16Vec){0,0,0}, &(Vec){1.75, 1.75, 1.75});
			SpawnEffect("Wm_mr_wirehit_hit", 0, &(Vec){pos.x + 8.0, pos.y, pos.z + 500.0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});

			MapSoundPlayer(SoundRelatedClass, STRM_BGM_SHIRO_BOSS_CLEAR, 1);
			BossGoalForAllPlayers();

			this->dying = 1;
			this->timer = 0;
		}

		this->timer += 1;
	}
	void daSamurshai::endState_Outro() { }

bool daSamurshai::isNearWall() {
	// back up our current settings
	VEC3 savePos = pos;
	VEC3 saveSpeed = speed;
	int saveDirection = direction;

	float checkLeft = (direction == 0) ? 8.0f : 104.0f;
	float checkRight = (direction == 0) ? 104.0f : 8.0f;

	bool result = false;

	speed.x = -0.1f;
	speed.y = 0.0f;
	pos.x = savePos.x - checkLeft;
	direction = 1; // left
	if (collMgr.calculateAdjacentCollision())
		result = true;

	speed.x = 0.1f;
	speed.y = 0.0f;
	pos.x = savePos.x + checkRight;
	direction = 0; // right
	if (collMgr.calculateAdjacentCollision())
		result = true;

	// restore our settings
	pos = savePos;
	speed = saveSpeed;
	direction = saveDirection;

	return result;
}


//
// processed\../src/bossPodouble.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include <stage.h>
#include "boss.h"
#include <profile.h>

void poodleCollisionCallback(ActivePhysics *apThis, ActivePhysics *apOther);

void poodleCollisionCallback(ActivePhysics *apThis, ActivePhysics *apOther) {
		if (apOther->owner->profileId == ProfileId::BROS_FIREBALL) { return; }
		else if (apOther->owner->profileId == ProfileId::BROS_ICEBALL) { return; }
		else { dEn_c::collisionCallback(apThis, apOther); }
	}

class daPodouble : public daBoss {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	void updateHitboxSize();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;

	m3d::mdl_c bodyModel;
	m3d::mdl_c fogModel;
	//m3d::mdl_c fog2Model;

	m3d::anmChr_c fleeAnimation;
	m3d::anmTexSrt_c body;

	m3d::anmChr_c fogChr;
	m3d::anmTexSrt_c fogSRT;

	//m3d::anmChr_c fog2Chr;
	//m3d::anmTexSrt_c fog2SRT;


	char isFire;
	char goingUp;
	int timer;
	float dying;
	int damage;
	float Baseline;
	char isInvulnerable;
	int countdown;

	public: static dActor_c *build();

	// void spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);


	USING_STATES(daPodouble);
	DECLARE_STATE(Bounce);
	DECLARE_STATE(Spit);
	DECLARE_STATE(Damage);

	DECLARE_STATE(Grow);
	DECLARE_STATE(Outro);
	DECLARE_STATE(SyncDie);

};

const char* PodoubleNameList [] = {"bubble", NULL};
const SpriteData PodoubleSpriteData = {ProfileId::EN_BOSS_BUBBLE, 8, 0xFFFFFFF8, 0, 0, 0x20, 0x20, 0, 0, 0, 0, 8};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile PodoubleProfile(&daPodouble::build, SpriteId::EN_BOSS_BUBBLE, &PodoubleSpriteData, ProfileId::SHIP_WINDOW, ProfileId::EN_BOSS_BUBBLE, "EN_BOSS_BUBBLE", PodoubleNameList, 0x8);

dActor_c *daPodouble::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daPodouble));
	return new(buffer) daPodouble;
}

///////////////////////
// Externs and States
///////////////////////
	extern "C" int SmoothRotation(short* rot, u16 amt, int unk2);

	CREATE_STATE(daPodouble, Bounce);
	CREATE_STATE(daPodouble, Spit);
	CREATE_STATE(daPodouble, Damage);

	CREATE_STATE(daPodouble, Grow);
	CREATE_STATE(daPodouble, Outro);
	CREATE_STATE(daPodouble, SyncDie);


////////////////////////
// Collision Functions
////////////////////////

	void daPodouble::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) { DamagePlayer(this, apThis, apOther); }

	void daPodouble::yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther) 					 { this->playerCollision(apThis, apOther); }
	bool daPodouble::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) 	 {
		this->playerCollision(apThis, apOther);
		return true;
	}
	bool daPodouble::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) {
		this->playerCollision(apThis, apOther);
		return true;
	}
	bool daPodouble::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther)		 {
		this->playerCollision(apThis, apOther);
		return true;
	}

	bool daPodouble::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) 	{ return true; }
	bool daPodouble::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) { return true; }
	bool daPodouble::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther)		{ return true; }

	bool daPodouble::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
		apOther->owner->kill();
		return true;
	}

	bool daPodouble::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther){
		apOther->owner->Delete(1);
		if (this->isInvulnerable) { return true; }

		if (this->isFire == 0) {
			this->damage += 4;

			if (this->damage < 12)  { doStateChange(&StateID_Damage); }
			else 				    { doStateChange(&StateID_Outro); }
			return true;
		} else return false;
	}

	bool daPodouble::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
		if (this->isInvulnerable) { return true; }

		if (this->isFire == 0) {
			this->damage += 2;

			if (this->damage < 12)  { doStateChange(&StateID_Damage); }
			else 				    { doStateChange(&StateID_Outro); }
			return true;
		} else return false;
	}

	bool daPodouble::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) {
		apOther->owner->Delete(1);
		if (this->isInvulnerable) { return true; }

		if (this->isFire == 1) {
			if (apOther->owner->profileId == ProfileId::ICEBALL) { this->damage += 2; }
			else 						                         { this->damage += 4; }

			if (this->damage < 12)  { doStateChange(&StateID_Damage); }
			else 				    { doStateChange(&StateID_Outro); }

			return true;
		}
		else { return false; }
	}


void daPodouble::updateHitboxSize() {
	aPhysics.info.xDistToEdge = 11.429f * scale.x;
	aPhysics.info.yDistToEdge = 11.429f * scale.y;
}


int daPodouble::onCreate() {

	this->isFire = this->settings >> 28;
	this->Baseline = this->pos.y - (float)((this->settings & 0xFF) * 0.8);


	allocator.link(-1, GameHeaps[0], 0, 0x20);

	// Fire or Ice
	if (this->isFire == 1) {
		this->resFile.data = getResource("bubble", "g3d/t00.brres");
	}
	else {
		this->resFile.data = getResource("bubble", "g3d/t05.brres");
	}

	// Body and anms
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("bubble");
	nw4r::g3d::ResAnmChr shit = resFile.GetResAnmChr(isFire ? "RedFlee" : "BlueFlee");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	fleeAnimation.setup(mdl, shit, &allocator, 0);

	nw4r::g3d::ResAnmTexSrt anmRes = this->resFile.GetResAnmTexSrt("bubble");
	this->body.setup(mdl, anmRes, &this->allocator, 0, 1);
	this->body.bindEntry(&this->bodyModel, anmRes, 0, 0);
	this->bodyModel.bindAnim(&this->body, 0.0);


	// Fog up and anms
	mdl = this->resFile.GetResMdl("bubble_fog");
	fogModel.setup(mdl, &allocator, 0x124, 1, 0);

	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr("bubble_fog");
	this->fogChr.setup(mdl, anmChr, &this->allocator, 0);
	this->fogChr.bind(&this->fogModel, anmChr, 1);
	this->fogModel.bindAnim(&this->fogChr, 0.0);
	this->fogChr.setUpdateRate(1.0);

	anmRes = this->resFile.GetResAnmTexSrt("bubble_fog");
	this->fogSRT.setup(mdl, anmRes, &this->allocator, 0, 1);
	this->fogSRT.bindEntry(&this->fogModel, anmRes, 0, 0);
	this->fogModel.bindAnim(&this->fogSRT, 0.0);


	// Fog down and anms
	/*mdl = this->resFile.GetResMdl("bubble_fog2");
	fog2Model.setup(mdl, &allocator, 0x124, 1, 0);

	anmChr = this->resFile.GetResAnmChr("bubble_fog2");
	this->fog2Chr.setup(mdl, anmChr, &this->allocator, 0);
	this->fog2Chr.bind(&this->fog2Model, anmChr, 1);
	this->fogModel.bindAnim(&this->fog2Chr, 0.0);
	this->fog2Chr.setUpdateRate(1.0);

	anmRes = this->resFile.GetResAnmTexSrt("bubble_fog");
	this->fog2SRT.setup(mdl, anmRes, &this->allocator, 0, 1);
	this->fog2SRT.bindEntry(&this->fog2Model, anmRes, 0, 0);
	this->fog2Model.bindAnim(&this->fog2SRT, 0.0);*/



	allocator.unlink();


	// Stuff I do understand
	this->scale = (Vec){1.0, 1.0, 1.0};


	this->direction = (this->isFire) ? 0 : 1;
	this->countdown = (this->isFire) ? 90 : 0;

	this->rot.x = 0; // X is vertical axis
	this->rot.y = (direction) ? 0xD800 : 0x2800;
	this->rot.z = 0; // Z is ... an axis >.>

	this->speed.x = 0.0;
	this->speed.y = 0.0;
	this->max_speed.x = 0.0;
	this->x_speed_inc = 0.0;

	this->goingUp = 0;



	ActivePhysics::Info HitMeBaby;

	HitMeBaby.xDistToCenter = 0.0;
	HitMeBaby.yDistToCenter = 0.0;

	HitMeBaby.xDistToEdge = 40.0;
	HitMeBaby.yDistToEdge = 40.0;

	HitMeBaby.category1 = 0x3;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x4F;
	HitMeBaby.bitfield2 = (this->isFire) ? 0x380626 : 0x380626;
	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &poodleCollisionCallback;

	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();

	doStateChange(&StateID_Grow);

	this->onExecute();
	return true;
}

int daPodouble::onDelete() {
	return true;
}

int daPodouble::onExecute() {
	acState.execute();

	float diff = 8.57f * scale.x;
	float checkY = pos.y - diff, checkLastY = last_pos.y - diff;

	VEC2 myPos = {pos.x, checkY};
	VEC2 outBlockPos;
	float outFloat;
	s16 outAngle;
	int result = dWaterManager_c::instance->queryPosition(&myPos, &outBlockPos, &outFloat, &outAngle, currentLayerID);

	if ((!isFire && result == 0) || (isFire && result == 1)) {
		if ((checkLastY <= outFloat && outFloat < checkY) || (checkY <= outFloat && outFloat < checkLastY)) {
			VEC3 efPos = {pos.x, checkY, 6500.0f};
			VEC3 efScale = {scale.x * 0.7f, scale.y * 0.7f, scale.z * 0.7f};
			SpawnEffect(isFire ? "Wm_en_magmawave" : "Wm_en_waterwave_in", 0, &efPos, 0, &efScale);

			if (checkLastY <= outFloat && outFloat < checkY) {
				dBgGm_c::instance->makeSplash(pos.x, checkY, 0x11);
			} else {
				dBgGm_c::instance->makeSplash(pos.x, checkY, 0x10);
			}
		}
	}

	return true;
}

int daPodouble::onDraw() {
//	if (this->speed.y >= 0) {
		matrix.translation(pos.x, pos.y, pos.z);

		fogModel.setDrawMatrix(matrix);
		fogModel.setScale(&scale);
		fogModel.calcWorld(false);

		fogModel.scheduleForDrawing();
		fogModel._vf1C();
		fogChr.process();

		//if(this->fogChr.isAnimationDone())
		//	this->fogChr.setCurrentFrame(0.0);

		this->fogSRT.process();
/*	}
	else {
		matrix.translation(pos.x, pos.y, pos.z);

		fog2Model.setDrawMatrix(matrix);
		fog2Model.setScale(&scale);
		fog2Model.calcWorld(false);

		fog2Model.scheduleForDrawing();
		fog2Model._vf1C();

		if(this->fog2Chr.isAnimationDone())
			this->fog2Chr.setCurrentFrame(0.0);

		this->fog2SRT.process();
	}*/

	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);

	bodyModel.scheduleForDrawing();
	bodyModel._vf1C();
	this->body.process();
	if (acState.getCurrentState() == &StateID_SyncDie)
		fleeAnimation.process();

	return true;
}


///////////////
// Grow State
///////////////
	void daPodouble::beginState_Grow() {
		this->timer = 0;
		if (isFire) { return; }

		SetupKameck(this, Kameck);
		this->scale = (Vec){1.0, 1.0, 1.0};
	}

	void daPodouble::executeState_Grow() {

		this->timer += 1;

		if (isFire) {
			float scaleSpeed;

			if (timer == 150) { PlaySound(this, SE_BOSS_IGGY_WANWAN_TO_L); }

			if ((timer > 150) && (timer < 230)) {
				scaleSpeed = (3.5 - 1.0) / 80.0;

				float modifier;

				modifier = 1.0 + ((timer - 150) * scaleSpeed);

				this->scale = (Vec){modifier, modifier, modifier};
				this->pos.y = this->pos.y + (18/80.0);
			}

			if (timer > 420) {
				PlaySound(this, SE_EMY_CS_MOVE_W8_BUBBLE_APP);
				doStateChange(&StateID_Bounce);
			}

			return;
		}

		bool ret;
		ret = GrowBoss(this, Kameck, 1.0, 3.5, 18, this->timer);

		if (this->timer == 382) {

			int players = GetActivePlayerCount();

			Vec tempPos = (Vec){this->pos.x - 190.0, this->pos.y + 120.0, 3564.0};
			dStageActor_c *spawner = create(ProfileId::AC_YOSHI_EGG, 0x71010000, &tempPos, &(S16Vec){0,0,0}, 0);
			spawner->speed.x = spawner->speed.x / 2.0;

			if (players > 1) {
				tempPos = (Vec){this->pos.x - 190.0, this->pos.y + 120.0, 3564.0};
				spawner = create(ProfileId::AC_YOSHI_EGG, 0xF1010000, &tempPos, &(S16Vec){0,0,0}, 0);
				spawner->speed.x = spawner->speed.x / 2.0;
			}

			if (players > 2) {
				tempPos = (Vec){this->pos.x - 190.0, this->pos.y + 120.0, 3564.0};
				spawner->create(ProfileId::AC_YOSHI_EGG, 0x71010000, &tempPos, &(S16Vec){0,0,0}, 0);
			}

			if (players > 3) {
				tempPos = (Vec){this->pos.x - 190.0, this->pos.y + 120.0, 3564.0};
				create(ProfileId::AC_YOSHI_EGG, 0xF1010000, &tempPos, &(S16Vec){0,0,0}, 0);
			}
		}

		if (ret) {
			PlaySound(this, SE_EMY_CS_MOVE_W8_BUBBLE_APP);
			doStateChange(&StateID_Bounce);
		}
	}
	void daPodouble::endState_Grow() {
		this->Baseline = this->pos.y;
		if (isFire) { return; }

		CleanupKameck(this, Kameck);
	}


///////////////
// Bounce State
///////////////
	void daPodouble::beginState_Bounce() {
		this->rot.y = (direction) ? 0xD800 : 0x2800;
		this->rot.x = 0;

		this->max_speed.y = -5.0;
		this->speed.y = -1.0;
		this->y_speed_inc = -0.1875;

		this->goingUp = 0;
	}
	void daPodouble::executeState_Bounce() {

		if (this->countdown) {
			this->countdown--;
			return; }

		HandleYSpeed();
		doSpriteMovement();

		if (this->pos.y < this->Baseline) {
			this->speed.y = 7.5;
			this->goingUp = 1; }

		if (-0.1 < this->speed.y < 0.1) {
			if (this->goingUp == 1) { doStateChange(&StateID_Spit); } }


		// Check for stupid liquid junk
		checkLiquidImmersion(&(Vec2){this->pos.x, this->pos.y}, 3.0f);

	}
	void daPodouble::endState_Bounce() {
		this->speed.y = 0.0;
		this->y_speed_inc = 0.0;
	}


///////////////
// Spit State
///////////////
	void daPodouble::beginState_Spit() { this->timer = 0; }
	void daPodouble::executeState_Spit() {

		if (this->timer < 0x40) {
			this->rot.x -= 0x80;
		}

		else if (this->timer < 0x48) {
			this->rot.x += 0x400;
		}

		else if (this->timer == 0x48) {
			if (this->isFire == 0) {
				dStageActor_c *spawner = create(ProfileId::BROS_ICEBALL, 0x10, &this->pos, &(S16Vec){0,0,0}, 0);
				*((u32 *) (((char *) spawner) + 0x3DC)) = this->id;

				int num;
				num = GenerateRandomNumber(20) - 10;
				float modifier = (float)(num) / 10.0;

				spawner->max_speed.y += modifier;
				spawner->speed.y += modifier;

				num = GenerateRandomNumber(20) - 10;
				modifier = (float)(num) / 10.0;

				spawner->max_speed.x += modifier;
				spawner->speed.x += modifier;


				PlaySoundAsync(this, SE_EMY_ICE_BROS_ICE);
				doStateChange(&StateID_Bounce);
			}
			else {
				dStageActor_c *spawner = create(ProfileId::BROS_FIREBALL, 0, &this->pos, &(S16Vec){0,0,0}, 0);

				int num;
				num = GenerateRandomNumber(20);
				float modifier = (float)(num) / 5.0;

				spawner->max_speed.y += modifier;
				spawner->speed.y += modifier;

				num = GenerateRandomNumber(20);
				modifier = (float)(num) / 10.0;

				spawner->max_speed.x += modifier;
				spawner->speed.x += modifier;

				PlaySoundAsync(this, SE_EMY_FIRE_BROS_FIRE);
				doStateChange(&StateID_Bounce);
			}
		}

		this->timer += 1;
	}
	void daPodouble::endState_Spit() {
		this->speed.y = -1.0;
		this->y_speed_inc = -0.1875;
	}


///////////////
// Damage State
///////////////
	void daPodouble::beginState_Damage() {
		this->timer = 0;
		this->isInvulnerable = 1;

		if (this->isFire == 0) {
			PlaySoundAsync(this, SE_OBJ_PNGN_ICE_THAW);
			SpawnEffect("Wm_ob_iceevaporate", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0}); }
		else {
			PlaySoundAsync(this, SE_EMY_FIRE_SNAKE_EXTINCT);
			SpawnEffect("Wm_en_firesnk_icehitsmk_b", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){3.0, 3.0, 3.0}); }
	}
	void daPodouble::executeState_Damage() {

		int amt;
		amt = sin(this->timer * 3.14 / 4.0) * 0x2000;

		this->rot.y = amt;
		this->rot.y += (direction) ? 0xD800 : 0x2800;

		float targetScale = 3.5f - (damage * 0.175f);
		if (scale.x > targetScale) {
			float newScale = scale.x - 0.006f;
			if (newScale < targetScale)
				newScale = targetScale;
			scale.x = scale.y = scale.z = newScale;
			updateHitboxSize();
		}

		if (this->timer > 180) {
			doStateChange(&StateID_Bounce);
		}

		if ((this->timer == 60) || (this->timer == 80) || (this->timer == 100)) {
			if (this->isFire == 0) {
				dStageActor_c *spawner = create(ProfileId::BROS_ICEBALL, 0x10, &this->pos, &(S16Vec){0,0,0}, 0);
				*((u32 *) (((char *) spawner) + 0x3DC)) = this->id;
				PlaySoundAsync(this, SE_EMY_ICE_BROS_ICE);
			}
			else {
				create(ProfileId::BROS_FIREBALL, 0, &this->pos, &(S16Vec){0,0,0}, 0);
				PlaySoundAsync(this, SE_EMY_FIRE_BROS_FIRE);
			}
		}

		this->timer += 1;

	}
	void daPodouble::endState_Damage() {
		this->isInvulnerable = 0;
	}


///////////////
// Outro State
///////////////
	void daPodouble::beginState_Outro() {

		daPodouble *other = (daPodouble*)fBase_c::searchByProfileId(ProfileId::EN_BOSS_BUBBLE, 0);
			if (other->id == this->id) {
				other = (daPodouble*)fBase_c::searchByProfileId(ProfileId::EN_BOSS_BUBBLE, this);
			}
		other->doStateChange(&StateID_SyncDie);

		for (int i = 0; i < 4; i++) {
			dAcPy_c *player = (dAcPy_c*)GetSpecificPlayerActor(i);
			if (player && player->getYoshi()) {
				player->input.setFlag(dPlayerInput_c::NO_SHAKING);
			}
		}

		OutroSetup(this);
		this->timer = 0;

	}
	void daPodouble::executeState_Outro() {

		if (this->dying == 1) {
			if (this->timer > 180) { ExitStage(ProfileId::WORLD_MAP, 0, BEAT_LEVEL, MARIO_WIPE); }
			if (this->timer == 60) { PlayerVictoryCries(this); }

			this->timer += 1;
			return;
		}

		bool ret;
		ret = ShrinkBoss(this, &this->pos, 3.5, this->timer);

		if (ret == true) {
			BossExplode(this, &this->pos);
			this->dying = 1;
			this->timer = 0;
			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_EMY_BUBBLE_EXTINCT, 1);
		}

		this->timer += 1;

	}
	void daPodouble::endState_Outro() { }



///////////////
// SyncDie State
///////////////
	void daPodouble::beginState_SyncDie() {

		this->removeMyActivePhysics();
		this->timer = 0;

		nw4r::g3d::ResAnmChr anmChr = resFile.GetResAnmChr(isFire ? "RedFlee" : "BlueFlee");

		fleeAnimation.bind(&bodyModel, anmChr, 1);
		bodyModel.bindAnim(&fleeAnimation, 0.0);
		fleeAnimation.setUpdateRate(0.5f);

		fogChr.bind(&fogModel, anmChr, 1);
		fogModel.bindAnim(&fogChr, 0.0f);
		fogChr.setUpdateRate(0.5f);

		PlaySound(this, SE_EMY_GABON_ROCK_THROW);
	}
	void daPodouble::executeState_SyncDie() {
		if (fleeAnimation.isAnimationDone())
			Delete(0);
	}
	void daPodouble::endState_SyncDie() { }

//
// processed\../src/bossTopman.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include <stage.h>
#include "boss.h"
#include <profile.h>

class daDreidel : public daBoss {
public:
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;

	m3d::mdl_c bodyModel;

	m3d::anmChr_c chrAnimation;

	char isDown;
	float XSpeed;
	u32 cmgr_returnValue;
	bool isBouncing;
	char isInSpace;
	char fromBehind;
	char isInvulnerable;
	int isInvulnerableCountdown;
	int isTurningCountdown;
	char charging;
	int flashing;

	float dying;

	static dActor_c *build();

	void bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate);
	void updateModelMatrices();
	bool calculateTileCollisions();

	void powBlockActivated(bool isNotMPGP);

	void spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);

	void addScoreWhenHit(void *other);

	USING_STATES(daDreidel);
	DECLARE_STATE(Walk);
	DECLARE_STATE(Turn);
	DECLARE_STATE(KnockBack);

	DECLARE_STATE(ChargePrep);
	DECLARE_STATE(Charge);
	DECLARE_STATE(ChargeRecover);
	DECLARE_STATE(Damage);

	DECLARE_STATE(Grow);
	DECLARE_STATE(Outro);

};

const char* BossTopmanNameList [] = {"topman", NULL};
const SpriteData BossTopmanSpriteData = {ProfileId::EN_BOSS_TOPMAN, 0, 0, 0, 0, 0x10, 0x10, 0, 0, 0, 0, 2};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile BossTopmanProfile(&daDreidel::build, SpriteId::EN_BOSS_TOPMAN, &BossTopmanSpriteData, ProfileId::SLOW_QUICK_TAG, ProfileId::EN_BOSS_TOPMAN, "EN_BOSS_TOPMAN", BossTopmanNameList, 0x8);

dActor_c *daDreidel::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daDreidel));
	return new(buffer) daDreidel;
}

///////////////////////
// Externs and States
///////////////////////
	extern "C" void *EN_LandbarrelPlayerCollision(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);
	// CalculateDistanceFromActorsNextPosToFurthestPlayer???
	extern "C" int SmoothRotation(short* rot, u16 amt, int unk2);


	CREATE_STATE(daDreidel, Walk);
	CREATE_STATE(daDreidel, Turn);
	CREATE_STATE(daDreidel, KnockBack);

	CREATE_STATE(daDreidel, ChargePrep);
	CREATE_STATE(daDreidel, Charge);
	CREATE_STATE(daDreidel, ChargeRecover);
	CREATE_STATE(daDreidel, Damage);

	CREATE_STATE(daDreidel, Grow);
	CREATE_STATE(daDreidel, Outro);

	// 	begoman_attack2"	// wobble back and forth tilted forwards
	// 	begoman_attack3"	// Leaned forward, antennae extended
	// 	begoman_damage"		// Bounces back slightly
	// 	begoman_damage2"	// Stops spinning and wobbles to the ground like a top
	// 	begoman_stand"		// Stands still, waiting
	// 	begoman_wait"		// Dizzily Wobbles
	// 	begoman_wait2"		// spins around just slightly
	// 	begoman_attack"		// Rocks backwards, and then attacks to an upright position, pulsing out his antennae


////////////////////////
// Collision Functions
////////////////////////
	// void topCollisionCallback(ActivePhysics *apThis, ActivePhysics *apOther);

	// void topCollisionCallback(ActivePhysics *apThis, ActivePhysics *apOther) {
	// 	OSReport("Collided with %d", apOther->owner->profileId);
	// 	if (apOther->owner->profileId != 041) {
	// 		dEn_c::collisionCallback(apThis, apOther);
	// 	}
	// 	else {
	// 		daDreidel *actor = (daDreidel*)apThis->owner;
	// 		actor->damage += 1;
	// 		actor->doStateChange(&daDreidel::StateID_Damage);

	// 		if (actor->damage > 2) { actor->doStateChange(&daDreidel::StateID_Outro); }
	// 	}
	// }
	void daDreidel::addScoreWhenHit(void *other) { };

	void daDreidel::spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
		if (apOther->owner->profileId == ProfileId::NEEDLE_FOR_KOOPA_JR_B) { //time to get hurt
			OSReport("YO SUP I'M A TOPMAN AND I'M COLLIDING WITH A FUCKING WALL [%d]\n", damage);
			if (this->isInvulnerable) {
				OSReport("I'm invulnerable so I'm ignoring it\n");
				return;
			}
			this->damage += 1;
			OSReport("I'm increasing my damage to %d\n", damage);
			doStateChange(&StateID_Damage);

			if (this->damage == 3) { doStateChange(&StateID_Outro); }
		}
		else { dEn_c::spriteCollision(apThis, apOther); }
	}

	void daDreidel::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {


		char hitType;
		hitType = usedForDeterminingStatePress_or_playerCollision(this, apThis, apOther, 0);

		if(hitType > 0) {
			this->_vf220(apOther->owner);
			this->counter_504[apOther->owner->which_player] = 0;
		} else {

			if (this->charging == 1) {

				char MarioPos;

				if (this->pos.x < apOther->owner->pos.x) { MarioPos = 0; } // Mario is to the right
				else 									 { MarioPos = 1; } // Mario is to the left


				if (this->direction != MarioPos) {	// Mario is stnading behind the boss
					EN_LandbarrelPlayerCollision(this, apThis, apOther);
					if (MarioPos == 1)  { this->direction = 1; }
					else 				{ this->direction = 0; }

					doStateChange(&StateID_KnockBack);
				}

				else { // Mario is standing in front of the boss
					this->_vf220(apOther->owner);
					EN_LandbarrelPlayerCollision(this, apThis, apOther);
				}
			}

			else if (this->isInvulnerable == 0) {

				if (this->pos.x > apOther->owner->pos.x) {
					this->direction = 1;
				}
				else {
					this->direction = 0;
				}

				this->counter_504[apOther->owner->which_player] = 0;
				EN_LandbarrelPlayerCollision(this, apThis, apOther);
				doStateChange(&StateID_KnockBack);
			}
			else {
				this->counter_504[apOther->owner->which_player] = 0;
				EN_LandbarrelPlayerCollision(this, apThis, apOther);
			}
		}

		deathInfo.isDead = 0;
		this->flags_4FC |= (1<<(31-7));
	}

	void daDreidel::yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
		this->playerCollision(apThis, apOther);
	}

	bool daDreidel::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) {
		DamagePlayer(this, apThis, apOther);
		return true;
	}
	bool daDreidel::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
		DamagePlayer(this, apThis, apOther);
		return true;
	}
	bool daDreidel::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) {
		DamagePlayer(this, apThis, apOther);
		return true;
	}

	bool daDreidel::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
		if (this->isInvulnerable == 0) {
			doStateChange(&StateID_KnockBack);
		}
		return true;
	}
	bool daDreidel::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther){
		if (this->isInvulnerable == 0) {
			doStateChange(&StateID_KnockBack);
		}
		return true;
	}


	bool daDreidel::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther){ return true; }
	bool daDreidel::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) { return true; }
	bool daDreidel::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther){ return true; }
	bool daDreidel::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) { return true; }
	bool daDreidel::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) { return true; }

void daDreidel::powBlockActivated(bool isNotMPGP) { }


bool daDreidel::calculateTileCollisions() {
	// Returns true if sprite should turn, false if not.

	HandleXSpeed();
	HandleYSpeed();
	doSpriteMovement();

	cmgr_returnValue = collMgr.isOnTopOfTile();
	collMgr.calculateBelowCollisionWithSmokeEffect();

	if (isBouncing) {
		stuffRelatingToCollisions(0.1875f, 1.0f, 0.5f);
		if (speed.y != 0.0f)
			isBouncing = false;
	}

	float xDelta = pos.x - last_pos.x;
	if (xDelta >= 0.0f)
		direction = 0;
	else
		direction = 1;

	if (collMgr.isOnTopOfTile()) {
		// Walking into a tile branch

		if (cmgr_returnValue == 0)
			isBouncing = true;

		if (speed.x != 0.0f) {
			//playWmEnIronEffect();
		}

		speed.y = 0.0f;

		// u32 blah = collMgr.s_80070760();
		// u8 one = (blah & 0xFF);
		// static const float incs[5] = {0.00390625f, 0.0078125f, 0.015625f, 0.0234375f, 0.03125f};
		// x_speed_inc = incs[one];
		max_speed.x = (direction == 1) ? -1.0f : 1.0f;
	} else {
		x_speed_inc = 0.0f;
	}

	// Bouncing checks
	if (_34A & 4) {
		Vec v = (Vec){0.0f, 1.0f, 0.0f};
		collMgr.pSpeed = &v;

		if (collMgr.calculateAboveCollision(collMgr.outputMaybe))
			speed.y = 0.0f;

		collMgr.pSpeed = &speed;

	} else {
		if (collMgr.calculateAboveCollision(collMgr.outputMaybe))
			speed.y = 0.0f;
	}

	collMgr.calculateAdjacentCollision(0);

	// Switch Direction
	if (collMgr.outputMaybe & (0x15 << direction)) {
		if (collMgr.isOnTopOfTile()) {
			isBouncing = true;
		}
		return true;
	}
	return false;
}

void daDreidel::bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate) {
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr(name);
	this->chrAnimation.bind(&this->bodyModel, anmChr, unk);
	this->bodyModel.bindAnim(&this->chrAnimation, unk2);
	this->chrAnimation.setUpdateRate(rate);
}

int daDreidel::onCreate() {

	// Model creation
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	this->resFile.data = getResource("topman", "g3d/begoman_spike.brres");
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("begoman");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&this->bodyModel, 0);


	// Animations start here
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr("begoman_wait");
	this->chrAnimation.setup(mdl, anmChr, &this->allocator, 0);

	allocator.unlink();

	// Stuff I do understand
	this->scale = (Vec){0.2, 0.2, 0.2};

	// this->pos.y = this->pos.y + 30.0; // X is vertical axis
	this->rot.x = 0; // X is vertical axis
	this->rot.y = 0xD800; // Y is horizontal axis
	this->rot.z = 0; // Z is ... an axis >.>
	this->direction = 1; // Heading left.

	this->speed.x = 0.0;
	this->speed.y = 0.0;
	this->max_speed.x = 1.1;
	this->x_speed_inc = 0.0;
	this->XSpeed = 1.1;

	this->isInSpace = this->settings & 0xF;
	this->fromBehind = 0;
	this->flashing = 0;


	ActivePhysics::Info HitMeBaby;

	HitMeBaby.xDistToCenter = 0.0;
	HitMeBaby.yDistToCenter = 24.0;

	HitMeBaby.xDistToEdge = 28.0;
	HitMeBaby.yDistToEdge = 24.0;

	HitMeBaby.category1 = 0x3;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x4F;
	HitMeBaby.bitfield2 = 0xffbafffe;
	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();


	// Tile collider

	// These fucking rects do something for the tile rect
	spriteSomeRectX = 28.0f;
	spriteSomeRectY = 32.0f;
	_320 = 0.0f;
	_324 = 16.0f;

	// These structs tell stupid collider what to collide with - these are from koopa troopa
	static const lineSensor_s below(12<<12, 4<<12, 0<<12);
	static const pointSensor_s above(0<<12, 12<<12);
	static const lineSensor_s adjacent(6<<12, 9<<12, 6<<12);

	collMgr.init(this, &below, &above, &adjacent);
	collMgr.calculateBelowCollisionWithSmokeEffect();

	cmgr_returnValue = collMgr.isOnTopOfTile();

	if (collMgr.isOnTopOfTile())
		isBouncing = false;
	else
		isBouncing = true;


	// State Changers
	bindAnimChr_and_setUpdateRate("begoman_wait2", 1, 0.0, 1.0);
	doStateChange(&StateID_Grow);

	this->onExecute();
	return true;
}

int daDreidel::onDelete() {
	return true;
}

int daDreidel::onExecute() {
	acState.execute();
	updateModelMatrices();

	return true;
}

int daDreidel::onDraw() {

	if (this->isInvulnerable == 1) {
		this->flashing++;
	}

	if (this->flashing < 5) {
		bodyModel.scheduleForDrawing();
	}

	bodyModel._vf1C();

	if (this->flashing > 8) { this->flashing = 0; }

	return true;
}

void daDreidel::updateModelMatrices() {
	matrix.translation(pos.x, pos.y - 2.0, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}



///////////////
// Grow State
///////////////
	void daDreidel::beginState_Grow() {
		bindAnimChr_and_setUpdateRate("begoman_wait2", 1, 0.0, 0.75);

		this->timer = 0;

		SetupKameck(this, Kameck);
	}

	void daDreidel::executeState_Grow() {

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}

		this->timer += 1;

		bool ret;
		ret = GrowBoss(this, Kameck, 0.2, 0.4, 0, this->timer);

		if (ret) {
			PlaySound(this, SE_EMY_MECHAKOOPA_BOUND);
			doStateChange(&StateID_Walk);
		}
	}
	void daDreidel::endState_Grow() {
		this->chrAnimation.setUpdateRate(1.0);
		CleanupKameck(this, Kameck);
	}


///////////////
// Walk State
///////////////
	void daDreidel::beginState_Walk() {
		this->max_speed.x = (this->direction) ? -this->XSpeed : this->XSpeed;
		this->speed.x = (direction) ? -1.2f : 1.2f;

		this->max_speed.y = (this->isInSpace) ? -2.0 : -4.0;
		this->speed.y = 	(this->isInSpace) ? -2.0 : -4.0;
		this->y_speed_inc = (this->isInSpace) ? -0.09375 : -0.1875;

		this->isTurningCountdown = 0;
	}
	void daDreidel::executeState_Walk() {

		if (this->isInvulnerableCountdown > 0) {
			this->isInvulnerableCountdown--;
		}
		else {
			this->isInvulnerable = 0;
			this->flashing = 0;
		}

		PlaySound(this, SE_BOSS_JR_CROWN_JR_RIDE); // 5

		bool ret = calculateTileCollisions();
		if (ret) {
			doStateChange(&StateID_Turn);
		}

		u8 dir = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);
		if (dir != this->direction) {
			this->isTurningCountdown++;
		}

		if (this->isTurningCountdown > 60) { doStateChange(&StateID_Turn); }

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}
	}
	void daDreidel::endState_Walk() { this->timer += 1; }


///////////////
// Turn State
///////////////
	void daDreidel::beginState_Turn() {
		this->direction ^= 1;
		this->speed.x = 0.0;
	}
	void daDreidel::executeState_Turn() {

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}

		u16 amt = (this->direction == 0) ? 0x2800 : 0xD800;
		int done = SmoothRotation(&this->rot.y, amt, 0x800);

		if(done) {
			if (this->damage > 0) 	{ doStateChange(&StateID_ChargePrep); }
			else 					{ doStateChange(&StateID_Walk); }
		}
	}
	void daDreidel::endState_Turn() { this->rot.y = (this->direction) ? 0xD800 : 0x2800; }


///////////////
// Knockback State
///////////////
	void daDreidel::beginState_KnockBack() {
		bindAnimChr_and_setUpdateRate("begoman_damage", 1, 0.0, 0.65);

		this->max_speed.x = (this->direction) ? 6.5f : -6.5f;
		this->speed.x = (this->direction) ? 6.5f : -6.5f;
	}
	void daDreidel::executeState_KnockBack() {

		bool ret = calculateTileCollisions();
		if (ret) {
			this->max_speed.x = -this->max_speed.x;
			this->speed.x = -this->speed.x;
		}
		this->speed.x = this->speed.x / 1.08;

		bodyModel._vf1C();
		if(this->chrAnimation.isAnimationDone()) {
			if (this->damage > 0) 	{ doStateChange(&StateID_ChargePrep); }
			else 					{ doStateChange(&StateID_Walk); }
		}

	}
	void daDreidel::endState_KnockBack() {
		if (this->rot.y == 0x2800) {
			// CreateEffect(&this->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0}, 175);
			this->direction = 0;
		}
		else {
			// CreateEffect(&this->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0}, 192);
			this->direction = 1;
		}
		// this->direction ^= 1;
		bindAnimChr_and_setUpdateRate("begoman_wait2", 1, 0.0, 1.0);
	}


///////////////
// ChargePrep State
///////////////
	void daDreidel::beginState_ChargePrep() {
		bindAnimChr_and_setUpdateRate("begoman_attack", 1, 0.0, 0.9);
	}
	void daDreidel::executeState_ChargePrep() {
		if(this->chrAnimation.isAnimationDone()) {
			doStateChange(&StateID_Charge);
		}
	}
	void daDreidel::endState_ChargePrep() { }


///////////////
// Charge State
///////////////
	void daDreidel::beginState_Charge() {
		bindAnimChr_and_setUpdateRate("begoman_attack3", 1, 0.0, 1.0);
		this->timer = 0;
		this->isTurningCountdown = 0;

		this->max_speed.x = (this->direction) ? -this->XSpeed : this->XSpeed;
		this->speed.x = (direction) ? -2.6f : 2.6f;

		this->max_speed.y = (this->isInSpace) ? -2.0 : -4.0;
		this->speed.y = 	(this->isInSpace) ? -2.0 : -4.0;
		this->y_speed_inc = (this->isInSpace) ? -0.09375 : -0.1875;

		this->charging = 1;
	}
	void daDreidel::executeState_Charge() {

		if (this->isInvulnerableCountdown > 0) {
			this->isInvulnerableCountdown--;
		}
		else {
			this->isInvulnerable = 0;
			this->flashing = 0;
		}

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}

		bool ret = calculateTileCollisions();
		if (ret) {
			doStateChange(&StateID_ChargeRecover);
		}

		u8 dir = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);
		if (dir != this->direction) {
			this->isTurningCountdown++;
			this->speed.x = this->speed.x / 1.04;
		}

		if (this->isTurningCountdown > 90) { doStateChange(&StateID_Turn); }
	}
	void daDreidel::endState_Charge() {
		this->charging = 0;

		this->counter_504[0] = 0;
		this->counter_504[1] = 0;
		this->counter_504[2] = 0;
		this->counter_504[3] = 0;
	}


///////////////
// ChargeRecover State
///////////////
	void daDreidel::beginState_ChargeRecover() {
		bindAnimChr_and_setUpdateRate("begoman_stand", 1, 0.0, 0.5);
	}
	void daDreidel::executeState_ChargeRecover() {
		if(this->chrAnimation.isAnimationDone()) {
			doStateChange(&StateID_Turn);
		}
	}
	void daDreidel::endState_ChargeRecover() { }


///////////////
// Damage State
///////////////
	void daDreidel::beginState_Damage() {
		this->isInvulnerable = 1;
		bindAnimChr_and_setUpdateRate("begoman_wait", 1, 0.0, 0.75);
		this->timer = 0;

		PlaySound(this, SE_PLY_TOUCH_BIRI);
		PlaySound(this, SE_BOSS_JR_ELEC_SPARK);
		PlaySound(this, SE_EMY_BIRIKYU_SPARK);

		Vec front = {this->pos.x-4.0, this->pos.y+8.0, 5500.0};
		Vec back = {this->pos.x-4.0, this->pos.y+8.0, -5500.0};

		SpawnEffect("Wm_ob_cmnspark", 0, &front, 0, &(Vec){2.5, 2.5, 1.5});
		SpawnEffect("Wm_mr_wirehit_line", 0, &front, 0, &(Vec){1.5, 1.5, 1.5});
		SpawnEffect("Wm_mr_kick_grain", 0, &front, 0, &(Vec){1.5, 1.5, 1.5});
		SpawnEffect("Wm_mr_wirehit_glow", 0, &back, 0, &(Vec){2.5, 2.5, 2.5});
	}
	void daDreidel::executeState_Damage() {

		if(this->chrAnimation.isAnimationDone()) {
			this->timer += 1;
			if (this->timer == 1) {

				u8 dir = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);
				if (dir != this->direction) {
					doStateChange(&StateID_Turn);
				}
				else {
					if (this->damage > 1) 	{ doStateChange(&StateID_ChargePrep); }
					else 					{ doStateChange(&StateID_Walk); }
				}
			}
			else {
			}
			this->chrAnimation.setCurrentFrame(0.0);
		}
	}
	void daDreidel::endState_Damage() {
		bindAnimChr_and_setUpdateRate("begoman_wait2", 1, 0.0, 1.0);
		this->isInvulnerableCountdown = 90;
	}


///////////////
// Outro State
///////////////
	void daDreidel::beginState_Outro() {
		OutroSetup(this);
	}
	void daDreidel::executeState_Outro() {

		if (this->dying == 1) {
			if (this->timer > 180) { ExitStage(ProfileId::WORLD_MAP, 0, BEAT_LEVEL, MARIO_WIPE); }
			if (this->timer == 60) { PlayerVictoryCries(this); }

			this->timer += 1;
			return;
		}

		bool ret;
		ret = ShrinkBoss(this, &this->pos, 0.5, this->timer);

		if (ret == true) 	{
			BossExplode(this, &this->pos);
			this->dying = 1;
			this->timer = 0;
		}
		else 		{ PlaySound(this, SE_EMY_BUBBLE_EXTINCT); }

		this->timer += 1;
	}
	void daDreidel::endState_Outro() { }

//
// processed\../src/bossCaptainBowser.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include <stage.h>
#include <playerAnim.h>
#include "boss.h"
#include <profile.h>

extern "C" void *StageScreen;

extern u32 GameTimer;

#define time_macro *(u32*)((GameTimer) + 0x4)


// const char* effects_name_list [] = {
// 	"Wm_jr_electricline", // cool
// 	"Wm_jr_fireattack", // cool
// 	"Wm_jr_firehit", // cool
// 	"Wm_jr_fireplace", // cool
// 	"Wm_jr_fireplace_ind", // cool
// 	"Wm_jr_shot",
// 	"Wm_jr_sweat",
// 	"Wm_ko_fireattack", // cool
// 	"Wm_ko_firehit", // cool
// 	"Wm_ko_firehitdie01", // cool
// 	"Wm_ko_firehitdie02", // cool
// 	"Wm_ko_firehitdie03", // cool
// 	"Wm_ko_magmapocha",
// 	"Wm_ko_magmapochabig",
// 	"Wm_ko_shout", // cool
// 	"Wm_ko_shout02", // cool
// 	"Wm_seacloudout", // cool
// };


const char* CBarcNameList [] = {
	"KoopaShip",
	"koopa",
	"choropoo",
	"koopa_clown_bomb",
	"dossun",
	"fire_cannon",
	NULL
};


class daCaptainBowser : public daBoss {
public:
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();
	int afterExecute(int param);

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;
	nw4r::g3d::ResFile shipFile;

	m3d::mdl_c bodyModel;
	m3d::mdl_c shipModel;

	m3d::anmChr_c chrAnimation;
	m3d::anmChr_c shipAnm;

	nw4r::snd::SoundHandle prplSound;

	static const int SHIP_SCOLL_COUNT = 7;
	Physics shipSColls[SHIP_SCOLL_COUNT];
	mEf::es2 effect;

	mEf::es2 shipDmgA;
	mEf::es2 shipDmgB;
	mEf::es2 shipDmgC;
	mEf::es2 shipDmgD;
	mEf::es2 shipDmgE;

	mEf::es2 flamethrowerEffect;
	mEf::es2 flamethrowerEffectInd;

	nw4r::g3d::ResFile flamethrowerRF;
	m3d::mdl_c flamethrowerModel;
	m3d::anmTexSrt_c flamethrowerAnim;
	bool renderFlamethrowerModel;
	ActivePhysics flameCollision;

#define flameOffsetX -160.0f
#define flameOffsetY 150.0f
#define flameZ 1900.0f
	Vec flameScale;

	char isAngry;
	char isInvulnerable;
	char isIntro;
	int maxDamage;
	int playerCount;
	float roarLen;

	float bowserX, bowserY;
	s16 bowserRotX, bowserRotY;
	float bowserXSpeed, bowserYSpeed, bowserMaxYSpeed, bowserYAccel;

	s16 shipRotY;
	float sinTimerX;
	float sinTimerY;
	bool sinTimerXRunning, sinTimerYRunning, stopMoving;

	bool shipAnmFinished;
	float explosionBottomBound;

	bool deathSequenceRunning;
	bool forceClownEnds;
	int timerWhenCrashHappens;
	int timerForVictoryDance;
	void initiateDeathSequence();

	int clownCount;
	dEn_c *clownPointers[4];
	VEC2 clownDests[4];

	int saveTimer;
	bool exitedFlag;

	public: static dActor_c *build();

	void bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate);

	void spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);

	void addScoreWhenHit(void *other);

	USING_STATES(daCaptainBowser);
	DECLARE_STATE(Wait);
	DECLARE_STATE(Throw);
	DECLARE_STATE(Fire);

	DECLARE_STATE(Roar);
	DECLARE_STATE(Damage);

	DECLARE_STATE(Intro);
	DECLARE_STATE(FinalAttack);
	DECLARE_STATE(Outro);
	DECLARE_STATE(PanToExit);

};

const SpriteData BossCaptainBowserSpriteData = {ProfileId::EN_BOSS_CAPTAIN_BOWSER, 0x10, 0x10, 0, 0, 0x200, 0x200, 0, 0, 0x200, 0x200, 2};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile BossCaptainBowserProfile(&daCaptainBowser::build, SpriteId::EN_BOSS_CAPTAIN_BOWSER, &BossCaptainBowserSpriteData, ProfileId::BRANCH, ProfileId::EN_BOSS_CAPTAIN_BOWSER, "EN_BOSS_CAPTAIN_BOWSER", CBarcNameList, 0x8);

dActor_c *daCaptainBowser::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daCaptainBowser));
	return new(buffer) daCaptainBowser;
}

///////////////////////
// Externs and States
///////////////////////


	CREATE_STATE(daCaptainBowser, Wait);
	CREATE_STATE(daCaptainBowser, Throw);
	CREATE_STATE(daCaptainBowser, Fire);

	CREATE_STATE(daCaptainBowser, Roar);
	CREATE_STATE(daCaptainBowser, Damage);

	CREATE_STATE(daCaptainBowser, Intro);
	CREATE_STATE(daCaptainBowser, FinalAttack);
	CREATE_STATE(daCaptainBowser, Outro);
	CREATE_STATE(daCaptainBowser, PanToExit);



////////////////////////
// Collision Functions
////////////////////////
void daCaptainBowser::addScoreWhenHit(void *other) { };

bool daCaptainBowser::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
	apOther->owner->kill();
	SpawnEffect("Wm_en_burst_m", 0, &apOther->owner->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
	apThis->someFlagByte |= 2;
	return true;
}

void daCaptainBowser::spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
	if (apOther->owner->profileId == ProfileId::JR_CLOWN_PLAYER_CANNONSHOT) { //time to get hurt
		if (this->isInvulnerable) {
			return;
		}
		this->damage -= 1;

		spawnHitEffectAtPosition((Vec2){apOther->owner->pos.x, apOther->owner->pos.y});

		SpawnEffect("Wm_en_burst_m", 0, &apOther->owner->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		PlaySound(apOther->owner, SE_BOSS_CMN_STOMPED);
		apOther->owner->Delete(1);

		if (this->damage == this->maxDamage/2) 	{ doStateChange(&StateID_Roar); }
		else if (this->damage < 0)  			{ initiateDeathSequence(); }
		else 									{ doStateChange(&StateID_Damage); }
	}
}

void daCaptainBowser::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
}



void daCaptainBowser::bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate) {
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr(name);
	this->chrAnimation.bind(&this->bodyModel, anmChr, unk);
	this->bodyModel.bindAnim(&this->chrAnimation, unk2);
	this->chrAnimation.setUpdateRate(rate);
}

int daCaptainBowser::onCreate() {
	bowserX = -148.0f;
	bowserY = 122.0f;
	bowserRotY = 0xD800;

	shipRotY = 0x4000;
	sinTimerXRunning = true;
	sinTimerYRunning = true;

	// Model creation
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	// B-b-b-bad boy Bowsaa
	this->resFile.data = getResource("koopa", "g3d/koopa.brres");
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("koopa");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Boss(&bodyModel, 0);

	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr("kp_wait");
	this->chrAnimation.setup(mdl, anmChr, &this->allocator, 0);


	// A ship off the ol' block
	this->shipFile.data = getResource("KoopaShip", "g3d/KoopaShip.brres");
	nw4r::g3d::ResMdl mdlShip = this->shipFile.GetResMdl("KoopaShip");
	shipModel.setup(mdlShip, &allocator, 0x224, 1, 0);
	SetupTextures_MapObj(&shipModel, 0);

	nw4r::g3d::ResAnmChr anmChrShip = this->shipFile.GetResAnmChr("KoopaShip");
	this->shipAnm.setup(mdlShip, anmChrShip, &this->allocator, 0);
	this->shipAnm.bind(&this->shipModel, anmChrShip, 1);
	this->shipModel.bindAnim(&this->shipAnm, 0.0);
	this->shipAnm.setUpdateRate(1.0);

	// Flamethrower
	flamethrowerRF.data = getResource("fire_cannon", "g3d/flame_koopa.brres");

	nw4r::g3d::ResMdl ftResMdl = flamethrowerRF.GetResMdl("fire_effect1x6_right");
	nw4r::g3d::ResAnmTexSrt ftResAnm = flamethrowerRF.GetResAnmTexSrt("fire_effect1x6_right");

	flamethrowerModel.setup(ftResMdl, &allocator, 0x224, 1, 0);
	SetupTextures_MapObj(&flamethrowerModel, 0);

	flamethrowerAnim.setup(ftResMdl, ftResAnm, &allocator, 0, 1);
	flamethrowerAnim.bindEntry(&flamethrowerModel, ftResAnm, 0, 0);
	flamethrowerModel.bindAnim(&flamethrowerAnim, 0.0f);
	flamethrowerAnim.setFrameForEntry(0.0f, 0);
	flamethrowerAnim.setUpdateRate(1.0f);

	allocator.unlink();

	// Prep the goods
	this->playerCount = GetActivePlayerCount();
	this->maxDamage = 24;

	pos.z = 8000.0;
	this->scale = (Vec){0.57, 0.57, 0.57};

	this->damage = this->maxDamage;
	static const float scX1[] = {-176.447600, 64.340078, -157.925471, -157.925471, -158.561530, 49.742932, 48.957043};
	static const float scY1[] = {128.217300, 86.427956, 54.136191, -36.090801, 22.765115, 162.568398, 66.849169};
	static const float scX2[] = {-96.022566, 150.126781, 173.523155, 81.887358, -50.343171, 84.419332, 117.889270};
	static const float scY2[] = {54.136191, 54.136191, -36.090801, -79.779661, -26.166291, 142.846802, -2.083058};
	static s16 sRots[] = {-8192, -8192, -8192};

	for (int i = 0; i < SHIP_SCOLL_COUNT; i++) {
		shipSColls[i].setup(this,
				scX1[i], scY1[i], scX2[i], scY2[i],
				0, 0, 0, 1, 0);
		if (i >= 4)
			shipSColls[i].setPtrToRotation(&sRots[i - 4]);
	}

	// Bowser Physics!
	ActivePhysics::Info BowserPhysics;
	BowserPhysics.xDistToCenter = -152.0;
	BowserPhysics.yDistToCenter = 152.0;

	BowserPhysics.xDistToEdge = 28.0;
	BowserPhysics.yDistToEdge = 26.0;

	BowserPhysics.category1 = 0x3;
	BowserPhysics.category2 = 0x0;
	BowserPhysics.bitfield1 = 0x4F;
	BowserPhysics.bitfield2 = 0x8028E;
	BowserPhysics.unkShort1C = 0;
	BowserPhysics.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &BowserPhysics);



	// State Changers
	this->isIntro = 3;
	doStateChange(&StateID_Intro);

	return true;
}

int daCaptainBowser::onDelete() {
	if (prplSound.Exists())
		prplSound.Stop(0);
	return true;
}

int daCaptainBowser::afterExecute(int param) {
	return dEn_c::afterExecute(param);
}

int daCaptainBowser::onExecute() {
	if (forceClownEnds) {
		dEn_c *clownIter = 0;
		while (clownIter = (dEn_c*)dEn_c::searchByProfileId(ProfileId::JR_CLOWN_FOR_PLAYER, clownIter)) {
			clownIter->counter_500 = 120; // what a terrible hack.
			float *pPropRotationIncrement = (float*)(((u32)clownIter) + 0x740);
			*pPropRotationIncrement = 30.0f;

			SmoothRotation((s16*)(((u32)clownIter) + 0xD4A), 0, 0x300);
		}
	}

	acState.execute();
	if (saveTimer > 0)
		time_macro = saveTimer;

	if (!prplSound.Exists() && acState.getCurrentState() != &StateID_Outro && acState.getCurrentState() != &StateID_PanToExit) {
		PlaySoundWithFunctionB4(SoundRelatedClass, &prplSound, SE_BOSS_SHIP_PRPL, 1);
	}

	aPhysics.info.xDistToCenter = bowserX;
	aPhysics.info.yDistToCenter = bowserY + 28.0f;

	bodyModel._vf1C();
	shipModel._vf1C();

	for (int i = 0; i < SHIP_SCOLL_COUNT; i++)
		shipSColls[i].update();

	float xmod = sinTimerXRunning ? (sin(this->sinTimerX * 3.14 / 180.0) * 60.0) : 0.0f;
	float ymod = sin(this->sinTimerY * 3.14 / 130.0) * (sinTimerYRunning ? 84.0 : 10.0);

	if(this->isIntro == 0) {
		pos.x = ClassWithCameraInfo::instance->screenCentreX + 200.0 + xmod;
		pos.y = ClassWithCameraInfo::instance->screenCentreY - 180.0 + ymod;

		sinTimerX++;
		if (sinTimerX >= 360) {
			sinTimerX = 0;
			if (stopMoving)
				sinTimerXRunning = false;
		}

		sinTimerY++;
		if (sinTimerY >= 260) {
			sinTimerY = 0;
			if (stopMoving)
				sinTimerYRunning = false;
		}
	}

	if(this->shipAnm.isAnimationDone() && acState.getCurrentState() != &StateID_Outro && acState.getCurrentState() != &StateID_PanToExit) {
		this->shipAnm.setCurrentFrame(0.0);
	}

	return true;
}

int daCaptainBowser::onDraw() {

	if(this->isIntro > 2) { return false; }

	matrix.translation(pos.x+bowserX, pos.y+bowserY, pos.z-200.0); // 136.0 is the bottom of the platform footing
	matrix.applyRotationYXZ(&bowserRotX, &bowserRotY, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&(Vec){1.0, 1.0, 1.0});
	bodyModel.calcWorld(false);

	bodyModel.scheduleForDrawing();


	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &shipRotY, &rot.z);

	shipModel.setDrawMatrix(matrix);
	shipModel.setScale(&scale);
	shipModel.calcWorld(false);

	shipModel.scheduleForDrawing();

	if (renderFlamethrowerModel) {
		matrix.translation(pos.x + flameOffsetX, pos.y + flameOffsetY, flameZ);
		s16 thing = 0x8000;
		matrix.applyRotationZ(&thing);

		flamethrowerModel.setDrawMatrix(matrix);
		flamethrowerModel.setScale(&flameScale);
		flamethrowerModel.calcWorld(false);

		flamethrowerModel.scheduleForDrawing();
	}

	return true;
}


//////////////////
// State Intro
//////////////////
	void daCaptainBowser::beginState_Intro() {
		this->timer = 0;
		bindAnimChr_and_setUpdateRate("kp_wait", 1, 0.0, 1.5);
		this->isInvulnerable = 1;
		roarLen = 300;
	}
	void daCaptainBowser::executeState_Intro() {

		if (this->chrAnimation.isAnimationDone()) {
			// End the intro
			if (this->isIntro == 1) {
				OSReport("We're done: %d", this->timer);
				doStateChange(&StateID_Wait);
				return;
			}
			this->chrAnimation.setCurrentFrame(0.0); }

		// Screen Rumble
		if ((this->timer > 180) && (this->timer < 420)) {
		// if (this->timer == 180) {
			// Do Rumbly - 807CD3AC

			pos.x = ClassWithCameraInfo::instance->screenCentreX;
			pos.y = ClassWithCameraInfo::instance->screenCentreY;

			ShakeScreen(StageScreen, 2, 1, 0, 0);
			PlaySoundAsync(this, SE_BOSS_KOOPA_RUMBLE1); // 0x5D4
			// Stage80::instance->ShakeScreen(self, 5, 1, 0);
		}

		// Bowser Flies In
		if (this->timer == 422) {
			this->isIntro = 2;

			for (int i = 0; i < SHIP_SCOLL_COUNT; i++)
				shipSColls[i].addToList();
		}

		if (this->timer > 420) {
			int effectiveTimer = min(timer, 719U);
			pos.x = ClassWithCameraInfo::instance->screenCentreX + ((effectiveTimer - 420.0) * 1.5) - ((roarLen * 1.5) - 200.0);
			pos.y = ClassWithCameraInfo::instance->screenCentreY - 380.0 + ((effectiveTimer - 420.0) * 1.5) - ((roarLen * 1.5) - 200.0);
		}

		// Bowser does a shitty roar
		if (this->timer == (roarLen - 190 + 420)) {
			this->isIntro = 1;
			bindAnimChr_and_setUpdateRate("kp_roar3", 1, 0.0, 1.0);
		}
		if (this->timer > (roarLen - 190 + 420)) {

			if (this->chrAnimation.getCurrentFrame() == 53.0) {
				PlaySound(this, SE_VOC_KP_L_SHOUT);
			}

			if (this->chrAnimation.getCurrentFrame() > 53.0) {
				ShakeScreen(StageScreen, 2, 2, 0, 0);
				effect.spawn("Wm_ko_shout", 0, &(Vec){pos.x-182.0, pos.y+132.0, pos.z}, &(S16Vec){0,0,0x7000}, &(Vec){1.0, 1.0, 1.0});
			}
		}

		this->timer++;
	}
	void daCaptainBowser::endState_Intro() {

		this->aPhysics.addToList();

		this->isInvulnerable = 0;
		this->isIntro = 0;
	}


//////////////////
// State Wait
//////////////////
	void daCaptainBowser::beginState_Wait() {
		if (this->isAngry == 0) {
			bindAnimChr_and_setUpdateRate("kp_wait", 1, 0.0, 1.5);
		}
		else {
			bindAnimChr_and_setUpdateRate("kp_wait", 1, 0.0, 2.0);
		}
	}
	void daCaptainBowser::executeState_Wait() {

	if (this->chrAnimation.isAnimationDone()) {
		this->chrAnimation.setCurrentFrame(0.0);

		int num = GenerateRandomNumber(4);

		if (num == 0) {
			doStateChange(&StateID_Fire);
		}
		else{
			doStateChange(&StateID_Throw);
		}
	}

	}
	void daCaptainBowser::endState_Wait() {  }


//////////////////
// State Throw
//////////////////
	void daCaptainBowser::beginState_Throw() {
		bindAnimChr_and_setUpdateRate("break", 1, 0.0, 1.0);
		this->timer = 0;
	}
	void daCaptainBowser::executeState_Throw() {

		if (this->chrAnimation.getCurrentFrame() == 60.0) { // throw back
			int num = GenerateRandomNumber(4);
			CreateActor(ProfileId::EN_BOSS_KOOPA_THROW, 0x101 + ((num + 1) * 0x10), (Vec){pos.x+bowserX, pos.y+bowserY, pos.z}, 0, 0);
		}

		if (this->chrAnimation.getCurrentFrame() == 126.0) { // throw front
			int num = GenerateRandomNumber(4);
			CreateActor(ProfileId::EN_BOSS_KOOPA_THROW, ((num + 1) * 0x10) + 1, (Vec){pos.x+bowserX, pos.y+bowserY, pos.z}, 0, 0);
		}

		if (this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
			if (this->isAngry == 1) {
				if (this->timer == 1) {
					doStateChange(&StateID_Wait);
				}
			}
			else {
				doStateChange(&StateID_Wait);
			}

			this->timer++;
		}

	}
	void daCaptainBowser::endState_Throw() {  }


//////////////////
// State Fire
//////////////////
	void daCaptainBowser::beginState_Fire() {
		bindAnimChr_and_setUpdateRate("fire1", 1, 0.0, 1.5);
		this->timer = 0;
	}
	void daCaptainBowser::executeState_Fire() {

		if (this->chrAnimation.getCurrentFrame() == 70.5) { // spit fire
			PlaySound(this, SE_BOSS_KOOPA_L_FIRE_SHOT);
			CreateActor(ProfileId::EN_BOSS_KOOPA_FLAME, 0, (Vec){pos.x-172.0, pos.y+152.0, pos.z}, 0, 0);
		}

		if (this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
			if (this->isAngry == 1) {
				if (this->timer == 1) {
					doStateChange(&StateID_Wait);
				}
			}
			else {
				doStateChange(&StateID_Wait);
			}

			this->timer++;
		}

	}
	void daCaptainBowser::endState_Fire() {  }



//////////////////
// State Roar
//////////////////
	void daCaptainBowser::beginState_Roar() {
		bindAnimChr_and_setUpdateRate("kp_roar3", 1, 0.0, 1.0);
		this->isInvulnerable = 1;
		this->timer = 0;
	}
	void daCaptainBowser::executeState_Roar() {

		if (this->chrAnimation.getCurrentFrame() == 53.0) { // This is where the smackdown starts
			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_VOC_KP_L_SHOUT, 1);
		}

		if (this->chrAnimation.getCurrentFrame() > 53.0) { // This is where the smackdown starts
			effect.spawn("Wm_ko_shout", 0, &(Vec){pos.x-174.0, pos.y+140.0, pos.z}, &(S16Vec){0,0,0x7000}, &(Vec){1.0, 1.0, 1.0});
		}

		if (this->chrAnimation.isAnimationDone()) {
			doStateChange(deathSequenceRunning ? &StateID_FinalAttack : &StateID_Wait);
		}

	}
	void daCaptainBowser::endState_Roar() {
		this->isInvulnerable = 0;
		this->isAngry = 1;
	}



//////////////////
// State Damage
//////////////////
	void daCaptainBowser::beginState_Damage() {
		bindAnimChr_and_setUpdateRate("grow_big", 1, 0.0, 1.0);
		this->isInvulnerable = 1;
		this->chrAnimation.setCurrentFrame(9.0);

		PlaySound(this, SE_VOC_KP_DAMAGE_HPDP);
	}
	void daCaptainBowser::executeState_Damage() {

		if (this->chrAnimation.getCurrentFrame() == 65.0) { // stop it here before it's too late
			doStateChange(&StateID_Wait);
		}

	}
	void daCaptainBowser::endState_Damage() { this->isInvulnerable = 0; }


//////////////////
// State Outro
//////////////////
void daCaptainBowser::initiateDeathSequence() {
	deathSequenceRunning = true;
	stopMoving = true;
	saveTimer = time_macro;

	StopBGMMusic();
	dFlagMgr_c::instance->set(31, 0, false, false, false);

	*((u32*)(((char*)dBgGm_c::instance) + 0x900F0)) = 999;

	doStateChange(&StateID_Roar);
}

void daCaptainBowser::beginState_FinalAttack() {
	isInvulnerable = true;

	bindAnimChr_and_setUpdateRate("mastfail", 1, 0.0, 1.0f);

	timer = 0;
	flameScale.x = flameScale.y = flameScale.z = 0.0f;
}

void daCaptainBowser::executeState_FinalAttack() {
	timer++;

	if (timer == 56) {
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_VOC_JR_CHARGE, 1);
		handle.SetPitch(0.25f);
	} else if (timer == 185) {
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_VOC_KP_SHOUT, 1);
	} else if (timer == 348) {
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_EMY_BIG_PAKKUN_DAMAGE_1, 1);
	}

	if (timer > 204 && timer < 315) {
		if (timer == 205) {
			// First thing
			renderFlamethrowerModel = true;

			static const ActivePhysics::Info fcInfo = {
				0.0f, 0.0f, 0.0f, 0.0f, // placeholder
				3, 0, 0x4F, 0x8028E, 0,
				&dEn_c::collisionCallback
			};
			flameCollision.initWithStruct(this, &fcInfo);
			flameCollision.addToList();
		}
		if (timer < 289) {
			if (flameScale.y < 2.0f) {
				flameScale.y = flameScale.y = flameScale.z = flameScale.y + 0.1f;
			} else {
				flameScale.y = flameScale.y = flameScale.z = 2.5f;
			}
		}
		flameScale.x = flameScale.y * 1.5f;

		flameCollision.info.xDistToCenter = flameOffsetX - (48.0f * flameScale.x);
		flameCollision.info.yDistToCenter = flameOffsetY;
		flameCollision.info.xDistToEdge = 48.0f * flameScale.x;
		flameCollision.info.yDistToEdge = 7.0f * flameScale.y;

		Vec efPos = {pos.x + flameOffsetX, pos.y + flameOffsetY, flameZ};
		S16Vec efRot = {-0x4000, 0, 0};
		//flamethrowerEffect.spawn("Wm_en_fireburner", 0, &efPos, &efRot, &flameScale);
		flamethrowerEffectInd.spawn("Wm_en_fireburner6ind", 0, &efPos, &efRot, &flameScale);
		flamethrowerModel._vf1C();
		flamethrowerAnim.process();
	} else if (timer == 315) {
		renderFlamethrowerModel = false;
		flameCollision.removeFromList();
		aPhysics.removeFromList();

		Vec efPos = {pos.x + flameOffsetX - 6.0f, pos.y + flameOffsetY + 1.0f, pos.z};
		float offsets[] = {0.0f, 3.0f, 0.0f, -3.0f};
		for (int i = 0; i < 20; i++) {
			efPos.y = pos.y + flameOffsetY + offsets[i & 3];
			SpawnEffect("Wm_mr_fireball_hit01", 0, &efPos, &(S16Vec){0,0,0}, &(Vec){1.5f, 1.5f, 1.5f});
			efPos.x -= 12.0f;
		}

		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_OBJ_PAIPO, 1);
	} else if (timer == 348) {
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_DEMO_ED_BALLOON_LAND, 1);

		Vec efPos = {pos.x - 72.0f, pos.y + 170.0f, pos.z};
		SpawnEffect("Wm_mr_wallkick_l", 0, &efPos, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
	}

	if (chrAnimation.isAnimationDone()) {
		doStateChange(&StateID_Outro);
	}
}

void daCaptainBowser::endState_FinalAttack() {
}

void daCaptainBowser::beginState_Outro() {
	WLClass::instance->_4 = 5;
	WLClass::instance->_8 = 0;
	dStage32C_c::instance->freezeMarioBossFlag = 1;

	bowserX += 56.0f;
	bindAnimChr_and_setUpdateRate("kp_death1", 1, 0.0, 1.0f);

	//shipRotY = -0x4000;
	shipAnm.bind(&shipModel, shipFile.GetResAnmChr("mastfail_after"), 1);
	shipModel.bindAnim(&shipAnm, 0.0);
	shipAnm.setUpdateRate(0.5f);

	bowserXSpeed = -3.5f;
	bowserYSpeed = 8.9f;
	bowserMaxYSpeed = -4.0f;
	bowserYAccel = -0.24375f;

	nw4r::snd::SoundHandle handle;
	PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_VOC_KP_L_FALL, 1);

	explosionBottomBound = 0.0f;

	timer = 0;
	timerWhenCrashHappens = 1000000;
	timerForVictoryDance = 1000000;
}

extern void *_8042A788;
extern void playFanfare(void *, int type);
extern dStateBase_c JrClownEndDemoState;
void daCaptainBowser::executeState_Outro() {
	timer++;

	if (!shipAnmFinished) {
		float frame = shipAnm.getCurrentFrame();

		// nuke the things!
		if (frame == 35.0f) {
			dActor_c *iter = 0;

			while (iter = (dActor_c*)dActor_c::searchByBaseType(2, iter)) {
				dStageActor_c *sa = (dStageActor_c*)iter;

				if (sa->profileId == ProfileId::EN_BIRIKYU_MAKER || sa->profileId == ProfileId::KAZAN_MGR) {
					sa->Delete(1);
				}

				if (sa->profileId == ProfileId::EN_LINE_BIRIKYU ||
						sa->profileId == ProfileId::EN_STAR_COIN ||
						sa->profileId == ProfileId::EN_HATENA_BALLOON ||
						sa->profileId == ProfileId::EN_ITEM ||
						sa->profileId == ProfileId::EN_METEOR || // Meteor
						sa->profileId == ProfileId::EN_BOSS_KOOPA_THROW) { // Koopa Throw
					sa->killedByLevelClear();
					sa->Delete(1);
				}
			}

			// freeze ye olde clowne
			dEn_c *clownIter = 0;
			while (clownIter = (dEn_c*)dEn_c::searchByProfileId(ProfileId::JR_CLOWN_FOR_PLAYER, clownIter)) {
				clownIter->doStateChange(&JrClownEndDemoState);
			}
			forceClownEnds = true;

			// remove all ship collisions
			for (int i = 0; i < SHIP_SCOLL_COUNT; i++)
				shipSColls[i].removeFromList();

		} else if (frame == 150.0f) {
			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_BOSS_KOOPA_CRASH, 1);
			timerWhenCrashHappens = timer;
			prplSound.Stop(10);

			ClassWithCameraInfo *cwci = ClassWithCameraInfo::instance;
			Vec efPos = {cwci->screenCentreX+168.0f, cwci->screenTop-cwci->screenHeight, pos.z};
			SpawnEffect("Wm_bg_volcano", 0, &efPos, &(S16Vec){0,0,0}, &(Vec){4.0, 4.0, 4.0});

			ShakeScreen(StageScreen, 17, 7, 0, 0);

		} else if (shipAnm.isAnimationDone()) {
			shipAnmFinished = true;
		}

		if (frame > 30.0f) {
			if (timer & 4 && explosionBottomBound > -249.0f) {
				static const char *efs[] = {"Wm_en_explosion", "Wm_ob_cmnboxpiece"};

				int id = MakeRandomNumber(2);
				Vec efPos = {
					pos.x - 150.0f + MakeRandomNumber(300),
					pos.y + explosionBottomBound + MakeRandomNumber(250 + explosionBottomBound),
					pos.z + 200.0f
				};
				float efScale = (float(MakeRandomNumber(30)) / 20.0f);

				SpawnEffect(efs[id], 0, &efPos, &(S16Vec){0,0,0}, &(Vec){efScale,efScale,efScale});
			}

			if ((timer % 12) == 0 && (frame < 150.0f)) {
				nw4r::snd::SoundHandle handle;
				PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_DEMO_OP_CAKE_CLASH_1210f, 1);
			}

			explosionBottomBound -= 0.85f;
		}

		// handleYSpeed():
		bowserYSpeed += bowserYAccel;
		if (bowserYSpeed < bowserMaxYSpeed)
			bowserYSpeed = bowserMaxYSpeed;

		// doMovement()
		bowserX += bowserXSpeed;
		bowserY += bowserYSpeed;

		bowserRotX -= 0xC00;
		bowserRotY -= 0x100;
	}


	// FUN SHITS.
	if (timer == (timerWhenCrashHappens + 90)) {
		playFanfare(_8042A788, 4);
		timerForVictoryDance = timer + (7*60);

		// Prepare for moving the clowns
		clownCount = 0;

		dEn_c *unsortedClownPointers[4];
		dAcPy_c *unsortedClownPlayers[4];

		dEn_c *clownIter = 0;
		while (clownIter = (dEn_c*)dEn_c::searchByProfileId(ProfileId::JR_CLOWN_FOR_PLAYER, clownIter)) {
			dAcPy_c *player = *((dAcPy_c**)(((u32)clownIter) + 0x738));
			if (player) {
				unsortedClownPointers[clownCount] = clownIter;
				unsortedClownPlayers[clownCount] = player;
				clownCount++;
			}
		}

		// Now sort them by ID
		int sortedClownID = 0;
		for (int playerID = 0; playerID < 4; playerID++) {
			dAcPy_c *player = (dAcPy_c*)GetSpecificPlayerActor(playerID);

			for (int searchClown = 0; searchClown < clownCount; searchClown++) {
				if (player == unsortedClownPlayers[searchClown]) {
					clownPointers[sortedClownID] = unsortedClownPointers[searchClown];
					sortedClownID++;
					break;
				}
			}
		}

		ClassWithCameraInfo *cwci = ClassWithCameraInfo::instance;

		// calculate their end positions
		// Assuming each clown takes up ~32 width, and we have 16 padding between them ...
		float clownSpan = (clownCount * 48.0f) - 16.0f;
		float clownX = cwci->screenCentreX - (clownSpan / 2.0f);

		for (int i = 0; i < clownCount; i++) {
			clownDests[i].x = clownX;
			clownDests[i].y = cwci->screenCentreY;
			clownX += 48.0f;
		}
	}

	if (timer > (timerWhenCrashHappens + 90)) {
		// Let's move the clowns
		int playersAtEnd = 0;

		for (int i = 0; i < clownCount; i++) {
			dEn_c *clown = clownPointers[i];

			float moveSpeed = 1.2f;

			// Are we there already?
			float xDiff = abs(clown->pos.x - clownDests[i].x);
			float yDiff = abs(clown->pos.y - clownDests[i].y);

			int check = 0;
			if (xDiff < moveSpeed) {
				clown->pos.x = clownDests[i].x;
				check |= 1;
			}
			if (yDiff < moveSpeed) {
				clown->pos.y = clownDests[i].y;
				check |= 2;
			}
			if (check == 3) {
				playersAtEnd++;
				continue;
			}

			// Otherwise, move them a bit further
			VEC3 direction = {clownDests[i].x - clown->pos.x, clownDests[i].y - clown->pos.y, 0.0f};
			VECNormalize(&direction, &direction);
			VECScale(&direction, &direction, moveSpeed);

			clown->pos.x += direction.x;
			clown->pos.y += direction.y;
		}

		if (playersAtEnd >= clownCount) {
			//if (timerForVictoryDance == 1000000)
			//	timerForVictoryDance = timer + 45;
		}

		if (timer == timerForVictoryDance) {
			static const int vocs[4] = {
				SE_VOC_MA_CLEAR_LAST_BOSS,
				SE_VOC_LU_CLEAR_LAST_BOSS,
				SE_VOC_KO_CLEAR_LAST_BOSS,
				SE_VOC_KO2_CLEAR_LAST_BOSS
			};
			for (int i = 0; i < clownCount; i++) {
				dAcPy_c *player = *((dAcPy_c**)(((u32)clownPointers[i]) + 0x738));
				// let's be hacky
				dPlayerModelHandler_c *pmh = (dPlayerModelHandler_c*)(((u32)player) + 0x2A60);
				int whatAnim = goal_puton_capB;
				if (pmh->mdlClass->powerup_id == 4)
					whatAnim = goal_puton_capB;
				else if (pmh->mdlClass->powerup_id == 5)
					whatAnim = goal_puton_capC;
				pmh->mdlClass->startAnimation(whatAnim, 1.0f, 0.0f, 0.0f);

				nw4r::snd::SoundHandle handle;
				PlaySoundWithFunctionB4(SoundRelatedClass, &handle, vocs[pmh->mdlClass->player_id_1], 1);
			}
		}

		if (timer == (timerForVictoryDance + 180)) {
			doStateChange(&StateID_PanToExit);
			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_PLY_CROWN_ACC, 1);
		}
		//dAcPy_c *splayer = *((dAcPy_c**)(((u32)clownPointers[0]) + 0x738));
		//OSReport("Player has %s\n", splayer->states2.getCurrentState()->getName());
	}
}
void daCaptainBowser::endState_Outro() {  }


void daCaptainBowser::beginState_PanToExit() {
	timer = 0;
}
void daCaptainBowser::endState_PanToExit() {
}

void daCaptainBowser::executeState_PanToExit() {
	float targetClownY = ClassWithCameraInfo::instance->screenCentreY - 160.0f;
	for (int i = 0; i < clownCount; i++) {
		dEn_c *clown = clownPointers[i];
		clown->pos.y -= 1.5f;
		if (clown->pos.y < targetClownY && !exitedFlag) {
			RESTART_CRSIN_LevelStartStruct.purpose = 0; 
			RESTART_CRSIN_LevelStartStruct.world1 = 7;
			RESTART_CRSIN_LevelStartStruct.world2 = 7;
			RESTART_CRSIN_LevelStartStruct.level1 = 40;
			RESTART_CRSIN_LevelStartStruct.level2 = 40;
			RESTART_CRSIN_LevelStartStruct.areaMaybe = 0;
			RESTART_CRSIN_LevelStartStruct.entrance = 0xFF;
			RESTART_CRSIN_LevelStartStruct.unk4 = 0; // load replay
			DontShowPreGame = true;
			ExitStage(ProfileId::RESTART_CRSIN, 0, BEAT_LEVEL, MARIO_WIPE);
			exitedFlag = true;

			//ExitStage(ProfileId::MOVIE, DEFEAT_BOWSER_MOVIE, BEAT_LEVEL, MARIO_WIPE);

			for (int i = 0; i < 4; i++)
				if (Player_Lives[i] == 0)
					Player_Lives[i] = 5;
		}
	}
}


//
// processed\../src/bossFlameThrower.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include "boss.h"
#include <profile.h>

class daKoopaBreath : public dEn_c {
	int onCreate();
	int onExecute();

	mEf::es2 effect;
	public: static dActor_c *build();

	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther);

};

void daKoopaBreath::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) { DamagePlayer(this, apThis, apOther); }
void daKoopaBreath::spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther) {}

const SpriteData KoopaFlameThrowerSpriteData = {ProfileId::EN_BOSS_KOOPA_FLAME, 0x10, 0x10, 0, 0, 0x20, 0x20, 0x40, 0x40, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile KoopaFlameThrowerProfile(&daKoopaBreath::build, SpriteId::EN_BOSS_KOOPA_FLAME, &KoopaFlameThrowerSpriteData, ProfileId::WM_ANTLION, ProfileId::EN_BOSS_KOOPA_FLAME, "KoopaFlameThrower");

dActor_c *daKoopaBreath::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daKoopaBreath));
	return new(buffer) daKoopaBreath;
}


int daKoopaBreath::onCreate() {
	
	ActivePhysics::Info GreatBalls;
	
	GreatBalls.xDistToCenter = 0.0;
	GreatBalls.yDistToCenter = 0.0;
	GreatBalls.xDistToEdge = 38.0;
	GreatBalls.yDistToEdge = 28.0;
	
	GreatBalls.category1 = 0x3;
	GreatBalls.category2 = 0x0;
	GreatBalls.bitfield1 = 0x47;
	GreatBalls.bitfield2 = 0xFFFFFFFF;
	GreatBalls.unkShort1C = 0;
	GreatBalls.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &GreatBalls);
	this->aPhysics.addToList();
	speed.x = -2.0; 
	
	this->onExecute();
	return true;
}


int daKoopaBreath::onExecute() {
	HandleXSpeed();
	doSpriteMovement();

	PlaySound(this, SE_BOSS_JR_FIRE_BURNING);

	effect.spawn("Wm_ko_fireattack", 0, &(Vec){pos.x, pos.y, pos.z}, &(S16Vec){0,0,0}, &(Vec){3.0, 3.0, 3.0});

	float rect[] = {0.0, 0.0, 38.0, 38.0};
	int ret = this->outOfZone(this->pos, (float*)&rect, this->currentZoneID);
	if(ret) {
		this->Delete(1);
	}

	return true;
}

//
// processed\../src/bossKoopaThrow.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include "boss.h"
#include <profile.h>

struct TypeInfo { 
	const char *arcName;
	const char *brresName; 
	const char *modelName; 
	const char *deathEffect; 
	int launchSound; 
	int breakSound; 
	int flySound; 
	float size; 
	float scale; 
	u16 xrot; 
	u16 yrot; 
	u16 zrot; 
};

static const TypeInfo types[6] = {
	{"choropoo", 			"g3d/choropoo.brres", 			"spanner", 				"Wm_en_hit", 		0, 						SE_BOSS_JR_FLOOR_BREAK, 0, 							8.0f, 	2.0f, 0, 		0, 		0x1000},
	{"choropoo", 			"g3d/choropoo.brres", 			"spanner", 				"Wm_en_burst_s", 	0, 						SE_BOSS_JR_BOMB_BURST, 	0, 							12.0f, 	2.0f, 0, 		0, 		0x1000},
	{"koopa_clown_bomb", 	"g3d/koopa_clown_bomb.brres", 	"koopa_clown_bomb", 	"Wm_en_burst_s", 	SE_EMY_ELCJ_THROW, 		SE_BOSS_JR_BOMB_BURST, 	0, 							16.0f, 	0.8f, 0x200, 	0x800, 	0x1000},
	{"bros", 				"g3d/t00.brres", 				"bros_hammer", 			"Wm_en_hit", 		0, 						SE_OBJ_HAMMER_HIT_BOTH, 0,						 	16.0f, 	2.0f, 0, 		0, 		0x1000},
	{"dossun",				"g3d/t02.brres", 				"dossun", 				"Wm_en_hit", 		SE_EMY_DOSSUN, 			SE_EMY_DOSSUN_DEAD, 	0, 							14.0f, 	1.0f, 0,		0,		0},
	{"PresentBox_penguin",	"g3d/present.brres", 			"PresentBox_penguin", 	"Wm_dm_presentopen",SE_DEMO_OP_PRESENT_THROW_2400f, SE_DEMO_OP_PRESENT_BOX_BURST, 	0, 			20.0f, 	1.0f, 0x20, 	0x40, 	0x200}
};


const char* KPTarcNameList [] = {
	"choropoo",
	"koopa_clown_bomb",
	"dossun",
	"PresentBox_penguin",
	"bros",
	NULL	
};


class daKoopaThrow : public dEn_c {
	int onCreate();
	int onExecute();
	int onDelete();
	int onDraw();

	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;

	int timer;
	char Type;
	char direction;
	char front;
	float ymod;
	int lifespan;
	u32 cmgr_returnValue;

	bool playsAnim;
	m3d::anmChr_c chrAnim;

	nw4r::snd::SoundHandle hammerSound;

	const TypeInfo *currentInfo;

	public: static dActor_c *build();

	void updateModelMatrices();
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);


	USING_STATES(daKoopaThrow);
	DECLARE_STATE(Straight);

};

CREATE_STATE(daKoopaThrow, Straight);


// Types:
//
//	0 - Wrench
//  1 - Exploding Wrench
//	2 - Bomb
//  3 - Hammer
//  4 - Thwomp
//	5 - Present
//


extern "C" void *PlayWrenchSound(dEn_c *);
extern "C" void *dAcPy_c__ChangePowerupWithAnimation(void * Player, int powerup);
extern "C" int CheckExistingPowerup(void * Player);

void daKoopaThrow::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) { 
	if (Type == 5) {
		PlaySoundAsync(this, currentInfo->breakSound);
		SpawnEffect(currentInfo->deathEffect, 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){3.0, 3.0, 3.0});
		// dStageActor_c *spawned = CreateActor(EN_ITEM, 0x20000063, this->pos, 0, 0);
		// spawned->pos.x = this->pos.x;
		// spawned->pos.y = this->pos.y;

		int p = CheckExistingPowerup(apOther->owner);
		if (p == 0 || p == 3) {	// Powerups - 0 = small; 1 = big; 2 = fire; 3 = mini; 4 = prop; 5 = peng; 6 = ice; 7 = hammer
			dAcPy_c__ChangePowerupWithAnimation(apOther->owner, 1);
		}

		this->Delete(1);

		return;
	}

	DamagePlayer(this, apThis, apOther);

	if (Type == 1 || Type == 2) {
		PlaySoundAsync(this, SE_BOSS_JR_BOMB_BURST);

		SpawnEffect("Wm_en_burst_s", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.75, 0.75, 0.75});
		SpawnEffect("Wm_mr_wirehit", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.25, 1.25, 1.25});
		this->Delete(1);
	}
}

void daKoopaThrow::spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther) {}

bool daKoopaThrow::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true;
}
bool daKoopaThrow::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) { 
	return false; 
}
bool daKoopaThrow::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true;
}
bool daKoopaThrow::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
	if (Type == 1 || Type == 2) {
		SpawnEffect("Wm_en_burst_s", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.75, 0.75, 0.75});
		SpawnEffect("Wm_mr_wirehit", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.25, 1.25, 1.25});
	}
	else {
		SpawnEffect("Wm_ob_cmnboxgrain", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.5, 0.5, 0.5});		
	}

	PlaySoundAsync(this, currentInfo->breakSound);
	this->Delete(1);
	return true;
}
bool daKoopaThrow::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther) {
	return true;
}
bool daKoopaThrow::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) { 
	DamagePlayer(this, apThis, apOther);

	if (Type == 1 || Type == 2) {
		PlaySoundAsync(this, SE_BOSS_JR_BOMB_BURST);

		SpawnEffect("Wm_en_burst_s", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.75, 0.75, 0.75});
		SpawnEffect("Wm_mr_wirehit", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.25, 1.25, 1.25});
		this->Delete(1);
	}
	return true;
}

const SpriteData KoopaThrowSpriteData = {ProfileId::EN_BOSS_KOOPA_THROW, 0x10, 0x10, 0, 0, 0x20, 0x20, 0x40, 0x40, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile KoopaThrowProfile(&daKoopaThrow::build, SpriteId::EN_BOSS_KOOPA_THROW, &KoopaThrowSpriteData, ProfileId::WM_ANCHOR, ProfileId::EN_BOSS_KOOPA_THROW, "EN_BOSS_KOOPA_THROW", KPTarcNameList, 0x20);

dActor_c *daKoopaThrow::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daKoopaThrow));
	return new(buffer) daKoopaThrow;
}


int daKoopaThrow::onCreate() {
	
	this->direction = this->settings & 0xF;
	this->Type = (this->settings >> 4) & 0xF;
	this->front = (this->settings >> 8) & 0xF;

	currentInfo = &types[Type]; 

	allocator.link(-1, GameHeaps[0], 0, 0x20);

	nw4r::g3d::ResFile rf(getResource(currentInfo->arcName, currentInfo->brresName));
	nw4r::g3d::ResMdl resMdl = rf.GetResMdl(currentInfo->modelName);

	bodyModel.setup(resMdl, &allocator, (Type == 4 ? 0x224 : 0), 1, 0);
	SetupTextures_Enemy(&bodyModel, 0);

	if (Type == 4) {
		// Thwomp
		playsAnim = true;

		nw4r::g3d::ResAnmChr anmChr = rf.GetResAnmChr("boss_throw");
		chrAnim.setup(resMdl, anmChr, &allocator, 0);
		chrAnim.bind(&bodyModel, anmChr, 1);
		bodyModel.bindAnim(&chrAnim, 0.0);
		chrAnim.setUpdateRate(1.0);
	}

	allocator.unlink();
	
	
	ActivePhysics::Info KoopaJunk;
	
	KoopaJunk.xDistToCenter = 0.0f;
	KoopaJunk.yDistToCenter = (Type == 4) ? currentInfo->size : 0.0;
	KoopaJunk.xDistToEdge = currentInfo->size;
	KoopaJunk.yDistToEdge = currentInfo->size;

	this->scale.x = currentInfo->scale;
	this->scale.y = currentInfo->scale;
	this->scale.z = currentInfo->scale;
	
	KoopaJunk.category1 = 0x3;
	KoopaJunk.category2 = 0x0;
	KoopaJunk.bitfield1 = 0x47;
	KoopaJunk.bitfield2 = 0xFFFFFFFF;
	KoopaJunk.unkShort1C = 0;
	KoopaJunk.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &KoopaJunk);
	this->aPhysics.addToList();


	spriteSomeRectX = currentInfo->size;
	spriteSomeRectY = currentInfo->size;
	_320 = 0.0f;
	_324 = currentInfo->size;

	// These structs tell stupid collider what to collide with - these are from koopa troopa
	static const lineSensor_s below(12<<12, 4<<12, 0<<12);
	static const pointSensor_s above(0<<12, 12<<12);
	static const lineSensor_s adjacent(6<<12, 9<<12, 6<<12);

	collMgr.init(this, &below, &above, &adjacent);
	collMgr.calculateBelowCollisionWithSmokeEffect();

	cmgr_returnValue = collMgr.isOnTopOfTile();


	if (this->direction == 0) 	   { // Ground Facing Left
		this->pos.x -= 0.0; // -32 to +32
		this->pos.y += 36.0;
		// this->rot.z = 0x2000;
	}
	else if (this->direction == 1) { // Ground Facing Right
		this->pos.x += 0.0; // +32 to -32
		this->pos.y += 36.0;
		// this->rot.z = 0xE000;
	}
	if (this->front == 1) { this->pos.z = -1804.0; }
	else 				  { this->pos.z =  3300.0; }

	
	if (currentInfo->launchSound != 0) {
		PlaySound(this, currentInfo->launchSound);
	}

	if (Type == 3) {
		PlaySoundWithFunctionB4(SoundRelatedClass, &hammerSound, SE_EMY_MEGA_BROS_HAMMER, 1);
	}

	doStateChange(&StateID_Straight);
	
	this->onExecute();
	return true;
}


int daKoopaThrow::onDelete() {
	if (hammerSound.Exists())
		hammerSound.Stop(10);
	return true;
}

int daKoopaThrow::onDraw() {
	bodyModel.scheduleForDrawing();
	return true;
}


void daKoopaThrow::updateModelMatrices() {
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}


int daKoopaThrow::onExecute() {
	acState.execute();
	updateModelMatrices();
	if (playsAnim) {
		if (chrAnim.isAnimationDone())
			chrAnim.setCurrentFrame(0.0f);
		bodyModel._vf1C();
	}

	float rect[] = {this->_320, this->_324, this->spriteSomeRectX, this->spriteSomeRectY};
	int ret = this->outOfZone(this->pos, (float*)&rect, this->currentZoneID);
	if(ret) {
		this->Delete(1);
	}

	return true;
}



void daKoopaThrow::beginState_Straight() { 
	float rand = (float)GenerateRandomNumber(10) * 0.4;

	if (this->direction == 0) { // directions 1 spins clockwise, fly rightwards
		speed.x = 1.5 + rand; 
	}
	else {						// directions 0 spins anti-clockwise, fly leftwards
		speed.x = -1.5 - rand; 
	}

	speed.y = 9.0;
}
void daKoopaThrow::executeState_Straight() { 

	speed.y = speed.y - 0.01875;

	HandleXSpeed();
	HandleYSpeed();
	doSpriteMovement();

	// cmgr_returnValue = collMgr.isOnTopOfTile();
	// collMgr.calculateBelowCollisionWithSmokeEffect();

	// if (collMgr.isOnTopOfTile() || (collMgr.outputMaybe & (0x15 << direction))) {
	// 	// hit the ground or wall
	// 	PlaySoundAsync(this, currentInfo->breakSound);

	// 	SpawnEffect(currentInfo->deathEffect, 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.75, 0.75, 0.75});
	// 	this->Delete(1);
	// }

	if (this->direction == 1) { // directions 1 spins clockwise, fly rightwards
		this->rot.x -= currentInfo->xrot;
		this->rot.y -= currentInfo->yrot;
		this->rot.z -= currentInfo->zrot; }
	else {						// directions 0 spins anti-clockwise, fly leftwards
		this->rot.x -= currentInfo->xrot;
		this->rot.y -= currentInfo->yrot;
		this->rot.z += currentInfo->zrot; }	
	

	if (Type < 2) {
		PlayWrenchSound(this);
	}
	else if (currentInfo->flySound == 0) { return; }
	else {
		PlaySound(this, currentInfo->flySound);
	}

}
void daKoopaThrow::endState_Straight() { }










//
// processed\../src/bossPlayerClown.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include "boss.h"
#include <profile.h>

// #define cField(TYPE, OFFSET) (*(TYPE*)(((u32)clown) + (OFFSET)))
// #define cPlayerOccupying cField(dStageActor_c*, 0x738)
// #define cModel cField(m3d::mdl_c*, 0xFEC)
// #define cTimer cField(u32, 0xFEC+sizeof(m3d::mdl_c))
// #define cAllocator cField(mHeapAllocator_c*, 0xFD0)

#define cPlayerOccupying (*(dStageActor_c**)(((u32)(clown)) + 0x738 ))
#define cAllocator ((mHeapAllocator_c*)(((u32)(clown)) + 0xFD0 ))
#define cModel ((m3d::mdl_c*)( ((u32)(clown)) + 0xFEC ))
#define cTimer (*(u32*)((u32)(clown) + sizeof(m3d::mdl_c) + 0xFEC ))

extern "C" int PClownCarExecute(dEn_c *clown);
extern "C" void PClownCarAfterCreate(dEn_c *clown, u32);
extern "C" int PClownCarDraw(dEn_c *clown);
extern "C" void PClownCarMove(dEn_c *clown);

//clowncar sprite
const char* PCCarcNameList [] = {"koopaJr_clown_ply", NULL};
extern "C" dActor_c *dClownCarPlayerBuild();
const SpriteData ClownCarSpawnerSpriteData = { ProfileId::JR_CLOWN_FOR_PLAYER, 0, 0 , 0 , 0, 0x10, 0x10, 0, 0, 0, 0, 0 };
Profile ClownCarSpawnerProfile(&dClownCarPlayerBuild, SpriteId::JR_CLOWN_FOR_PLAYER, &ClownCarSpawnerSpriteData, ProfileId::JR_CLOWN_FOR_PLAYER, ProfileId::JR_CLOWN_FOR_PLAYER, "JR_CLOWN_FOR_PLAYER", PCCarcNameList);

int CConDraw(dEn_c *clown) {
	// setup cannon model
	clown->matrix.translation(clown->pos.x, clown->pos.y + 8.0, clown->pos.z-100.0);
	short newrotz = -0x2000;
	short newroty = ((clown->rot.y * 0x4000) / 0x800) - 0x4000;
	short newrotx;
	if (clown->rot.x < 0x8000) {
		newrotx = -clown->rot.x;
	}
	else {
		newrotx = clown->rot.x;
	}
	// OSReport("Angle?: %x, %x", clown->rot.y, newroty);
	clown->matrix.applyRotationYXZ(&clown->rot.x, &newroty, &newrotz);

	cModel->setDrawMatrix(clown->matrix);
	if(clown->settings >> 4 & 1) {
		cModel->setScale(&(Vec){0.25, 0.5, 0.25});
	} else {
		cModel->setScale(&(Vec){0.0, 0.0, 0.0});
	}
	cModel->calcWorld(false);

	cModel->scheduleForDrawing();


	return PClownCarDraw(clown);
	// run normal clown function
}
extern dStateBase_c JrClownEndDemoState;
extern dStateBase_c JrClownDemoWaitState;
extern dStateBase_c ClownDemoWaitState;

int CConExecute(dEn_c *clown) {
	// A REALLY TERRIBLE HACK.
	float saveX = clown->pos.x;
	float saveY = clown->pos.y;

	int ret = PClownCarExecute(clown);

	dStateBase_c *state = clown->acState.getCurrentState();
	if (state == &JrClownEndDemoState || state == &JrClownDemoWaitState || state == &ClownDemoWaitState) {
		clown->pos.x = saveX;
		clown->pos.y = saveY;
		clown->speed.x = 0.0f;
		clown->speed.y = 0.0f;
	}
	return true;
}

void CCafterCreate(dEn_c *clown, u32 param) {

	if(clown->settings >> 4 & 1) {
		clown->scale.x *= 1.25;
		clown->scale.y *= 1.25;
		clown->scale.z *= 1.25;
	} else {
		clown->scale.x *= 1;
		clown->scale.y *= 1;
		clown->scale.z *= 1;
	}

	// setup the model
	nw4r::g3d::ResFile resFile;

	cAllocator->link(-1, GameHeaps[0], 0, 0x20);

	resFile.data = getResource("koopaJr_clown_ply", "g3d/cannon.brres");
	nw4r::g3d::ResMdl mdl = resFile.GetResMdl("Cannon");
	cModel->setup(mdl, cAllocator, 0x224, 1, 0);
	SetupTextures_MapObj(cModel, 0);

	cAllocator->unlink();

	// Original AfterCreate
	PClownCarAfterCreate(clown, param);

	int playerCount = 0;
	for (int i = 0; i < 4; i++)
		if (Player_Active[i])
			playerCount++;

	if ((clown->settings & 0xF) != 0) {
		int playerID = (clown->settings & 0xF) - 1;
		if (playerID >= playerCount)
			clown->Delete(1);
	}
}

void CConExecuteMove(dEn_c *clown) {
	u8 player = cPlayerOccupying->which_player;
	// OSReport("Angle = %x, %x, %x", (GetSpecificPlayerActor(player))->rot.y, (GetSpecificPlayerActor(player))->rot.x, (GetSpecificPlayerActor(player))->rot.z);
	// OSReport("Clown = %x, %x, %x", (clown)->rot.y, (clown)->rot.x, (clown)->rot.z);

	Vec tempPos;
	
	u32 buttonPushed = Remocon_GetPressed(GetRemoconMng()->controllers[cPlayerOccupying->which_player]);
	if ((buttonPushed & 0x0100) && ((clown->settings >> 4) & 1)) {
	
		if (cTimer > 90) {
			if (clown->direction == 0) { // Going right
				tempPos = (Vec){clown->pos.x + 32.0, clown->pos.y + 32.0, 3564.0};
				dStageActor_c *spawned = CreateActor(ProfileId::JR_CLOWN_PLAYER_CANNONSHOT, 0, tempPos, 0, 0);
				spawned->speed.x = 5.0;
			}
			else {
				tempPos = (Vec){clown->pos.x - 32.0, clown->pos.y + 32.0, 3564.0};
				dStageActor_c *spawned = CreateActor(ProfileId::JR_CLOWN_PLAYER_CANNONSHOT, 0, tempPos, 0, 0);
				spawned->speed.x = -5.0;
			}

			SpawnEffect("Wm_en_killervanish", 0, &tempPos, &(S16Vec){0,0,0}, &(Vec){0.1, 0.1, 0.1});
			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_OBJ_HOUDAI_S_SHOT, 1);

			cTimer = 0;
		}
	}

	cTimer++;

	ClassWithCameraInfo *cwci = ClassWithCameraInfo::instance;
	float leftBound = cwci->screenLeft + 12.0f;
	float rightBound = (cwci->screenLeft + cwci->screenWidth) - 12.0f;
	if (clown->pos.x < leftBound)
		clown->pos.x = leftBound;
	if (clown->pos.x > rightBound)
		clown->pos.x = rightBound;

	// run normal move
	PClownCarMove(clown);
}


extern "C" m3d::mdl_c *__ct__Q23m3d5mdl_cFv(m3d::mdl_c *mdl);
extern "C" mHeapAllocator_c *__ct__16mHeapAllocator_cFv(mHeapAllocator_c *al);
extern "C" dEn_c *__ct__20daJrClownForPlayer_cFv(dEn_c *clown);

dEn_c *newClownCtor(dEn_c *clown) {
	__ct__20daJrClownForPlayer_cFv(clown);
	__ct__16mHeapAllocator_cFv(cAllocator);
	__ct__Q23m3d5mdl_cFv(cModel);
	return clown;
}


extern "C" void __dt__Q23m3d5mdl_cFv(m3d::mdl_c *mdl, u32 willDelete);
extern "C" void __dt__16mHeapAllocator_cFv(mHeapAllocator_c *al, u32 willDelete);
extern "C" void __dt__20daJrClownForPlayer_cFv(dEn_c *clown, u32 willDelete);

extern "C" u32 sAllocatorFunc__FrmHeap;

void newClownDtor(dEn_c *clown, u32 willDelete) {
	void **al = (void **)(((u32)clown) + 0x524);
	if (*al != &sAllocatorFunc__FrmHeap) {
		OSReport("oh no! bad allocator %p\n", *al);
		*al = &sAllocatorFunc__FrmHeap;
	}

	__dt__Q23m3d5mdl_cFv(cModel, 0xFFFFFFFF);
	__dt__16mHeapAllocator_cFv(cAllocator, 0xFFFFFFFF);
	__dt__20daJrClownForPlayer_cFv(clown, willDelete);
}

extern "C" void JrClownForPlayer_playAccelSound() {
	nw4r::snd::SoundHandle handle;
	PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_PLY_CROWN_ACC, 1);
}



class daClownShot : public dEn_c {
public:
	int onCreate();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;
	m3d::mdl_c bodyModel;

	mEf::es2 effect;
	static dActor_c *build();

	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
};

void daClownShot::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) { }

dActor_c *daClownShot::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daClownShot));
	return new(buffer) daClownShot;
}

Profile CustomClownShotProfile(&daClownShot::build, ProfileId::JR_CLOWN_PLAYER_CANNONSHOT, NULL, ProfileId::WM_PAKKUN, ProfileId::JR_CLOWN_PLAYER_CANNONSHOT, "JR_CLOWN_PLAYER_CANNONSHOT", NULL, 0x12);


int daClownShot::onCreate() {
	allocator.link(-1, GameHeaps[0], 0, 0x20);
	this->resFile.data = getResource("koopaJr_clown_ply", "g3d/houdai_ball.brres");
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("houdai_ball");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	allocator.unlink();

	ActivePhysics::Info GreatBalls;
	
	GreatBalls.xDistToCenter = 0.0;
	GreatBalls.yDistToCenter = 0.0;
	GreatBalls.xDistToEdge = 8.0;
	GreatBalls.yDistToEdge = 7.0;
	
	GreatBalls.category1 = 0x3;
	GreatBalls.category2 = 0x0;
	GreatBalls.bitfield1 = 0x6F;
	GreatBalls.bitfield2 = 0xffbafffe;
	GreatBalls.unkShort1C = 0;
	GreatBalls.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &GreatBalls);
	this->aPhysics.addToList();


	// These fucking rects do something for the tile rect
	spriteSomeRectX = 8.0f;
	spriteSomeRectY = 8.0f;
	_320 = 0.0f;
	_324 = 0.0f;

	u32 flags = SENSOR_BREAK_BRICK | SENSOR_BREAK_BLOCK | SENSOR_80000000;
	static const lineSensor_s below(flags, 12<<12, 4<<12, 0<<12);
	static const pointSensor_s above(flags, 0<<12, 12<<12);
	static const lineSensor_s adjacent(flags, 6<<12, 9<<12, 6<<12);

	collMgr.init(this, &below, &above, &adjacent);
	collMgr.calculateBelowCollisionWithSmokeEffect();


	this->speed.y = 4.0;
	this->y_speed_inc = -0.1875;
	
	this->onExecute();
	return true;
}

int daClownShot::onDraw() {
	matrix.translation(this->pos.x, this->pos.y, this->pos.z);

	matrix.applyRotationYXZ(&this->rot.x, &this->rot.y, &this->rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(true);

	bodyModel.scheduleForDrawing();
	return true;
}


int daClownShot::onExecute() {
	HandleXSpeed();
	HandleYSpeed();
	doSpriteMovement();

	collMgr.calculateBelowCollisionWithSmokeEffect();
	collMgr.calculateAboveCollision(0);
	collMgr.calculateAdjacentCollision();
	if (collMgr.outputMaybe) {
		SpawnEffect("Wm_en_burst_m", 0, &pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_OBJ_TARU_BREAK, 1);
		Delete(1);
		return true;
	}

	effect.spawn("Wm_en_killersmoke", 0, &(Vec){pos.x, pos.y, pos.z}, &(S16Vec){0,0,0}, &(Vec){0.7, 0.7, 0.7});

	float rect[] = {0.0, 0.0, 8.0, 8.0};
	int ret = this->outOfZone(this->pos, (float*)&rect, this->currentZoneID);
	if(ret) {
		this->Delete(1);
	}

	return true;
}




// This is for making clown shots able to kill other shit

extern "C" bool Amp_NewPreSpriteCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
	// apThis = amp, apOther = other thing
	dEn_c *amp = (dEn_c*)apThis->owner;

	if (apOther->info.category2 == 9) {
		if (amp->collisionCat9_RollingObject(apThis, apOther))
			return true;
	} else if (apOther->owner->profileId == ProfileId::JR_CLOWN_PLAYER_CANNONSHOT) {
		amp->killByDieFall(apOther->owner);
		return true;
	}

	return false;
}

extern "C" void KazanRock_Explode(void *kazanRock);
extern "C" void KazanRock_OriginalCollisionCallback(ActivePhysics *apThis, ActivePhysics *apOther);
extern "C" void KazanRock_CollisionCallback(ActivePhysics *apThis, ActivePhysics *apOther) {
	if (apOther->owner->profileId == ProfileId::JR_CLOWN_PLAYER_CANNONSHOT) {
		apThis->someFlagByte |= 2;
		KazanRock_Explode(apThis->owner);
	} else {
		KazanRock_OriginalCollisionCallback(apThis, apOther);
	}
}
//
// processed\../src/bossBridgeBowser.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include <stage.h>
#include "boss.h"
#include <profile.h>

extern "C" void *BowserExitDemoState(void *, unsigned int);
extern "C" void *ForceMarioExitDemoMode(void *, unsigned int);
extern "C" void *BowserFireballCollision(dEn_c *, ActivePhysics *, ActivePhysics *);
extern "C" void *BowserDamageAnmClr(dEn_c *);
extern "C" void *BowserDamageStepTwo(dEn_c *);
extern "C" void *BowserDamageNormal(dEn_c *);
extern "C" void *BowserDamageKill(dEn_c *);
extern "C" void *BowserDamageEnd(dEn_c *);

int BridgeBowserHP = 2;
int lastBomb = 0;

extern bool HackyBombDropVariable;

void BowserDoomSpriteCollision(dEn_c *bowser, ActivePhysics *apThis, ActivePhysics *apOther) {
	// If you collide with something or other, call the fireball collision

	if (apOther->owner->profileId == ProfileId::EN_BOSS_BOMB_DROPPED) {

		if (lastBomb == apOther->owner->id) { return; }
		if (!HackyBombDropVariable) return;
		HackyBombDropVariable = false;

		// void * bowserClass = (void*)(((u32)bowser) + 0x5F8);
		// int HP = *(int*)(((u32)bowserClass) + 4);

		OSReport("HP: %d", BridgeBowserHP);

		if (BridgeBowserHP <= 0) {
			BridgeBowserHP = 0;

			*(int*)(((u32)bowser) + 0x540) = 0x28;

			BowserDamageAnmClr(bowser);

			BowserDamageStepTwo(bowser);
			BowserDamageKill(bowser);

			// WeirdLevelEndClass->sub_8005CB60(*otherActor->returnPtrToField38D());

			// this->vf300(otherActor);
			BowserDamageEnd(bowser);

			// daBossKoopaDemo_c *BowserDemo = (daBossKoopaDemo_c*)fBase_c::searchByProfileId(ProfileId::BOSS_KOOPA_DEMO, 0);
			daBossKoopa_c *BowserClass = (daBossKoopa_c*)bowser;
			OSReport("Koopa Controller: %x", BowserClass);
			BowserClass->doStateChange(&daBossKoopa_c::StateID_Fall);
			dFlagMgr_c::instance->set(3, 0, true, false, false);

			BridgeBowserHP = 2;

		}
		else {
			*(int*)(((u32)bowser) + 0x540) = 0x28;

			BowserDamageAnmClr(bowser);
			BowserDamageNormal(bowser);

			BridgeBowserHP -= 1;
		}

		lastBomb = apOther->owner->id;

		dEn_c * bomb = (dEn_c*)apOther->owner;
		dFlagMgr_c::instance->set(bomb->settings & 0xFF, 0, true, false, false);
		bomb->kill();
	}

	return;
}

extern "C" void initializeMagic(dStageActor_c *); 
void BowserDoomStart(dStageActor_c *Controller) {
	if (Controller->settings & 1) {
		OSReport("Here we go!");

		dEn_c *Bowser = (dEn_c*)fBase_c::searchByProfileId(ProfileId::EN_BOSS_KOOPA, 0);
		Bowser->Delete(1);
		lastBomb = 0;
	} else {
		initializeMagic(Controller);
	}
}

extern "C" void executeMagic(dStageActor_c *); 
void BowserDoomExecute(dStageActor_c *Controller) {
	if (Controller->settings & 1) {
		dFlagMgr_c::instance->set(2, 0, true, false, false);
		Controller->Delete(1);
	} else {
		executeMagic(Controller);
	}
}

void BowserDoomEnd(dStageActor_c *Controller) {
	if (Controller->settings & 1) {
		OSReport("Bai bai everybody");
		Controller->Delete(1);
	}
}

void BowserStartEnd(dStageActor_c *Controller) {
	if (Controller->settings & 1) {
		dFlagMgr_c::instance->set(1, 0, true, false, false);
	}
}

u32 isBowserImmuneToFireBalls() {
	fBase_c *controller = fBase_c::searchByProfileId(ProfileId::BOSS_KOOPA_DEMO);
	if (controller != NULL && controller->settings & 1) {
		return 1;
	}
	return 0;
}

extern "C" void setDeathInfo_Quake_Boss(dEn_c *, int);
void BowserPowBlock(dEn_c *bowser, int isMPGP) {
	fBase_c *controller = fBase_c::searchByProfileId(ProfileId::BOSS_KOOPA_DEMO);
	if (controller != NULL && controller->settings & 1) {
		return;
	} else {
		setDeathInfo_Quake_Boss(bowser, isMPGP);
	}
} 
//
// processed\../src/bossBombDrop.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include "boss.h"
#include <profile.h>

const char* BDarcNameList [] = {
	"koopa_clown_bomb",
	NULL
};


class dDroppedBomb : public dEn_c {
	int onCreate();
	int onExecute();
	int onDelete();
	int onDraw();

	void kill();

	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;

	u32 cmgr_returnValue;

	public: static dActor_c *build();

	void updateModelMatrices();
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	// void spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
};

void dDroppedBomb::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
	this->kill();
}

Profile DroppedBombProfile(&dDroppedBomb::build, ProfileId::EN_BOSS_BOMB_DROPPED, NULL, ProfileId::WM_SMALLCLOUD, ProfileId::EN_BOSS_BOMB_DROPPED, "EN_BOSS_BOMB_DROPPED", NULL, 0x20);

dActor_c *dDroppedBomb::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dDroppedBomb));
	return new(buffer) dDroppedBomb;
}

// void dDroppedBomb::spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther) { this->kill(); }
bool dDroppedBomb::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {return true;}
bool dDroppedBomb::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) { return false; }
bool dDroppedBomb::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {return true;}
bool dDroppedBomb::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {return true;}
bool dDroppedBomb::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther) {return true;}
bool dDroppedBomb::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {return true;}

void dDroppedBomb::kill() {
	PlaySoundAsync(this, SE_BOSS_JR_BOMB_BURST);

	SpawnEffect("Wm_en_explosion", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
	SpawnEffect("Wm_mr_wirehit", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.25, 1.25, 1.25});
	this->Delete(1);
}

int dDroppedBomb::onCreate() {

	allocator.link(-1, GameHeaps[0], 0, 0x20);

	nw4r::g3d::ResFile rf(getResource("koopa_clown_bomb", "g3d/koopa_clown_bomb.brres"));
	bodyModel.setup(rf.GetResMdl("koopa_clown_bomb"), &allocator, 0x224, 1, 0);
	SetupTextures_MapObj(&bodyModel, 0);

	allocator.unlink();


	ActivePhysics::Info KoopaJunk;

	KoopaJunk.xDistToCenter = -20.0f;
	KoopaJunk.yDistToCenter = 0.0;
	KoopaJunk.xDistToEdge = 20.0f;
	KoopaJunk.yDistToEdge = 20.0f;

	this->scale.x = 1.0;
	this->scale.y = 1.0;
	this->scale.z = 1.0;

	KoopaJunk.category1 = 0x3;
	KoopaJunk.category2 = 0x0;
	KoopaJunk.bitfield1 = 0x4F;
	KoopaJunk.bitfield2 = 0xFFFFFFFF;
	KoopaJunk.unkShort1C = 0;
	KoopaJunk.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &KoopaJunk);
	this->aPhysics.addToList();


	spriteSomeRectX = 20.f;
	spriteSomeRectY = 20.f;
	_320 = 0.0f;
	_324 = 20.f;

	// These structs tell stupid collider what to collide with - these are from koopa troopa
	static const lineSensor_s below(12<<12, 4<<12, 0<<12);
	static const pointSensor_s above(0<<12, 12<<12);
	static const lineSensor_s adjacent(6<<12, 9<<12, 6<<12);

	collMgr.init(this, &below, &above, &adjacent);
	collMgr.calculateBelowCollisionWithSmokeEffect();

	cmgr_returnValue = collMgr.isOnTopOfTile();


	pos.z = 3300.0;
	speed.y = -1.5f;

	PlaySound(this, SE_EMY_ELCJ_THROW);
	return true;
}


int dDroppedBomb::onDelete() {
	return true;
}

int dDroppedBomb::onDraw() {
	bodyModel.scheduleForDrawing();
	return true;
}


void dDroppedBomb::updateModelMatrices() {
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}


int dDroppedBomb::onExecute() {
	// acState.execute();
	updateModelMatrices();

	rot.x += 0x200;
	rot.y += 0x400;
	rot.z += 0x600;

	float rect[] = {this->_320, this->_324, this->spriteSomeRectX, this->spriteSomeRectY};
	int ret = this->outOfZone(this->pos, (float*)&rect, this->currentZoneID);
	if(ret) {
		this->Delete(1);
		dFlagMgr_c::instance->set(settings & 0xFF, 0, true, false, false);
	}

	speed.y = speed.y - 0.01875;

	HandleXSpeed();
	HandleYSpeed();
	doSpriteMovement();

	cmgr_returnValue = collMgr.isOnTopOfTile();
	collMgr.calculateBelowCollisionWithSmokeEffect();

	if (collMgr.isOnTopOfTile() || (collMgr.outputMaybe & (0x15 << direction))) {
		this->kill();
		dFlagMgr_c::instance->set(settings & 0xFF, 0, true, false, false);
	}

	return true;
}





// =========================================================================================================
// ================================================ CONTROLLER =============================================
// =========================================================================================================

class dBombDrop : public dStageActor_c {
	int onCreate();
	int onExecute();
	int onDelete();
	int onDraw();

	int timer;
	dStageActor_c * target;
	int eventA;
	int eventB;

	public: static dActor_c *build();
};

const SpriteData BossBombDropSpriteData = {ProfileId::EN_BOSS_BOMB, 0x10, 0x10, 0, 0, 0x200, 0x200, 0, 0, 0x200, 0x200, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile BossBombDropProfile(&dBombDrop::build, SpriteId::EN_BOSS_BOMB, &BossBombDropSpriteData, ProfileId::WM_CLOUD, ProfileId::EN_BOSS_BOMB, "EN_BOSS_BOMB", BDarcNameList);

dActor_c *dBombDrop::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dBombDrop));
	return new(buffer) dBombDrop;
}


bool HackyBombDropVariable = false;
extern int BridgeBowserHP;

int dBombDrop::onCreate() {
	BridgeBowserHP = 2;

	int t = this->settings & 0xF;
	this->eventA = ((this->settings >> 24) & 0xFF) - 1;
	this->eventB = ((this->settings >> 16) & 0xFF) - 1;


	if (t == 0) {
		target = (dStageActor_c*)fBase_c::searchByProfileId(ProfileId::EN_BOSS_KOOPA, 0);
	}
	else {
		target = GetSpecificPlayerActor(t - 1);
	}

	dFlagMgr_c::instance->set(eventA, 0, false, false, false);
	dFlagMgr_c::instance->set(eventB, 0, false, false, false);

	HackyBombDropVariable = false;

	return true;
}

int dBombDrop::onDelete() { return true; }
int dBombDrop::onDraw() { return true; }

int dBombDrop::onExecute() {
	pos.x = target->pos.x;

	bool active;
	active = dFlagMgr_c::instance->active(eventA);
	if (active) {
		create(ProfileId::EN_BOSS_BOMB_DROPPED, eventA+1, &pos , &rot, 0);
		HackyBombDropVariable = true;
		dFlagMgr_c::instance->set(eventA, 0, false, false, false);
	}

	active = dFlagMgr_c::instance->active(eventB);
	if (active) {
		create(ProfileId::EN_BOSS_BOMB_DROPPED, eventB+1, &pos, &rot, 0);
		HackyBombDropVariable = true;
		dFlagMgr_c::instance->set(eventB, 0, false, false, false);
	}

	return true;
}






//
// processed\../src/effectvideo.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include <profile.h>

extern "C" bool SpawnEffect(const char*, int, Vec*, S16Vec*, Vec*);


class EffectVideo : public dEn_c {
	int onCreate();
	int onExecute();
	int onDelete();

	u64 eventFlag;
	s32 timer;
	u32 delay;

	u32 effect;
	u8 type;
	float scale;

	public: static dActor_c *build();

};

const char *EffectSpawnerArcNameList[] = {0};
const SpriteData EffectSpawnerSpriteData = {ProfileId::EN_FX_SPAWNER, 8, 0xfffffff8, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 8};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile EffectSpawnerProfile(&EffectVideo::build, SpriteId::EN_FX_SPAWNER, &EffectSpawnerSpriteData, ProfileId::LIFT_TORIDE_ROLL, ProfileId::EN_FX_SPAWNER, "EN_FX_SPAWNER", EffectSpawnerArcNameList, 0x2);

dActor_c *EffectVideo::build() {
	void *buffer = AllocFromGameHeap1(sizeof(EffectVideo));
	return new(buffer) EffectVideo;
}


int EffectVideo::onCreate() {
	
	this->timer = 0;

	char eventNum	= (this->settings >> 24) & 0xFF;

	this->eventFlag = (u64)1 << (eventNum - 1);
	
	this->type		= (this->settings >> 16) & 0xF;
	this->effect	= this->settings & 0xFFF;
	this->scale		= float((this->settings >> 20) & 0xF) / 4.0;
	this->delay		= (this->settings >> 12) & 0xF * 30;
	
	if (this->scale == 0.0) { this->scale = 1.0; }

	this->onExecute();
	return true;
}


int EffectVideo::onDelete() {
	return true;
}


int EffectVideo::onExecute() {

	if (dFlagMgr_c::instance->flags & this->eventFlag) {

		if (this->timer == this->delay) {

			if (this->type == 0) { // Plays a sound
				PlaySoundAsync(this, this->effect);
			}
	
			else {	// Plays an Effect

				const char *efName = 0;

				switch (this->effect) {
					case 1: efName = "Wm_mr_2dlandsmoke"; break;
					case 2: efName = "Wm_mr_cmnsndlandsmk"; break;
					case 3: efName = "Wm_mr_cmnlandsmoke"; break;
					case 4: efName = "Wm_en_landsmoke"; break;
					case 5: efName = "Wm_en_landsmoke_s"; break;
					case 6: efName = "Wm_en_sndlandsmk"; break;
					case 7: efName = "Wm_en_sndlandsmk_s"; break;
					case 8: efName = "Wm_en_burst_big"; break;
					case 9: efName = "Wm_en_burst_m"; break;
					case 10: efName = "Wm_en_burst_s"; break;
					case 11: efName = "Wm_en_burst_ss"; break;
					case 12: efName = "Wm_en_burst_water01"; break;
					case 13: efName = "Wm_en_burst_water02"; break;
					case 14: efName = "Wm_en_cmnwatertail"; break;
					case 15: efName = "Wm_en_cmnwaterdash"; break;
					case 16: efName = "Wm_en_cmnwater02"; break;
					case 17: efName = "Wm_en_cmnwater"; break;
					case 18: efName = "Wm_en_waterwave_in"; break;
					case 19: efName = "Wm_en_waterwave_in_a"; break;
					case 20: efName = "Wm_en_waterwave_in_b"; break;
					case 21: efName = "Wm_en_firevanish"; break;
					case 22: efName = "Wm_en_watersplash"; break;
					case 23: efName = "Wm_en_watersplash_cld"; break;
					case 24: efName = "Wm_mr_watersplash"; break;
					case 25: efName = "Wm_en_poisoninbig01"; break;
					case 26: efName = "Wm_en_poisoninbig02"; break;
					case 27: efName = "Wm_en_poisonwave"; break;
					case 28: efName = "Wm_en_poisonwave_a"; break;
					case 29: efName = "Wm_en_poisonwave_b"; break;
					case 30: efName = "Wm_en_cmnmagmawave"; break;
					case 31: efName = "Wm_en_magmawave"; break;
					case 32: efName = "Wm_en_magmawave_a"; break;
					case 33: efName = "Wm_en_magmawave_b"; break;
					case 34: efName = "Wm_en_vshit"; break;
					case 35: efName = "Wm_en_vshit_hit"; break;
					case 36: efName = "Wm_en_vshit_glow"; break;
					case 37: efName = "Wm_en_vshit_star"; break;
					case 38: efName = "Wm_en_vshit_ring"; break;
					case 39: efName = "Wm_en_comattack"; break;
					case 40: efName = "Wm_ob_cmnshotstar"; break;
					case 41: efName = "Wm_ob_cmnshothit"; break;
					case 42: efName = "Wm_ob_cmnshotspark"; break;
					case 43: efName = "Wm_ob_cmnsparkloop"; break;
					case 44: efName = "Wm_ob_cmnspark"; break;
					case 45: efName = "Wm_ob_cmnicekira"; break;
					case 46: efName = "Wm_ob_cmnrockpiece"; break;
					case 47: efName = "Wm_ob_cmnboxpiece"; break;
					case 48: efName = "Wm_ob_cmnboxsmoke"; break;
					case 49: efName = "Wm_ob_cmnboxgrain"; break;
					case 50: efName = "Wm_en_hit"; break;
					case 51: efName = "Wm_en_hit_ring"; break;
					case 52: efName = "Wm_mr_misshit"; break;
					case 53: efName = "Wm_mr_misshit_ring"; break;
					case 54: efName = "Wm_en_quicksand"; break;
					case 55: efName = "Wm_ob_envsunlight"; break;
					case 56: efName = "Wm_ob_envsunlight_a"; break;
					case 57: efName = "Wm_ob_envsunlight_b"; break;
					case 58: efName = "Wm_mr_landsmoke"; break;
					case 59: efName = "Wm_mr_landsmoke_s"; break;
					case 60: efName = "Wm_mr_landsmoke_ss"; break;
					case 61: efName = "Wm_mr_sealandsmk"; break;
					case 62: efName = "Wm_mr_sealandsmk_s"; break;
					case 63: efName = "Wm_mr_sealandsmk_ss"; break;
					case 64: efName = "Wm_mr_sndlandsmk"; break;
					case 65: efName = "Wm_mr_sndlandsmk_s"; break;
					case 66: efName = "Wm_mr_sndlandsmk_ss"; break;
					case 67: efName = "Wm_mr_beachlandsmk"; break;
					case 68: efName = "Wm_mr_beachlandsmk_s"; break;
					case 69: efName = "Wm_mr_beachlandsmk_ss"; break;
					case 70: efName = "Wm_mr_slipsmoke"; break;
					case 71: efName = "Wm_mr_slipsmoke_ss"; break;
					case 72: efName = "Wm_mr_slipsmoke_big"; break;
					case 73: efName = "Wm_mr_sndslipsmk"; break;
					case 74: efName = "Wm_mr_sndslipsmk_ss"; break;
					case 75: efName = "Wm_mr_beachslipsmk"; break;
					case 76: efName = "Wm_mr_beachslipsmk_ss"; break;
					case 77: efName = "Wm_mr_iceslipsmk"; break;
					case 78: efName = "Wm_mr_iceslipsmk_ss"; break;
					case 79: efName = "Wm_mr_brakesmoke"; break;
					case 80: efName = "Wm_mr_brakesmoke_ss"; break;
					case 81: efName = "Wm_mr_sndbrakesmk"; break;
					case 82: efName = "Wm_mr_sndbrakesmk_ss"; break;
					case 83: efName = "Wm_mr_beachbrakesmk"; break;
					case 84: efName = "Wm_mr_beachbrakesmk_ss"; break;
					case 85: efName = "Wm_mr_icebrakesmk"; break;
					case 86: efName = "Wm_mr_icebrakesmk_ss"; break;
					case 87: efName = "Wm_mr_drop"; break;
					case 88: efName = "Wm_mr_quicksand"; break;
					case 89: efName = "Wm_mr_swimpaddle"; break;
					case 90: efName = "Wm_mr_flutterkick"; break;
					case 91: efName = "Wm_mr_ivy"; break;
					case 92: efName = "Wm_en_firebar_fire"; break;
					case 93: efName = "Wm_en_firebar_ind"; break;
					case 94: efName = "Wm_en_firebar"; break;
					case 95: efName = "Wm_mr_fireball_a"; break;
					case 96: efName = "Wm_mr_fireball_b"; break;
					case 97: efName = "Wm_mr_fireball"; break;
					case 98: efName = "Wm_mr_iceball_a"; break;
					case 99: efName = "Wm_mr_iceball_b"; break;
					case 100 : efName = "Wm_mr_iceball"; break;
					case 101 : efName = "Wm_ob_icemisshit"; break;
					case 102 : efName = "Wm_ob_icemisshit_smk"; break;
					case 103 : efName = "Wm_mr_fireball_hit"; break;
					case 104 : efName = "Wm_mr_fireball_hit01"; break;
					case 105 : efName = "Wm_en_bubble"; break;
					case 106 : efName = "Wm_en_bubble_a"; break;
					case 107 : efName = "Wm_en_bubble_b"; break;
					case 108 : efName = "Wm_mr_startail"; break;
					case 109 : efName = "Wm_mr_movecliff"; break;
					case 110 : efName = "Wm_mr_cliffcatch"; break;
					case 111 : efName = "Wm_mr_cliffcatch_cd"; break;
					case 112 : efName = "Wm_en_iron"; break;
					case 113 : efName = "Wm_mr_wallkick_r"; break;
					case 114 : efName = "Wm_mr_wallkick_up_r"; break;
					case 115 : efName = "Wm_mr_wallkick_cld_r"; break;
					case 116 : efName = "Wm_mr_wallkick_dn_r"; break;
					case 117 : efName = "Wm_mr_wallkick_c_r"; break;
					case 118 : efName = "Wm_mr_wallkick_b_r"; break;
					case 119 : efName = "Wm_mr_wallkick_l"; break;
					case 120 : efName = "Wm_mr_wallkick_up_l"; break;
					case 121 : efName = "Wm_mr_wallkick_cld_l"; break;
					case 122 : efName = "Wm_mr_wallkick_dn_l"; break;
					case 123 : efName = "Wm_mr_wallkick_c_l"; break;
					case 124 : efName = "Wm_mr_wallkick_b_l"; break;
					case 125 : efName = "Wm_mr_wallkick_s_r"; break;
					case 126 : efName = "Wm_mr_wallkick_up_s_r"; break;
					case 127 : efName = "Wm_mr_wallkick_cld_s_r"; break;
					case 128 : efName = "Wm_mr_wallkick_dn_s_r"; break;
					case 129 : efName = "Wm_mr_wallkick_c_s_r"; break;
					case 130 : efName = "Wm_mr_wallkick_b_s_r"; break;
					case 131 : efName = "Wm_mr_wallkick_s_l"; break;
					case 132 : efName = "Wm_mr_wallkick_up_s_l"; break;
					case 133 : efName = "Wm_mr_wallkick_cld_s_l"; break;
					case 134 : efName = "Wm_mr_wallkick_dn_s_l"; break;
					case 135 : efName = "Wm_mr_wallkick_c_s_l"; break;
					case 136 : efName = "Wm_mr_wallkick_b_s_l"; break;
					case 137 : efName = "Wm_mr_wallkick_ss_r"; break;
					case 138 : efName = "Wm_mr_wallkick_up_ss_r"; break;
					case 139 : efName = "Wm_mr_wallkick_cld_ss_r"; break;
					case 140 : efName = "Wm_mr_wallkick_dn_ss_r"; break;
					case 141 : efName = "Wm_mr_wallkick_b_ss_r"; break;
					case 142 : efName = "Wm_mr_wallkick_c_ss_r"; break;
					case 143 : efName = "Wm_mr_wallkick_ss_l"; break;
					case 144 : efName = "Wm_mr_wallkick_up_ss_l"; break;
					case 145 : efName = "Wm_mr_wallkick_cld_ss_l"; break;
					case 146 : efName = "Wm_mr_wallkick_dn_ss_l"; break;
					case 147 : efName = "Wm_mr_wallkick_b_ss_l"; break;
					case 148 : efName = "Wm_mr_wallkick_c_ss_l"; break;
					case 149 : efName = "Wm_mr_wallslip_r"; break;
					case 150 : efName = "Wm_mr_wallslip_l"; break;
					case 151 : efName = "Wm_mr_wallslip_cld"; break;
					case 152 : efName = "Wm_mr_wallslip_s_r"; break;
					case 153 : efName = "Wm_mr_wallslip_s_l"; break;
					case 154 : efName = "Wm_mr_wallslip_cld_s"; break;
					case 155 : efName = "Wm_mr_wallslip_ss_r"; break;
					case 156 : efName = "Wm_mr_wallslip_ss_l"; break;
					case 157 : efName = "Wm_mr_wallslip_cld_ss"; break;
					case 158 : efName = "Wm_mr_hardhit"; break;
					case 159 : efName = "Wm_mr_hardhit_glow"; break;
					case 160 : efName = "Wm_mr_hardhit_spak"; break;
					case 161 : efName = "Wm_mr_hardhit_grain"; break;
					case 162 : efName = "Wm_mr_kickhit"; break;
					case 163 : efName = "Wm_mr_kick_glow"; break;
					case 164 : efName = "Wm_mr_kick_grain"; break;
					case 165 : efName = "Wm_mr_softhit"; break;
					case 166 : efName = "Wm_mr_softhit_glow"; break;
					case 167 : efName = "Wm_mr_softhit_spak"; break;
					case 168 : efName = "Wm_mr_wirehit"; break;
					case 169 : efName = "Wm_mr_wirehit_line"; break;
					case 170 : efName = "Wm_mr_wirehit_star"; break;
					case 171 : efName = "Wm_mr_wirehit_glow"; break;
					case 172 : efName = "Wm_mr_wirehit_hit"; break;
					case 173 : efName = "Wm_ob_coin"; break;
					case 174 : efName = "Wm_ob_coinkira"; break;
					case 175 : efName = "Wm_ob_bluecoinkira"; break;
					case 176 : efName = "Wm_ob_greencoinkira"; break;
					case 177 : efName = "Wm_ob_greencoinkira_c"; break;
					case 178 : efName = "Wm_ob_greencoinkira_b"; break;
					case 179 : efName = "Wm_ob_greencoinkira_a"; break;
					case 180 : efName = "Wm_ob_redcoinkira"; break;
					case 181 : efName = "Wm_ob_starcoinget"; break;
					case 182 : efName = "Wm_ob_starcoinget_gl"; break;
					case 183 : efName = "Wm_ob_starcoinget_lighit"; break;
					case 184 : efName = "Wm_ob_starcoinget_hit"; break;
					case 185 : efName = "Wm_ob_starcoinget_str"; break;
					case 186 : efName = "Wm_ob_starcoinget_ring"; break;
					case 187 : efName = "Wm_mr_electricshock"; break;
					case 188 : efName = "Wm_mr_electricshock_glw"; break;
					case 189 : efName = "Wm_mr_electricshock_biri01"; break;
					case 190 : efName = "Wm_mr_electricshock_biri02"; break;
					case 191 : efName = "Wm_mr_electricshock_kira"; break;
					case 192 : efName = "Wm_mr_electricshock_s"; break;
					case 193 : efName = "Wm_mr_electricshock_glw_s"; break;
					case 194 : efName = "Wm_mr_electricshock_biri01_s"; break;
					case 195 : efName = "Wm_mr_electricshock_biri02_s"; break;
					case 196 : efName = "Wm_mr_electricshock_kira_s"; break;
					case 197 : efName = "Wm_en_birikyu"; break;
					case 198 : efName = "Wm_en_birikyu_glw"; break;
					case 199 : efName = "Wm_en_birikyu_kira"; break;
					case 200 : efName = "Wm_en_birikyu_biri"; break;
					case 201 : efName = "Wm_mr_1upkira"; break;
					case 202 : efName = "Wm_mr_1upkira_spin"; break;
					case 203 : efName = "Wm_mr_1upkira_01"; break;
					case 204 : efName = "Wm_mr_1upkira_02"; break;
					case 205 : efName = "Wm_mr_1upkira_s"; break;
					case 206 : efName = "Wm_mr_1upkira_spin_s"; break;
					case 207 : efName = "Wm_mr_1upkira_01_s"; break;
					case 208 : efName = "Wm_mr_1upkira_02_s"; break;
					case 209 : efName = "Wm_mr_1upkira_ss"; break;
					case 210 : efName = "Wm_mr_1upkira_spin_ss"; break;
					case 211 : efName = "Wm_mr_1upkira_01_ss"; break;
					case 212 : efName = "Wm_en_hanapetal"; break;
					case 213 : efName = "Wm_en_hanapetal_a"; break;
					case 214 : efName = "Wm_en_hanapetal_b"; break;
					case 215 : efName = "Wm_en_movecloud"; break;
					case 216 : efName = "Wm_mr_cloud_on"; break;
					case 217 : efName = "Wm_en_blockcloud"; break;
					case 218 : efName = "Wm_en_hanasnort"; break;
					case 219 : efName = "Wm_en_hanasnort_r"; break;
					case 220 : efName = "Wm_en_hanasnort_l"; break;
					case 221 : efName = "Wm_en_hanasnort_cld"; break;
					case 222 : efName = "Wm_mr_gauge"; break;
					case 223 : efName = "Wm_mr_flaggetkira"; break;
					case 224 : efName = "Wm_mr_flaggetkira_s"; break;
					case 225 : efName = "Wm_mr_flaggetkira_ss"; break;
					case 226 : efName = "Wm_ob_flagget"; break;
					case 227 : efName = "Wm_ob_flagget_kira"; break;
					case 228 : efName = "Wm_ob_flaggetkira_cld"; break;
					case 229 : efName = "Wm_ob_flagget_light"; break;
					case 230 : efName = "Wm_ob_icethaw"; break;
					case 231 : efName = "Wm_ob_icebreak"; break;
					case 232 : efName = "Wm_ob_icebreakwt"; break;
					case 233 : efName = "Wm_ob_icebreaksmk"; break;
					case 234 : efName = "Wm_ob_icewait"; break;
					case 235 : efName = "Wm_ob_icewaitwat"; break;
					case 236 : efName = "Wm_ob_iceattack"; break;
					case 237 : efName = "Wm_ob_iceattackkira"; break;
					case 238 : efName = "Wm_ob_iceattackline"; break;
					case 239 : efName = "Wm_ob_iceattacksmk"; break;
					case 240 : efName = "Wm_ob_icehit"; break;
					case 241 : efName = "Wm_ob_icehitwat"; break;
					case 242 : efName = "Wm_ob_icehithit"; break;
					case 243 : efName = "Wm_ob_icehitsmk"; break;
					case 244 : efName = "Wm_ob_iceevaporate"; break;
					case 245 : efName = "Wm_ob_icepoison"; break;
					case 246 : efName = "Wm_ob_waterbreak"; break;
					case 247 : efName = "Wm_ob_waterbreak_a"; break;
					case 248 : efName = "Wm_ob_waterbreak_b"; break;
					case 249 : efName = "Wm_ob_waterbreak_c"; break;
					case 250 : efName = "Wm_en_firesnk_icehit_h"; break;
					case 251 : efName = "Wm_en_firesnk_icehitsmk_h"; break;
					case 252 : efName = "Wm_en_firesnk_icehit_b"; break;
					case 253 : efName = "Wm_en_firesnk_icehitsmk_b"; break;
					case 254 : efName = "Wm_en_firesnkspark01"; break;
					case 255 : efName = "Wm_en_firesnkspark02"; break;
					case 256 : efName = "Wm_mr_vshipattack"; break;
					case 257 : efName = "Wm_mr_vshipattack_line"; break;
					case 258 : efName = "Wm_mr_vshipattack_hosi"; break;
					case 259 : efName = "Wm_mr_vshipattack_gl"; break;
					case 260 : efName = "Wm_mr_vshipattack_ud"; break;
					case 261 : efName = "Wm_mr_vshipattack_ind"; break;
					case 262 : efName = "Wm_mr_vshipattack_ind_a"; break;
					case 263 : efName = "Wm_mr_vshipattack_ind_c"; break;
					case 264 : efName = "Wm_mr_vshipattack_ind_b"; break;
					case 265 : efName = "Wm_mr_spinstart"; break;
					case 266 : efName = "Wm_mr_propellertail"; break;
					case 267 : efName = "Wm_mr_p_iceslip"; break;
					case 268 : efName = "Wm_mr_p_snowslip"; break;
					case 269 : efName = "Wm_mr_penguinsmoke"; break;
					case 270 : efName = "Wm_mr_pdesertsmoke"; break;
					case 271 : efName = "Wm_mr_pbeachsmoke"; break;
					case 272 : efName = "Wm_mr_penguinsnow"; break;
					case 273 : efName = "Wm_mr_penguinice"; break;
					case 274 : efName = "Wm_mr_spinsmoke"; break;
					case 275 : efName = "Wm_mr_spinjump"; break;
					case 276 : efName = "Wm_mr_spinjump_re"; break;
					case 277 : efName = "Wm_mr_spindepart"; break;
					case 278 : efName = "Wm_mr_spindepart_a"; break;
					case 279 : efName = "Wm_mr_spindepart_b"; break;
					case 280 : efName = "Wm_mr_spindown"; break;
					case 281 : efName = "Wm_mr_spindown_a"; break;
					case 282 : efName = "Wm_mr_spindown_b"; break;
					case 283 : efName = "Wm_mr_spindownline"; break;
					case 284 : efName = "Wm_mr_normalspin_pm"; break;
					case 285 : efName = "Wm_mr_normalspin"; break;
					case 286 : efName = "Wm_mr_halfspin"; break;
					case 287 : efName = "Wm_en_shellredtail"; break;
					case 288 : efName = "Wm_en_shellgreentail"; break;
					case 289 : efName = "Wm_mr_starkira"; break;
					case 290 : efName = "Wm_mr_starkira_a"; break;
					case 291 : efName = "Wm_mr_starkira_b"; break;
					case 292 : efName = "Wm_mr_starkira_s"; break;
					case 293 : efName = "Wm_mr_starkira_a_s"; break;
					case 294 : efName = "Wm_mr_starkira_b_s"; break;
					case 295 : efName = "Wm_ob_itemget"; break;
					case 296 : efName = "Wm_ob_itemget_hitlighit"; break;
					case 297 : efName = "Wm_ob_itemget_hit"; break;
					case 298 : efName = "Wm_ob_itemget_ring"; break;
					case 299 : efName = "Wm_mr_itemget01"; break;
					case 300 : efName = "Wm_mr_itemget02"; break;
					case 301 : efName = "Wm_ob_itemappear"; break;
					case 302 : efName = "Wm_ob_itemappear_r"; break;
					case 303 : efName = "Wm_ob_itemappear_gl"; break;
					case 304 : efName = "Wm_ob_itemappear_ss"; break;
					case 305 : efName = "Wm_ob_itemappear_r_ss"; break;
					case 306 : efName = "Wm_ob_itemappear_gl_ss"; break;
					case 307 : efName = "Wm_ob_startail"; break;
					case 308 : efName = "Wm_ob_startail_star"; break;
					case 309 : efName = "Wm_ob_startail_kira"; break;
					case 310 : efName = "Wm_ob_itempropeller"; break;
					case 311 : efName = "Wm_ob_powdown"; break;
					case 312 : efName = "Wm_ob_powdown_ind"; break;
					case 313 : efName = "Wm_ob_powdown_ind_a"; break;
					case 314 : efName = "Wm_ob_powdown_ind_c"; break;
					case 315 : efName = "Wm_ob_powdown_ind_b"; break;
					case 316 : efName = "Wm_ob_itemlandsmoke"; break;
					case 317 : efName = "Wm_ob_itemsealandsmk"; break;
					case 318 : efName = "Wm_ob_itemsndlandsmk"; break;
					case 319 : efName = "Wm_en_spindamage"; break;
					case 320 : efName = "Wm_en_spindamage_rg"; break;
					case 321 : efName = "Wm_en_spindamage_star"; break;
					case 322 : efName = "Wm_en_spindamage_big"; break;
					case 323 : efName = "Wm_en_spindamage_big_st"; break;
					case 324 : efName = "Wm_en_spindamage_big_rg"; break;
					case 325 : efName = "Wm_mr_atitismoke"; break;
					case 326 : efName = "Wm_en_sanbosmoke"; break;
					case 327 : efName = "Wm_en_sanbospillsand"; break;
					case 328 : efName = "Wm_en_sanbohit"; break;
					case 329 : efName = "Wm_en_sanbohit_smk"; break;
					case 330 : efName = "Wm_en_sanbohit_hit"; break;
					case 331 : efName = "Wm_en_sanbohit_ring"; break;
					case 332 : efName = "Wm_en_sanbohitsmk"; break;
					case 333 : efName = "Wm_en_keronpafire"; break;
					case 334 : efName = "Wm_en_keronpafire_f"; break;
					case 335 : efName = "Wm_en_keronpafire_ca"; break;
					case 336 : efName = "Wm_en_keronpalight"; break;
					case 337 : efName = "Wm_en_explosion"; break;
					case 338 : efName = "Wm_en_explosion_ln"; break;
					case 339 : efName = "Wm_en_explosion_gl01"; break;
					case 340 : efName = "Wm_en_explosion_hd"; break;
					case 341 : efName = "Wm_en_explosion_un"; break;
					case 342 : efName = "Wm_en_explosion_gl02"; break;
					case 343 : efName = "Wm_en_explosion_smk"; break;
					case 344 : efName = "Wm_en_bombheibreak"; break;
					case 345 : efName = "Wm_en_bombignition"; break;
					case 346 : efName = "Wm_en_bomignition_ln"; break;
					case 347 : efName = "Wm_en_bomignition_gl01"; break;
					case 348 : efName = "Wm_en_bomignition_pati"; break;
					case 349 : efName = "Wm_mr_sanddive"; break;
					case 350 : efName = "Wm_mr_sanddive_sd"; break;
					case 351 : efName = "Wm_mr_sanddive_in"; break;
					case 352 : efName = "Wm_mr_sanddive_out"; break;
					case 353 : efName = "Wm_mr_sanddive_smk"; break;
					case 354 : efName = "Wm_mr_sanddive_m"; break;
					case 355 : efName = "Wm_mr_sanddive_sd_m"; break;
					case 356 : efName = "Wm_mr_sanddive_in_m"; break;
					case 357 : efName = "Wm_mr_sanddive_out_m"; break;
					case 358 : efName = "Wm_mr_sanddive_smk_m"; break;
					case 359 : efName = "Wm_mr_sanddive_s"; break;
					case 360 : efName = "Wm_mr_sanddive_sb_s"; break;
					case 361 : efName = "Wm_mr_sanddive_smk_s"; break;
					case 362 : efName = "Wm_mr_sandsplash"; break;
					case 363 : efName = "Wm_en_dossunfall01"; break;
					case 364 : efName = "Wm_en_dossunfall02"; break;
					case 365 : efName = "Wm_en_dossunfall03"; break;
					case 366 : efName = "Wm_en_kuribobigsplit"; break;
					case 367 : efName = "Wm_en_kuribobigsplit_sk"; break;
					case 368 : efName = "Wm_en_kuribobigsplit_ht"; break;
					case 369 : efName = "Wm_en_kuribobigsplit_gr02"; break;
					case 370 : efName = "Wm_en_kuribobigsplit_gr01"; break;
					case 371 : efName = "Wm_en_kuribobigsplit_rg"; break;
					case 372 : efName = "Wm_en_kuribosplit"; break;
					case 373 : efName = "Wm_en_kuribosplit_gl02"; break;
					case 374 : efName = "Wm_en_kuribosplit_gl01"; break;
					case 375 : efName = "Wm_en_kuribosplit_sk"; break;
					case 376 : efName = "Wm_en_teresatail"; break;
					case 377 : efName = "Wm_en_teresavanish"; break;
					case 378 : efName = "Wm_en_obakedoor"; break;
					case 379 : efName = "Wm_en_obakedoor_sm"; break;
					case 380 : efName = "Wm_en_obakedoor_ic"; break;
					case 381 : efName = "Wm_mr_yoshistep"; break;
					case 382 : efName = "Wm_mr_yoshistep_a"; break;
					case 383 : efName = "Wm_mr_yoshistep_a_cld"; break;
					case 384 : efName = "Wm_mr_yoshistep_b"; break;
					case 385 : efName = "Wm_mr_fruitget"; break;
					case 386 : efName = "Wm_mr_fruitget_w"; break;
					case 387 : efName = "Wm_mr_fruitget_h"; break;
					case 388 : efName = "Wm_ob_eggbreak_gr"; break;
					case 389 : efName = "Wm_ob_eggbreak_rd"; break;
					case 390 : efName = "Wm_ob_eggbreak_yw"; break;
					case 391 : efName = "Wm_ob_eggbreak_bl"; break;
					case 392 : efName = "Wm_mr_yoshifire"; break;
					case 393 : efName = "Wm_mr_yoshifire_a"; break;
					case 394 : efName = "Wm_mr_yoshifire_b"; break;
					case 395 : efName = "Wm_mr_yoshiiceball"; break;
					case 396 : efName = "Wm_mr_yoshiiceball_b"; break;
					case 397 : efName = "Wm_mr_yoshiiceball_a"; break;
					case 398 : efName = "Wm_mr_yoshifirehit"; break;
					case 399 : efName = "Wm_mr_yoshifirehit01"; break;
					case 400 : efName = "Wm_mr_yoshiicehit"; break;
					case 401 : efName = "Wm_mr_yoshiicehit_a"; break;
					case 402 : efName = "Wm_mr_yoshiicehit_b"; break;
					case 403 : efName = "Wm_mr_yssweatrun"; break;
					case 404 : efName = "Wm_mr_yssweat"; break;
					case 405 : efName = "Wm_mr_ystonguehit"; break;
					case 406 : efName = "Wm_mr_ystonguehit_a"; break;
					case 407 : efName = "Wm_en_crowhit"; break;
					case 408 : efName = "Wm_en_crowfly"; break;
					case 409 : efName = "Wm_en_crowattack_r"; break;
					case 410 : efName = "Wm_en_crowattack_l"; break;
					case 411 : efName = "Wm_en_pakkunfire"; break;
					case 412 : efName = "Wm_en_pakkunfire00"; break;
					case 413 : efName = "Wm_en_firebros_fire"; break;
					case 414 : efName = "Wm_en_firebros_fire_a"; break;
					case 415 : efName = "Wm_en_firebros_fire_b"; break;
					case 416 : efName = "Wm_mr_magmawave"; break;
					case 417 : efName = "Wm_mr_magmawave_a"; break;
					case 418 : efName = "Wm_mr_magmawave_b"; break;
					case 419 : efName = "Wm_ob_magmagear"; break;
					case 420 : efName = "Wm_mr_poisonwave"; break;
					case 421 : efName = "Wm_mr_poisonwave_a"; break;
					case 422 : efName = "Wm_mr_poisonwave_b"; break;
					case 423 : efName = "Wm_mr_waterwave_in"; break;
					case 424 : efName = "Wm_mr_waterwave_in_a"; break;
					case 425 : efName = "Wm_mr_waterwave_in_b"; break;
					case 426 : efName = "Wm_mr_waterwave_in_c"; break;
					case 427 : efName = "Wm_mr_waterwave_in_d"; break;
					case 428 : efName = "Wm_mr_waterwave_out"; break;
					case 429 : efName = "Wm_mr_waterwave_out_a"; break;
					case 430 : efName = "Wm_mr_waterwave_out_b"; break;
					case 431 : efName = "Wm_mr_waterwave_out_c"; break;
					case 432 : efName = "Wm_mr_waterwave_in_ss"; break;
					case 433 : efName = "Wm_mr_waterwave_in_a_ss"; break;
					case 434 : efName = "Wm_mr_waterwave_in_b_ss"; break;
					case 435 : efName = "Wm_mr_waterwave_out_ss"; break;
					case 436 : efName = "Wm_mr_waterwave_out_a_ss"; break;
					case 437 : efName = "Wm_mr_waterwave_out_b_ss"; break;
					case 438 : efName = "Wm_mr_waterrun_l_ss"; break;
					case 439 : efName = "Wm_mr_waterrun_r_ss"; break;
					case 440 : efName = "Wm_mr_waterswim"; break;
					case 441 : efName = "Wm_ob_magmasign01"; break;
					case 442 : efName = "Wm_ob_magmasign02"; break;
					case 443 : efName = "Wm_ob_firespillarunder"; break;
					case 444 : efName = "Wm_ob_firespillar02"; break;
					case 445 : efName = "Wm_ob_firespillar01"; break;
					case 446 : efName = "Wm_mr_foot_snow"; break;
					case 447 : efName = "Wm_mr_foot_ice"; break;
					case 448 : efName = "Wm_mr_foot_sand"; break;
					case 449 : efName = "Wm_mr_foot_beach"; break;
					case 450 : efName = "Wm_mr_foot_water"; break;
					case 451 : efName = "Wm_mr_turn_beach_r"; break;
					case 452 : efName = "Wm_mr_turn_beach_l"; break;
					case 453 : efName = "Wm_mr_turn_water_r"; break;
					case 454 : efName = "Wm_mr_turn_water_l"; break;
					case 455 : efName = "Wm_mr_turn_ice_r"; break;
					case 456 : efName = "Wm_mr_turn_ice_l"; break;
					case 457 : efName = "Wm_mr_turn_sand_r"; break;
					case 458 : efName = "Wm_mr_turn_sand_l"; break;
					case 459 : efName = "Wm_mr_turn_snow_r"; break;
					case 460 : efName = "Wm_mr_turn_snow_l"; break;
					case 461 : efName = "Wm_mr_turn_usual_r"; break;
					case 462 : efName = "Wm_mr_turn_usual_l"; break;
					case 463 : efName = "Wm_ob_sandpillar01"; break;
					case 464 : efName = "Wm_ob_sandpillar02"; break;
					case 465 : efName = "Wm_ob_spillarsign01"; break;
					case 466 : efName = "Wm_ob_spillarsign02"; break;
					case 467 : efName = "Wm_mr_spsmoke"; break;
					case 468 : efName = "Wm_en_spsmoke"; break;
					case 469 : efName = "Wm_en_sphitsmoke"; break;
					case 470 : efName = "Wm_mr_sprisesmoke"; break;
					case 471 : efName = "Wm_en_huhubreathstart"; break;
					case 472 : efName = "Wm_en_huhubreath"; break;
					case 473 : efName = "Wm_en_huhuhaze"; break;
					case 474 : efName = "Wm_en_huhufloat"; break;
					case 475 : efName = "Wm_en_huhudamage01"; break;
					case 476 : efName = "Wm_en_huhudamage02"; break;
					case 477 : efName = "Wm_en_huhurevival01"; break;
					case 478 : efName = "Wm_en_huhurevival02"; break;
					case 479 : efName = "Wm_mr_wfloatsplash"; break;
					case 480 : efName = "Wm_mr_wfloatsplash_a"; break;
					case 481 : efName = "Wm_mr_wfloatsplash_b"; break;
					case 482 : efName = "Wm_en_wfsplash_in_r"; break;
					case 483 : efName = "Wm_en_wfsplash_in01_r"; break;
					case 484 : efName = "Wm_en_wfsplash_in02_r"; break;
					case 485 : efName = "Wm_en_wfsplash_in_l"; break;
					case 486 : efName = "Wm_en_wfsplash_in01_l"; break;
					case 487 : efName = "Wm_en_wfsplash_in02_l"; break;
					case 488 : efName = "Wm_en_wfsplash_out_r"; break;
					case 489 : efName = "Wm_en_wfsplash_out01_r"; break;
					case 490 : efName = "Wm_en_wfsplash_out02_r"; break;
					case 491 : efName = "Wm_en_wfsplash_out_l"; break;
					case 492 : efName = "Wm_en_wfsplash_out01_l"; break;
					case 493 : efName = "Wm_en_wfsplash_out02_l"; break;
					case 494 : efName = "Wm_mr_balloonburst"; break;
					case 495 : efName = "Wm_mr_balloonburst_w"; break;
					case 496 : efName = "Wm_mr_balloonburst_h"; break;
					case 497 : efName = "Wm_en_magkillersmoke"; break;
					case 498 : efName = "Wm_en_mgkillershot_r"; break;
					case 499 : efName = "Wm_en_mgkillershot_l"; break;
					case 500 : efName = "Wm_en_killersmoke"; break;
					case 501 : efName = "Wm_en_killershot"; break;
					case 502 : efName = "Wm_en_killervanish"; break;
					case 503 : efName = "Wm_en_kingkiller"; break;
					case 504 : efName = "Wm_en_kingkiller_gr"; break;
					case 505 : efName = "Wm_en_kingkiller_rg"; break;
					case 506 : efName = "Wm_en_kingkiller_sm"; break;
					case 507 : efName = "Wm_en_mgsearchkiller"; break;
					case 508 : efName = "Wm_en_searchkiller"; break;
					case 509 : efName = "Wm_en_pakkunsweat"; break;
					case 510 : efName = "Wm_en_pakkun_ball01"; break;
					case 511 : efName = "Wm_en_pakkun_ball02"; break;
					case 512 : efName = "Wm_en_pakkun_foo"; break;
					case 513 : efName = "Wm_en_igafirehit"; break;
					case 514 : efName = "Wm_en_patametsweat"; break;
					case 515 : efName = "Wm_ob_fireworks_y"; break;
					case 516 : efName = "Wm_ob_fireworks_y01"; break;
					case 517 : efName = "Wm_ob_fireworks_ycld"; break;
					case 518 : efName = "Wm_ob_fireworks_b"; break;
					case 519 : efName = "Wm_ob_fireworks_b01"; break;
					case 520 : efName = "Wm_ob_fireworks_bcld"; break;
					case 521 : efName = "Wm_ob_fireworks_g"; break;
					case 522 : efName = "Wm_ob_fireworks_g01"; break;
					case 523 : efName = "Wm_ob_fireworks_gcld"; break;
					case 524 : efName = "Wm_ob_fireworks_p"; break;
					case 525 : efName = "Wm_ob_fireworks_p01"; break;
					case 526 : efName = "Wm_ob_fireworks_pcld"; break;
					case 527 : efName = "Wm_ob_fireworks_k"; break;
					case 528 : efName = "Wm_ob_fireworks_kgl01"; break;
					case 529 : efName = "Wm_ob_fireworks_kgl02"; break;
					case 530 : efName = "Wm_ob_fireworks_k01"; break;
					case 531 : efName = "Wm_ob_fireworks_kcld1"; break;
					case 532 : efName = "Wm_ob_fireworks_k02"; break;
					case 533 : efName = "Wm_ob_fireworks_kcld2"; break;
					case 534 : efName = "Wm_ob_fireworks_1up"; break;
					case 535 : efName = "Wm_ob_fireworks_1upgl01"; break;
					case 536 : efName = "Wm_ob_fireworks_1upgl02"; break;
					case 537 : efName = "Wm_ob_fireworks_1up01"; break;
					case 538 : efName = "Wm_ob_fireworks_1upcld1"; break;
					case 539 : efName = "Wm_ob_fireworks_1up02"; break;
					case 540 : efName = "Wm_ob_fireworks_1upcld2"; break;
					case 541 : efName = "Wm_ob_fireworks_star"; break;
					case 542 : efName = "Wm_ob_fireworks_stargl01"; break;
					case 543 : efName = "Wm_ob_fireworks_stargl02"; break;
					case 544 : efName = "Wm_ob_fireworks_star01"; break;
					case 545 : efName = "Wm_ob_fireworks_starcld1"; break;
					case 546 : efName = "Wm_ob_fireworks_star02"; break;
					case 547 : efName = "Wm_ob_fireworks_starcld2"; break;
					case 548 : efName = "Wm_ob_switch"; break;
					case 549 : efName = "Wm_ob_switch01"; break;
					case 550 : efName = "Wm_en_sweat"; break;
					case 551 : efName = "Wm_en_choroappear"; break;
					case 552 : efName = "Wm_en_choroescape"; break;
					case 553 : efName = "Wm_en_brakesmoke"; break;
					case 554 : efName = "Wm_ob_redcioinkira"; break;
					case 555 : efName = "Wm_ob_redcioinkira_cd"; break;
					case 556 : efName = "Wm_ob_redcioinitem01"; break;
					case 557 : efName = "Wm_ob_redcioinitem_cd"; break;
					case 558 : efName = "Wm_ob_redcioinitem02"; break;
					case 559 : efName = "Wm_ob_redcioinitem02_b"; break;
					case 560 : efName = "Wm_ob_redcioinitem02_a"; break;
					case 561 : efName = "Wm_ob_itemfall"; break;
					case 562 : efName = "Wm_ob_itemfall_a"; break;
					case 563 : efName = "Wm_ob_itemfall_b"; break;
					case 564 : efName = "Wm_ob_redringkira"; break;
					case 565 : efName = "Wm_ob_redringget"; break;
					case 566 : efName = "Wm_ob_redringget_a"; break;
					case 567 : efName = "Wm_ob_redringget_b"; break;
					case 568 : efName = "Wm_ob_redringget_c"; break;
					case 569 : efName = "Wm_ob_warpcannonkira"; break;
					case 570 : efName = "Wm_ob_witchcraft"; break;
					case 571 : efName = "Wm_ob_witchcraftup"; break;
					case 572 : efName = "Wm_bs_kameckmagic"; break;
					case 573 : efName = "Wm_bs_kameckmagic_e"; break;
					case 574 : efName = "Wm_bs_kameckmagic_f"; break;
					case 575 : efName = "Wm_bs_kameckmagic_a"; break;
					case 576 : efName = "Wm_bs_kameckmagic_b"; break;
					case 577 : efName = "Wm_bs_kameckmagic_c"; break;
					case 578 : efName = "Wm_bs_kameckmagic_d"; break;
					case 579 : efName = "Wm_ob_keyfall"; break;
					case 580 : efName = "Wm_ob_keywait"; break;
					case 581 : efName = "Wm_ob_keywait_c"; break;
					case 582 : efName = "Wm_ob_keywait_a"; break;
					case 583 : efName = "Wm_ob_keywait_b"; break;
					case 584 : efName = "Wm_ob_keyget01"; break;
					case 585 : efName = "Wm_ob_keyget01_d"; break;
					case 586 : efName = "Wm_ob_keyget01_a"; break;
					case 587 : efName = "Wm_ob_keyget01_b"; break;
					case 588 : efName = "Wm_ob_keyget01_c"; break;
					case 589 : efName = "Wm_ob_keyget02"; break;
					case 590 : efName = "Wm_ob_keyget02_kira"; break;
					case 591 : efName = "Wm_ob_keyget02_ring01"; break;
					case 592 : efName = "Wm_ob_keyget02_ring02"; break;
					case 593 : efName = "Wm_ob_keyget02_gl02"; break;
					case 594 : efName = "Wm_ob_keyget02_gl01"; break;
					case 595 : efName = "Wm_ob_keyget02_lighit"; break;
					case 596 : efName = "Wm_ob_keyget02_hit"; break;
					case 597 : efName = "Wm_ob_keyget02_str"; break;
					case 598 : efName = "Wm_ob_stream"; break;
					case 599 : efName = "Wm_seacloudout"; break;
					case 600 : efName = "Wm_shellopen"; break;
					case 601 : efName = "Wm_shellopen_a"; break;
					case 602 : efName = "Wm_shellopen_b"; break;
					case 603 : efName = "Wm_2d_courseclear"; break;
					case 604 : efName = "Wm_2d_courseclear_da"; break;
					case 605 : efName = "Wm_2d_courseclear_kiraL"; break;
					case 606 : efName = "Wm_2d_courseclear_kiraR"; break;
					case 607 : efName = "Wm_2d_courseclear_cld"; break;
					case 608 : efName = "Wm_2d_courseclear_smkL"; break;
					case 609 : efName = "Wm_2d_courseclearsmcld01"; break;
					case 610 : efName = "Wm_2d_courseclear_smkR"; break;
					case 611 : efName = "Wm_2d_courseclearsmcld02"; break;
					case 612 : efName = "Wm_2d_timeup"; break;
					case 613 : efName = "Wm_2d_timeupsmoke"; break;
					case 614 : efName = "Wm_2d_timeupstar"; break;
					case 615 : efName = "Wm_2d_timeupstarcld"; break;
					case 616 : efName = "Wm_2d_gameover"; break;
					case 617 : efName = "Wm_2d_gameover_a"; break;
					case 618 : efName = "Wm_2d_gameover_b"; break;
					case 619 : efName = "Wm_2d_mrstarkira"; break;
					case 620 : efName = "Wm_2d_1up02"; break;
					case 621 : efName = "Wm_2d_1up01"; break;
					case 622 : efName = "Wm_2d_coin100"; break;
					case 623 : efName = "Wm_2d_coin100a"; break;
					case 624 : efName = "Wm_2d_coinlight"; break;
					case 625 : efName = "Wm_2d_continue"; break;
					case 626 : efName = "Wm_2d_stockitem"; break;
					case 627 : efName = "Wm_2d_stockitem_a"; break;
					case 628 : efName = "Wm_2d_stockitem_b"; break;
					case 629 : efName = "Wm_mr_stockitemuse"; break;
					case 630 : efName = "Wm_mr_stockitemuse_a"; break;
					case 631 : efName = "Wm_mr_stockitemuse_b"; break;
					case 632 : efName = "Wm_mr_stockitemuse_c"; break;
					case 633 : efName = "Wm_2d_moviecoinkira"; break;
					case 634 : efName = "Wm_2d_moviecoinvanish"; break;
					case 635 : efName = "Wm_2d_movieopen"; break;
					case 636 : efName = "Wm_2d_movieopen_a"; break;
					case 637 : efName = "Wm_2d_movieopen_b1"; break;
					case 638 : efName = "Wm_2d_movieopen_b2"; break;
					case 639 : efName = "Wm_2d_resultscore"; break;
					case 640 : efName = "Wm_2d_resultrest"; break;
					case 641 : efName = "Wm_2d_resultno1"; break;
					case 642 : efName = "Wm_2d_result"; break;
					case 643 : efName = "Wm_2d_result_a1"; break;
					case 644 : efName = "Wm_2d_result_a2"; break;
					case 645 : efName = "Wm_2d_result_b1"; break;
					case 646 : efName = "Wm_2d_result_b2"; break;
					case 647 : efName = "Wm_2d_starcoinget"; break;
					case 648 : efName = "Wm_2d_starcoinvanish"; break;
					case 649 : efName = "Wm_2d_multiclear"; break;
					case 650 : efName = "Wm_2d_titlestar01"; break;
					case 651 : efName = "Wm_2d_titlestar02"; break;
					case 652 : efName = "Wm_en_fireburner"; break;
					case 653 : efName = "Wm_en_firebrnsignind"; break;
					case 654 : efName = "Wm_en_firebrnsign"; break;
					case 655 : efName = "Wm_en_fireburner3ind"; break;
					case 656 : efName = "Wm_en_fireburner4ind"; break;
					case 657 : efName = "Wm_en_fireburner6ind"; break;
					case 658 : efName = "Wm_mr_palm_s"; break;
					case 659 : efName = "Wm_mr_palm"; break;
					case 660 : efName = "Wm_ob_boat"; break;
					case 661 : efName = "Wm_ob_fallsmoke"; break;
					case 662 : efName = "Wm_ob_fallsmoke_big"; break;
					case 663 : efName = "Wm_ob_fallsmoke_s"; break;
					case 664 : efName = "Wm_bg_volcano"; break;
					case 665 : efName = "Wm_bg_volcano_a"; break;
					case 666 : efName = "Wm_bg_volcano_b"; break;
					case 667 : efName = "Wm_ob_treasurebox"; break;
					case 668 : efName = "Wm_ob_treasureboxwait"; break;
					case 669 : efName = "Wm_ob_treasureboxwait_a"; break;
					case 670 : efName = "Wm_ob_treasureboxwait_b"; break;
					case 671 : efName = "Wm_ob_treasureboxtail"; break;
					case 672 : efName = "Wm_ob_itemteil"; break;
					case 673 : efName = "Wm_ob_icicle"; break;
					case 674 : efName = "Wm_mr_brosquake"; break;
					case 675 : efName = "Wm_en_atitismoke"; break;
					case 676 : efName = "Wm_en_waterwave_in_a"; break;
					case 677 : efName = "Wm_en_waterwave_in_b"; break;
					case 678 : efName = "Wm_en_watersplash_cld"; break;
					case 679 : efName = "Wm_en_poisonwave_a"; break;
					case 680 : efName = "Wm_en_poisonwave_b"; break;
					case 681 : efName = "Wm_en_magmawave_a"; break;
					case 682 : efName = "Wm_en_magmawave_b"; break;
					case 683 : efName = "Wm_en_vshit_hit"; break;
					case 684 : efName = "Wm_en_vshit_glow"; break;
					case 685 : efName = "Wm_en_vshit_ring"; break;
					case 686 : efName = "Wm_en_vshit_star"; break;
					case 687 : efName = "Wm_en_hit_ring"; break;
					case 688 : efName = "Wm_mr_misshit_ring"; break;
					case 689 : efName = "Wm_ob_envsunlight_b"; break;
					case 690 : efName = "Wm_ob_envsunlight_a"; break;
					case 691 : efName = "Wm_mr_fireball_a"; break;
					case 692 : efName = "Wm_mr_fireball_b"; break;
					case 693 : efName = "Wm_mr_iceball_a"; break;
					case 694 : efName = "Wm_mr_iceball_b"; break;
					case 695 : efName = "Wm_ob_icemisshit_smk"; break;
					case 696 : efName = "Wm_mr_fireball_hit01"; break;
					case 697 : efName = "Wm_en_bubble_a"; break;
					case 698 : efName = "Wm_en_bubble_b"; break;
					case 699 : efName = "Wm_mr_cliffcatch_cd"; break;
					case 700 : efName = "Wm_mr_wallkick_up_r"; break;
					case 701 : efName = "Wm_mr_wallkick_dn_r"; break;
					case 702 : efName = "Wm_mr_wallkick_b_r"; break;
					case 703 : efName = "Wm_mr_wallkick_c_r"; break;
					case 704 : efName = "Wm_mr_wallkick_cld_r"; break;
					case 705 : efName = "Wm_mr_wallkick_cld_r"; break;
					case 706 : efName = "Wm_mr_wallkick_up_l"; break;
					case 707 : efName = "Wm_mr_wallkick_dn_l"; break;
					case 708 : efName = "Wm_mr_wallkick_b_l"; break;
					case 709 : efName = "Wm_mr_wallkick_c_l"; break;
					case 710 : efName = "Wm_mr_wallkick_cld_l"; break;
					case 711 : efName = "Wm_mr_wallkick_cld_l"; break;
					case 712 : efName = "Wm_mr_wallkick_up_s_r"; break;
					case 713 : efName = "Wm_mr_wallkick_dn_s_r"; break;
					case 714 : efName = "Wm_mr_wallkick_b_s_r"; break;
					case 715 : efName = "Wm_mr_wallkick_c_s_r"; break;
					case 716 : efName = "Wm_mr_wallkick_cld_s_r"; break;
					case 717 : efName = "Wm_mr_wallkick_cld_s_r"; break;
					case 718 : efName = "Wm_mr_wallkick_up_s_l"; break;
					case 719 : efName = "Wm_mr_wallkick_dn_s_l"; break;
					case 720 : efName = "Wm_mr_wallkick_b_s_l"; break;
					case 721 : efName = "Wm_mr_wallkick_c_s_l"; break;
					case 722 : efName = "Wm_mr_wallkick_cld_s_l"; break;
					case 723 : efName = "Wm_mr_wallkick_cld_s_l"; break;
					case 724 : efName = "Wm_mr_wallkick_up_ss_r"; break;
					case 725 : efName = "Wm_mr_wallkick_dn_ss_r"; break;
					case 726 : efName = "Wm_mr_wallkick_b_ss_r"; break;
					case 727 : efName = "Wm_mr_wallkick_c_ss_r"; break;
					case 728 : efName = "Wm_mr_wallkick_cld_ss_r"; break;
					case 729 : efName = "Wm_mr_wallkick_cld_ss_r"; break;
					case 730 : efName = "Wm_mr_wallkick_up_ss_l"; break;
					case 731 : efName = "Wm_mr_wallkick_dn_ss_l"; break;
					case 732 : efName = "Wm_mr_wallkick_b_ss_l"; break;
					case 733 : efName = "Wm_mr_wallkick_c_ss_l"; break;
					case 734 : efName = "Wm_mr_wallkick_cld_ss_l"; break;
					case 735 : efName = "Wm_mr_wallkick_cld_ss_l"; break;
					case 736 : efName = "Wm_mr_wallslip_cld"; break;
					case 737 : efName = "Wm_mr_wallslip_cld"; break;
					case 738 : efName = "Wm_mr_wallslip_cld_s"; break;
					case 739 : efName = "Wm_mr_wallslip_cld_s"; break;
					case 740 : efName = "Wm_mr_wallslip_cld_ss"; break;
					case 741 : efName = "Wm_mr_wallslip_cld_ss"; break;
					case 742 : efName = "Wm_mr_hardhit_spak"; break;
					case 743 : efName = "Wm_mr_hardhit_glow"; break;
					case 744 : efName = "Wm_mr_hardhit_grain"; break;
					case 745 : efName = "Wm_mr_kick_glow"; break;
					case 746 : efName = "Wm_mr_kick_grain"; break;
					case 747 : efName = "Wm_mr_softhit_spak"; break;
					case 748 : efName = "Wm_mr_softhit_glow"; break;
					case 749 : efName = "Wm_mr_wirehit_glow"; break;
					case 750 : efName = "Wm_mr_wirehit_hit"; break;
					case 751 : efName = "Wm_mr_wirehit_line"; break;
					case 752 : efName = "Wm_mr_wirehit_star"; break;
					case 753 : efName = "Wm_ob_greencoinkira_c"; break;
					case 754 : efName = "Wm_ob_greencoinkira_b"; break;
					case 755 : efName = "Wm_ob_greencoinkira_a"; break;
					case 756 : efName = "Wm_ob_starcoinget_str"; break;
					case 757 : efName = "Wm_ob_starcoinget_gl"; break;
					case 758 : efName = "Wm_ob_starcoinget_hit"; break;
					case 759 : efName = "Wm_ob_starcoinget_ring"; break;
					case 760 : efName = "Wm_ob_starcoinget_lighit"; break;
					case 761 : efName = "Wm_mr_electricshock_glw"; break;
					case 762 : efName = "Wm_mr_electricshock_biri01"; break;
					case 763 : efName = "Wm_mr_electricshock_biri02"; break;
					case 764 : efName = "Wm_mr_electricshock_kira"; break;
					case 765 : efName = "Wm_mr_electricshock_glw_s"; break;
					case 766 : efName = "Wm_mr_electricshock_biri01_s"; break;
					case 767 : efName = "Wm_mr_electricshock_biri02_s"; break;
					case 768 : efName = "Wm_mr_electricshock_kira_s"; break;
					case 769 : efName = "Wm_en_birikyu_glw"; break;
					case 770 : efName = "Wm_en_birikyu_biri"; break;
					case 771 : efName = "Wm_en_birikyu_kira"; break;
					case 772 : efName = "Wm_mr_1upkira_spin"; break;
					case 773 : efName = "Wm_mr_1upkira_01"; break;
					case 774 : efName = "Wm_mr_1upkira_02"; break;
					case 775 : efName = "Wm_mr_1upkira_spin_s"; break;
					case 776 : efName = "Wm_mr_1upkira_01_s"; break;
					case 777 : efName = "Wm_mr_1upkira_02_s"; break;
					case 778 : efName = "Wm_mr_1upkira_spin_ss"; break;
					case 779 : efName = "Wm_mr_1upkira_01_ss"; break;
					case 780 : efName = "Wm_en_hanapetal_a"; break;
					case 781 : efName = "Wm_en_hanapetal_b"; break;
					case 782 : efName = "Wm_en_hanasnort_r"; break;
					case 783 : efName = "Wm_en_hanasnort_l"; break;
					case 784 : efName = "Wm_en_hanasnort_cld"; break;
					case 785 : efName = "Wm_en_hanasnort_cld"; break;
					case 786 : efName = "Wm_ob_flagget_kira"; break;
					case 787 : efName = "Wm_ob_flagget_light"; break;
					case 788 : efName = "Wm_ob_flaggetkira_cld"; break;
					case 789 : efName = "Wm_ob_icebreakwt"; break;
					case 790 : efName = "Wm_ob_icebreaksmk"; break;
					case 791 : efName = "Wm_ob_icewaitwat"; break;
					case 792 : efName = "Wm_ob_iceattackkira"; break;
					case 793 : efName = "Wm_ob_iceattackline"; break;
					case 794 : efName = "Wm_ob_iceattacksmk"; break;
					case 795 : efName = "Wm_ob_icehithit"; break;
					case 796 : efName = "Wm_ob_icehitwat"; break;
					case 797 : efName = "Wm_ob_icehitsmk"; break;
					case 798 : efName = "Wm_ob_waterbreak_c"; break;
					case 799 : efName = "Wm_ob_waterbreak_a"; break;
					case 800 : efName = "Wm_ob_waterbreak_b"; break;
					case 801 : efName = "Wm_mr_vshipattack_line"; break;
					case 802 : efName = "Wm_mr_vshipattack_hosi"; break;
					case 803 : efName = "Wm_mr_vshipattack_gl"; break;
					case 804 : efName = "Wm_mr_vshipattack_ud"; break;
					case 805 : efName = "Wm_mr_vshipattack_ind_c"; break;
					case 806 : efName = "Wm_mr_vshipattack_ind_a"; break;
					case 807 : efName = "Wm_mr_vshipattack_ind_b"; break;
					case 808 : efName = "Wm_mr_spindepart_b"; break;
					case 809 : efName = "Wm_mr_spindepart_a"; break;
					case 810 : efName = "Wm_mr_spindown_a"; break;
					case 811 : efName = "Wm_mr_spindown_b"; break;
					case 812 : efName = "Wm_mr_starkira_a"; break;
					case 813 : efName = "Wm_mr_starkira_b"; break;
					case 814 : efName = "Wm_mr_starkira_a_s"; break;
					case 815 : efName = "Wm_mr_starkira_b_s"; break;
					case 816 : efName = "Wm_ob_itemget_hit"; break;
					case 817 : efName = "Wm_ob_itemget_ring"; break;
					case 818 : efName = "Wm_ob_itemget_hitlighit"; break;
					case 819 : efName = "Wm_ob_itemappear_r"; break;
					case 820 : efName = "Wm_ob_itemappear_gl"; break;
					case 821 : efName = "Wm_ob_itemappear_r_ss"; break;
					case 822 : efName = "Wm_ob_itemappear_gl_ss"; break;
					case 823 : efName = "Wm_ob_startail_star"; break;
					case 824 : efName = "Wm_ob_startail_kira"; break;
					case 825 : efName = "Wm_ob_powdown_ind_a"; break;
					case 826 : efName = "Wm_ob_powdown_ind_c"; break;
					case 827 : efName = "Wm_ob_powdown_ind_b"; break;
					case 828 : efName = "Wm_en_spindamage_rg"; break;
					case 829 : efName = "Wm_en_spindamage_star"; break;
					case 830 : efName = "Wm_en_spindamage_big_rg"; break;
					case 831 : efName = "Wm_en_spindamage_big_st"; break;
					case 832 : efName = "Wm_en_sanbohit_hit"; break;
					case 833 : efName = "Wm_en_sanbohit_ring"; break;
					case 834 : efName = "Wm_en_sanbohit_smk"; break;
					case 835 : efName = "Wm_en_keronpafire_ca"; break;
					case 836 : efName = "Wm_en_keronpafire_f"; break;
					case 837 : efName = "Wm_en_explosion_ln"; break;
					case 838 : efName = "Wm_en_explosion_gl01"; break;
					case 839 : efName = "Wm_en_explosion_hd"; break;
					case 840 : efName = "Wm_en_explosion_un"; break;
					case 841 : efName = "Wm_en_explosion_gl02"; break;
					case 842 : efName = "Wm_en_explosion_smk"; break;
					case 843 : efName = "Wm_en_bomignition_ln"; break;
					case 844 : efName = "Wm_en_bomignition_gl01"; break;
					case 845 : efName = "Wm_en_bomignition_pati"; break;
					case 846 : efName = "Wm_mr_sanddive_sd"; break;
					case 847 : efName = "Wm_mr_sanddive_in"; break;
					case 848 : efName = "Wm_mr_sanddive_out"; break;
					case 849 : efName = "Wm_mr_sanddive_smk"; break;
					case 850 : efName = "Wm_mr_sanddive_sd_m"; break;
					case 851 : efName = "Wm_mr_sanddive_in_m"; break;
					case 852 : efName = "Wm_mr_sanddive_out_m"; break;
					case 853 : efName = "Wm_mr_sanddive_smk_m"; break;
					case 854 : efName = "Wm_mr_sanddive_sb_s"; break;
					case 855 : efName = "Wm_mr_sanddive_smk_s"; break;
					case 856 : efName = "Wm_en_kuribobigsplit_sk"; break;
					case 857 : efName = "Wm_en_kuribobigsplit_ht"; break;
					case 858 : efName = "Wm_en_kuribobigsplit_gr02"; break;
					case 859 : efName = "Wm_en_kuribobigsplit_gr01"; break;
					case 860 : efName = "Wm_en_kuribobigsplit_rg"; break;
					case 861 : efName = "Wm_en_kuribosplit_sk"; break;
					case 862 : efName = "Wm_en_kuribosplit_gl01"; break;
					case 863 : efName = "Wm_en_kuribosplit_gl02"; break;
					case 864 : efName = "Wm_en_obakedoor_sm"; break;
					case 865 : efName = "Wm_en_obakedoor_ic"; break;
					case 866 : efName = "Wm_mr_yoshistep_b"; break;
					case 867 : efName = "Wm_mr_yoshistep_a"; break;
					case 868 : efName = "Wm_mr_yoshistep_a_cld"; break;
					case 869 : efName = "Wm_mr_fruitget_w"; break;
					case 870 : efName = "Wm_mr_fruitget_h"; break;
					case 871 : efName = "Wm_mr_yoshifire_a"; break;
					case 872 : efName = "Wm_mr_yoshifire_b"; break;
					case 873 : efName = "Wm_mr_yoshiiceball_b"; break;
					case 874 : efName = "Wm_mr_yoshiiceball_a"; break;
					case 875 : efName = "Wm_mr_yoshifirehit01"; break;
					case 876 : efName = "Wm_mr_yoshiicehit_b"; break;
					case 877 : efName = "Wm_mr_yoshiicehit_a"; break;
					case 878 : efName = "Wm_mr_ystonguehit_a"; break;
					case 879 : efName = "Wm_en_firebros_fire_a"; break;
					case 880 : efName = "Wm_en_firebros_fire_b"; break;
					case 881 : efName = "Wm_mr_magmawave_a"; break;
					case 882 : efName = "Wm_mr_magmawave_b"; break;
					case 883 : efName = "Wm_mr_poisonwave_a"; break;
					case 884 : efName = "Wm_mr_poisonwave_b"; break;
					case 885 : efName = "Wm_mr_waterwave_in_a"; break;
					case 886 : efName = "Wm_mr_waterwave_in_b"; break;
					case 887 : efName = "Wm_mr_waterwave_in_c"; break;
					case 888 : efName = "Wm_mr_waterwave_in_d"; break;
					case 889 : efName = "Wm_mr_waterwave_out_a"; break;
					case 890 : efName = "Wm_mr_waterwave_out_b"; break;
					case 891 : efName = "Wm_mr_waterwave_out_c"; break;
					case 892 : efName = "Wm_mr_waterwave_in_a_ss"; break;
					case 893 : efName = "Wm_mr_waterwave_in_b_ss"; break;
					case 894 : efName = "Wm_mr_waterwave_out_a_ss"; break;
					case 895 : efName = "Wm_mr_waterwave_out_b_ss"; break;
					case 896 : efName = "Wm_mr_wfloatsplash_a"; break;
					case 897 : efName = "Wm_mr_wfloatsplash_b"; break;
					case 898 : efName = "Wm_en_wfsplash_in01_r"; break;
					case 899 : efName = "Wm_en_wfsplash_in02_r"; break;
					case 900 : efName = "Wm_en_wfsplash_in01_l"; break;
					case 901 : efName = "Wm_en_wfsplash_in02_l"; break;
					case 902 : efName = "Wm_en_wfsplash_out01_r"; break;
					case 903 : efName = "Wm_en_wfsplash_out02_r"; break;
					case 904 : efName = "Wm_en_wfsplash_out01_l"; break;
					case 905 : efName = "Wm_en_wfsplash_out02_l"; break;
					case 906 : efName = "Wm_mr_balloonburst_w"; break;
					case 907 : efName = "Wm_mr_balloonburst_h"; break;
					case 908 : efName = "Wm_en_kingkiller_gr"; break;
					case 909 : efName = "Wm_en_kingkiller_rg"; break;
					case 910 : efName = "Wm_en_kingkiller_sm"; break;
					case 911 : efName = "Wm_ob_fireworks_y01"; break;
					case 912 : efName = "Wm_ob_fireworks_ycld"; break;
					case 913 : efName = "Wm_ob_fireworks_b01"; break;
					case 914 : efName = "Wm_ob_fireworks_bcld"; break;
					case 915 : efName = "Wm_ob_fireworks_g01"; break;
					case 916 : efName = "Wm_ob_fireworks_gcld"; break;
					case 917 : efName = "Wm_ob_fireworks_p01"; break;
					case 918 : efName = "Wm_ob_fireworks_pcld"; break;
					case 919 : efName = "Wm_ob_fireworks_k02"; break;
					case 920 : efName = "Wm_ob_fireworks_kgl01"; break;
					case 921 : efName = "Wm_ob_fireworks_kgl02"; break;
					case 922 : efName = "Wm_ob_fireworks_k01"; break;
					case 923 : efName = "Wm_ob_fireworks_kcld1"; break;
					case 924 : efName = "Wm_ob_fireworks_kcld2"; break;
					case 925 : efName = "Wm_ob_fireworks_1up02"; break;
					case 926 : efName = "Wm_ob_fireworks_1upgl01"; break;
					case 927 : efName = "Wm_ob_fireworks_1upgl02"; break;
					case 928 : efName = "Wm_ob_fireworks_1up01"; break;
					case 929 : efName = "Wm_ob_fireworks_1upcld1"; break;
					case 930 : efName = "Wm_ob_fireworks_1upcld2"; break;
					case 931 : efName = "Wm_ob_fireworks_star02"; break;
					case 932 : efName = "Wm_ob_fireworks_stargl01"; break;
					case 933 : efName = "Wm_ob_fireworks_stargl02"; break;
					case 934 : efName = "Wm_ob_fireworks_star01"; break;
					case 935 : efName = "Wm_ob_fireworks_starcld1"; break;
					case 936 : efName = "Wm_ob_fireworks_starcld2"; break;
					case 937 : efName = "Wm_ob_switch01"; break;
					case 938 : efName = "Wm_ob_redcioinkira_cd"; break;
					case 939 : efName = "Wm_ob_redcioinitem_cd"; break;
					case 940 : efName = "Wm_ob_redcioinitem02_b"; break;
					case 941 : efName = "Wm_ob_redcioinitem02_a"; break;
					case 942 : efName = "Wm_ob_itemfall_a"; break;
					case 943 : efName = "Wm_ob_itemfall_b"; break;
					case 944 : efName = "Wm_ob_redringget_a"; break;
					case 945 : efName = "Wm_ob_redringget_b"; break;
					case 946 : efName = "Wm_ob_redringget_c"; break;
					case 947 : efName = "Wm_bs_kameckmagic_f"; break;
					case 948 : efName = "Wm_bs_kameckmagic_e"; break;
					case 949 : efName = "Wm_bs_kameckmagic_a"; break;
					case 950 : efName = "Wm_bs_kameckmagic_c"; break;
					case 951 : efName = "Wm_bs_kameckmagic_d"; break;
					case 952 : efName = "Wm_bs_kameckmagic_b"; break;
					case 953 : efName = "Wm_ob_keywait_a"; break;
					case 954 : efName = "Wm_ob_keywait_b"; break;
					case 955 : efName = "Wm_ob_keywait_c"; break;
					case 956 : efName = "Wm_ob_keyget01_d"; break;
					case 957 : efName = "Wm_ob_keyget01_a"; break;
					case 958 : efName = "Wm_ob_keyget01_b"; break;
					case 959 : efName = "Wm_ob_keyget01_c"; break;
					case 960 : efName = "Wm_ob_keyget02_ring02"; break;
					case 961 : efName = "Wm_ob_keyget02_kira"; break;
					case 962 : efName = "Wm_ob_keyget02_gl02"; break;
					case 963 : efName = "Wm_ob_keyget02_str"; break;
					case 964 : efName = "Wm_ob_keyget02_gl01"; break;
					case 965 : efName = "Wm_ob_keyget02_hit"; break;
					case 966 : efName = "Wm_ob_keyget02_ring01"; break;
					case 967 : efName = "Wm_ob_keyget02_lighit"; break;
					case 968 : efName = "Wm_shellopen_a"; break;
					case 969 : efName = "Wm_shellopen_b"; break;
					case 970 : efName = "Wm_2d_courseclear_da"; break;
					case 971 : efName = "Wm_2d_courseclear_kiraL"; break;
					case 972 : efName = "Wm_2d_courseclear_kiraR"; break;
					case 973 : efName = "Wm_2d_courseclear_smkL"; break;
					case 974 : efName = "Wm_2d_courseclear_smkR"; break;
					case 975 : efName = "Wm_2d_courseclear_cld"; break;
					case 976 : efName = "Wm_2d_courseclear_cld"; break;
					case 977 : efName = "Wm_2d_courseclearsmcld01"; break;
					case 978 : efName = "Wm_2d_courseclearsmcld02"; break;
					case 979 : efName = "Wm_2d_timeupsmoke"; break;
					case 980 : efName = "Wm_2d_timeupstar"; break;
					case 981 : efName = "Wm_2d_timeupstarcld"; break;
					case 982 : efName = "Wm_2d_gameover_a"; break;
					case 983 : efName = "Wm_2d_gameover_b"; break;
					case 984 : efName = "Wm_2d_coin100a"; break;
					case 985 : efName = "Wm_2d_coinlight"; break;
					case 986 : efName = "Wm_2d_stockitem_a"; break;
					case 987 : efName = "Wm_2d_stockitem_b"; break;
					case 988 : efName = "Wm_mr_stockitemuse_a"; break;
					case 989 : efName = "Wm_mr_stockitemuse_b"; break;
					case 990 : efName = "Wm_mr_stockitemuse_c"; break;
					case 991 : efName = "Wm_2d_movieopen_a"; break;
					case 992 : efName = "Wm_2d_movieopen_b2"; break;
					case 993 : efName = "Wm_2d_movieopen_b1"; break;
					case 994 : efName = "Wm_2d_result_a2"; break;
					case 995 : efName = "Wm_2d_result_b2"; break;
					case 996 : efName = "Wm_2d_result_a1"; break;
					case 997 : efName = "Wm_2d_result_b1"; break;
					case 998 : efName = "Wm_bg_volcano_a"; break;
					case 999 : efName = "Wm_bg_volcano_b"; break;
					case 1000: efName = "Wm_ob_treasureboxwait_a"; break;
					case 1001: efName = "Wm_ob_treasureboxwait_b"; break;
					case 1002: efName = "Wm_jr_electricstart"; break;
					case 1003: efName = "Wm_jr_electricglow"; break;
					case 1004: efName = "Wm_jr_electricspark"; break;
					case 1005: efName = "Wm_jr_electricline"; break;
				}

				if (efName != 0)
					SpawnEffect(efName, 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){this->scale, this->scale, this->scale});
			}
	
			this->timer = 0;
			if (this->delay == 0) { this->delay = -1; }
		}
		
		this->timer += 1;
	}
	return true;
}


//
// processed\../src/fakeStarCoin.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include <profile.h>


extern "C" bool SpawnEffect(const char*, int, Vec*, S16Vec*, Vec*);

const char* FakeStarCoinFileList [] = {
	"star_coin",
	NULL
};

class daFakeStarCoin : public dEn_c {
	int onCreate();
	int onExecute();
	int onDelete();
	int onDraw();

	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;

	u64 eventFlag;
	s32 timer;
	u32 delay;

	u32 effect;
	u8 type;

	public: static dActor_c *build();

	void updateModelMatrices();
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);

};

const SpriteData fakeStarCoinSpriteData = { ProfileId::EN_FAKE_STARCOIN, 0x80, 0 , 0x80, 0x80, 0x80, 0x80, 0, 0, 0x60, 0x50, 8};
Profile fakeStarCoinProfile(&daFakeStarCoin::build, SpriteId::EN_FAKE_STARCOIN, &fakeStarCoinSpriteData, ProfileId::AC_LIFT_SEESAW, ProfileId::EN_FAKE_STARCOIN, "EN_FAKE_STARCOIN", FakeStarCoinFileList, 0x22);

void daFakeStarCoin::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) { 

	PlaySound(this, SE_EMY_CS_TERESA_BEAT_YOU);
	SpawnEffect("Wm_en_obakedoor", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
	
	//FIXME changed to dStageActor_c::Delete(u8) from fBase_c::Delete(void)
	this->Delete(1);
}

bool daFakeStarCoin::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
	return collisionCat9_RollingObject(apThis, apOther);
}
bool daFakeStarCoin::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) {
	return collisionCat9_RollingObject(apThis, apOther);
}
bool daFakeStarCoin::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) {
	return collisionCat9_RollingObject(apThis, apOther);
}
bool daFakeStarCoin::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther) {
	return collisionCat9_RollingObject(apThis, apOther);
}

bool daFakeStarCoin::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) { 
	SpawnEffect("Wm_en_explosion", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
	SpawnEffect("Wm_en_explosion_smk", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){3.0, 3.0, 3.0});

	PlaySound(this, SE_OBJ_EMY_FIRE_DISAPP);
	this->Delete(1);

	return true;
}
bool daFakeStarCoin::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) { 
	SpawnEffect("Wm_ob_cmnicekira", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
	SpawnEffect("Wm_ob_icebreakwt", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
	SpawnEffect("Wm_ob_iceattack", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});

	PlaySound(this, SE_OBJ_PNGN_ICE_BREAK);

	this->Delete(1);
	return true; 
}
bool daFakeStarCoin::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
	SpawnEffect("Wm_ob_cmnboxgrain", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
	SpawnEffect("Wm_en_obakedoor_sm", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});

	PlaySound(this, SE_BOSS_JR_FLOOR_BREAK);

	//FIXME changed to dStageActor_c::Delete(u8) from fBase_c::Delete(void)
	this->Delete(1);
	return true;
}
bool daFakeStarCoin::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
	return collisionCat9_RollingObject(apThis, apOther);
}
bool daFakeStarCoin::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther) {
	return collisionCat1_Fireball_E_Explosion(apThis, apOther);
}

bool daFakeStarCoin::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther) {
	return collisionCat9_RollingObject(apThis, apOther);
}



dActor_c *daFakeStarCoin::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daFakeStarCoin));
	return new(buffer) daFakeStarCoin;
}


int daFakeStarCoin::onCreate() {
	
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	nw4r::g3d::ResFile rf(getResource("star_coin", "g3d/star_coin.brres"));
	bodyModel.setup(rf.GetResMdl("star_coinA"), &allocator, 0x224, 1, 0);
	SetupTextures_MapObj(&bodyModel, 0);

	allocator.unlink();
	
	ActivePhysics::Info HitMeBaby;
	HitMeBaby.xDistToCenter = 0.0;
	HitMeBaby.yDistToCenter = -3.0;
	HitMeBaby.xDistToEdge = 12.0;
	HitMeBaby.yDistToEdge = 15.0;
	HitMeBaby.category1 = 0x5;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x4F;
	HitMeBaby.bitfield2 = 0xFFFFFFFF;
	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();

	this->scale.x = 1.0;
	this->scale.y = 1.0;
	this->scale.z = 1.0;

	this->pos.x -= 120.0;
	this->pos.z = 3300.0;
	
	this->onExecute();
	return true;
}


int daFakeStarCoin::onDelete() {
	return true;
}

int daFakeStarCoin::onDraw() {
	bodyModel.scheduleForDrawing();
	return true;
}


void daFakeStarCoin::updateModelMatrices() {
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}

int daFakeStarCoin::onExecute() {
	updateModelMatrices();

	this->rot.x += 0x200;
	return true;
}

//
// processed\../src/shyguy.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include <profile.h>


const char* SGarcNameList [] = {
	"shyguy",
	"iron_ball",
	NULL
};

// Shy Guy Settings
//
// Nybble 5: Shy Guy Types
//		0 - Walker
//		1 - Pacing Walker
//		2 - Sleeper
//		3 - Jumper
// 		4 - Judo Master
// 		5 - Spike Thrower
// 		6 - Ballooneer Horizontal
// 		7 - Ballooneer Vertical
// 		8 - Ballooneer Circular
//		9 - Walking Giant
// 		10 - Pacing Giant
//
// Nybble 9: Distance Moved
//		# - Distance for Pacing Walker, Pacing Giants, and Ballooneers
//
// If I add items in the balloons....
// I_kinoko, I_fireflower, I_propeller_model, I_iceflower, I_star, I_penguin - model names
// anmChr - wait2

void shyCollisionCallback(ActivePhysics *apThis, ActivePhysics *apOther);
void ChucklesAndKnuckles(ActivePhysics *apThis, ActivePhysics *apOther);
void balloonSmack(ActivePhysics *apThis, ActivePhysics *apOther);

class daShyGuy : public dEn_c {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;
	nw4r::g3d::ResFile anmFile;
	nw4r::g3d::ResFile balloonFile;
	// nw4r::g3d::ResFile carryFile;

	m3d::mdl_c bodyModel;
	m3d::mdl_c balloonModel;
	m3d::mdl_c balloonModelB;
	// m3d::mdl_c carryModel;1

	m3d::anmChr_c chrAnimation;
	// m3d::anmChr_c carryAnm;

	mEf::es2 effect;

	int timer;
	int jumpCounter;
	int baln;
	float dying;
	float Baseline;
	char damage;
	char isDown;
	char renderBalloon;
	Vec initialPos;
	int distance;
	float XSpeed;
	u32 cmgr_returnValue;
	bool isBouncing;
	float balloonSize;
	char backFire;
	char spikeTurn;
	int directionStore;
	dStageActor_c *spikeA;
	dStageActor_c *spikeB;
	bool stillFalling;

	StandOnTopCollider giantRider;
	ActivePhysics Chuckles;
	ActivePhysics Knuckles;
	ActivePhysics balloonPhysics;

	public: static dActor_c *build();

	void bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate);
	void updateModelMatrices();
	bool calculateTileCollisions();

	void spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	// bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat5_Mario(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat11_PipeCannon(ActivePhysics *apThis, ActivePhysics *apOther);

	void _vf148();
	void _vf14C();
	bool CreateIceActors();

	bool willWalkOntoSuitableGround();

	USING_STATES(daShyGuy);
	DECLARE_STATE(Walk);
	DECLARE_STATE(Turn);
	DECLARE_STATE(RealWalk);
	DECLARE_STATE(RealTurn);
	DECLARE_STATE(Jump);
	DECLARE_STATE(Sleep);
	DECLARE_STATE(Balloon_H);
	DECLARE_STATE(Balloon_V);
	DECLARE_STATE(Balloon_C);
	DECLARE_STATE(Judo);
	DECLARE_STATE(Spike);

	DECLARE_STATE(GoDizzy);
	DECLARE_STATE(BalloonDrop);
	DECLARE_STATE(FireKnockBack);
	DECLARE_STATE(FlameHit);
	DECLARE_STATE(Recover);

	DECLARE_STATE(Die);

	public: void popBalloon();
	int type;
};

const SpriteData ShyGuySpriteData = {ProfileId::EN_SHYGUY, 0x10, -48, 0, 0xFFFFFFC0, 0x10, 0x40, 0x40, 0x40, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile ShyGuyProfile(&daShyGuy::build, SpriteId::EN_SHYGUY, &ShyGuySpriteData, ProfileId::DUMMY_DOOR_CHILD, ProfileId::EN_SHYGUY, "EN_SHYGUY", SGarcNameList, 0x12);

dActor_c *daShyGuy::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daShyGuy));
	return new(buffer) daShyGuy;
}

///////////////////////
// Externs and States
///////////////////////
	extern "C" bool SpawnEffect(const char*, int, Vec*, S16Vec*, Vec*);

	//FIXME make this dEn_c->used...
	extern "C" char usedForDeterminingStatePress_or_playerCollision(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther, int unk1);
	extern "C" int SomeStrangeModification(dStageActor_c* actor);
	extern "C" void DoStuffAndMarkDead(dStageActor_c *actor, Vec vector, float unk);
	extern "C" int SmoothRotation(short* rot, u16 amt, int unk2);
	// extern "C" void addToList(StandOnTopCollider *self);

	extern "C" bool HandlesEdgeTurns(dEn_c* actor);


	CREATE_STATE(daShyGuy, Walk);
	CREATE_STATE(daShyGuy, Turn);
	CREATE_STATE(daShyGuy, RealWalk);
	CREATE_STATE(daShyGuy, RealTurn);
	CREATE_STATE(daShyGuy, Jump);
	CREATE_STATE(daShyGuy, Sleep);
	CREATE_STATE(daShyGuy, Balloon_H);
	CREATE_STATE(daShyGuy, Balloon_V);
	CREATE_STATE(daShyGuy, Balloon_C);
	CREATE_STATE(daShyGuy, Judo);
	CREATE_STATE(daShyGuy, Spike);

	CREATE_STATE(daShyGuy, GoDizzy);
	CREATE_STATE(daShyGuy, BalloonDrop);
	CREATE_STATE(daShyGuy, FireKnockBack);
	CREATE_STATE(daShyGuy, FlameHit);
	CREATE_STATE(daShyGuy, Recover);

	CREATE_STATE(daShyGuy, Die);

////////////////////////
// Collision Functions
////////////////////////

	bool actorCanPopBalloon(dStageActor_c *ac) {
		int n = ac->profileId;
		return n == ProfileId::PLAYER || n == ProfileId::YOSHI ||
			n == ProfileId::PL_FIREBALL || n == ProfileId::ICEBALL ||
			n == ProfileId::YOSHI_FIRE || n == ProfileId::HAMMER;
	}
	// Collision callback to help shy guy not die at inappropriate times and ruin the dinner

	void shyCollisionCallback(ActivePhysics *apThis, ActivePhysics *apOther) {
		int t = ((daShyGuy*)apThis->owner)->type;
		if (t == 6 || t == 7 || t == 8) {
			// Should I do something about ice blocks here?
			if (actorCanPopBalloon(apOther->owner))
				((daShyGuy*)apThis->owner)->popBalloon();
		}

		if ((apOther->owner->profileId == ProfileId::EN_TOGETEKKYU) && (t == 5)) { return; }

		dEn_c::collisionCallback(apThis, apOther);
	}

	void ChucklesAndKnuckles(ActivePhysics *apThis, ActivePhysics *apOther) {
		if (apOther->owner->profileId != ProfileId::PLAYER) { return; }
		((dEn_c*)apThis->owner)->_vf220(apOther->owner);
	}

	void balloonSmack(ActivePhysics *apThis, ActivePhysics *apOther) {
		if (((daShyGuy*)apThis->owner)->frzMgr._mstate == 0) {
			if (actorCanPopBalloon(apOther->owner))
				((daShyGuy*)apThis->owner)->popBalloon();
		}
	}

	void daShyGuy::spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
		u16 profileId = ((dEn_c*)apOther->owner)->profileId;

		if (profileId == ProfileId::EN_COIN || profileId == ProfileId::EN_EATCOIN || profileId == ProfileId::AC_BLOCK_COIN || profileId == ProfileId::EN_COIN_JUGEM || profileId == ProfileId::EN_COIN_ANGLE
			|| profileId == ProfileId::EN_COIN_JUMP || profileId == ProfileId::EN_COIN_FLOOR || profileId == ProfileId::EN_COIN_VOLT || profileId == ProfileId::EN_COIN_WIND
			|| profileId == ProfileId::EN_BLUE_COIN || profileId == ProfileId::EN_COIN_WATER || profileId == ProfileId::EN_REDCOIN || profileId == ProfileId::EN_GREENCOIN
			|| profileId == ProfileId::EN_JUMPDAI || profileId == ProfileId::EN_ITEM)
			{ return; }

		if (acState.getCurrentState() == &StateID_RealWalk) {

			pos.x = ((pos.x - ((dEn_c*)apOther->owner)->pos.x) > 0) ? pos.x + 1.5 : pos.x - 1.5;
			// pos.x = direction ? pos.x + 1.5 : pos.x - 1.5;
			doStateChange(&StateID_RealTurn); }

		if (acState.getCurrentState() == &StateID_FireKnockBack) {
			float distance = pos.x - ((dEn_c*)apOther->owner)->pos.x;
			pos.x = pos.x + (distance / 4.0);
		}

		dEn_c::spriteCollision(apThis, apOther);
	}

	void daShyGuy::popBalloon() {
		doStateChange(&StateID_BalloonDrop);
	}

	void daShyGuy::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
		dStateBase_c *stateVar;
		dStateBase_c *deathState;

		char hitType;
		if (this->type < 6) {  // Regular Shy Guys
			stateVar = &StateID_GoDizzy;
			deathState = &StateID_Die;
		}
		else { // Ballooneers
			stateVar = &StateID_BalloonDrop;
			deathState = &StateID_Die;
		}


		if (this->isDown == 0) {
			hitType = usedForDeterminingStatePress_or_playerCollision(this, apThis, apOther, 2);
		}
		else { // Shy Guy is in downed mode
			hitType = usedForDeterminingStatePress_or_playerCollision(this, apThis, apOther, 0);
		}

		if(hitType == 1) {	// regular jump
			apOther->someFlagByte |= 2;
			if (this->isDown == 0) {
				this->playEnemyDownSound1();
				if (damage >= 1) {
					doStateChange(deathState); }
				else {
					doStateChange(stateVar); }
				damage++;
			}
			else { // Shy Guy is in downed mode - kill it with fire
				this->playEnemyDownSound1();
				doStateChange(deathState);
			}
		}
		else if(hitType == 3) {	// spinning jump or whatever?
			apOther->someFlagByte |= 2;
			if (this->isDown == 0) {
				this->playEnemyDownSound1();
				if (damage >= 1) {
					doStateChange(deathState); }
				else {
					doStateChange(stateVar); }
				damage++;
			}
			else { // Shy Guy is in downed mode - kill it with fire
				this->playEnemyDownSound1();
				doStateChange(deathState);
			}
		}
		else if(hitType == 0) {
			this->dEn_c::playerCollision(apThis, apOther);
			this->_vf220(apOther->owner);
		}
		// else if(hitType == 2) { \\ Minimario? }
	}

	void daShyGuy::yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
		this->playerCollision(apThis, apOther);
	}
	bool daShyGuy::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) {
		PlaySound(this, SE_EMY_DOWN);
		SpawnEffect("Wm_mr_hardhit", 0, &pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		//addScoreWhenHit accepts a player parameter.
		//DON'T DO THIS:
		// this->addScoreWhenHit(this);
		doStateChange(&StateID_Die);
		return true;
	}
	bool daShyGuy::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
		return this->collisionCatD_Drill(apThis, apOther);
	}
	bool daShyGuy::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) {
		return this->collisionCatD_Drill(apThis, apOther);
	}
	bool daShyGuy::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
		return this->collisionCatD_Drill(apThis, apOther);
	}
	bool daShyGuy::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther){
		return this->collisionCatD_Drill(apThis, apOther);
	}
	bool daShyGuy::collisionCat5_Mario(ActivePhysics *apThis, ActivePhysics *apOther){
		return this->collisionCatD_Drill(apThis, apOther);
	}
	bool daShyGuy::collisionCat11_PipeCannon(ActivePhysics *apThis, ActivePhysics *apOther){
		return this->collisionCatD_Drill(apThis, apOther);
	}
	bool daShyGuy::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
		StageE4::instance->spawnCoinJump(pos, 0, 2, 0);
		return this->collisionCatD_Drill(apThis, apOther);
	}

	bool daShyGuy::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther){
		bool wut = dEn_c::collisionCat3_StarPower(apThis, apOther);
		doStateChange(&StateID_Die);
		return wut;
	}

	bool daShyGuy::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther){
		doStateChange(&StateID_DieSmoke);
		return true;
	}
	bool daShyGuy::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
		this->damage += 1;

		dStateBase_c *stateVar;
		stateVar = &StateID_DieSmoke;

		if (this->type < 6) {  // Regular Shy Guys Except Jumper

			backFire = apOther->owner->direction ^ 1;

			// if (this->isDown == 0) {
			// 	stateVar = &StateID_FireKnockBack;
			// }
			// else {
				StageE4::instance->spawnCoinJump(pos, 0, 1, 0);
				doStateChange(&StateID_DieSmoke);
			// }
		}
		else { // Ballooneers
			stateVar = &StateID_FlameHit;
		}

		if (this->damage > 1) {
			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_EMY_DOWN, 1);
			StageE4::instance->spawnCoinJump(pos, 0, 1, 0);
			doStateChange(&StateID_DieSmoke);
		}
		else {
			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_EMY_KURIBO_L_DAMAGE_01, 1);
			doStateChange(stateVar);
		}
		return true;
	}

	// void daShyGuy::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) {

	// 	dEn_C::collisionCat2_IceBall_15_YoshiIce(apThis, apOther);
	// }

	// These handle the ice crap
	void daShyGuy::_vf148() {
		dEn_c::_vf148();
		doStateChange(&StateID_Die);
	}
	void daShyGuy::_vf14C() {
		dEn_c::_vf14C();
		doStateChange(&StateID_Die);
	}

	extern "C" void sub_80024C20(void);
	extern "C" void __destroy_arr(void*, void(*)(void), int, int);
	//extern "C" __destroy_arr(struct DoSomethingCool, void(*)(void), int cnt, int bar);

	bool daShyGuy::CreateIceActors() {
		struct DoSomethingCool my_struct = { 0, this->pos, {1.2, 1.5, 1.5}, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
	    this->frzMgr.Create_ICEACTORs( (void*)&my_struct, 1 );
	    __destroy_arr( (void*)&my_struct, sub_80024C20, 0x3C, 1 );
	    chrAnimation.setUpdateRate(0.0f);
	    return true;
	}

bool daShyGuy::calculateTileCollisions() {
	// Returns true if sprite should turn, false if not.

	HandleXSpeed();
	HandleYSpeed();
	doSpriteMovement();

	cmgr_returnValue = collMgr.isOnTopOfTile();
	collMgr.calculateBelowCollisionWithSmokeEffect();

	if (isBouncing) {
		stuffRelatingToCollisions(0.1875f, 1.0f, 0.5f);
		if (speed.y != 0.0f)
			isBouncing = false;
	}

	float xDelta = pos.x - last_pos.x;
	if (xDelta >= 0.0f)
		direction = 0;
	else
		direction = 1;

	if (collMgr.isOnTopOfTile()) {
		// Walking into a tile branch

		if (cmgr_returnValue == 0)
			isBouncing = true;

		if (speed.x != 0.0f) {
			//playWmEnIronEffect();
		}

		speed.y = 0.0f;

		// u32 blah = collMgr.s_80070760();
		// u8 one = (blah & 0xFF);
		// static const float incs[5] = {0.00390625f, 0.0078125f, 0.015625f, 0.0234375f, 0.03125f};
		// x_speed_inc = incs[one];
		max_speed.x = (direction == 1) ? -XSpeed : XSpeed;
	} else {
		x_speed_inc = 0.0f;
	}

	// Bouncing checks
	if (_34A & 4) {
		Vec v = (Vec){0.0f, 1.0f, 0.0f};
		collMgr.pSpeed = &v;

		if (collMgr.calculateAboveCollision(collMgr.outputMaybe))
			speed.y = 0.0f;

		collMgr.pSpeed = &speed;

	} else {
		if (collMgr.calculateAboveCollision(collMgr.outputMaybe))
			speed.y = 0.0f;
	}

	collMgr.calculateAdjacentCollision(0);

	// Switch Direction
	if (collMgr.outputMaybe & (0x15 << direction)) {
		if (collMgr.isOnTopOfTile()) {
			isBouncing = true;
		}
		return true;
	}
	return false;
}

void daShyGuy::bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate) {
	nw4r::g3d::ResAnmChr anmChr = this->anmFile.GetResAnmChr(name);
	this->chrAnimation.bind(&this->bodyModel, anmChr, unk);
	this->bodyModel.bindAnim(&this->chrAnimation, unk2);
	this->chrAnimation.setUpdateRate(rate);
}

int daShyGuy::onCreate() {

	this->type = this->settings >> 28 & 0xF;
	int baln = this->settings >> 24 & 0xF;
	this->distance = this->settings >> 12 & 0xF;

	stillFalling = 0;

	allocator.link(-1, GameHeaps[0], 0, 0x20);

	this->deleteForever = 1;

	// Balloon Specifics
	if (type == 6 || type == 7 || type == 8) {
		this->renderBalloon = 1;

		this->balloonFile.data = getResource("shyguy", "g3d/balloon.brres");
		nw4r::g3d::ResMdl mdlB = this->balloonFile.GetResMdl("ballon");
		balloonModel.setup(mdlB, &allocator, 0x224, 1, 0);
		balloonModelB.setup(mdlB, &allocator, 0x224, 1, 0);

		ActivePhysics::Info iballoonPhysics;

		iballoonPhysics.xDistToCenter = 0.0;
		iballoonPhysics.yDistToCenter = -18.0;
		iballoonPhysics.xDistToEdge   = 13.0;
		iballoonPhysics.yDistToEdge   = 12.0;

		iballoonPhysics.category1  = 0x3;
		iballoonPhysics.category2  = 0x0;
		iballoonPhysics.bitfield1  = 0x4f;
		iballoonPhysics.bitfield2  = 0xffbafffe;
		iballoonPhysics.unkShort1C = 0x0;
		iballoonPhysics.callback   = balloonSmack;

		balloonPhysics.initWithStruct(this, &iballoonPhysics);
		balloonPhysics.addToList();


		// if (baln != 0) {
		// 	char *itemArc;
		// 	char *itemBrres;
		// 	char *itemMdl;

		// 	if (baln == 1) {
		// 		itemArc		= "I_kinoko";
		// 		itemBrres	= "g3d/I_kinoko.brres";
		// 		itemMdl		= "I_kinoko";
		// 	}
		// 	else if (baln == 2) {
		// 		itemArc		= "I_fireflower";
		// 		itemBrres	= "g3d/I_fireflower.brres";
		// 		itemMdl		= "I_fireflower";
		// 	}
		// 	else if (baln == 3) {
		// 		itemArc		= "I_propeller";
		// 		itemBrres	= "g3d/I_propeller.brres";
		// 		itemMdl		= "I_propeller_model";
		// 	}
		// 	else if (baln == 4) {
		// 		itemArc		= "I_iceflower";
		// 		itemBrres	= "g3d/I_iceflower.brres";
		// 		itemMdl		= "I_iceflower";
		// 	}
		// 	else if (baln == 5) {
		// 		itemArc		= "I_star";
		// 		itemBrres	= "g3d/I_star.brres";
		// 		itemMdl		= "I_star";
		// 	}
		// 	else if (baln == 6) {
		// 		itemArc		= "I_penguin";
		// 		itemBrres	= "g3d/I_penguin.brres";
		// 		itemMdl		= "I_penguin";
		// 	}

		// 	this->carryFile.data = getResource(itemArc, itemBrres);
		// 	nw4r::g3d::ResMdl mdlC = this->carryFile.GetResMdl(itemMdl);
		// 	carryModel.setup(mdlC, &allocator, 0x224, 1, 0);

		// 	nw4r::g3d::ResAnmChr anmChrC = this->carryFile.GetResAnmChr("wait2");
		// 	this->carryAnm.setup(mdlC, anmChrC, &this->allocator, 0);

		// 	this->carryAnm.bind(&this->carryModel, anmChrC, 1);
		// 	this->carryModel.bindAnim(&this->carryAnm, 0.0);
		// 	this->carryAnm.setUpdateRate(1.0);
		// }
	}
	else {this->renderBalloon = 0;}


	// Shy Guy Colours
	if (type == 1 || type == 8 || type == 10) {
		this->resFile.data = getResource("shyguy", "g3d/ShyGuyBlue.brres");
		distance = 1;
	}
	else if (type == 5) {
		this->resFile.data = getResource("shyguy", "g3d/ShyGuyGreen.brres");
	}
	else if (type == 3) {
		this->resFile.data = getResource("shyguy", "g3d/ShyGuyCyan.brres");
	}
	else if (type == 4) {
		this->resFile.data = getResource("shyguy", "g3d/ShyGuyPurple.brres");
	}
	else {
		this->resFile.data = getResource("shyguy", "g3d/ShyGuyRed.brres");
	}
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("body_h");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&this->bodyModel, 0);

	// Animations start here
	this->anmFile.data = getResource("shyguy", "g3d/ShyGuyAnimations.brres");
	nw4r::g3d::ResAnmChr anmChr = this->anmFile.GetResAnmChr("c18_IDLE_R");
	this->chrAnimation.setup(mdl, anmChr, &this->allocator, 0);

	allocator.unlink();

	// Stuff I do understand

	this->scale = (Vec){20.0, 20.0, 20.0};

	this->pos.y += 36.0;
	this->rot.x = 0; // X is vertical axis
	this->rot.y = 0xD800; // Y is horizontal axis
	this->rot.z = 0; // Z is ... an axis >.>
	this->direction = 1; // Heading left.

	this->speed.x = 0.0;
	this->speed.y = 0.0;
	this->max_speed.x = 0.6;
	this->x_speed_inc = 0.15;
	this->Baseline = this->pos.y;
	this->XSpeed = 0.6;
	this->balloonSize = 1.5;


	ActivePhysics::Info HitMeBaby;

	// Note: if this gets changed, also change the point where the default
	// values are assigned after de-ballooning
	HitMeBaby.xDistToCenter = 0.0;
	HitMeBaby.yDistToCenter = 12.0;
	HitMeBaby.xDistToEdge = 8.0;
	HitMeBaby.yDistToEdge = 12.0;
	if (renderBalloon) {
		HitMeBaby.yDistToCenter = 9.0f;
		HitMeBaby.yDistToEdge = 9.0f;
	}

	HitMeBaby.category1 = 0x3;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x6F;
	HitMeBaby.bitfield2 = 0xffbafffe;
	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &shyCollisionCallback;

	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();


	// Tile collider

	// These fucking rects do something for the tile rect
	spriteSomeRectX = 28.0f;
	spriteSomeRectY = 32.0f;
	_320 = 0.0f;
	_324 = 16.0f;

	// These structs tell stupid collider what to collide with - these are from koopa troopa
	static const lineSensor_s below(-5<<12, 5<<12, 0<<12);
	static const pointSensor_s above(0<<12, 12<<12);
	static const lineSensor_s adjacent(6<<12, 9<<12, 6<<12);

	collMgr.init(this, &below, &above, &adjacent);
	collMgr.calculateBelowCollisionWithSmokeEffect();

	cmgr_returnValue = collMgr.isOnTopOfTile();

	if (collMgr.isOnTopOfTile())
		isBouncing = false;
	else
		isBouncing = true;


	// State Changers

	if (type == 0) {
		bindAnimChr_and_setUpdateRate("c18_EV_WIN_2_R", 1, 0.0, 1.5);
		doStateChange(&StateID_RealWalk);
	}
	else if (type == 1) {
		bindAnimChr_and_setUpdateRate("c18_EV_WIN_2_R", 1, 0.0, 1.5);
		doStateChange(&StateID_RealWalk);
	}
	else if (type == 2) {
		doStateChange(&StateID_Sleep);
	}
	else if (type == 3) {
		doStateChange(&StateID_Jump);
	}
	else if (type == 4) {
		// Chuckles is left, Knuckles is Right
		ActivePhysics::Info iChuckles;
		ActivePhysics::Info iKnuckles;

		iChuckles.xDistToCenter = -27.0;
		iChuckles.yDistToCenter = 12.0;
		iChuckles.xDistToEdge   = 27.0;
		iChuckles.yDistToEdge   = 10.0;

		iKnuckles.xDistToCenter = 27.0;
		iKnuckles.yDistToCenter = 12.0;
		iKnuckles.xDistToEdge   = 27.0;
		iKnuckles.yDistToEdge   = 10.0;

		iKnuckles.category1  = iChuckles.category1  = 0x3;
		iKnuckles.category2  = iChuckles.category2  = 0x0;
		iKnuckles.bitfield1  = iChuckles.bitfield1  = 0x4F;
		iKnuckles.bitfield2  = iChuckles.bitfield2  = 0x0;
		iKnuckles.unkShort1C = iChuckles.unkShort1C = 0x0;
		iKnuckles.callback   = iChuckles.callback   = ChucklesAndKnuckles;

		Chuckles.initWithStruct(this, &iChuckles);
		Knuckles.initWithStruct(this, &iKnuckles);

		doStateChange(&StateID_Judo);
	}
	else if (type == 5) {
		doStateChange(&StateID_Spike);
	}
	else if (type == 6) {
		doStateChange(&StateID_Balloon_H);
	}
	else if (type == 7) {
		doStateChange(&StateID_Balloon_V);
	}
	else if (type == 8) {
		doStateChange(&StateID_Balloon_C);
	}

	this->onExecute();
	return true;
}

int daShyGuy::onDelete() {
	return true;
}

int daShyGuy::onExecute() {
	acState.execute();
	updateModelMatrices();
	bodyModel._vf1C();

	return true;
}

int daShyGuy::onDraw() {
	bodyModel.scheduleForDrawing();

	if (this->renderBalloon == 1) {
		balloonModel.scheduleForDrawing();
		balloonModelB.scheduleForDrawing();
	}

	// if (this->baln > 0) {
	// 	carryModel.scheduleForDrawing();
	// 	carryModel._vf1C();

	// 	if(this->carryAnm.isAnimationDone())
	// 		this->carryAnm.setCurrentFrame(0.0);
	// }

	return true;
}

void daShyGuy::updateModelMatrices() {
	// This won't work with wrap because I'm lazy.

	if (this->frzMgr._mstate == 1)
		matrix.translation(pos.x, pos.y, pos.z);
	else
		matrix.translation(pos.x, pos.y - 2.0, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);

	if (this->renderBalloon == 1) {
		matrix.translation(pos.x, pos.y - 32.0, pos.z);

		balloonModel.setDrawMatrix(matrix);
		balloonModel.setScale(balloonSize, balloonSize, balloonSize);
		balloonModel.calcWorld(false);

		balloonModelB.setDrawMatrix(matrix);
		balloonModelB.setScale(balloonSize, balloonSize, balloonSize);
		balloonModelB.calcWorld(false);
	}

	// if (this->baln > 0) {
	// 	matrix.applyRotationYXZ(0,0,0);
	// 	matrix.translation(pos.x+40.0, pos.y - 28.0, pos.z + 1000.0);

	// 	carryModel.setDrawMatrix(matrix);
	// 	carryModel.setScale(21.0, 21.0, 21.0);
	// 	carryModel.calcWorld(false);
	// }

}

///////////////
// Walk State
///////////////
	void daShyGuy::beginState_Walk() {
		this->timer = 0;
		this->rot.y = (direction) ? 0xD800 : 0x2800;

		this->max_speed.x = 0.0;
		this->speed.x = 0.0;
		this->x_speed_inc = 0.0;
	}
	void daShyGuy::executeState_Walk() {
		chrAnimation.setUpdateRate(1.5f);

		this->pos.x += (direction) ? -0.4 : 0.4;

		if (this->timer > (this->distance * 32)) {
			doStateChange(&StateID_Turn);
		}

		if(this->chrAnimation.isAnimationDone())
			this->chrAnimation.setCurrentFrame(0.0);

		this->timer = this->timer + 1;
	}
	void daShyGuy::endState_Walk() {
	}

///////////////
// Turn State
///////////////
	void daShyGuy::beginState_Turn() {
		// bindAnimChr_and_setUpdateRate("c18_IDLE_R", 1, 0.0, 1.0);
		this->direction ^= 1;
		this->speed.x = 0.0;
	}
	void daShyGuy::executeState_Turn() {

		if(this->chrAnimation.isAnimationDone())
			this->chrAnimation.setCurrentFrame(0.0);

		u16 amt = (this->direction == 0) ? 0x2800 : 0xD800;
		int done = SmoothRotation(&this->rot.y, amt, 0x800);

		if(done) {
			this->doStateChange(&StateID_Walk);
		}
	}
	void daShyGuy::endState_Turn() {
	}

///////////////
// Jump State
///////////////
	void daShyGuy::beginState_Jump() {
		this->max_speed.x = 0.0;
		this->speed.x = 0.0;
		this->x_speed_inc = 0.0;

		this->timer = 0;
		this->jumpCounter = 0;
	}
	void daShyGuy::executeState_Jump() {

		// Always face Mario
		u8 facing = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);

		if (facing != this->direction) {
			this->direction = facing;
			this->rot.y = (direction) ? 0xD800 : 0x2800;
		}

		// Shy Guy is on ground
		if (this->pos.y < this->Baseline) {

			bindAnimChr_and_setUpdateRate("c18_IDLE_R", 1, 0.0, 1.0);

			this->timer = this->timer + 1;

			// Make him wait for 0.5 seconds
			if (this->timer > 30) {

				if(this->chrAnimation.isAnimationDone())
					this->chrAnimation.setCurrentFrame(0.0);

				this->speed.x = 0;
				this->speed.y = 0;
			}

			// Then Jump!
			else {
				if (this->jumpCounter == 3) { this->jumpCounter = 0; }

				this->pos.y = this->Baseline + 1;
				this->timer = 0;
				this->jumpCounter = this->jumpCounter + 1;


				if (this->jumpCounter == 3) {
					bindAnimChr_and_setUpdateRate("c18_NORMAL_STEAL_R", 1, 0.0, 1.0);
					this->speed.y = 8.0;
					PlaySoundAsync(this, SE_PLY_JUMPDAI_HIGH);
				}
				else {
					bindAnimChr_and_setUpdateRate("c18_EV_WIN_1_R", 1, 0.0, 1.0);
					this->speed.y = 6.0;
					PlaySoundAsync(this, SE_PLY_JUMPDAI);
				}

			}
		}

		// While he's jumping, it's time for gravity.
		else {

			this->speed.y = this->speed.y - 0.15;

			if (this->jumpCounter == 3) {
				if(this->chrAnimation.isAnimationDone())
					this->chrAnimation.setCurrentFrame(0.0);
			}
			else {
				if(this->chrAnimation.isAnimationDone())
					this->chrAnimation.setCurrentFrame(0.0);
			}
		}

		this->HandleXSpeed();
		this->HandleYSpeed();
		this->UpdateObjectPosBasedOnSpeedValuesReal();
	}
	void daShyGuy::endState_Jump() {
	}

///////////////
// Sleep State
///////////////
	void daShyGuy::beginState_Sleep() {
		bindAnimChr_and_setUpdateRate("c18_EV_LOSE_2_R", 1, 0.0, 1.0);
		this->rot.y = 0x0000;
	}
	void daShyGuy::executeState_Sleep() {
		if(this->chrAnimation.isAnimationDone())
			this->chrAnimation.setCurrentFrame(0.0);
	}
	void daShyGuy::endState_Sleep() {
	}

///////////////
// Balloon H State
///////////////
	void daShyGuy::beginState_Balloon_H() {
		bindAnimChr_and_setUpdateRate("c18_L_DMG_F_3_R", 1, 0.0, 1.0);
		this->timer = 0;
		this->initialPos = this->pos;
		this->rot.x = 0xFE00;
		this->rot.y = 0;
	}
	void daShyGuy::executeState_Balloon_H() {

		// Makes him bob up and down
		this->pos.y = this->initialPos.y + ( sin(this->timer * 3.14 / 60.0) * 6.0 );

		// Makes him move side to side
		this->pos.x = this->initialPos.x + ( sin(this->timer * 3.14 / 600.0) * (float)this->distance * 8.0);

		this->timer = this->timer + 1;

		if(this->chrAnimation.isAnimationDone())
			this->chrAnimation.setCurrentFrame(0.0);

	}
	void daShyGuy::endState_Balloon_H() {
	}

///////////////
// Balloon V State
///////////////
	void daShyGuy::beginState_Balloon_V() {
		bindAnimChr_and_setUpdateRate("c18_L_DMG_F_3_R", 1, 0.0, 1.0);
		this->timer = 0;
		this->initialPos = this->pos;
		this->rot.x = 0xFE00;
		this->rot.y = 0;
	}
	void daShyGuy::executeState_Balloon_V() {
		// Makes him bob up and down
		this->pos.x = this->initialPos.x + ( sin(this->timer * 3.14 / 60.0) * 6.0 );

		// Makes him move side to side
		this->pos.y = this->initialPos.y + ( sin(this->timer * 3.14 / 600.0) * (float)this->distance * 8.0 );

		this->timer = this->timer + 1;

		if(this->chrAnimation.isAnimationDone())
			this->chrAnimation.setCurrentFrame(0.0);
	}
	void daShyGuy::endState_Balloon_V() {
	}

///////////////
// Balloon C State
///////////////
	void daShyGuy::beginState_Balloon_C() {
		bindAnimChr_and_setUpdateRate("c18_L_DMG_F_3_R", 1, 0.0, 1.0);
		this->timer = 0;
		this->initialPos = this->pos;
		this->rot.x = 0xFE00;
		this->rot.y = 0;
	}
	void daShyGuy::executeState_Balloon_C() {
		// Makes him bob up and down
		this->pos.x = this->initialPos.x + ( sin(this->timer * 3.14 / 600.0) * (float)this->distance * 8.0 );

		// Makes him move side to side
		this->pos.y = this->initialPos.y + ( cos(this->timer * 3.14 / 600.0) * (float)this->distance * 8.0 );

		this->timer = this->timer + 1;

		if(this->chrAnimation.isAnimationDone())
			this->chrAnimation.setCurrentFrame(0.0);
	}
	void daShyGuy::endState_Balloon_C() {
	}

///////////////
// Judo State
///////////////
	void daShyGuy::beginState_Judo() {
		this->max_speed.x = 0.0;
		this->speed.x = 0.0;
		this->x_speed_inc = 0.0;
		this->pos.y -= 4.0;

		this->timer = 0;
	}
	void daShyGuy::executeState_Judo() {

	// chargin 476? 673? 760? 768? 808? 966?
		if (this->timer == 0) { bindAnimChr_and_setUpdateRate("c18_OB_IDLE_R", 1, 0.0, 1.0); }

		this->timer = this->timer + 1;

		if (this->timer == 80) {
			if (this->direction == 1) {
				SpawnEffect("Wm_ob_keyget02_lighit", 0, &(Vec){this->pos.x + 7.0, this->pos.y + 14.0, this->pos.z - 5500.0}, &(S16Vec){0,0,0}, &(Vec){0.8, 0.8, 0.8});
			}
			else {
				SpawnEffect("Wm_ob_keyget02_lighit", 0, &(Vec){this->pos.x - 7.0, this->pos.y + 14.0, this->pos.z + 5500.0}, &(S16Vec){0,0,0}, &(Vec){0.8, 0.8, 0.8});
			}
		}

		if (this->timer < 120) {
			// Always face Mario
			u8 facing = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);

			if (facing != this->direction) {
				this->direction = facing;
				if (this->direction == 1) {
					this->rot.y = 0xD800;
				}
				else {
					this->rot.y = 0x2800;
				}
			}


			if(this->chrAnimation.isAnimationDone())
				this->chrAnimation.setCurrentFrame(0.0);
		}

		else if (this->timer == 120) {
			bindAnimChr_and_setUpdateRate("c18_H_CUT_R", 1, 0.0, 1.0);

		}

		else if (this->timer == 132) {
			PlaySoundAsync(this, SE_EMY_CRASHER_PUNCH);

			if (this->direction == 1) {
				SpawnEffect("Wm_mr_wallkick_b_l", 0, &(Vec){this->pos.x - 18.0, this->pos.y + 16.0, this->pos.z}, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
				Chuckles.addToList();
			}
			else {
				SpawnEffect("Wm_mr_wallkick_s_r", 0, &(Vec){this->pos.x + 18.0, this->pos.y + 16.0, this->pos.z}, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
				Knuckles.addToList();
			}
		}

		else {

			if(this->chrAnimation.isAnimationDone()) {
				if (this->direction == 1) {
					SpawnEffect("Wm_mr_wirehit_hit", 0, &(Vec){this->pos.x - 38.0, this->pos.y + 16.0, this->pos.z}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
					Chuckles.removeFromList();
				}
				else {
					SpawnEffect("Wm_mr_wirehit_hit", 0, &(Vec){this->pos.x + 38.0, this->pos.y + 16.0, this->pos.z}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
					Knuckles.removeFromList();
				}

				this->timer = 0;
				PlaySoundAsync(this, SE_EMY_BIG_PAKKUN_DAMAGE_1);
			}
		}
	}
	void daShyGuy::endState_Judo() {
	}

///////////////
// Spike State
///////////////
	void daShyGuy::beginState_Spike() {
		this->timer = 80;
		spikeTurn = 0;

		this->max_speed.x = 0.0;
		this->speed.x = 0.0;
		this->x_speed_inc = 0.0;
		this->pos.y -= 4.0;
	}
	void daShyGuy::executeState_Spike() {

		if (this->timer == 0) { bindAnimChr_and_setUpdateRate("c18_OB_IDLE_R", 1, 0.0, 1.0); }

		if (this->timer < 120) {
			// Always face Mario
			u8 facing = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);

			if (facing != this->direction) {
				this->direction = facing;
				if (this->direction == 1) {
					this->rot.y = 0xD800;
				}
				else {
					this->rot.y = 0x2800;
				}
			}

			if(this->chrAnimation.isAnimationDone())
				this->chrAnimation.setCurrentFrame(0.0);
		}

		else if (this->timer == 120) {
			bindAnimChr_and_setUpdateRate("c18_H_SHOT_R", 1, 0.0, 1.0);
		}

		else if (this->timer == 160) {
			PlaySound(this, SE_EMY_KANIBO_THROW);

			Vec pos;
			pos.x = this->pos.x;
			pos.y = this->pos.y;
			pos.z = this->pos.z;
			dStageActor_c *spawned;

			if (this->direction == 1) {
				spawned = CreateActor(ProfileId::EN_TOGETEKKYU, 0x2, pos, 0, 0);
				spawned->scale.x = 0.9;
				spawned->scale.y = 0.9;
				spawned->scale.z = 0.9;

				spawned->speed.x = -2.0;
				spawned->speed.y = 2.0;
			}
			else {
				spawned = CreateActor(ProfileId::EN_TOGETEKKYU, 0x12, pos, 0, 0);
				spawned->scale.x = 0.9;
				spawned->scale.y = 0.9;
				spawned->scale.z = 0.9;

				spawned->speed.x = 2.0;
				spawned->speed.y = 2.0;
			}
		}

		else {

			if(this->chrAnimation.isAnimationDone()) {
				this->timer = 0;
				return;
			}
		}

		this->timer = this->timer + 1;

	}
	void daShyGuy::endState_Spike() {
	}

///////////////
// Real Walk State
///////////////
bool daShyGuy::willWalkOntoSuitableGround() {
	static const float deltas[] = {2.5f, -2.5f};
	VEC3 checkWhere = {
			pos.x + deltas[direction],
			4.0f + pos.y,
			pos.z};

	u32 props = collMgr.getTileBehaviour2At(checkWhere.x, checkWhere.y, currentLayerID);

	//if (getSubType(props) == B_SUB_LEDGE)
	if (((props >> 16) & 0xFF) == 8)
		return false;

	float someFloat = 0.0f;
	if (collMgr.sub_800757B0(&checkWhere, &someFloat, currentLayerID, 1, -1)) {
		if (someFloat < checkWhere.y && someFloat > (pos.y - 5.0f))
			return true;
	}

	return false;
}


	void daShyGuy::beginState_RealWalk() {
		//inline this piece of code
		this->max_speed.x = (this->direction) ? -this->XSpeed : this->XSpeed;
		this->speed.x = (direction) ? -0.6f : 0.6f;

		this->max_speed.y = -4.0;
		this->speed.y = -4.0;
		this->y_speed_inc = -0.1875;
	}
	void daShyGuy::executeState_RealWalk() {
		chrAnimation.setUpdateRate(1.5f);

		// if (distance) {
		// 	// What the fuck. Somehow, having this code makes the shyguy not
		// 	// fall through solid-on-top platforms...
		// 	bool turn = collMgr.isOnTopOfTile();
		// 	if (!turn) {
		// 		if (!stillFalling) {
		// 			stillFalling = true;
		// 			pos.x = direction ? pos.x + 1.5 : pos.x - 1.5;
		// 			doStateChange(&StateID_RealTurn);
		// 		}
		// 	} else
		// }


		if (distance) {
			if (collMgr.isOnTopOfTile()) {
				stillFalling = false;

				if (!willWalkOntoSuitableGround()) {
					pos.x = direction ? pos.x + 1.5 : pos.x - 1.5;
					doStateChange(&StateID_RealTurn);
				}
			}
			else {
				if (!stillFalling) {
					stillFalling = true;
					pos.x = direction ? pos.x + 1.5 : pos.x - 1.5;
					doStateChange(&StateID_RealTurn);
				}
			}
		}

		bool ret = calculateTileCollisions();
		if (ret) {
			doStateChange(&StateID_RealTurn);
		}

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}
	}
	void daShyGuy::endState_RealWalk() { }

///////////////
// Real Turn State
///////////////
	void daShyGuy::beginState_RealTurn() {

		this->direction ^= 1;
		this->speed.x = 0.0;
	}
	void daShyGuy::executeState_RealTurn() {

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}

		u16 amt = (this->direction == 0) ? 0x2800 : 0xD800;
		int done = SmoothRotation(&this->rot.y, amt, 0x800);

		if(done) {
			this->doStateChange(&StateID_RealWalk);
		}
	}
	void daShyGuy::endState_RealTurn() {
	}

///////////////
// GoDizzy State
///////////////
	void daShyGuy::beginState_GoDizzy() {
		bindAnimChr_and_setUpdateRate("c18_L_DMG_F_1_R", 1, 0.0, 1.0);

		// SpawnEffect("Wm_en_spindamage", 0, &(Vec){this->pos.x, this->pos.y + 24.0, 0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});

		this->max_speed.x = 0;
		this->speed.x = 0;
		this->x_speed_inc = 0;

		this->max_speed.y = -4.0;
		this->speed.y = -4.0;
		this->y_speed_inc = -0.1875;

		this->timer = 0;
		this->jumpCounter = 0;
		this->isDown = 1;
	}
	void daShyGuy::executeState_GoDizzy() {
		calculateTileCollisions();

		effect.spawn("Wm_en_spindamage", 0, &(Vec){this->pos.x, this->pos.y + 24.0, 0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});

		if (this->jumpCounter == 0) {
			if(this->chrAnimation.isAnimationDone()) {
				this->jumpCounter = 1;
				bindAnimChr_and_setUpdateRate("c18_L_DMG_F_3_R", 1, 0.0, 1.0);
			}
		}

		else {
			if(this->chrAnimation.isAnimationDone()) {
				this->chrAnimation.setCurrentFrame(0.0);
			}

			if (this->timer > 600) {
				doStateChange(&StateID_Recover);
				damage = 0;
			}

			this->timer += 1;
		}
	}
	void daShyGuy::endState_GoDizzy() {}

///////////////
// BalloonDrop State
///////////////
	void daShyGuy::beginState_BalloonDrop() {
		bindAnimChr_and_setUpdateRate("c18_C_BLOCK_BREAK_R", 1, 0.0, 2.0);

		this->max_speed.x = 0.0;
		this->speed.x = 0.0;
		this->x_speed_inc = 0.0;

		this->max_speed.y = -2.0;
		this->speed.y = -2.0;
		this->y_speed_inc = -0.1875;

		this->isDown = 1;
		this->renderBalloon = 0;

		// char powerup;

		// if (baln == 1) {
		// 	powerup		= 0x0B000007;
		// }
		// else if (baln == 2) {
		// 	powerup		= 0x0B000009;
		// }
		// else if (baln == 3) {
		// 	powerup		= 0x0B000001;
		// }
		// else if (baln == 4) {
		// 	powerup		= 0x0C00000E;
		// }
		// else if (baln == 5) {
		// 	powerup		= 0x0C000015;
		// }
		// else if (baln == 6) {
		// 	powerup		= 0x0C000011;
		// }
		// CreateActor(60, powerup, (Vec){pos.x, pos.y - 28.0, pos.z}, 0, 0);
		// this->baln = 0;

		balloonPhysics.removeFromList();
		SpawnEffect("Wm_en_explosion_ln", 0, &(Vec){this->pos.x, this->pos.y - 32.0, 0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		PlaySound(this, SE_PLY_BALLOON_BRAKE);

		if (this->type != 8)
			this-distance == 0;

		type = 0;
	}
	void daShyGuy::executeState_BalloonDrop() {

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}

		bool ret = calculateTileCollisions();

		if (speed.y == 0.0) {
			SpawnEffect("Wm_en_sndlandsmk_s", 0, &(Vec){this->pos.x, this->pos.y, 0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
			doStateChange(&StateID_GoDizzy);

			aPhysics.info.yDistToCenter = 12.0f;
			aPhysics.info.yDistToEdge = 12.0f;
		}
	}
	void daShyGuy::endState_BalloonDrop() {
	}

///////////////
// FireKnockBack State
///////////////
	void daShyGuy::beginState_FireKnockBack() {
		bindAnimChr_and_setUpdateRate("c18_C_BLOCK_BREAK_R", 1, 0.0, 1.0);

		// Backfire 0 == Fireball to the right
		// Backfire 1 == Fireball to the left

		directionStore = this->direction;
		speed.x = (this->backFire) ? this->XSpeed : -this->XSpeed;
		speed.x *= 1.2f;
		max_speed.x = speed.x;
		x_speed_inc = 0.0f;
	}
	void daShyGuy::executeState_FireKnockBack() {

		calculateTileCollisions();
		// move backwards here
		this->speed.x = this->speed.x / 1.02f;

		if(this->chrAnimation.isAnimationDone()) {
			if (aPhysics.result1 == 0 && aPhysics.result2 == 0 && aPhysics.result3 == 0) {
				bindAnimChr_and_setUpdateRate("c18_EV_WIN_2_R", 1, 0.0, 1.5);
				doStateChange(&StateID_RealWalk);
			}
		}
	}
	void daShyGuy::endState_FireKnockBack() {
		this->direction = directionStore;
	}

///////////////
// FlameHit State
///////////////
	void daShyGuy::beginState_FlameHit() {
		bindAnimChr_and_setUpdateRate("c18_C_BLOCK_BREAK_R", 1, 0.0, 1.0);
	}
	void daShyGuy::executeState_FlameHit() {

		if(this->chrAnimation.isAnimationDone()) {
			if (type == 6) {
				doStateChange(&StateID_Balloon_H);
			}
			else if (type == 7) {
				doStateChange(&StateID_Balloon_V);
			}
			else if (type == 8) {
				doStateChange(&StateID_Balloon_C);
			}
		}
	}
	void daShyGuy::endState_FlameHit() {}

///////////////
// Recover State
///////////////
	void daShyGuy::beginState_Recover() {
		bindAnimChr_and_setUpdateRate("c18_L_DMG_F_4_R", 1, 0.0, 1.0);
	}
	void daShyGuy::executeState_Recover() {

		calculateTileCollisions();

		if(this->chrAnimation.isAnimationDone()) {
			if (type == 3) {
				doStateChange(&StateID_Jump);
			}
			else {
				bindAnimChr_and_setUpdateRate("c18_EV_WIN_2_R", 1, 0.0, 1.5);
				doStateChange(&StateID_RealWalk);
			}
		}
	}
	void daShyGuy::endState_Recover() {
		this->isDown = 0;
		this->rot.y = (direction) ? 0xD800 : 0x2800;
	}

///////////////
// Die State
///////////////
	void daShyGuy::beginState_Die() {
		// dEn_c::dieFall_Begin();
		this->removeMyActivePhysics();

		bindAnimChr_and_setUpdateRate("c18_C_BLOCK_BREAK_R", 1, 0.0, 2.0);
		this->timer = 0;
		this->dying = -10.0;
		this->Baseline = this->pos.y;
		this->rot.y = 0;
		this->rot.x = 0;

		if (type > 5 && type < 9) {
			this->renderBalloon = 0;
			SpawnEffect("Wm_en_explosion_ln", 0, &(Vec){this->pos.x, this->pos.y - 32.0, 0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		}
	}
	void daShyGuy::executeState_Die() {

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}

		this->timer += 1;

		// this->pos.x += 0.5;
		this->pos.y = Baseline + (-0.2 * dying * dying) + 20.0;

		this->dying += 0.5;

		if (this->timer > 450) {
			OSReport("Killing");
			this->kill();
			this->Delete(this->deleteForever);
		}

		// dEn_c::dieFall_Execute();

	}
	void daShyGuy::endState_Die() {
	}


//
// processed\../src/shyguyGiants.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include <profile.h>

extern void shyCollisionCallback(ActivePhysics *apThis, ActivePhysics *apOther);
const char* SGGarcNameList [] = {
	"shyguy",
	NULL
};

// Shy Guy Settings
//
// Nybble 5: Size
//		0 - Big
//		1 - Mega
//		2 - Giga
//
// Nybble 6: Colour
//		0 - Red
//		1 - Blue
//		2 - Green
//		3 - Cyan
//		4 - Magenta
//


class daShyGuyGiant : public dEn_c {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;
	nw4r::g3d::ResFile anmFile;

	m3d::mdl_c bodyModel;
	m3d::anmChr_c chrAnimation;
	mEf::es2 effect;

	int timer;
	int type;
	float dying;
	float Baseline;
	char damage;
	char isDown;
	Vec initialPos;
	int distance;
	float XSpeed;
	u32 cmgr_returnValue;
	bool isBouncing;
	int directionStore;

	public: static dActor_c *build();

	void bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate);
	void updateModelMatrices();
	bool calculateTileCollisions();

	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat5_Mario(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat11_PipeCannon(ActivePhysics *apThis, ActivePhysics *apOther);

	void powBlockActivated(bool isNotMPGP);

	void _vf148();
	void _vf14C();
	bool CreateIceActors();
	void addScoreWhenHit(void *other);
	void bouncePlayerWhenJumpedOn(void *player);

	void spawnHitEffectAtPosition(Vec2 pos);
	void doSomethingWithHardHitAndSoftHitEffects(Vec pos);
	void playEnemyDownSound2();
	void playHpdpSound1(); // plays PLAYER_SE_EMY/GROUP_BOOT/SE_EMY_DOWN_HPDP_S or _H
	void playEnemyDownSound1();
	void playEnemyDownComboSound(void *player); // AcPy_c/daPlBase_c?
	void playHpdpSound2(); // plays PLAYER_SE_EMY/GROUP_BOOT/SE_EMY_DOWN_HPDP_S or _H
	void _vf260(void *other); // AcPy/PlBase? plays the SE_EMY_FUMU_%d sounds based on some value
	void _vf264(dStageActor_c *other); // if other is player or yoshi, do Wm_en_hit and a few other things
	void _vf268(void *other); // AcPy/PlBase? plays the SE_EMY_DOWN_SPIN_%d sounds based on some value
	void _vf278(void *other); // AcPy/PlBase? plays the SE_EMY_YOSHI_FUMU_%d sounds based on some value

	USING_STATES(daShyGuyGiant);
	DECLARE_STATE(RealWalk);
	DECLARE_STATE(RealTurn);
	DECLARE_STATE(Die);
};

const SpriteData ShyGuyGiantSpriteData = {ProfileId::EN_SHYGUY_GIANT, 0x10, 0x30, 0, 0xFFFFFFFC0, 0x10, 0x40, 0x40, 0x40, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile ShyGuyGiantsProfile(&daShyGuyGiant::build, SpriteId::EN_SHYGUY_GIANT, &ShyGuyGiantSpriteData, ProfileId::WM_TREASURESHIP, ProfileId::EN_SHYGUY_GIANT, "EN_SHYGUY_GIANT", SGGarcNameList, 0x12);

dActor_c *daShyGuyGiant::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daShyGuyGiant));
	//OSReport("Building Shy Guy");
	return new(buffer) daShyGuyGiant;
}

///////////////////////
// Externs and States
///////////////////////
	extern "C" bool SpawnEffect(const char*, int, Vec*, S16Vec*, Vec*);

	//FIXME make this dEn_c->used...
	extern "C" char usedForDeterminingStatePress_or_playerCollision(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther, int unk1);
	extern "C" int SomeStrangeModification(dStageActor_c* actor);
	extern "C" void DoStuffAndMarkDead(dStageActor_c *actor, Vec vector, float unk);
	extern "C" int SmoothRotation(short* rot, u16 amt, int unk2);

	// Collision related
	extern "C" void BigHanaPlayer(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);
	extern "C" void BigHanaYoshi(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);
	extern "C" bool BigHanaWeirdGP(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);
	extern "C" bool BigHanaGroundPound(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);
	extern "C" bool BigHanaFireball(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);
	extern "C" bool BigHanaIceball(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);

	extern "C" void dAcPy_vf3F8(void* player, dEn_c* monster, int t);

	CREATE_STATE(daShyGuyGiant, RealWalk);
	CREATE_STATE(daShyGuyGiant, RealTurn);
	CREATE_STATE(daShyGuyGiant, Die);

////////////////////////
// Collision Functions
////////////////////////

	void daShyGuyGiant::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
		apOther->someFlagByte |= 2;

		dStageActor_c *player = apOther->owner;

		char hitType;
		hitType = usedForDeterminingStatePress_or_playerCollision(this, apThis, apOther, 0);
		if (hitType > 0) {
			PlaySound(this, SE_EMY_CMN_STEP);
			this->counter_504[apOther->owner->which_player] = 0xA;
		} else {
			this->dEn_c::playerCollision(apThis, apOther);
			this->_vf220(apOther->owner);
			if (Player_VF3D4(player)) {
				// WE'VE GOT A STAR, FOLKS
				if (apThis->_18 == 1 && !player->collMgr.isOnTopOfTile() && player->pos.y > apThis->bottom()) {
					bouncePlayer(player, 3.0f);
					PlaySound(this, SE_EMY_CMN_STEP);
				} else {
					dAcPy_vf3F8(player, this, 3);
				}
				this->counter_504[apOther->owner->which_player] = 0xA;

			}
		}
	}
	void daShyGuyGiant::_vf278(void *other) {
		PlaySound(this, SE_EMY_HANACHAN_STOMP);
}

	void daShyGuyGiant::bouncePlayerWhenJumpedOn(void *player) {
		bouncePlayer(player, 5.0f);
	}

	void daShyGuyGiant::yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
		this->playerCollision(apThis, apOther);
	}
	bool daShyGuyGiant::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) {
		return BigHanaWeirdGP(this, apThis, apOther);
	}
	bool daShyGuyGiant::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
		return BigHanaGroundPound(this, apThis, apOther);
	}
	bool daShyGuyGiant::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) {
		return BigHanaGroundPound(this, apThis, apOther);
	}

	bool daShyGuyGiant::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
		apOther->owner->kill();
		return true;
	}
	bool daShyGuyGiant::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther){
		dAcPy_vf3F8(apOther->owner, this, 3);
		this->counter_504[apOther->owner->which_player] = 0xA;
		return true;
	}
	bool daShyGuyGiant::collisionCat5_Mario(ActivePhysics *apThis, ActivePhysics *apOther){
		return true;
	}
	bool daShyGuyGiant::collisionCat11_PipeCannon(ActivePhysics *apThis, ActivePhysics *apOther){
		return true;
	}
	bool daShyGuyGiant::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
		return true;
	}
	bool daShyGuyGiant::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther){
		/*int hitType = usedForDeterminingStatePress_or_playerCollision(this, apThis, apOther, 0);
		if (hitType == 1 || hitType == 3) {
			PlaySound(this, SE_EMY_CMN_STEP);
			bouncePlayerWhenJumpedOn(apOther->owner);
		} else {
			dAcPy_vf3F8(apOther->owner, this, 3);
		}

		this->counter_504[apOther->owner->which_player] = 0xA;
		return true;*/
		return false;
	}

	bool daShyGuyGiant::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther){
		return BigHanaFireball(this, apThis, apOther);
	}
	bool daShyGuyGiant::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) {
		return BigHanaFireball(this, apThis, apOther);
	}
	bool daShyGuyGiant::collisionCat2_IceBall_15_YoshiIce(ActivePhysics *apThis, ActivePhysics *apOther) {
		return BigHanaIceball(this, apThis, apOther);
	}

	// These handle the ice crap
	void daShyGuyGiant::_vf148() {
		dEn_c::_vf148();
		doStateChange(&StateID_Die);
	}
	void daShyGuyGiant::_vf14C() {
		dEn_c::_vf14C();
		doStateChange(&StateID_Die);
	}

	extern "C" void sub_80024C20(void);
	extern "C" void __destroy_arr(void*, void(*)(void), int, int);

	bool daShyGuyGiant::CreateIceActors() {
		struct DoSomethingCool my_struct = { 0, this->pos, {2.4, 3.0, 3.0}, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		if (type == 1) { my_struct.scale = (Vec3){4.8, 6.0, 6.0}; }
		if (type == 2) { my_struct.scale = (Vec3){7.2, 9.0, 9.0}; }
	    this->frzMgr.Create_ICEACTORs( (void*)&my_struct, 1 );
	    __destroy_arr( (void*)&my_struct, sub_80024C20, 0x3C, 1 );
	    return true;
	}

	void daShyGuyGiant::addScoreWhenHit(void *other) { }

	void daShyGuyGiant::spawnHitEffectAtPosition(Vec2 pos) { }
	void daShyGuyGiant::doSomethingWithHardHitAndSoftHitEffects(Vec pos) { }
	void daShyGuyGiant::playEnemyDownSound2() { }
	void daShyGuyGiant::playHpdpSound1() { } // plays PLAYER_SE_EMY/GROUP_BOOT/SE_EMY_DOWN_HPDP_S or _H
	void daShyGuyGiant::playEnemyDownSound1() { }
	void daShyGuyGiant::playEnemyDownComboSound(void *player) { } // AcPy_c/daPlBase_c?
	void daShyGuyGiant::playHpdpSound2() { } // plays PLAYER_SE_EMY/GROUP_BOOT/SE_EMY_DOWN_HPDP_S or _H
	void daShyGuyGiant::_vf260(void *other) { } // AcPy/PlBase? plays the SE_EMY_FUMU_%d sounds based on some value
	void daShyGuyGiant::_vf264(dStageActor_c *other) { } // if other is player or yoshi, do Wm_en_hit and a few other things
	void daShyGuyGiant::_vf268(void *other) { } // AcPy/PlBase? plays the SE_EMY_DOWN_SPIN_%d sounds based on some value

	void daShyGuyGiant::powBlockActivated(bool isNotMPGP) {
	}

bool daShyGuyGiant::calculateTileCollisions() {
	// Returns true if sprite should turn, false if not.

	HandleXSpeed();
	HandleYSpeed();
	doSpriteMovement();

	cmgr_returnValue = collMgr.isOnTopOfTile();
	collMgr.calculateBelowCollisionWithSmokeEffect();

	if (isBouncing) {
		stuffRelatingToCollisions(0.1875f, 1.0f, 0.5f);
		if (speed.y != 0.0f)
			isBouncing = false;
	}

	float xDelta = pos.x - last_pos.x;
	if (xDelta >= 0.0f)
		direction = 0;
	else
		direction = 1;

	if (collMgr.isOnTopOfTile()) {
		// Walking into a tile branch

		if (cmgr_returnValue == 0)
			isBouncing = true;

		if (speed.x != 0.0f) {
			//playWmEnIronEffect();
		}

		speed.y = 0.0f;

		// u32 blah = collMgr.s_80070760();
		// u8 one = (blah & 0xFF);
		// static const float incs[5] = {0.00390625f, 0.0078125f, 0.015625f, 0.0234375f, 0.03125f};
		// x_speed_inc = incs[one];
		max_speed.x = (direction == 1) ? -this->XSpeed : this->XSpeed;
	} else {
		x_speed_inc = 0.0f;
	}

	// Bouncing checks
	if (_34A & 4) {
		Vec v = (Vec){0.0f, 1.0f, 0.0f};
		collMgr.pSpeed = &v;

		if (collMgr.calculateAboveCollision(collMgr.outputMaybe))
			speed.y = 0.0f;

		collMgr.pSpeed = &speed;

	} else {
		if (collMgr.calculateAboveCollision(collMgr.outputMaybe))
			speed.y = 0.0f;
	}

	collMgr.calculateAdjacentCollision(0);

	// Switch Direction
	if (collMgr.outputMaybe & (0x15 << direction)) {
		if (collMgr.isOnTopOfTile()) {
			isBouncing = true;
		}
		return true;
	}
	return false;
}

void daShyGuyGiant::bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate) {
	nw4r::g3d::ResAnmChr anmChr = this->anmFile.GetResAnmChr(name);
	this->chrAnimation.bind(&this->bodyModel, anmChr, unk);
	this->bodyModel.bindAnim(&this->chrAnimation, unk2);
	this->chrAnimation.setUpdateRate(rate);
}

int daShyGuyGiant::onCreate() {
	//OSReport("Spawning Shy Guy");
	this->type = (this->settings >> 28) & 0xF;

	allocator.link(-1, GameHeaps[0], 0, 0x20);

	u32 colour = (this->settings >> 24) & 0xF;

	// Shy Guy Colours
	if (colour == 1) {
		this->resFile.data = getResource("shyguy", "g3d/ShyGuyBlue.brres");
	}
	else if (colour == 2) {
		this->resFile.data = getResource("shyguy", "g3d/ShyGuyGreen.brres");
	}
	else if (colour == 3) {
		this->resFile.data = getResource("shyguy", "g3d/ShyGuyCyan.brres");
	}
	else if (colour == 4) {
		this->resFile.data = getResource("shyguy", "g3d/ShyGuyPurple.brres");
	}
	else {
		this->resFile.data = getResource("shyguy", "g3d/ShyGuyRed.brres");
	}
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("body_h");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&this->bodyModel, 0);

	// Animations start here
	this->anmFile.data = getResource("shyguy", "g3d/ShyGuyAnimations.brres");
	nw4r::g3d::ResAnmChr anmChr = this->anmFile.GetResAnmChr("c18_IDLE_R");
	this->chrAnimation.setup(mdl, anmChr, &this->allocator, 0);

	allocator.unlink();

	// Stuff I do understand

	this->pos.y += 32.0;
	this->rot.x = 0; // X is vertical axis
	this->rot.y = 0xD800; // Y is horizontal axis
	this->rot.z = 0; // Z is ... an axis >.>
	this->direction = 1; // Heading left.

	this->speed.x = 0.0;
	this->speed.y = 0.0;
	this->Baseline = this->pos.y;

	ActivePhysics::Info HitMeBaby;
	float anmSpeed;

	if (type == 0) {
		this->scale = (Vec){40.0f, 40.0f, 40.0f};

		HitMeBaby.xDistToCenter = 0.0;
		HitMeBaby.yDistToCenter = 20.0;

		HitMeBaby.xDistToEdge = 14.0;
		HitMeBaby.yDistToEdge = 20.0;

		this->XSpeed = 0.4;
		anmSpeed = 1.0;

		static const lineSensor_s below(12<<12, 4<<12, 0<<12);
		static const lineSensor_s adjacent(14<<12, 9<<12, 14<<12);
		collMgr.init(this, &below, 0, &adjacent);
	}
	else if (type == 1) {
		this->scale = (Vec){80.0f, 80.0f, 80.0f};

		HitMeBaby.xDistToCenter = 0.0;
		HitMeBaby.yDistToCenter = 40.0;

		HitMeBaby.xDistToEdge = 28.0;
		HitMeBaby.yDistToEdge = 40.0;

		this->XSpeed = 0.4;
		anmSpeed = 0.5;

		static const lineSensor_s below(12<<12, 4<<12, 0<<12);
		static const lineSensor_s adjacent(28<<12, 9<<12, 28<<12);
		collMgr.init(this, &below, 0, &adjacent);
	}
	else {
		this->scale = (Vec){120.0f, 120.0f, 120.0f};

		HitMeBaby.xDistToCenter = 0.0;
		HitMeBaby.yDistToCenter = 60.0;

		HitMeBaby.xDistToEdge = 42.0;
		HitMeBaby.yDistToEdge = 60.0;

		this->XSpeed = 0.4;
		anmSpeed = 0.25;

		static const lineSensor_s below(12<<12, 4<<12, 0<<12);
		static const lineSensor_s adjacent(42<<12, 9<<12, 42<<12);
		collMgr.init(this, &below, 0, &adjacent);
	}

	HitMeBaby.category1 = 0x3;
	HitMeBaby.category2 = 0x9;
	HitMeBaby.bitfield1 = 0x4F;
	HitMeBaby.bitfield2 = 0xffba7ffe;
	HitMeBaby.unkShort1C = 0x20000;
	HitMeBaby.callback = &shyCollisionCallback;

	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();

	collMgr.calculateBelowCollisionWithSmokeEffect();

	cmgr_returnValue = collMgr.isOnTopOfTile();

	if (collMgr.isOnTopOfTile())
		isBouncing = false;
	else
		isBouncing = true;

	// State Changer
	bindAnimChr_and_setUpdateRate("c18_EV_WIN_2_R", 1, 0.0, anmSpeed);
	doStateChange(&StateID_RealWalk);

	this->onExecute();
	return true;
}

int daShyGuyGiant::onDelete() {
	return true;
}

int daShyGuyGiant::onExecute() {
	acState.execute();
	updateModelMatrices();

	return true;
}

int daShyGuyGiant::onDraw() {
	bodyModel.scheduleForDrawing();
	return true;
}

void daShyGuyGiant::updateModelMatrices() {
	float yoff;

	if (type == 0) 		{ yoff = -5.0; }
	else if (type == 1) { yoff = -10.0; }
	else 				{ yoff = -15.0; }

	matrix.translation(pos.x, pos.y + yoff, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}


///////////////
// Real Walk State
///////////////
	void daShyGuyGiant::beginState_RealWalk() {
		//inline this piece of code
		this->max_speed.x = (this->direction) ? -this->XSpeed : this->XSpeed;
		this->speed.x = (direction) ? -this->XSpeed : this->XSpeed;

		this->max_speed.y = -4.0;
		this->speed.y = -4.0;
		this->y_speed_inc = -0.1875;
	}
	void daShyGuyGiant::executeState_RealWalk() {
		bodyModel._vf1C();

		bool ret = calculateTileCollisions();
		if (ret) {
			doStateChange(&StateID_RealTurn);
		}

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}
	}
	void daShyGuyGiant::endState_RealWalk() { }

///////////////
// Real Turn State
///////////////
	void daShyGuyGiant::beginState_RealTurn() {

		this->direction ^= 1;
		this->speed.x = 0.0;
	}
	void daShyGuyGiant::executeState_RealTurn() {
		bodyModel._vf1C();

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}

		u16 amt = (this->direction == 0) ? 0x2800 : 0xD800;
		int done = SmoothRotation(&this->rot.y, amt, 0x800);

		if(done) {
			this->doStateChange(&StateID_RealWalk);
		}
	}
	void daShyGuyGiant::endState_RealTurn() {
	}

///////////////
// Die State
///////////////
	void daShyGuyGiant::beginState_Die() {
		// dEn_c::dieFall_Begin();
		this->removeMyActivePhysics();

		bindAnimChr_and_setUpdateRate("c18_C_BLOCK_BREAK_R", 1, 0.0, 2.0);
		this->timer = 0;
		this->dying = -10.0;
		this->Baseline = this->pos.y;
		this->rot.y = 0;
		this->rot.x = 0;
	}
	void daShyGuyGiant::executeState_Die() {
		bodyModel._vf1C();

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);
		}

		this->timer += 1;

		// this->pos.x += 0.5;
		this->pos.y = Baseline + (-0.2 * dying * dying) + 20.0;

		this->dying += 0.5;

		if (this->timer > 450) {
			this->kill();
			this->Delete(this->deleteForever);
		}

		// dEn_c::dieFall_Execute();

	}
	void daShyGuyGiant::endState_Die() {
	}


//
// processed\../src/meteor.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include "boss.h"
#include <profile.h>

class dMeteor : public dEn_c {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	public: static dActor_c *build();

	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;
	nw4r::g3d::ResFile resFile;
	mEf::es2 effect;

	int timer;
	int spinSpeed;
	char spinDir;
	char isElectric;

	Physics MakeItRound;

	void updateModelMatrices();
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);

	public:
		void kill();
};
const char* MEarcNameList [] = {
	"kazan_rock",
	NULL
};
const SpriteData MeteorSpriteData = {ProfileId::EN_METEOR, 8, 0, 8, 0, 0x200, 0x200, 0x30, 0x30, 0, 0, 8};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile MeteorProfile(&dMeteor::build, SpriteId::EN_METEOR, &MeteorSpriteData, ProfileId::EN_TARZANROPE, ProfileId::EN_METEOR, "EN_METEOR", MEarcNameList, 0x2);

dActor_c *dMeteor::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dMeteor));
	return new(buffer) dMeteor;
}

// extern "C" dStageActor_c *GetSpecificPlayerActor(int num);
// extern "C" void *modifyPlayerPropertiesWithRollingObject(dStageActor_c *Player, float _52C);


void dMeteor::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
}

void MeteorPhysicsCallback(dMeteor *self, dEn_c *other) {
	if (other->profileId == ProfileId::JR_CLOWN_PLAYER_CANNONSHOT) {
		OSReport("CANNON COLLISION");

		SpawnEffect("Wm_en_explosion", 0, &other->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		SpawnEffect("Wm_en_explosion_smk", 0, &other->pos, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
		PlaySound(other, SE_OBJ_TARU_BREAK);
		other->Delete(1);

		switch ((self->settings >> 24) & 3) {
			case 1:
				dStageActor_c::create(ProfileId::EN_HATENA_BALLOON, 0x100, &self->pos, 0, self->currentLayerID);
				break;
			case 2:
				VEC3 coinPos = {self->pos.x - 16.0f, self->pos.y, self->pos.z};
				dStageActor_c::create(ProfileId::EN_COIN, 9, &coinPos, 0, self->currentLayerID);
				break;
		}

		self->kill();
	}
}

bool dMeteor::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
	DamagePlayer(this, apThis, apOther);
	return true;
}


int dMeteor::onCreate() {

	// Setup Model
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	this->resFile.data = getResource("kazan_rock", "g3d/kazan_rock.brres");
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("kazan_rock");
	bodyModel.setup(mdl, &allocator, 0x128, 1, 0);

	if (this->settings >> 31) {
		SetupTextures_MapObj(&bodyModel, 0);
	}

	allocator.unlink();


	// Retrieve Scale and set it up
	float sca = (float)((this->settings >> 8) & 0xFF);
	sca = (sca/5.0) + 0.2;

	this->scale = (Vec){sca,sca,sca};

	// Other settings
	this->spinDir = this->settings & 0x1;
	this->spinSpeed = ((this->settings >> 16) & 0xFF) * 20;
	this->isElectric = (this->settings >> 4) & 0x1;


	// Setup Physics
	if (isElectric) {
		ActivePhysics::Info elec;
		elec.xDistToCenter = 0.0;
		elec.yDistToCenter = 0.0;

		elec.xDistToEdge = 13.0 * sca;
		elec.yDistToEdge = 13.0 * sca;

		elec.category1 = 0x3;
		elec.category2 = 0x0;
		elec.bitfield1 = 0x4F;
		elec.bitfield2 = 0x200;
		elec.unkShort1C = 0;
		elec.callback = &dEn_c::collisionCallback;

		this->aPhysics.initWithStruct(this, &elec);
		this->aPhysics.addToList();
	}

	MakeItRound.baseSetup(this, &MeteorPhysicsCallback, &MeteorPhysicsCallback, &MeteorPhysicsCallback, 1, 0);

	MakeItRound.x = 0.0;
	MakeItRound.y = 0.0;

	MakeItRound.diameter = 13.0 * sca;
	MakeItRound.isRound = 1;

	MakeItRound.update();

	MakeItRound.addToList();

	this->pos.z = (settings & 0x1000000) ? -2000.0f : 3458.0f;

	this->onExecute();
	return true;
}

int dMeteor::onDelete() {
	return true;
}

int dMeteor::onExecute() {

	if (spinDir == 0) 	{ rot.z -= spinSpeed; }
	else 				{ rot.z += spinSpeed; }

	MakeItRound.update();
	updateModelMatrices();

	if (isElectric) {
		effect.spawn("Wm_en_birikyu_biri", 0, &(Vec){pos.x, pos.y, pos.z+500.0}, &rot, &(Vec){scale.x*0.8, scale.y*0.8, scale.z*0.8});
		PlaySound(this, SE_EMY_BIRIKYU_SPARK);
	}

	// for (i=0; i<4; i++) {
	// 	dStageActor_c *player = GetSpecificPlayerActor(i);
	// 	modifyPlayerPropertiesWithRollingObject(player, );
	// }

	return true;
}

int dMeteor::onDraw() {

	bodyModel.scheduleForDrawing();
	bodyModel._vf1C();
	return true;
}

void dMeteor::updateModelMatrices() {
	// This won't work with wrap because I'm lazy.
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}

void dMeteor::kill() {
	PlaySound(this, SE_OBJ_ROCK_LAND);
	SpawnEffect("Wm_ob_cmnboxsmoke", 0, &pos, &rot, &scale);
	SpawnEffect("Wm_ob_cmnboxgrain", 0, &pos, &rot, &scale);

	this->Delete(1);
}



//
// processed\../src/electricLine.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include <profile.h>

class daElectricLine : public dEn_c {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;

	dEn_c *Needles;
	u32 delay;
	u32 timer;
	char loops;

	public: static dActor_c *build();

	USING_STATES(daElectricLine);
	DECLARE_STATE(Activate);
	DECLARE_STATE(Deactivate);
	DECLARE_STATE(Die);
};

const char *ElectricLineArcList[] = {"boss_koopaJr_toge", NULL};
const SpriteData ElectricLineSpriteData = {ProfileId::EN_ELECTRIC_LINE, 0, 0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile ElectricLineProfile(&daElectricLine::build, SpriteId::EN_ELECTRIC_LINE, &ElectricLineSpriteData, ProfileId::KAWANAGARE, ProfileId::EN_ELECTRIC_LINE, "EN_ELECTRIC_LINE", ElectricLineArcList);

dActor_c *daElectricLine::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daElectricLine));
	return new(buffer) daElectricLine;
}

///////////////////////
// Externs and States
///////////////////////


	CREATE_STATE(daElectricLine, Activate);
	CREATE_STATE(daElectricLine, Deactivate);
	CREATE_STATE(daElectricLine, Die);



int daElectricLine::onCreate() {

	Vec temppos = this->pos;
	temppos.x += 24.0;

	// Settings for rotation: 0 = facing right, 1 = facing left, 2 = facing up, 3 = facing down
	char settings = 0;
	if (this->settings & 0x1) {
		settings = 1;
		temppos.x -= 32.0;
	}


	Needles = (daNeedles*)create(ProfileId::NEEDLE_FOR_KOOPA_JR_B, settings, &temppos, &this->rot, 0);
	Needles->doStateChange(&daNeedles::StateID_DemoWait);

	// Needles->aPhysics.info.category1 = 0x3;
	// Needles->aPhysics.info.bitfield1 = 0x4F;
	// Needles->aPhysics.info.bitfield2 = 0xffbafffe;

	// Delay in 1/6ths of a second
	this->delay = (this->settings >> 16) * 10;
	this->loops = (this->settings >> 4);

	// State Changers
	doStateChange(&StateID_Activate);

	this->onExecute();
	return true;
}

int daElectricLine::onDelete() {
	return true;
}

int daElectricLine::onExecute() {
	acState.execute();
	return true;
}

int daElectricLine::onDraw() {
	return true;
}


// States:
//
// DemoWait - all nullsubs, does nothing
// DemoAwake - moves the spikes in their respective directions
// Idle - Fires off an infinity of effects for some reason.
// Die - removes physics, then nullsubs


///////////////
// Activate State
///////////////
	void daElectricLine::beginState_Activate() {
		this->timer = this->delay;
		Needles->doStateChange(&daNeedles::StateID_Idle);
	}
	void daElectricLine::executeState_Activate() {
		if (this->loops) {
			this->timer--;
			if (this->timer == 0) {
				this->loops += 1;
				doStateChange(&StateID_Deactivate);
			}
		}
	}
	void daElectricLine::endState_Activate() { }

///////////////
// Deactivate State
///////////////
	void daElectricLine::beginState_Deactivate() {
		this->timer = this->delay;
		Needles->removeMyActivePhysics();
		Needles->doStateChange(&daNeedles::StateID_DemoWait);
	}
	void daElectricLine::executeState_Deactivate() {

		this->timer--;
		if (this->timer == 0) {
			doStateChange(&StateID_Activate);
		}
	}
	void daElectricLine::endState_Deactivate() {
		Needles->addMyActivePhysics();
	}


///////////////
// Die State
///////////////
	void daElectricLine::beginState_Die() { Needles->doStateChange(&daNeedles::StateID_Die); }
	void daElectricLine::executeState_Die() { }
	void daElectricLine::endState_Die() { }


//
// processed\../src/thundercloud.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <profile.h>

#include "boss.h"

const char* TLCarcNameList [] = {
	"tcloud",
	NULL
};

class dThunderCloud : public dEn_c {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;
	nw4r::g3d::ResFile resFile;
	m3d::anmChr_c anm;

	mEf::es2 bolt;
	mEf::es2 charge;

	float Baseline;
	u32 timer;
	int dying;
	char killFlag;
	bool stationary;
	float leader;
	pointSensor_s below;

	bool usingEvents;
	u64 eventFlag;

	ActivePhysics Lightning;

	void dieFall_Begin();
	void dieFall_Execute();
	public: static dActor_c *build();

	void updateModelMatrices();

	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat5_Mario(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat11_PipeCannon(ActivePhysics *apThis, ActivePhysics *apOther);

	void bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate);

	void powBlockActivated(bool isNotMPGP);

	void _vf148();
	void _vf14C();
	bool CreateIceActors();

	void lightningStrike();

	USING_STATES(dThunderCloud);
	DECLARE_STATE(Follow);
	DECLARE_STATE(Lightning);
	DECLARE_STATE(Wait);
};

const SpriteData ThunderCloudSpriteData = {ProfileId::EN_THUNDERCLOUD, 0, 0, 0, 0, 0x200, 0x200, 0x30, 0x30, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile ThunderCloudProfile(&dThunderCloud::build, SpriteId::EN_THUNDERCLOUD, &ThunderCloudSpriteData, ProfileId::WM_BUBBLE, ProfileId::EN_THUNDERCLOUD, "EN_THUNDERCLOUD", TLCarcNameList, 0x12);


dActor_c *dThunderCloud::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dThunderCloud));
	return new(buffer) dThunderCloud;
}


CREATE_STATE(dThunderCloud, Follow);
CREATE_STATE(dThunderCloud, Lightning);
CREATE_STATE(dThunderCloud, Wait);

void dThunderCloud::powBlockActivated(bool isNotMPGP) { }


// Collision Callbacks
	extern "C" void dAcPy_vf3F4(void* mario, void* other, int t);
	extern "C" bool BigHanaFireball(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);
	extern "C" void *dAcPy_c__ChangePowerupWithAnimation(void * Player, int powerup);
	extern "C" int CheckExistingPowerup(void * Player);

	void dThunderCloud::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {

		if (this->counter_504[apOther->owner->which_player]) {
			if (apThis->info.category2 == 0x9) {
				int p = CheckExistingPowerup(apOther->owner);
				if (p != 3) {	// Powerups - 0 = small; 1 = big; 2 = fire; 3 = mini; 4 = prop; 5 = peng; 6 = ice; 7 = hammer
					dAcPy_c__ChangePowerupWithAnimation(apOther->owner, 3);
				}
				else { dAcPy_vf3F4(apOther->owner, this, 9); }
			}

			else { dAcPy_vf3F4(apOther->owner, this, 9); }
		}

		this->counter_504[apOther->owner->which_player] = 0x20;
	}

	void dThunderCloud::yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther) { this->playerCollision(apThis, apOther); }
	bool dThunderCloud::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) { this->playerCollision(apThis, apOther); return true; }
	bool dThunderCloud::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) { this->playerCollision(apThis, apOther); return true; }
	bool dThunderCloud::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) { this->playerCollision(apThis, apOther); return true; }
	bool dThunderCloud::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther) { this->playerCollision(apThis, apOther); return true; }
	bool dThunderCloud::collisionCat5_Mario(ActivePhysics *apThis, ActivePhysics *apOther) { this->playerCollision(apThis, apOther); return true; }
	bool dThunderCloud::collisionCat11_PipeCannon(ActivePhysics *apThis, ActivePhysics *apOther) { this->playerCollision(apThis, apOther); return true; }

	bool dThunderCloud::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) { return BigHanaFireball(this, apThis, apOther); }
	bool dThunderCloud::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther) { return BigHanaFireball(this, apThis, apOther); }

	bool dThunderCloud::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) {
		if (apThis->info.category2 == 0x9) { return true; }
		PlaySound(this, SE_EMY_DOWN);
		doStateChange(&StateID_DieFall);
		return true;
	}
	bool dThunderCloud::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
		this->collisionCat13_Hammer(apThis, apOther);
		return true;
	}
	bool dThunderCloud::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther) {
		if (apThis->info.category2 == 0x9) { return true; }
		dEn_c::collisionCat3_StarPower(apThis, apOther);
		this->collisionCat13_Hammer(apThis, apOther);
		return true;
	}


	// These handle the ice crap
	void dThunderCloud::_vf148() {
		dEn_c::_vf148();
		doStateChange(&StateID_DieFall);
	}
	void dThunderCloud::_vf14C() {
		dEn_c::_vf14C();
		doStateChange(&StateID_DieFall);
	}

	extern "C" void sub_80024C20(void);
	extern "C" void __destroy_arr(void*, void(*)(void), int, int);
	//extern "C" __destroy_arr(struct DoSomethingCool, void(*)(void), int cnt, int bar);

	bool dThunderCloud::CreateIceActors() {
		this->Lightning.removeFromList();

		struct DoSomethingCool my_struct = { 0, (Vec){pos.x, pos.y - 16.0, pos.z}, {1.75, 1.4, 1.5}, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
	    this->frzMgr.Create_ICEACTORs( (void*)&my_struct, 1 );
	    __destroy_arr( (void*)&my_struct, sub_80024C20, 0x3C, 1 );
	    return true;
	}


void dThunderCloud::dieFall_Begin() {
	this->Lightning.removeFromList();
	this->timer = 0;
	this->dEn_c::dieFall_Begin();
}
void dThunderCloud::dieFall_Execute() {
	if (this->killFlag == 1) { return; }

	this->timer = this->timer + 1;

	this->dying = this->dying + 0.15;

	this->pos.x = this->pos.x + 0.15;
	this->pos.y = this->pos.y - ((-0.2 * (this->dying*this->dying)) + 5);

	this->dEn_c::dieFall_Execute();

	if (this->timer > 450) {

		if (((this->settings >> 28) > 0) || (stationary)) {
			this->Delete(1);
			this->killFlag = 1;
			return;
		}

		dStageActor_c *Player = GetSpecificPlayerActor(0);
		if (Player == 0) { Player = GetSpecificPlayerActor(1); }
		if (Player == 0) { Player = GetSpecificPlayerActor(2); }
		if (Player == 0) { Player = GetSpecificPlayerActor(3); }


		if (Player == 0) {
			this->pos.x = 0;
		} else {
			this->pos.x = Player->pos.x - 300;
		}

		this->pos.y = this->Baseline;

		SpawnEffect("Wm_en_blockcloud", 0, &pos, &(const S16Vec){0,0,0}, &(const Vec){1.0f,1.0f,1.0f});

		scale.x = scale.y = scale.z = 0.0f;
		this->aPhysics.addToList();
		doStateChange(&StateID_Follow);
	}
}


void dThunderCloud::bindAnimChr_and_setUpdateRate(const char* name, int unk, float unk2, float rate) {
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr(name);
	this->anm.bind(&this->bodyModel, anmChr, unk);
	this->bodyModel.bindAnim(&this->anm, unk2);
	this->anm.setUpdateRate(rate);
}

int dThunderCloud::onCreate() {

	// Setup the model
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	this->resFile.data = getResource("tcloud", "g3d/tcloud.brres");
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("cloud");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&bodyModel, 0);

	bool ret;
	nw4r::g3d::ResAnmChr anmChr = this->resFile.GetResAnmChr("cloud_wait");
	ret = this->anm.setup(mdl, anmChr, &this->allocator, 0);

	allocator.unlink();



	scale = (Vec){1.2f, 1.2f, 1.2f};

	// Scale and Physics
	ActivePhysics::Info Cloud;
	Cloud.xDistToCenter = 0.0;
	Cloud.yDistToCenter = 0.0;
	Cloud.category1 = 0x3;
	Cloud.category2 = 0x0;
	Cloud.bitfield1 = 0x4F;

	Cloud.bitfield2 = 0xffba7ffe;
	Cloud.xDistToEdge = 18.0f * scale.x;
	Cloud.yDistToEdge = 12.0f * scale.y;

	Cloud.unkShort1C = 0;
	Cloud.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &Cloud);
	this->aPhysics.addToList();

	below.x = 0;
	below.y = 0;
	collMgr.init(this, &below, 0, 0);

	// Some Settings
	this->Baseline = this->pos.y;
	this->dying = -5;
	this->killFlag = 0;
	this->pos.z = 5750.0f; // sun

	stationary 		= this->settings & 0xF;

	char eventNum	= (this->settings >> 16) & 0xFF;
	usingEvents = (stationary != 0) && (eventNum != 0);

	this->eventFlag = (u64)1 << (eventNum - 1);


	// State Change!
	if (stationary) { doStateChange(&StateID_Wait); }
	else 			{ doStateChange(&StateID_Follow); }

	this->onExecute();
	return true;
}

int dThunderCloud::onDelete() {
	return true;
}

int dThunderCloud::onExecute() {
	if (scale.x < 1.0f)
		scale.x = scale.y = scale.z = scale.x + 0.0375f;
	else
		scale.x = scale.y = scale.z = 1.0f;

	acState.execute();
	updateModelMatrices();
	bodyModel._vf1C();

	if ((dFlagMgr_c::instance->flags & this->eventFlag) && (!stationary)) {
		if (this->killFlag == 0 && acState.getCurrentState()->isNotEqual(&StateID_DieFall)) {
			this->kill();
			this->pos.y = this->pos.y + 800.0;
			this->killFlag = 1;
			doStateChange(&StateID_DieFall);
		}
	}

	return true;
}

int dThunderCloud::onDraw() {
	bodyModel.scheduleForDrawing();

	return true;
}


void dThunderCloud::updateModelMatrices() {
	// This won't work with wrap because I'm lazy.
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}


// Follow State

void dThunderCloud::beginState_Follow() {
	this->timer = 0;
	this->bindAnimChr_and_setUpdateRate("cloud_wait", 1, 0.0, 1.0);
	this->rot.x = 0;
	this->rot.y = 0;
	this->rot.z = 0;
	PlaySound(this, SE_AMB_THUNDER_CLOUD);
}
void dThunderCloud::executeState_Follow() {

	charge.spawn("Wm_mr_electricshock_biri02_s", 0, &pos, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});

	if(this->anm.isAnimationDone()) {
		this->anm.setCurrentFrame(0.0); }

	if (this->timer > 200) { this->doStateChange(&StateID_Lightning); }

	this->direction = dSprite_c__getXDirectionOfFurthestPlayerRelativeToVEC3(this, this->pos);

	float speedDelta;
	speedDelta = 0.05;

	if (this->direction == 0) { // Going Left
		this->speed.x = this->speed.x + speedDelta; //

		if (this->speed.x < 0) { this->speed.x += (speedDelta / 1.5); }
		if (this->speed.x < -6.0) { this->speed.x += (speedDelta * 2.0); }
	}
	else { // Going Right
		this->speed.x = this->speed.x - speedDelta;

		if (this->speed.x > 0) { this->speed.x -= (speedDelta / 1.5); }
		if (this->speed.x > 6.0) { this->speed.x -= (speedDelta * 2.0); }
	}

	this->HandleXSpeed();

	float yDiff;
	yDiff = (this->Baseline - this->pos.y) / 8;
	this->speed.y = yDiff;

	this->HandleYSpeed();

	this->UpdateObjectPosBasedOnSpeedValuesReal();

	this->timer = this->timer + 1;
}
void dThunderCloud::endState_Follow() {
	this->speed.y = 0;
}


// Wait State

void dThunderCloud::beginState_Wait() {
	this->timer = 0;
	this->bindAnimChr_and_setUpdateRate("cloud_wait", 1, 0.0, 1.0);
	this->rot.x = 0;
	this->rot.y = 0;
	this->rot.z = 0;
	PlaySound(this, SE_AMB_THUNDER_CLOUD);
}
void dThunderCloud::executeState_Wait() {

	charge.spawn("Wm_mr_electricshock_biri02_s", 0, &pos, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});

	if(this->anm.isAnimationDone()) {
		this->anm.setCurrentFrame(0.0); }

	if ((this->settings >> 16) & 0xFF) {
		if (dFlagMgr_c::instance->flags & this->eventFlag) {
			this->doStateChange(&StateID_Lightning);
		}
	}
	else {
		if (this->timer > 200) { this->doStateChange(&StateID_Lightning); }
		timer += 1;
	}
}
void dThunderCloud::endState_Wait() { }


// Lightning State
static void lightningCallback(ActivePhysics *one, ActivePhysics *two) {
	if (one->owner->profileId == ProfileId::EN_THUNDERCLOUD && two->owner->profileId == ProfileId::EN_THUNDERCLOUD)
		return;
	dEn_c::collisionCallback(one, two);
}

void dThunderCloud::lightningStrike() {
	PlaySound(this, SE_OBJ_KAZAN_ERUPTION);

	float boltsize = (leader-14.0)/2;
	float boltpos = -boltsize - 14.0;

	ActivePhysics::Info Shock;
	Shock.xDistToCenter = 0.0;
	Shock.yDistToCenter = boltpos;
	Shock.category1 = 0x3;
	Shock.category2 = 0x9;
	Shock.bitfield1 = 0x4D;

	Shock.bitfield2 = 0x420;
	Shock.xDistToEdge = 12.0;
	Shock.yDistToEdge = boltsize;

	Shock.unkShort1C = 0;
	Shock.callback = &dEn_c::collisionCallback;

	this->Lightning.initWithStruct(this, &Shock);
	this->Lightning.addToList();
}

void dThunderCloud::beginState_Lightning() {
	float backupY = pos.y, backupYSpeed = speed.y;

	speed.x = 0.0;
	speed.y = -1.0f;

	u32 result = 0;
	while (result == 0 && below.y > (-30 << 16)) {
		pos.y = backupY;
		below.y -= 0x4000;
		//OSReport("Sending out leader to %d", below.y>>12);

		result = collMgr.calculateBelowCollisionWithSmokeEffect();
		if (result == 0) {
			u32 tb1 = collMgr.getTileBehaviour1At(pos.x, pos.y + (below.y >> 12), 0);
			if (tb1 & 0x8000 && !(tb1 & 0x20))
				result = 1;
		}
		//OSReport("Result %d", result);
	}

	if (result == 0) {
		OSReport("Couldn't find any ground, falling back to 13 tiles distance");

		leader = 13 * 16;
	} else {
		OSReport("Lightning strikes at %d", below.y>>12);

		leader = -(below.y >> 12);
	}
	below.y = 0;

	pos.y = backupY;
	speed.y = backupYSpeed;

	if (usingEvents) {
		timer = 2;
		this->bindAnimChr_and_setUpdateRate("thundershoot", 1, 0.0, 1.0);
		lightningStrike();
	} else {
		timer = 0;
	}
}
void dThunderCloud::executeState_Lightning() {
	float boltsize, boltpos;
	switch (timer) {
		case 0:
			charge.spawn("Wm_en_birikyu", 0, &(Vec){pos.x, pos.y, pos.z}, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
			break;
		case 1:
			charge.spawn("Wm_en_birikyu", 0, &(Vec){pos.x, pos.y, pos.z}, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
			break;
		case 2:
			PlaySound(this, SE_BOSS_JR_ELEC_APP);
			PlaySound(this, SE_BOSS_JR_DAMAGE_ELEC);

			boltsize = (leader-14.0)/2;
			boltpos = -boltsize - 14.0;

			bolt.spawn("Wm_jr_electricline", 0, &(Vec){pos.x, pos.y + boltpos, pos.z}, &(S16Vec){0,0,0}, &(Vec){1.0, boltsize/36.0, 1.0});
			break;
		case 3:
			this->Lightning.removeFromList();
			charge.spawn("Wm_mr_electricshock_biri02_s", 0, &pos, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
			break;
		case 4:
			charge.spawn("Wm_mr_electricshock_biri02_s", 0, &pos, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
			break;
		case 5:
			if (stationary) { doStateChange(&StateID_Wait); }
			else 			{ doStateChange(&StateID_Follow); }
			break;
		default:
			charge.spawn("Wm_mr_electricshock_biri02_s", 0, &pos, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
			break;
	}

	if(this->anm.isAnimationDone() && this->anm.getCurrentFrame() != 0.0) {
		if (timer == 2 && usingEvents) {
			if (dFlagMgr_c::instance->flags & eventFlag) {
			} else {
				this->Lightning.removeFromList();
				doStateChange(&StateID_Wait);
			}
		} else {
			timer++;
			if (timer == 2) {
				this->bindAnimChr_and_setUpdateRate("thundershoot", 1, 0.0, 1.0);
				lightningStrike();
			} else if (timer == 3) {
				this->bindAnimChr_and_setUpdateRate("cloud_wait", 1, 0.0, 1.0);
			}
		}
		this->anm.setCurrentFrame(0.0);
	}
}

void dThunderCloud::endState_Lightning() {
	this->timer = 0;
}


// Thundercloud center = 0
// Thundercloud bottom = -12
// Thundercloud boltpos = -boltsize/2 - 14.0
// Thundercloud boltsize = (leader-14.0)/2
// Thundercloud effSize = 36.0 [*2]
// Thundercloud effScale = boltsize / effSize
// Thundercloud effPos = -boltsize/2 - 14.0



//
// processed\../src/makeYourOwnModelSprite.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profile.h>

// RYOMRes shit

const char* RYOMRes1ArcNameList [] = { "RYOMRes1", NULL };
const char* RYOMRes2ArcNameList [] = { "RYOMRes2", NULL };
const char* RYOMRes3ArcNameList [] = { "RYOMRes3", NULL };
const char* RYOMRes4ArcNameList [] = { "RYOMRes4", NULL };
const char* RYOMRes5ArcNameList [] = { "RYOMRes5", NULL };
const char* RYOMRes6ArcNameList [] = { "RYOMRes6", NULL };
const char* RYOMRes7ArcNameList [] = { "RYOMRes7", NULL };

class dRYOMRes_c : public dBase_c {
public:
	static dActor_c* build();
	mHeapAllocator_c allocator;
};

dActor_c* dRYOMRes_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dRYOMRes_c));
	return (dActor_c*)new(buffer) dRYOMRes_c;
}

const SpriteData RYOMRes1SpriteData = 
{ ProfileId::EN_RYOM_RES_1, 0, 0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 0 };

Profile RYOMRes1Profile(&dRYOMRes_c::build, SpriteId::EN_RYOM_RES_1, &RYOMRes1SpriteData, ProfileId::EN_RYOM_RES_1, ProfileId::EN_RYOM_RES_1, "EN_RYOM_RES_1", RYOMRes1ArcNameList);

const SpriteData RYOMRes2SpriteData = 
{ ProfileId::EN_RYOM_RES_2, 0, 0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 0 };

Profile RYOMRes2Profile(&dRYOMRes_c::build, SpriteId::EN_RYOM_RES_2, &RYOMRes2SpriteData, ProfileId::EN_RYOM_RES_2, ProfileId::EN_RYOM_RES_2, "EN_RYOM_RES_2", RYOMRes2ArcNameList);

const SpriteData RYOMRes3SpriteData = 
{ ProfileId::EN_RYOM_RES_3, 0, 0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 0 };

Profile RYOMRes3Profile(&dRYOMRes_c::build, SpriteId::EN_RYOM_RES_3, &RYOMRes3SpriteData, ProfileId::EN_RYOM_RES_3, ProfileId::EN_RYOM_RES_3, "EN_RYOM_RES_3", RYOMRes3ArcNameList);

const SpriteData RYOMRes4SpriteData = 
{ ProfileId::EN_RYOM_RES_4, 0, 0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 0 };

Profile RYOMRes4Profile(&dRYOMRes_c::build, SpriteId::EN_RYOM_RES_4, &RYOMRes4SpriteData, ProfileId::EN_RYOM_RES_4, ProfileId::EN_RYOM_RES_4, "EN_RYOM_RES_4", RYOMRes4ArcNameList);

const SpriteData RYOMRes5SpriteData = 
{ ProfileId::EN_RYOM_RES_5, 0, 0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 0 };

Profile RYOMRes5Profile(&dRYOMRes_c::build, SpriteId::EN_RYOM_RES_5, &RYOMRes5SpriteData, ProfileId::EN_RYOM_RES_5, ProfileId::EN_RYOM_RES_5, "EN_RYOM_RES_5", RYOMRes4ArcNameList);

const SpriteData RYOMRes6SpriteData = 
{ ProfileId::EN_RYOM_RES_6, 0, 0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 0 };

Profile RYOMRes6Profile(&dRYOMRes_c::build, SpriteId::EN_RYOM_RES_6, &RYOMRes6SpriteData, ProfileId::EN_RYOM_RES_6, ProfileId::EN_RYOM_RES_6, "EN_RYOM_RES_6", RYOMRes6ArcNameList);

const SpriteData RYOMRes7SpriteData = 
{ ProfileId::EN_RYOM_RES_7, 0, 0, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 0 };

Profile RYOMRes7Profile(&dRYOMRes_c::build, SpriteId::EN_RYOM_RES_7, &RYOMRes7SpriteData, ProfileId::EN_RYOM_RES_7, ProfileId::EN_RYOM_RES_7, "EN_RYOM_RES_7", RYOMRes7ArcNameList);

// actual RYOM sprite

//////////////////////////////////////////////////////////
//
//	How it works:
//
//		1) Skip down to line 131 - read the comments along the way if you like
//		2) Change the stuff inside " " to be what you want.
//		3) Copy paste an entire 'case' section of code, and change the number to change the setting it uses
//		4) give it back to Tempus to compile in
//



// This is the class allocator, you don't need to touch this
class dMakeYourOwn : public dStageActor_c {
	// Let's give ourselves a few functions
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	public: static dActor_c *build();

	// And a model and an anmChr
	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;
	nw4r::g3d::ResFile resFile;
	m3d::anmChr_c chrAnimation;

	nw4r::g3d::ResMdl mdl;

	// Some variables to use
	int model;
	bool isAnimating;
	float size;
	float zOrder;
	bool customZ;

	void setupAnim(const char* name, float rate);
	void setupModel(const char* arcName, const char* brresName, const char* mdlName);
};
const SpriteData RYOMSpriteData = {ProfileId::EN_RYOM, 0, 0, 0xFFFFFC00 ,0xFFFFFC00 ,0x400 ,0x400, 0, 0, 0, 0, 8};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile RYOMProfile(&dMakeYourOwn::build, SpriteId::EN_RYOM, &RYOMSpriteData, ProfileId::WM_KOOPA_CASTLE, ProfileId::EN_RYOM, "EN_RYOM", NULL, 0x2);

// This sets up how much space we have in memory
dActor_c *dMakeYourOwn::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dMakeYourOwn));
	return new(buffer) dMakeYourOwn;
}


// Saves space when we do it like this
void dMakeYourOwn::setupAnim(const char* name, float rate) {
	if (isAnimating) {
		nw4r::g3d::ResAnmChr anmChr;

		anmChr = this->resFile.GetResAnmChr(name);
		this->chrAnimation.setup(this->mdl, anmChr, &this->allocator, 0);
		this->chrAnimation.bind(&this->bodyModel, anmChr, 1);
		this->bodyModel.bindAnim(&this->chrAnimation, 0.0);
		this->chrAnimation.setUpdateRate(rate);
	}
}

void dMakeYourOwn::setupModel(const char* arcName, const char* brresName, const char* mdlName) {
	this->resFile.data = getResource(arcName, brresName);
	this->mdl = this->resFile.GetResMdl(mdlName);

	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
}


// This gets run when the sprite spawns!
int dMakeYourOwn::onCreate() {

	// Settings for your sprite!

	this->model = this->settings & 0xFF; 						// Sets nubble 12 to choose the model you want
	this->isAnimating = this->settings & 0x100;					// Sets nybble 11 to a checkbox for whether or not the model has an anmChr to use
	this->size = (float)((this->settings >> 24) & 0xFF) / 4.0; 	// Sets nybbles 5-6 to size. Size equals value / 4.


	float zLevels[16] = {-6500.0, -5000.0, -4500.0, -2000.0, 
						 -1000.0, 300.0, 800.0, 1600.0, 
						  2000.0, 3600.0, 4000.0, 4500.0, 
						  6000.0, 6500.0, 7000.0, 7500.0 };

	this->zOrder = zLevels[(this->settings >> 16) & 0xF];

	this->customZ = (((this->settings >> 16) & 0xF) != 0);

	// Setup the models inside an allocator
	allocator.link(-1, GameHeaps[0], 0, 0x20);


	// Makes the code shorter and clearer to put these up here

	// A switch case, add extra models in here
	switch (this->model) {

		// TITLESCREEN STUFF
		// DEFAULT 

		case 0:		//Red ballon, bobs

			setupModel("RYOMRes1", "g3d/bre0.brres", "ballon_red"); 
			SetupTextures_Item(&bodyModel, 0);
			this->pos.z = -3300.0;

			setupAnim("anim00", 1.0); 

			break;	

		case 1:		//Green ballon, bobs

			setupModel("RYOMRes1", "g3d/bre1.brres", "ballon_green"); 
			SetupTextures_Item(&bodyModel, 0);
			this->pos.z = 3300.0;

			setupAnim("anim01", 1.0); 
			break;	
			
		case 2:		// Mario, using "wait" with mouth open

			setupModel("RYOMRes1", "g3d/bre2.brres", "mario_ts"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = -3000.0;

			setupAnim("anim02", 1.0); 
			break;	
						
		case 3:		// Peach, custom anim, bobs

			setupModel("RYOMRes1", "g3d/bre3.brres", "peach_ts"); 
			SetupTextures_Enemy(&bodyModel, 0);
			this->pos.z = -3000.0;

			setupAnim("anim03", 1.0); 
			break;	

		case 4:		// Luigi with mouth open using "wait", bobs

			setupModel("RYOMRes1", "g3d/bre4.brres", "luigi_ts"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim04", 1.0); 
			break;	
			
		case 5:	 // Yellow Toad with mouth open, does wait, bobs

			setupModel("RYOMRes1", "g3d/bre5.brres", "toady_ts"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim05", 1.0); 
			break;	

		case 6:		// Blue Toad with mouth open, bobs head and himself

			setupModel("RYOMRes1", "g3d/bre6.brres", "toadb_ts"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim06", 1.0); 
			break;	
			
		// BOWSER BEAT TS
		
		case 7:		// Mario's clowncar, bobs, animates propeller

			setupModel("RYOMRes2", "g3d/bre7.brres", "clowncar_mario"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 3300.0;

			setupAnim("anim07", 1.0); 
			break;	
			
		case 8:		// Weegee clowncar, bobs, animates propeller, spins

			setupModel("RYOMRes2", "g3d/bre8.brres", "clowncar_luigi"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 3300.0;

			setupAnim("anim08", 2.0); 
			break;	
			
		case 9:		// Toad Yellow clowncar, bobs, animates propeller

			setupModel("RYOMRes2", "g3d/bre9.brres", "clowncar_toady"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 3300.0;

			setupAnim("anim09", 1.0); 
			break;	
			
		case 10:	// Toad Blue, bobs, animates propeller

			setupModel("RYOMRes2", "g3d/bre10.brres", "clowncar_toadb"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 3300.0;

			setupAnim("anim10", 1.0); 
			break;	
		
		case 11:	// Peach clowncar, bobs, animates propeller

			setupModel("RYOMRes2", "g3d/bre11.brres", "clowncar_peach"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 3300.0;

			setupAnim("anim11", 1.0); 
			break;	
	
		case 12:	// Mario in a clowncar, bobbing, with fist outstretched.
		
			setupModel("RYOMRes2", "g3d/bre12.brres", "mario_end"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim12", 1.0); 
			break;	
			
		case 13:	// Weegee failing

			setupModel("RYOMRes2", "g3d/bre13.brres", "luigi_end"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim13", 2.0); 
			break;	
			
		case 14:		// Toad Yellow, bobs head, bobs

			setupModel("RYOMRes2", "g3d/bre14.brres", "toady_end"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim14", 1.0);
			break;	
			
		case 15:		// Blue Toad, bobs head, bobs

			setupModel("RYOMRes2", "g3d/bre15.brres", "toadb_end"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim15", 1.0); 
			break;	
			
		case 16:		// Peach laughing, bobbing

			setupModel("RYOMRes2", "g3d/bre16.brres", "peach_end"); 
			SetupTextures_Enemy(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim16", 1.0); 
			break;	
			
	//PERFECT FILE TS
			
		case 17:		// This is the peach castle backdrop

			setupModel("RYOMRes1", "g3d/bre17.brres", "ground_perfect"); 
			SetupTextures_Map(&bodyModel, 0);
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 3300.0;

			setupAnim("anim17", 1.0); 
			break;	
			
		case 18:		// Mario very small, looking up.

			setupModel("RYOMRes1", "g3d/bre18.brres", "mario_perfect"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 3300.0;

			setupAnim("anim18", 1.0);
			break;	
			
		case 19:		// Weegee very small, looking up.

			setupModel("RYOMRes1", "g3d/bre19.brres", "luigi_perfect"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim19", 1.0); 
			break;	
			
		case 20:		// Yellow Toad, very small, looking up.

			setupModel("RYOMRes1", "g3d/bre16.brres", "toady_perfect"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim20", 1.0); 
			break;	
			
		case 21:		// Blue Toad, very small, looking up.

			setupModel("RYOMRes1", "g3d/bre16.brres", "toadb_perfect"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim21", 1.0); 
			break;	
			
		case 22:		// I don't think this is used, actually :|

			setupModel("RYOMRes1", "g3d/bre22.brres", "peach_perfect"); 
			SetupTextures_Enemy(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim22", 1.0); 
			break;	
			
		case 23:		// I don't think this is used, actually :|

			setupModel("RYOMRes1", "g3d/bre23.brres", "backdrop"); 
			SetupTextures_Map(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("anim23", 1.0); 
			break;	
			
	// A level thing
			
		case 24:		// Small cloud, bobs up and down

			setupModel("RYOMRes1", "g3d/bre24.brres", "cloud"); 
			SetupTextures_Item(&bodyModel, 0);
			this->pos.z = -3300.0;

			setupAnim("anim24", 1.0); 

			break;	
	
	// Here begins the ending crap 
	
		case 25:		// Ship fallen, with broken propellers and cannons.

			setupModel("RYOMRes7", "g3d/ShipFallen.brres", "KoopaShip"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("animation", 1.0);

			break;	
			
		case 26:		// A tree. From the ghost bg.

			setupModel("RYOMRes6", "g3d/tree_end.brres", "tree"); 
			SetupTextures_Map(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("animation", 1.0); 
			
			break;	
			
		case 27:		// Bowser, laying down, eyes closed. Medic? Medic!

			setupModel("RYOMRes7", "g3d/bowser_dead.brres", "koopa"); 
			SetupTextures_Boss(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("animation", 1.0);

			break;	
		
		case 28:		// A car. The animation has it tilted slightly. It's a bit darker than usual.

			setupModel("RYOMRes6", "g3d/clown_car_end.brres", "car"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 3000.0;

			setupAnim("animation", 1.0); 

			break;	
	//CREDITS SHIT
		case 29:		// Mario's clowncar, bobs, animates propeller

			setupModel("RYOMRes3", "g3d/bre29.brres", "clowncar_mario"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 0.0;

			setupAnim("anim29", 1.0); 
			break;	
			
		case 30:		// Weegee clowncar, bobs, animates propeller

			setupModel("RYOMRes3", "g3d/bre30.brres", "clowncar_luigi"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 0.0;

			setupAnim("anim30", 1.0); 
			break;	
			
		case 31:		// Toad Yellow clowncar, bobs, animates propeller

			setupModel("RYOMRes3", "g3d/bre31.brres", "clowncar_toady"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 0.0;

			setupAnim("anim31", 1.0); 
			break;	
			
		case 32:	// Toad Blue, bobs, animates propeller

			setupModel("RYOMRes3", "g3d/bre32.brres", "clowncar_toadb"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 0.0;

			setupAnim("anim32", 1.0); 
			break;	
		
		case 33:	// Peach clowncar, bobs, animates propeller

			setupModel("RYOMRes3", "g3d/bre33.brres", "clowncar_peach"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 0.0;

			setupAnim("anim33", 1.0); 
			break;	
	
		case 34:	// Mario in a clowncar, bobbing, with fist outstretched.
		
			setupModel("RYOMRes3", "g3d/bre34.brres", "mario_end"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 0;

			setupAnim("anim34", 1.0); 
			break;	
			
		case 35:	// Weegee 

			setupModel("RYOMRes3", "g3d/bre35.brres", "luigi_end"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 0.0;

			setupAnim("anim35", 1.0); 
			break;	
			
		case 36:		// Toad Yellow, bobs head, bobs

			setupModel("RYOMRes3", "g3d/bre36.brres", "toady_end"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 0.0;

			setupAnim("anim36", 1.0);
			break;	
			
		case 37:		// Blue Toad, bobs head, bobs

			setupModel("RYOMRes3", "g3d/bre37.brres", "toadb_end"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 0.0;

			setupAnim("anim37", 1.0); 
			break;	
			
		case 38:		// Peach laughing, bobbing

			setupModel("RYOMRes3", "g3d/bre38.brres", "peach_end"); 
			SetupTextures_Enemy(&bodyModel, 0);
			this->pos.z = 0.0;

			setupAnim("anim38", 1.0); 
			break;	
			
		case 39:		// PC Backdrop again

			setupModel("CreditsBG", "g3d/dupa.brres", "ground_perfect"); 
			SetupTextures_Map(&bodyModel, 0);
			this->pos.z = 0.0;

			setupAnim("anim38", 1.0); 
			break;	

		case 40:		// RYOMRes4 Canopy

			setupModel("RYOMRes4", "g3d/canopy.brres", "canopy"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 0.0;

			// setupAnim("anim38", 1.0); 
			break;	

		case 41:		// RYOMRes4 Canopy

			setupModel("RYOMRes4", "g3d/canopy_1.brres", "canopy_1"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 0.0;

			// setupAnim("anim38", 1.0); 
			break;	

		case 42:		// RYOMRes4 Canopy

			setupModel("RYOMRes4", "g3d/canopy_2.brres", "canopy_2"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 0.0;

			// setupAnim("anim38", 1.0); 
			break;	
		
		case 43:		// BallonR

			setupModel("RYOMRes5", "g3d/ballon.brres", "ballon_red"); 
			SetupTextures_Item(&bodyModel, 0);
			this->pos.z = 0.0;

				setupAnim("anim", 1.0); 
			break;	
			
		case 44:		// BallonG

			setupModel("RYOMRes5", "g3d/ballon2.brres", "ballon_green"); 
			SetupTextures_Item(&bodyModel, 0);
			this->pos.z = 0.0;

				setupAnim("anim", 1.0); 
			break;	
			
		case 45:		// Luigi Opening

			setupModel("RYOMRes5", "g3d/weeg.brres", "weeg"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 0.0;

				setupAnim("anim", 1.0); 
			break;	
			
		case 46:		// Mario Opening

			setupModel("RYOMRes5", "g3d/maleo.brres", "maleo"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 0.0;

				setupAnim("anim", 1.0); 
			break;	
			
		case 47:		// ToaB

			setupModel("RYOMRes5", "g3d/todb.brres", "todb"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 0.0;

				setupAnim("anim", 1.0); 
			break;	

		case 48:		// ToaY

			setupModel("RYOMRes5", "g3d/tody.brres", "tody"); 
			SetupTextures_Player(&bodyModel, 0);
			this->pos.z = 0.0;

				setupAnim("anim", 1.0); 
			break;	

		case 49:		// RYOMRes4 Canopy

			setupModel("RYOMRes4", "g3d/canopy_3.brres", "canopy_3"); 
			SetupTextures_MapObj(&bodyModel, 0);
			this->pos.z = 0.0;

			// setupAnim("anim38", 1.0); 
			break;	
	}

	allocator.unlink();

	if (size == 0.0) {	// If the person has the size nybble at zero, make it normal sized
		this->scale = (Vec){1.0,1.0,1.0};	
	}
	else {				// Else, use our size
		this->scale = (Vec){size,size,size};	
	}
		
	this->onExecute();
	return true;
}


// YOU'RE DONE, no need to do anything below here.


int dMakeYourOwn::onDelete() {
	return true;
}

int dMakeYourOwn::onExecute() {
	if (isAnimating) {
		bodyModel._vf1C();	// Advances the animation one update

		if(this->chrAnimation.isAnimationDone()) {
			this->chrAnimation.setCurrentFrame(0.0);	// Resets the animation when it's done
		}
	}

	return true;
}

int dMakeYourOwn::onDraw() {
	if (customZ) {
		matrix.translation(pos.x, pos.y, this->zOrder); }	// Set where to draw the model : -5500.0 is the official behind layer 2, while 5500.0 is in front of layer 0.
	else {
		matrix.translation(pos.x, pos.y, pos.z - 6500.0); }	// Set where to draw the model : -5500.0 is the official behind layer 2, while 5500.0 is in front of layer 0.

	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);	// Set how to rotate the drawn model 

	bodyModel.setDrawMatrix(matrix);	// Apply matrix
	bodyModel.setScale(&scale);			// Apply scale
	bodyModel.calcWorld(true);			// Do some shit

	bodyModel.scheduleForDrawing();		// Add it to the draw list for the game
	return true;
}

//
// processed\../src/challengeStar.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include <profile.h>

extern "C" bool SpawnEffect(const char*, int, Vec*, S16Vec*, Vec*);

extern int GlobalStarsCollected;


class dChallengeStar : public dEn_c {
	int onCreate();
	int onExecute();
	int onDelete();
	int onDraw();

	mHeapAllocator_c allocator;
	m3d::mdl_c bodyModel;

	mEf::es2 effect;

	u64 eventFlag;
	s32 timer;
	bool collected;

	public: static dActor_c *build();

	void updateModelMatrices();
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);

};


void dChallengeStar::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) { 

	if (collected) {
		this->Delete(1);
		return; }


	PlaySoundAsync(this, SE_OBJ_BROOM_KEY_SHOW);
	SpawnEffect("Wm_ob_greencoinkira_a", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.8, 0.8, 0.8});
	
	GlobalStarsCollected--;
	if (GlobalStarsCollected == 0) {
		dFlagMgr_c::instance->flags |= this->eventFlag;
	}
	
	collected = true;

	this->Delete(1);
}

void dChallengeStar::yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther) { this->playerCollision(apThis, apOther); }
bool dChallengeStar::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther) {
	this->playerCollision(apThis, apOther);
	return true;
}
bool dChallengeStar::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) {
	this->playerCollision(apThis, apOther);
	return true;
}
bool dChallengeStar::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) {
	this->playerCollision(apThis, apOther);
	return true;
}
bool dChallengeStar::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) {
	this->playerCollision(apThis, apOther);
	return true;
}
bool dChallengeStar::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther) {
	this->playerCollision(apThis, apOther);
	return true;
}

const char *ChallengeStarFileList[] = {0};
const SpriteData ChallengeStarSpriteData = { ProfileId::EN_SILVERSTAR, 0, 0, 0 , 0, 0x40, 0x10, 0, 0, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile ChallengeStarProfile(&dChallengeStar::build, SpriteId::EN_SILVERSTAR, &ChallengeStarSpriteData, ProfileId::WM_KURIBO, ProfileId::EN_SILVERSTAR, "EN_SILVERSTAR", ChallengeStarFileList, 0x20);


dActor_c *dChallengeStar::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dChallengeStar));
	return new(buffer) dChallengeStar;
}


int dChallengeStar::onCreate() {
	
	collected = false;
	char die = this->settings & 0xF;
	if (GetSpecificPlayerActor(die) == 0) { this->Delete(1); return 2; }

	GlobalStarsCollected++;

	allocator.link(-1, GameHeaps[0], 0, 0x20);

	nw4r::g3d::ResFile rf(getResource("I_star", "g3d/silver_star.brres"));
	bodyModel.setup(rf.GetResMdl("I_star"), &allocator, 0x224, 1, 0);
	SetupTextures_Map(&bodyModel, 0);

	allocator.unlink();
	
	ActivePhysics::Info HitMeBaby;
	HitMeBaby.xDistToCenter = 0.0;
	HitMeBaby.yDistToCenter = 3.0;
	HitMeBaby.xDistToEdge = 6.0;
	HitMeBaby.yDistToEdge = 6.0;
	HitMeBaby.category1 = 0x5;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x4F;
	HitMeBaby.bitfield2 = 0x200;
	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();

	char eventNum	= (this->settings >> 24)	& 0xFF;
	this->eventFlag = (u64)1 << (eventNum - 1);

	this->scale.x = 0.70;
	this->scale.y = 0.70;
	this->scale.z = 0.70;

	this->pos.x += 8.0;
	this->pos.y -= 14.0;
	this->pos.z = 3300.0;
	
	this->onExecute();
	return true;
}


int dChallengeStar::onDelete() {
	return true;
}

int dChallengeStar::onDraw() {
	bodyModel.scheduleForDrawing();
	return true;
}


void dChallengeStar::updateModelMatrices() {
	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);
	bodyModel.calcWorld(false);
}

int dChallengeStar::onExecute() {
	updateModelMatrices();

	effect.spawn("Wm_ob_keyget02_kira", 0, &this->pos, &(S16Vec){0,0,0}, &(Vec){0.8, 0.8, 0.8});
	this->rot.y += 0x200;
	return true;
}

//
// processed\../src/bonusRoom.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <profileid.h>
#include <sfx.h>
#include <playerAnim.h>
#include <stage.h>
#include <profile.h>

extern "C" void *MakeMarioEnterDemoMode();
extern "C" void *MakeMarioExitDemoMode();
extern "C" bool SpawnEffect(const char*, int, Vec*, S16Vec*, Vec*);
extern "C" void *StopBGMMusic();
extern "C" void *StartBGMMusic();
// extern "C" void *SoundRelatedClass;

// THIS IS A DUMB NAME
extern bool NoMichaelBuble;


// Controls the tempo for the songs.
// Lower numbers are faster, by a ratio factor.

int Tempo[16] = {13,11,12,12,
				 8,8,7,15,
				 15,8,10,16,
				 12,10,8,8};

int Songs[16][4][16][3] = {

	// 15

 	// First number is the block, Second is the note/sfx, Third is timing: 30 is one quarter note at 120 bpm, 0,0 ends the sequence

	// Some possibles
	// SMW Donut Plains
	// SMW Forest of Illusion
	// Paper Mario Battle Theme
	// Thwomp Volcano: PiT
	// SMRPG Forest?
	// SMRPG Nimbus Land?
	// Teehee Valley: Superstar Saga
	// SML Theme
	// Mario Sunshine Main Theme
	// Mario Kart DS Theme

	{ // Song 1 - Super Mario Bros Melody |***  |
		{{3,17,0},{3,17,2},{3,17,6},{1,13,10},{3,17,12},{5,20,16},{0,0,0}},
		{{1,13,0},{5,8,3},{3,5,6},{6,10,9},{7,12,11},{6,11,13},{6,10,14},{0,0,0}},
		{{1,13,0},{1,13,1},{1,13,3},{1,13,5},{2,15,6},{3,17,8},{1,13,9},{7,10,11},{6,8,12},{0,0,0}},
		{{1,13,0},{1,13,1},{1,13,3},{1,13,5},{2,15,6},{3,17,7},{0,0,0}}
	},

	{ // Song 2 - Super Mario Bros. Underground |**** |
		{{7,12,0},{7,24,2},{5,9,4},{5,21,6},{6,10,8},{6,22,10},{0,0,0}},
		{{3,5,0},{3,17,2},{1,2,4},{1,14,6},{2,3,8},{2,15,10},{0,0,0}},
		{{2,15,0},{1,14,1},{1,13,2},{7,12,3},{2,15,5},{1,14,7},{5,8,9},{4,7,11},{1,13,13},{0,0,0}},
		{{7,12,0},{4,18,1},{3,17,2},{2,16,3},{6,22,4},{5,21,5},{4,20,6},{2,15,10},{6,11,12},{6,10,14},{5,9,16},{5,8,18},{0,0,0}}
	},

	{ // Song 3 - SMB Starman |**   |
		{{4,6,0},{4,6,2},{4,6,4},{2,3,6},{4,6,7},{4,6,9},{2,3,11},{4,6,12},{2,3,13},{4,6,14},{0,0,0}},
		{{3,5,0},{3,5,2},{3,5,4},{1,1,6},{3,5,7},{3,5,9},{1,1,11},{3,5,12},{1,1,13},{3,5,14},{0,0,0}},
		{{4,18,0},{4,18,2},{4,18,4},{2,15,6},{4,18,7},{4,18,9},{2,15,11},{4,18,12},{2,15,13},{4,18,14},{0,0,0}},
		{{3,17,0},{3,17,2},{3,17,4},{1,13,6},{3,17,7},{3,17,9},{1,13,11},{3,17,12},{1,13,13},{3,17,14},{0,0,0}}
	},

	{ // Song 4 - SMB3 Clouds |*    |
		{{1,8,0},{6,20,4},{1,8,12},{2,9,16},{7,21,20},{0,0,0}},
		{{6,23,0},{5,20,4},{1,8,8},{3,17,16},{4,18,20},{1,14,24},{6,11,32},{0,0,0}},
		{{1,8,0},{6,20,4},{1,8,12},{2,9,16},{7,21,20},{0,0,0}},
		{{6,23,0},{5,20,4},{1,8,8},{3,17,16},{4,18,20},{1,14,24},{6,11,32},{0,0,0}}
	},

	{ // Song 5 - SMB3 Hammer Bros |*****|
		{{2,16,0},{3,17,2},{2,16,4},{3,17,6},{2,15,8},{1,13,10},{6,10,12},{1,13,14},{0,0,0}},
		{{2,16,0},{3,17,2},{2,16,4},{3,17,6},{2,15,8},{1,13,10},{6,10,12},{1,13,14},{1,13,18},{3,16,20},{2,15,21},{1,13,22},{6,10,26},{1,13,28},{0,0,0}},
		{{4,17,0},{4,17,2},{5,19,4},{6,20,6},{7,21,8},{4,17,10},{4,17,14},{3,15,16},{3,15,18},{2,14,20},{3,15,22},{0,0,0}},
		{{2,16,0},{3,17,2},{2,16,4},{3,17,6},{2,15,8},{1,13,10},{6,10,12},{1,13,14},{5,17,18},{5,17,20},{5,17,22},{5,17,24},{5,17,26},{5,17,28},{5,17,30},{0,0,0}}
	},

	{ // Song 6 - SMB3 Underwater |***  |
		{{1,8,0},{3,13,2},{6,20,4},{5,19,6},{7,22,10},{0,0,0}},
		{{5,19,14},{6,20,16},{4,17,18},{3,13,20},{1,8,22},{2,10,26},{0,0,0}},
		{{1,7,0},{2,8,2},{4,13,4},{6,20,6},{5,19,8},{7,22,12},{0,0,0}},
		{{5,19,16},{6,20,18},{0,0,0}}

		// Fuckin' too hard
		// {{1,8,0},{3,13,2},{6,20,4},{5,19,6},{7,22,10},{5,19,14},{6,20,16},{4,17,18},{3,13,20},{1,8,22},{2,10,26},{0,0,0}},
		// {{1,7,0},{2,8,2},{4,13,4},{6,20,6},{5,19,8},{7,22,12},{5,19,16},{6,20,18},{0,0,0}},
		// {{2,10,0},{3,13,2},{6,22,4},{5,21,6},{7,24,10},{6,22,14},{4,20,16},{1,8,18},{6,22,20},{4,20,22},{0,0,0}},
		// {{1,8,0},{2,11,2},{5,20,4},{4,18,6},{5,20,10},{3,16,14},{6,22,16},{5,20,24},{0,0,0}}
	},

	{ // Song 7 - SMW Castle |*    |
		{{5,9,0},{4,6,8},{1,1,12},{2,3,16},{4,6,20},{0,0,0}},
		{{1,1,0},{4,6,4},{7,13,8},{5,9,12},{4,8,20},{0,0,0}},
		{{3,16,0},{2,15,4},{1,13,8},{2,15,12},{1,10,20},{0,0,0}},
		{{2,15,0},{1,13,4},{2,15,8},{3,16,12},{1,15,20},{0,0,0}}
	},

	{ // Song 8 - SMW Theme |**   |
		{{6,10,0},{4,6,4},{1,1,7},{2,3,8},{4,6,9},{4,6,11},{0,0,0}},
		{{2,3,0},{1,1,1},{4,6,3},{4,6,5},{7,13,7},{6,10,9},{5,8,12},{0,0,0}},
		{{6,10,0},{4,6,4},{1,1,7},{2,3,8},{4,6,9},{4,6,11},{5,8,15},{6,10,16},{4,6,17},{1,1,18},{2,3,20},{4,6,23},{0,0,0}},
		{{1,13,0},{2,15,2},{1,13,4},{2,15,6},{1,13,8},{1,1,11},{7,11,12},{6,10,13},{5,8,14},{4,6,16},{0,0,0}}
	},

	{ // Song 9 - Yoshi Story Theme |*    |
		{{5,17,0},{6,19,4},{5,17,5},{6,19,6},{5,17,8},{0,0,0}},
		{{3,14,0},{4,15,4},{3,14,5},{4,15,6},{3,14,8},{0,0,0}},
		{{5,17,0},{6,19,4},{5,17,5},{6,19,6},{5,17,8},{0,0,0}},
		{{4,15,0},{3,14,1},{4,15,2},{3,14,4},{2,12,8},{1,10,9},{2,12,10},{1,10,12},{0,0,0}}
	},

	{ // Song 10 - SM64 Peaches Castle |***  |
		{{4,8,0},{5,10,6},{4,8,10},{3,7,14},{4,8,16},{6,13,18},{7,17,20},{0,0,0}},
		{{3,6,0},{4,8,6},{3,6,10},{2,5,14},{3,6,16},{5,12,18},{6,15,20},{0,0,0}},
		{{2,5,0},{3,6,6},{2,5,10},{1,4,14},{2,5,16},{4,10,18},{5,13,20},{0,0,0}},
		{{4,10,2},{5,12,4},{6,13,6},{7,15,8},{6,13,10},{7,15,12},{4,10,14},{5,12,18},{4,10,20},{5,12,22},{6,13,24},{6,13,28},{6,13,34},{6,13,36},{6,13,38},{0,0,0}}
	},

	{ // Song 11 - SM64 Koopa Road |***  |
		{{3,6,0},{1,1,10},{3,6,12},{7,16,14},{6,15,16},{5,11,18},{3,6,20},{0,0,0}},
		{{3,6,0},{2,4,6},{3,6,10},{5,11,12},{4,9,14},{5,11,16},{0,0,0}},
		{{3,6,0},{1,1,10},{3,6,12},{7,16,14},{6,15,16},{5,11,18},{3,6,20},{0,0,0}},
		{{1,1,0},{3,6,2},{7,18,4},{6,16,6},{5,15,10},{4,13,20},{5,15,22},{0,0,0}}
	},

	{ // Song 12 - Frappe Snowland |***  |
		{{1,14,2},{2,15,3},{3,17,4},{6,22,5},{3,17,7},{0,0,0}},
		{{2,15,0},{1,14,2},{2,15,4},{1,14,5},{6,10,7},{3,5,9},{4,7,10},{3,5,11},{0,0,0}},
		{{1,14,2},{2,15,3},{3,17,4},{6,22,5},{3,17,7},{0,0,0}},
		{{2,15,0},{1,14,2},{2,15,4},{1,14,5},{6,10,7},{6,10,9},{7,12,10},{6,10,11},{0,0,0}}
	},

	{ // Song 13 - Ghost Luigi Mansion theme |**** |
		{{7,17,2},{7,17,4},{7,17,6},{7,17,8},{4,13,12},{7,17,14},{6,16,16},{3,12,20},{0,0,0}},
		{{5,15,2},{5,15,4},{5,15,6},{5,15,8},{3,12,12},{5,15,14},{4,13,16},{2,11,22},{3,12,24},{1,5,28},{0,0,0}},
		{{7,17,2},{7,17,4},{7,17,6},{7,17,8},{4,13,12},{7,17,14},{6,16,16},{3,12,20},{0,0,0}},
		{{5,15,2},{5,15,4},{5,15,6},{5,15,8},{3,12,12},{5,15,14},{7,17,16},{5,15,18},{4,13,20},{3,12,22},{1,10,24},{0,0,0}}
	},

	{ // Song 14 - Desert |**   |
		{{6,9,0},{4,6,4},{3,5,12},{3,5,16},{4,6,18},{0,0,0}},
		{{6,9,0},{4,6,4},{3,5,12},{3,5,16},{4,6,18},{0,0,0}},
		{{4,13,0},{3,12,20},{5,14,22},{6,17,24},{5,14,26},{4,13,32},{0,0,0}},
		{{1,9,0},{2,11,2},{3,12,4},{5,14,8},{4,13,12},{0,0,0}}
	},

	{ // Song 15 - Gusty Garden Galaxy |*****|
		{{5,14,0},{4,13,10},{6,16,12},{5,14,14},{3,9,16},{1,6,26},{2,7,28},{3,9,30},{3,9,32},{2,7,38},{0,0,0}},
		{{6,16,0},{5,15,10},{7,18,12},{6,16,14},{4,14,16},{3,13,22},{2,11,26},{3,13,30},{2,11,32},{1,9,38},{0,0,0}},
		{{6,21,0},{5,20,10},{7,23,12},{6,21,14},{4,19,16},{3,18,22},{4,19,32},{3,18,42},{6,21,44},{4,19,46},{3,18,48},{1,16,54},{0,0,0}},
		{{5,18,0},{4,17,10},{6,19,12},{5,18,14},{4,16,16},{3,15,22},{5,18,26},{4,16,30},{2,14,32},{1,13,38},{2,14,44},{4,16,48},{0,0,0}}
	},

	{ // Song 16 - Overworld or Cave
		{{0,0,0}},
		{{0,0,0}},
		{{0,0,0}},
		{{0,0,0}}
	}
};

const char* Prizes[10][4] = {
	{ "I_kinoko", 		"g3d/I_kinoko.brres", 			"I_kinoko", 			"wait2" },
	{ "I_fireflower", 	"g3d/I_fireflower.brres", 		"I_fireflower", 		"wait2" },
	{ "I_propeller", 	"g3d/I_propeller.brres",	 	"I_propeller_model", 	"wait2" },
	{ "I_iceflower", 	"g3d/I_iceflower.brres", 		"I_iceflower", 			"wait2" },
	{ "I_penguin", 		"g3d/I_penguin.brres", 			"I_penguin", 			"wait2" },
	{ "I_kinoko_bundle","g3d/I_mini_kinoko.brres", 		"I_mini_kinoko", 		"wait2" },
	{ "I_star", 		"g3d/I_star.brres", 			"I_star", 				"wait2" },
	{ "I_hammer", 		"g3d/I_fireflower.brres", 		"I_fireflower", 			"wait2" },
	{ "I_kinoko_bundle","g3d/I_life_kinoko.brres", 		"I_life_kinoko", 		"wait2" },
	{ "obj_coin", 		"g3d/obj_coin.brres", 			"obj_coin", 			"wait2" }
};

const char* Notes[24] = {
	"sfx/3C",
	"sfx/3C#",
	"sfx/3D",
	"sfx/3D#",
	"sfx/3E",
	"sfx/3F",
	"sfx/3F#",
	"sfx/3G",
	"sfx/3G#",
	"sfx/3A",
	"sfx/3A#",
	"sfx/3B",
	"sfx/4C",
	"sfx/4C#",
	"sfx/4D",
	"sfx/4D#",
	"sfx/4E",
	"sfx/4F",
	"sfx/4F#",
	"sfx/4G",
	"sfx/4G#",
	"sfx/4A",
	"sfx/4A#",
	"sfx/4B"
};

const char* SAarcNameList [] = {
	"block_light",
	"block_light_color",
	"I_kinoko_bundle",
	NULL
};



/*****************************************************************************/
// Playing frickin' sounds

extern "C" void PlaySoundWithFunctionB4(void *spc, nw4r::snd::SoundHandle *handle, int id, int unk);
static nw4r::snd::StrmSoundHandle handle;

u8 hijackMusicWithSongName(const char *songName, int themeID, bool hasFast, int channelCount, int trackCount, int *wantRealStreamID);

void BonusMusicPlayer(int id) {
	if (handle.Exists())
		handle.Stop(0);

	int sID;
	hijackMusicWithSongName(Notes[id], -1, false, 2, 1, &sID);
	PlaySoundWithFunctionB4(SoundRelatedClass, &handle, sID, 1);
}



/*****************************************************************************/
// The Prize Model

class dSongPrize: public dEn_c {
public:
	int onCreate();
	int onDelete();
	int onExecute();
	int beforeDraw();
	int onDraw();

	void doSpin();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;
	m3d::mdl_c bodyModel;
	m3d::anmChr_c aw;

	int queue;
	int p;
	int timer;

	HermiteKey keysX[0x10];
	unsigned int Xkey_count;
	HermiteKey keysY[0x10];
	unsigned int Ykey_count;
	HermiteKey keysS[0x10];
	unsigned int Skey_count;

	USING_STATES(dSongPrize);
	DECLARE_STATE(Wait);
	DECLARE_STATE(Shrink);
	DECLARE_STATE(Spin);

	static dActor_c *build();
};

CREATE_STATE(dSongPrize, Wait);
CREATE_STATE(dSongPrize, Shrink);
CREATE_STATE(dSongPrize, Spin);

Profile SongPrizeProfile(&dSongPrize::build, ProfileId::EN_SONGPRIZE, NULL, ProfileId::WM_SINKSHIP, ProfileId::EN_SONGPRIZE, "EN_SONGPRIZE");

dActor_c *dSongPrize::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dSongPrize));
	return new(buffer) dSongPrize;
}

int dSongPrize::onCreate() {

	// Settings
	queue = this->settings & 0xF;
	int prize = this->settings >> 16;
	scale = (Vec){ 3.0, 3.0, 3.0 };

	p = prize;


	// Model creation
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	resFile.data = getResource(Prizes[p][0], Prizes[p][1]);
	nw4r::g3d::ResMdl mdl = resFile.GetResMdl(Prizes[p][2]);
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Item(&bodyModel, 0); // 800B42B0


	// Animation Assignment
	nw4r::g3d::ResAnmChr anmChr = resFile.GetResAnmChr("wait2");
	aw.setup(mdl, anmChr, &allocator, 0);
	aw.bind(&bodyModel, anmChr, 1);
	bodyModel.bindAnim(&aw, 0.0);
	aw.setUpdateRate(1.0);
	allocator.unlink();


	// Change State
	doStateChange(&dSongPrize::StateID_Wait);

	return true;
}

int dSongPrize::onDelete() {
	return true;
}

int dSongPrize::onExecute() {
	acState.execute();
	return true;
}

int dSongPrize::beforeDraw() { return 1; }
int dSongPrize::onDraw() {

	if (p == 9) {
		matrix.translation(pos.x, pos.y + (8.0 * scale.y), pos.z);
	}
	else {
		matrix.translation(pos.x, pos.y, pos.z);
	}

	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	bodyModel.setDrawMatrix(matrix);
	bodyModel.setScale(&scale);

	bodyModel.calcWorld(false);


	bodyModel.scheduleForDrawing();
	bodyModel._vf1C();

	if(this->aw.isAnimationDone())
		this->aw.setCurrentFrame(0.0);

	return true;
}

void dSongPrize::beginState_Wait() {}
void dSongPrize::executeState_Wait() {}
void dSongPrize::endState_Wait() {}

void dSongPrize::beginState_Shrink() {
	this->timer = 0;

	Xkey_count = 2;
	Ykey_count = 2;
	Skey_count = 2;

	// /* keysX[i] = { frame, value, slope }; */
	keysX[0] = (HermiteKey){ 0.0, pos.x, 0.8 };
	keysY[0] = (HermiteKey){ 0.0, pos.y, 0.8 };
	keysS[0] = (HermiteKey){ 0.0, 3.0, -0.8 };

	keysX[1] = (HermiteKey){ 60.0, pos.x + (30.0 * queue) - 172.0, 1.0 };
	keysY[1] = (HermiteKey){ 60.0, pos.y + 64.0, 1.0 };
	keysS[1] = (HermiteKey){ 60.0, 1.0, 0.0 };
}
void dSongPrize::executeState_Shrink() {
	float modX = GetHermiteCurveValue(timer, keysX, Xkey_count);
	float modY = GetHermiteCurveValue(timer, keysY, Ykey_count);
	//float modS = GetHermiteCurveValue(timer, keysS, Skey_count);
	float modS = 3.0f - (timer * (2.0f / 60.0f));

	pos = (Vec){ modX, modY, pos.z };
	scale = (Vec){ modS, modS, modS };

	if (timer == 60) { doStateChange(&StateID_Wait); }

	timer += 1;
}
void dSongPrize::endState_Shrink() {}

void dSongPrize::beginState_Spin() {
	this->timer = 0;

	Xkey_count = 2;
	keysX[0] = (HermiteKey){ 0.0, 0.0, 0.0 };
	keysX[1] = (HermiteKey){ 20.0, 65535.0, 0.0 };
}
void dSongPrize::executeState_Spin() {
	float modX = GetHermiteCurveValue(timer, keysX, Xkey_count);
	rot.y = (int)modX;

	if (timer == 20) { SpawnEffect("Wm_ob_flagget", 0, &(Vec){pos.x-10.0, pos.y-2.0, pos.z-100.0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0}); }
	if (timer == 30) { doStateChange(&StateID_Wait); }

	timer += 1;
}
void dSongPrize::endState_Spin() {}



class dSongBlock : public daEnBlockMain_c {
public:
	Physics::Info physicsInfo;

	int onCreate();
	int onDelete();
	int onExecute();
	int beforeDraw();
	int onDraw();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;
	m3d::mdl_c bodyModel;
	m3d::mdl_c glowModel;
	m3d::mdl_c deadModel;
	m3d::mdl_c deadglowModel;

	StageActorLight light;
	mHeapAllocator_c allocatorB;

	int note;
	int isGlowing;
	int glowTimer;
	int isDead;
	int standAlone;
	int item;

	void calledWhenUpMoveExecutes();
	void calledWhenDownMoveExecutes();
	void blockWasHit(bool isDown);
	void glow();
	void unglow();

	USING_STATES(dSongBlock);
	DECLARE_STATE(Wait);

	static dActor_c *build();
};

/*****************************************************************************/
// Sing Along

class dSingAlong : public dStageActor_c {
	public:
		static dSingAlong *instance;
		static dActor_c *build();

		void RegisterNote(int note);
		void addPowerups();

		int onCreate();
		int onDelete();
		int onExecute();
		int onDraw();

		//int beforeExecute() { return true; }
		int afterExecute(int) { return true; }

		dSingAlong() : state(this, &StateID_Intro) { }

		mHeapAllocator_c allocator;

		dSongPrize *PrizeModel;
		dSongPrize *Pa;
		dSongPrize *Pb;
		dSongPrize *Pc;
		dSongPrize *Pd;

		dSongBlock *SBa;
		dSongBlock *SBb;
		dSongBlock *SBc;
		dSongBlock *SBd;
		dSongBlock *SBe;
		dSongBlock *SBf;
		dSongBlock *SBg;

		int song;
		int prize[4];
 		int chorus;
		int currentNote;
		int endNote;
		int timer;
		int counter;
		int Powerups[10];
		int isResponding;
		int success;

		dStateWrapper_c<dSingAlong> state;

		// Intro, Call, Response, Display Prize, Failure, Win, Collect Prizes
		USING_STATES(dSingAlong);
		DECLARE_STATE(Intro);
		DECLARE_STATE(Call);
		DECLARE_STATE(Response);
		DECLARE_STATE(Prize);
		DECLARE_STATE(Failure);
		DECLARE_STATE(Win);
		DECLARE_STATE(Mistake);
};

const SpriteData SingAlongSpriteData = {ProfileId::AC_SINGALONG, 0x10, 0x10, 0, 0, 0x200, 0x200, 0, 0, 0x200, 0x200, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile SingAlongProfile(&dSingAlong::build, SpriteId::AC_SINGALONG, &SingAlongSpriteData, ProfileId::WM_KILLERBULLET, ProfileId::AC_SINGALONG, "AC_SINGALONG", SAarcNameList);

dSingAlong *dSingAlong::instance = 0;
dActor_c *dSingAlong::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dSingAlong));
	dSingAlong *c = new(buffer) dSingAlong;

	instance = c;
	return c;
}


/*****************************************************************************/
// Events
int dSingAlong::onCreate() {
	NoMichaelBuble = true;
	StageC4::instance->_1D = 1; // enable no-pause

	// Load in the settings
	this->song = this->settings & 0xF;
	this->prize[0] = (this->settings >> 28) & 0xF;
	this->prize[1] = (this->settings >> 24) & 0xF;
	this->prize[2] = (this->settings >> 20) & 0xF;
	this->prize[3] = (this->settings >> 16) & 0xF;
	this->chorus = -1;
	this->currentNote = 0;
	this->success = 0;

	this->Powerups[0] = 0; // Mushroom
	this->Powerups[1] = 0; // Fireflower
	this->Powerups[2] = 0; // Propeller
	this->Powerups[3] = 0; // Iceflower
	this->Powerups[4] = 0; // Penguin
	this->Powerups[5] = 0; // MiniShroom
	this->Powerups[6] = 0; // Starman
	this->Powerups[7] = 0; // Hammer
	this->Powerups[8] = 0; // 1-ups
	this->Powerups[9] = 0; // Coins

	// Create and prepare the blocks
	S16Vec rot = (S16Vec){0,0,0};
	float x = pos.x;
	float y = pos.y - 40.0;
	float z = pos.z;

	SBa = (dSongBlock*)create(ProfileId::EN_SONG_BLOCK, 1, &(Vec){x-96.0+(32.0*0), y, z}, &rot, 0);
	SBb = (dSongBlock*)create(ProfileId::EN_SONG_BLOCK, 2, &(Vec){x-96.0+(32.0*1), y, z}, &rot, 0);
	SBc = (dSongBlock*)create(ProfileId::EN_SONG_BLOCK, 3, &(Vec){x-96.0+(32.0*2), y, z}, &rot, 0);
	SBd = (dSongBlock*)create(ProfileId::EN_SONG_BLOCK, 4, &(Vec){x-96.0+(32.0*3), y, z}, &rot, 0);
	SBe = (dSongBlock*)create(ProfileId::EN_SONG_BLOCK, 5, &(Vec){x-96.0+(32.0*4), y, z}, &rot, 0);
	SBf = (dSongBlock*)create(ProfileId::EN_SONG_BLOCK, 6, &(Vec){x-96.0+(32.0*5), y, z}, &rot, 0);
	SBg = (dSongBlock*)create(ProfileId::EN_SONG_BLOCK, 7, &(Vec){x-96.0+(32.0*6), y, z}, &rot, 0);

	// // Trigger the intro state
	state.setState(&StateID_Intro);
	isResponding = 0;

	return true;
}

int dSingAlong::onExecute() {
	state.execute();

	return true;
}

int dSingAlong::onDraw() { return true; }

int dSingAlong::onDelete() {
	instance = 0;
	return 1;
}

/*****************************************************************************/
// Register a Note being played by the players
void dSingAlong::RegisterNote(int note) {
	nw4r::snd::SoundHandle handle;

	if (isResponding == 1) {

		if (note == Songs[song][chorus][currentNote][0]) {
			BonusMusicPlayer(Songs[song][chorus][currentNote][1]-1);
			// MapSoundPlayer(SoundRelatedClass, Notes[Songs[song][chorus][currentNote][1]-1], 1);
			currentNote += 1;
		}
		else {
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_MG_CMN_WIN_CLOSE, 1);
			isResponding = 0;
			state.setState(&StateID_Mistake);
		}
	}
}

/*****************************************************************************/
// Intro
CREATE_STATE(dSingAlong, Intro);

void dSingAlong::beginState_Intro() {}
void dSingAlong::endState_Intro() {}
void dSingAlong::executeState_Intro() {
	MakeMarioEnterDemoMode();
	state.setState(&StateID_Prize);
}

//*****************************************************************************/
// Prize
CREATE_STATE(dSingAlong, Prize);

void dSingAlong::beginState_Prize() {
	this->timer = 120;
}
void dSingAlong::executeState_Prize() {

	if ((timer == 120) && (chorus >= 0)) { // Play a nice success sound, and wait a second
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_MG_IH_PAIR_OK, 1);
		//PlaySound(this, SE_MG_IH_PAIR_OK); // SE_MG_IH_NICE or SE_MG_UH_NICE

		int p;
		p = prize[chorus];
		this->Powerups[p] += 1;
	}

	if ((timer == 60) && (chorus >= 0)) {
		if (chorus == 0) { Pa = PrizeModel; }
		if (chorus == 1) { Pb = PrizeModel; }
		if (chorus == 2) { Pc = PrizeModel; }
		if (chorus == 3) { Pd = PrizeModel; }

		PrizeModel->doStateChange(&dSongPrize::StateID_Shrink);
	}

	if (timer == 0) {
		chorus += 1;

		if (chorus == 4) {
			if (success != 4)
				state.setState(&StateID_Failure);
			else
				state.setState(&StateID_Win);
			return;
		}

		SpawnEffect("Wm_en_blockcloud", 0, &(Vec){pos.x, pos.y+32.0, pos.z+500.0}, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_OBJ_ITEM_APPEAR, 1);
		//PlaySound(this, SE_OBJ_ITEM_APPEAR); // SE_OBJ_GOOD_ITEM_APPEAR

		PrizeModel = (dSongPrize*)create(ProfileId::EN_SONGPRIZE, chorus + (prize[chorus] << 16), &pos, &rot, 0);
	}

	if (timer == -90) {
		state.setState(&StateID_Call);
	}

	timer -= 1;
}
void dSingAlong::endState_Prize() {}


//*****************************************************************************/
// Call
CREATE_STATE(dSingAlong, Call);

void dSingAlong::beginState_Call() {
	timer = 0;
	currentNote = 0;
}
void dSingAlong::executeState_Call() {
	if (timer == (Songs[song][chorus][currentNote][2] * Tempo[song])) {

		BonusMusicPlayer(Songs[song][chorus][currentNote][1]-1);

		Vec effPos;

		if      (Songs[song][chorus][currentNote][0] == 1) { SBa->glow(); effPos = SBa->pos; }
		else if (Songs[song][chorus][currentNote][0] == 2) { SBb->glow(); effPos = SBb->pos; }
		else if (Songs[song][chorus][currentNote][0] == 3) { SBc->glow(); effPos = SBc->pos; }
		else if (Songs[song][chorus][currentNote][0] == 4) { SBd->glow(); effPos = SBd->pos; }
		else if (Songs[song][chorus][currentNote][0] == 5) { SBe->glow(); effPos = SBe->pos; }
		else if (Songs[song][chorus][currentNote][0] == 6) { SBf->glow(); effPos = SBf->pos; }
		else if (Songs[song][chorus][currentNote][0] == 7) { SBg->glow(); effPos = SBg->pos; }

		SpawnEffect("Wm_en_vshit_ring", 0, &(Vec){effPos.x, effPos.y+8.0, effPos.z-100.0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});

		currentNote += 1;

		if (Songs[song][chorus][currentNote][0] == 0) {
			state.setState(&StateID_Response);
		}
	}

	timer += 1;
}
void dSingAlong::endState_Call() {
	MakeMarioExitDemoMode();
}


/*****************************************************************************/
// Response
CREATE_STATE(dSingAlong, Response);

void dSingAlong::beginState_Response() {
	timer = 0;
	currentNote = 0;
	isResponding = 1;
}
void dSingAlong::executeState_Response() {
	if (Songs[song][chorus][currentNote][0] == 0) {
		isResponding = 0;
		MakeMarioEnterDemoMode();
		this->success = this->success + 1;
		state.setState(&StateID_Prize);
	}
}
void dSingAlong::endState_Response() {}


//*****************************************************************************/
// Prize
CREATE_STATE(dSingAlong, Mistake);

void dSingAlong::beginState_Mistake() {
	SBa->unglow();
	SBb->unglow();
	SBc->unglow();
	SBd->unglow();
	SBe->unglow();
	SBf->unglow();
	SBg->unglow();

	MakeMarioEnterDemoMode();
	this->timer = 120;
	chorus += 1;
}
void dSingAlong::executeState_Mistake() {

	if (timer == 60) {
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_MG_IH_NOPAIR_NG, 1);

		SpawnEffect("Wm_en_blockcloud", 0, &(Vec){pos.x, pos.y+32.0, pos.z+500.0}, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
		PrizeModel->Delete(1);
	}

	if (chorus >= 4 && timer == 15) {
		state.setState(&StateID_Failure);
		return;
	}

	if (timer == 0) {
		SpawnEffect("Wm_en_blockcloud", 0, &(Vec){pos.x, pos.y+32.0, pos.z+500.0}, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_OBJ_ITEM_APPEAR, 1);

		PrizeModel = (dSongPrize*)create(ProfileId::EN_SONGPRIZE, chorus + (prize[chorus] << 16), &pos, &rot, 0);
	}

	if (timer == -90) {
		state.setState(&StateID_Call);
	}

	timer -= 1;
}
void dSingAlong::endState_Mistake() {

	if (chorus != 4) {
		SBa->isDead = 0;
		SBb->isDead = 0;
		SBc->isDead = 0;
		SBd->isDead = 0;
		SBe->isDead = 0;
		SBf->isDead = 0;
		SBg->isDead = 0;
	}
}

/*****************************************************************************/
// Failure
CREATE_STATE(dSingAlong, Failure);

void dSingAlong::beginState_Failure() {
	this->timer = 0;

	MakeMarioEnterDemoMode();
}
void dSingAlong::executeState_Failure() {
	if (timer == 5) {
		if (success == 0) {
			for (int i = 0; i < 4; i++)
				if (dAcPy_c *player = dAcPy_c::findByID(i))
					player->setAnimePlayWithAnimID(dm_surprise);
		}
		else {
			for (int i = 0; i < 4; i++)
				if (dAcPy_c *player = dAcPy_c::findByID(i)) {
					player->setAnimePlayWithAnimID(dm_glad);
					player->setFlag(0x24);
				}
		}
	}

	// Play a success/failure sound
	if (timer == 20) {
		StopBGMMusic();
		nw4r::snd::SoundHandle handle;

		if (success == 0)
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, STRM_BGM_MINIGAME_FANFARE_BAD, 1);
		else
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, STRM_BGM_MINIGAME_FANFARE_GOOD, 1);
	}

	// Delete the big powerup with a poof if it's fail
	// if (timer == 30*1) {
	// 	SpawnEffect("Wm_en_blockcloud", 0, &(Vec){pos.x, pos.y+32.0, pos.z+500.0}, &(S16Vec){0,0,0}, &(Vec){1.5, 1.5, 1.5});
	// 	nw4r::snd::SoundHandle handle;
	// 	PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_MG_IH_NOPAIR_OK, 1);
	// 	PrizeModel->Delete(1);
	// 	if (chorus == 0)
	// 		timer += 140;
	// }

	// Make the banked powerups do a little dance/effect
	// Play a sound for each powerup gained
	if (timer == 30*2 || timer == 30*3 || timer == 30*4 || timer == 30*5) {
		dSongPrize *dancer = 0;
		if (timer == 30*2)
			dancer = Pa;
		else if (timer == 30*3)
			dancer = Pb;
		else if (timer == 30*4)
			dancer = Pc;
		else if (timer == 30*5)
			dancer = Pd;

		if (dancer) {
			dancer->doStateChange(&dSongPrize::StateID_Spin);
			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_OBJ_ITEM_FROM_KINOPIO, 1);
		}
		else {
			timer += 29;
		}
	}

	// If victory, make mario do a little dance/sound
	if (timer == 30*7) {
		nw4r::snd::SoundHandle handle1, handle2, handle3, handle4;

		if (GetSpecificPlayerActor(0) != 0)
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle1, (success == 0) ? SE_VOC_MA_CS_COURSE_MISS : SE_VOC_MA_CLEAR_MULTI, 1);
		if (GetSpecificPlayerActor(1) != 0)
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle2, (success == 0) ? SE_VOC_LU_CS_COURSE_MISS : SE_VOC_LU_CLEAR_MULTI, 1);
		if (GetSpecificPlayerActor(2) != 0)
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle3, (success == 0) ? SE_VOC_KO_CS_COURSE_MISS : SE_VOC_KO_CLEAR_MULTI, 1);
		if (GetSpecificPlayerActor(3) != 0)
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle4, (success == 0) ? SE_VOC_KO2_CS_COURSE_MISS : SE_VOC_KO2_CLEAR_MULTI, 1);
	}


	// Add the powerups and exit the stage
	if (timer == 30*9) {
		this->addPowerups();
		ExitStage(ProfileId::WORLD_MAP, 0, BEAT_LEVEL, MARIO_WIPE);
	}
	timer += 1;
}
void dSingAlong::endState_Failure() {}


/*****************************************************************************/
// Win
CREATE_STATE(dSingAlong, Win);

void dSingAlong::beginState_Win() {
	this->timer = 0;
	MakeMarioEnterDemoMode();
}
void dSingAlong::executeState_Win() {
	if (timer == 5)
		for (int i = 0; i < 4; i++)
			if (dAcPy_c *player = dAcPy_c::findByID(i)) {
				player->setAnimePlayWithAnimID(dm_glad);
				player->setFlag(0x24);
			}

	// Play a success/failure sound
	if (timer == 30) {
		nw4r::snd::SoundHandle handle;
		PlaySoundWithFunctionB4(SoundRelatedClass, &handle, STRM_BGM_MINIGAME_FANFARE_GOOD, 1);
		StopBGMMusic();
	}

	// Make the banked powerups do a little dance/effect
	// Play a sound for each powerup gained
	if (timer == 30*3 || timer == 30*4 || timer == 30*5 || timer == 30*6) {
		dSongPrize *dancer = 0;
		if (timer == 30*3)
			dancer = Pa;
		else if (timer == 30*4)
			dancer = Pb;
		else if (timer == 30*5)
			dancer = Pc;
		else if (timer == 30*6)
			dancer = Pd;

		if (dancer) {
			dancer->doStateChange(&dSongPrize::StateID_Spin);
			nw4r::snd::SoundHandle handle;
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle, SE_OBJ_ITEM_FROM_KINOPIO, 1);
		}
		else {
			timer += 29;
		}
	}

	// If victory, make mario do a little dance/sound
	if (timer == 30*8) {
		nw4r::snd::SoundHandle handle1, handle2, handle3, handle4;

		if (GetSpecificPlayerActor(0) != 0)
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle1, SE_VOC_MA_CLEAR_MULTI, 1);
		if (GetSpecificPlayerActor(1) != 0)
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle2, SE_VOC_LU_CLEAR_MULTI, 1);
		if (GetSpecificPlayerActor(2) != 0)
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle3, SE_VOC_KO_CLEAR_MULTI, 1);
		if (GetSpecificPlayerActor(3) != 0)
			PlaySoundWithFunctionB4(SoundRelatedClass, &handle4, SE_VOC_KO2_CLEAR_MULTI, 1);

		SpawnEffect("Wm_ob_fireworks_y", 0, &(Vec){pos.x-80.0, pos.y+20.0, pos.z+500.0}, &(S16Vec){0,0,0}, &(Vec){0.75, 0.75, 0.75});
	}

	if (timer == (int)30*8.5) {
		SpawnEffect("Wm_ob_fireworks_b", 0, &(Vec){pos.x+108.0, pos.y+32.0, pos.z+500.0}, &(S16Vec){0,0,0}, &(Vec){0.75, 0.75, 0.75});
	}

	if (timer == 30*9) {
		SpawnEffect("Wm_ob_fireworks_g", 0, &(Vec){pos.x, pos.y+50.0, pos.z+500.0}, &(S16Vec){0,0,0}, &(Vec){0.75, 0.75, 0.75});
	}


	// Add the powerups and exit the stage
	if (timer == 30*11) {
		this->addPowerups();
		ExitStage(ProfileId::WORLD_MAP, 0, BEAT_LEVEL, MARIO_WIPE);
	}
	timer += 1;
}
void dSingAlong::endState_Win() {}


/*****************************************************************************/
// Add Powerups at the End of the Stage
void dSingAlong::addPowerups() {
	SaveFile *file = GetSaveFile();
	SaveBlock *block = file->GetBlock(file->header.current_file);

	for (int i = 0; i < 8; i++) { // Change this to 8 to support hammers
		block->new_powerups_available[i] = block->new_powerups_available[i] + this->Powerups[i];

		if (block->new_powerups_available[i] > 99) { block->new_powerups_available[i] = 99; }
	}

	for (int i = 0; i < 4; i++) { // Make sure all players get the reward!
		block->player_coins[i] = (this->Powerups[9] * 50) + block->player_coins[i];

		for (;block->player_coins[i] < 100; block->player_coins[i] - 100) {
			block->player_coins[i] = 1 + block->player_coins[i];
		}

		Player_Lives[i] = this->Powerups[8] + Player_Lives[i];
		if (Player_Lives[i] > 99) { Player_Lives[i] = 99; }
	}

	return;
}


/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/
// Replaces: Nothing yet



CREATE_STATE(dSongBlock, Wait);

const SpriteData SongBlockSpriteData = {ProfileId::EN_SONG_BLOCK, 0x10, 0x10, 0, 0, 0x200, 0x200, 0, 0, 0x200, 0x200, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile SongBlockProfile(&dSongBlock::build, SpriteId::EN_SONG_BLOCK, &SongBlockSpriteData, ProfileId::WM_KILLER, ProfileId::EN_SONG_BLOCK, "EN_SONG_BLOCK", SAarcNameList);

dActor_c *dSongBlock::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dSongBlock));
	return new(buffer) dSongBlock;
}


int dSongBlock::onCreate() {

	// Settings
	this->note = this->settings & 0xF;
	this->standAlone = (this->settings >> 4) & 0xF;
	this->item = (this->settings >> 16) & 0xFF;

	// Model creation
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	char modelName [24];
	sprintf(modelName, "g3d/block_light_%d.brres", this->note);

	this->resFile.data = getResource("block_light", modelName);
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("block_light");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_MapObj(&bodyModel, 0); // 800B42B0

	char glowName [25];
	sprintf(glowName, "g3d/block_light_g%d.brres", this->note);

	this->resFile.data = getResource("block_light", glowName);
	mdl = this->resFile.GetResMdl("block_light");
	glowModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_MapObj(&glowModel, 0); // 800B42B0



	// Dead Models
	this->resFile.data = getResource("block_light", "g3d/block_light_8.brres");
	mdl = this->resFile.GetResMdl("block_light");
	deadModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_MapObj(&deadModel, 0); // 800B42B0

	this->resFile.data = getResource("block_light", "g3d/block_light_g8.brres");
	mdl = this->resFile.GetResMdl("block_light");
	deadglowModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_MapObj(&deadglowModel, 0); // 800B42B0

	allocator.unlink();

	// Glow related
	isGlowing = 0;
	glowTimer = 0;
	isDead = 0;

	light.init(&allocatorB, 2);


	// Block Physics
	blockInit(pos.y);

	physicsInfo.x1 = -8;
	physicsInfo.y1 = 16;
	physicsInfo.x2 = 8;
	physicsInfo.y2 = 0;

	physicsInfo.otherCallback1 = &daEnBlockMain_c::OPhysicsCallback1;
	physicsInfo.otherCallback2 = &daEnBlockMain_c::OPhysicsCallback2;
	physicsInfo.otherCallback3 = &daEnBlockMain_c::OPhysicsCallback3;

	physics.setup(this, &physicsInfo, 3, currentLayerID);
	physics.flagsMaybe = 0x260;
	physics.callback1 = &daEnBlockMain_c::PhysicsCallback1;
	physics.callback2 = &daEnBlockMain_c::PhysicsCallback2;
	physics.callback3 = &daEnBlockMain_c::PhysicsCallback3;
	physics.addToList();

	// Change State
	doStateChange(&dSongBlock::StateID_Wait);

	return true;
}

int dSongBlock::onDelete() {
	physics.removeFromList();
	return true;
}

int dSongBlock::onExecute() {
	acState.execute();
	physics.update();
	blockUpdate();

	if (glowTimer > 0) { glowTimer--; }
	else { isGlowing = 0; }

	light.pos.x = pos.x;
	light.pos.y = pos.y+8.0;
	light.pos.z = pos.z;

	light.size = 226.0;
	light.update();

	// now check zone bounds based on state
	if (acState.getCurrentState()->isEqual(&StateID_Wait)) {
		checkZoneBoundaries(0);
	}

	return true;
}

int dSongBlock::beforeDraw() {
	light.draw();
	return dStageActor_c::beforeDraw();
}

int dSongBlock::onDraw() {
	matrix.translation(pos.x, pos.y+8.0, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	if (isDead == 0) {
		if (isGlowing == 0) {
			bodyModel.setDrawMatrix(matrix);
			bodyModel.setScale(&scale);
			bodyModel.calcWorld(false);

			bodyModel.scheduleForDrawing();
		}

		else {
			glowModel.setDrawMatrix(matrix);
			glowModel.setScale(&scale);
			glowModel.calcWorld(false);

			glowModel.scheduleForDrawing();
		}
	}
	else {
		if (isGlowing == 0) {
			deadModel.setDrawMatrix(matrix);
			deadModel.setScale(&scale);
			deadModel.calcWorld(false);

			deadModel.scheduleForDrawing();
		}

		else {
			deadglowModel.setDrawMatrix(matrix);
			deadglowModel.setScale(&scale);
			deadglowModel.calcWorld(false);

			deadglowModel.scheduleForDrawing();
		}
	}

	return true;
}

void dSongBlock::blockWasHit(bool isDown) {
	pos.y = initialY;

	SpawnEffect("Wm_en_vshit_ring", 0, &(Vec){pos.x, pos.y+8.0, pos.z-100.0}, &(S16Vec){0,0,0}, &(Vec){1.0, 1.0, 1.0});
	SpawnEffect("Wm_ob_keyget02_lighit", 0, &(Vec){pos.x, pos.y+8.0, pos.z-100.0}, &(S16Vec){0,0,0}, &(Vec){0.5, 0.5, 0.5});

	if (item > 0) {
		create(ProfileId::EN_ITEM, item, &(Vec){pos.x, pos.y, pos.z}, &rot, 0);
	}

	if (standAlone) {

		int play;
		// C, C#, D, D#, E, F, F#, G, G#, A, A#, B

		if 		(note == 0) { play = 12; }
		else if (note == 1) { play = 12; }
		else if (note == 2) { play = 14; }
		else if (note == 3) { play = 16; }
		else if (note == 4) { play = 17; }
		else if (note == 5) { play = 19; }
		else if (note == 6) { play = 21; }
		else if (note == 7) { play = 23; }
		else if (note == 8) { play = 0; }

		// nw4r::snd::SoundHandle handle;
		// PlaySoundWithFunctionB4(SoundRelatedClass, &handle, Notes[play], 1);
		BonusMusicPlayer(play);
	}
	else {
		dSingAlong::instance->RegisterNote(this->note);
	}

	physics.setup(this, &physicsInfo, 3, currentLayerID);
	physics.addToList();

	doStateChange(&StateID_Wait);
}

void dSongBlock::calledWhenUpMoveExecutes() {
	if (initialY >= pos.y)
		blockWasHit(false);
}

void dSongBlock::calledWhenDownMoveExecutes() {
	if (initialY <= pos.y)
		blockWasHit(true);
}

void dSongBlock::glow() {
	isGlowing = 1;
	isDead = 0;
	glowTimer = 15;
}

void dSongBlock::unglow() {
	isDead = 1;
	SpawnEffect("Wm_en_sanbohit_smk", 0, &(Vec){pos.x, pos.y+8.0, pos.z-100.0}, &(S16Vec){0,0,0}, &(Vec){0.4, 0.4, 0.4});
}

void dSongBlock::beginState_Wait() {}
void dSongBlock::endState_Wait() {}
void dSongBlock::executeState_Wait() {
	int result = blockResult();

	if (result == 0)
		return;

	if (result == 1) {
		glow();
		doStateChange(&daEnBlockMain_c::StateID_UpMove);
		anotherFlag = 2;
		isGroundPound = false;
	} else {
		glow();
		doStateChange(&daEnBlockMain_c::StateID_DownMove);
		anotherFlag = 1;
		isGroundPound = true;
	}
}



//
// processed\../src/pumpkinGoomba.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include <profileid.h>
#include <profile.h>

const char* GParcNameList [] = {
	"kuribo",
	"pumpkin",
	"wing",
	NULL	
};

class dGoombaPie : public dEn_c {
	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;
	m3d::mdl_c bodyModel;
	m3d::mdl_c burstModel;

	dStageActor_c *Goomber;
	u32 timer;
	bool isBursting;

	public: static dActor_c *build();

	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther);
	bool collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther);

	void _vf148();
	void _vf14C();
	bool CreateIceActors();
	void addScoreWhenHit(void *other);

	USING_STATES(dGoombaPie);
	DECLARE_STATE(Follow);
	DECLARE_STATE(Burst);
};

const SpriteData PumpkinGoombaSpriteData = { ProfileId::EN_PUMPKIN_GOOMBA, 8, 0x10, 0 , 0xFFFFFFF8, 8, 8, 0, 0, 0, 0, 0};
// #      -ID- ----  -X Offs- -Y Offs-  -RectX1- -RectY1- -RectX2- -RectY2-  -1C- -1E- -20- -22-  Flag ----
Profile PumpkinGoombaProfile(&dGoombaPie::build, SpriteId::EN_PUMPKIN_GOOMBA, &PumpkinGoombaSpriteData, ProfileId::WM_KINOKO_STAR, ProfileId::EN_PUMPKIN_GOOMBA, "EN_PUMPKIN_GOOMBA", GParcNameList, 0x12);

dActor_c *dGoombaPie::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dGoombaPie));
	return new(buffer) dGoombaPie;
}

///////////////////////
// Externs and States
///////////////////////
	extern "C" void *EN_LandbarrelPlayerCollision(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther);
	extern "C" int SmoothRotation(short* rot, u16 amt, int unk2);
	extern "C" char usedForDeterminingStatePress_or_playerCollision(dEn_c* t, ActivePhysics *apThis, ActivePhysics *apOther, int unk1);
	extern "C" bool SpawnEffect(const char*, int, Vec*, S16Vec*, Vec*);

	CREATE_STATE(dGoombaPie, Follow);
	CREATE_STATE(dGoombaPie, Burst);


////////////////////////
// Collision Functions
////////////////////////

	void pieCollisionCallback(ActivePhysics *one, ActivePhysics *two) {
		if (two->owner->profileId == ProfileId::EN_KURIBO) { return; }
		if (two->owner->profileId == ProfileId::EN_PATA_KURIBO) { return; }
		dEn_c::collisionCallback(one, two);
	}

	void dGoombaPie::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {

		char hitType;
		hitType = usedForDeterminingStatePress_or_playerCollision(this, apThis, apOther, 0);

		if(hitType == 1) {	// regular jump
			apOther->someFlagByte |= 2;
			doStateChange(&StateID_Burst);
		} 
		else if(hitType == 3) {	// spinning jump or whatever?
			apOther->someFlagByte |= 2;
			doStateChange(&StateID_Burst);
		} 
		else if(hitType == 0) {
			EN_LandbarrelPlayerCollision(this, apThis, apOther);
			if (this->pos.x > apOther->owner->pos.x) {
				this->direction = 1;
			}
			else {
				this->direction = 0;
			}
			doStateChange(&StateID_Burst);
		} 

		// fix multiple player collisions via megazig
		deathInfo.isDead = 0;
		this->flags_4FC |= (1<<(31-7));
		this->counter_504[apOther->owner->which_player] = 0;
	}

	void dGoombaPie::spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther) {}
	void dGoombaPie::yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther) { this->playerCollision(apThis, apOther); }
	bool dGoombaPie::collisionCatD_Drill(ActivePhysics *apThis, ActivePhysics *apOther) { doStateChange(&StateID_Burst); return true; }
	bool dGoombaPie::collisionCat7_GroundPound(ActivePhysics *apThis, ActivePhysics *apOther) { doStateChange(&StateID_Burst); return true; }
	bool dGoombaPie::collisionCat7_GroundPoundYoshi(ActivePhysics *apThis, ActivePhysics *apOther) { doStateChange(&StateID_Burst); return true; }
	bool dGoombaPie::collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) { doStateChange(&StateID_Burst); return true; }
	bool dGoombaPie::collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther){ doStateChange(&StateID_Burst); return true; }
	bool dGoombaPie::collisionCat13_Hammer(ActivePhysics *apThis, ActivePhysics *apOther) { doStateChange(&StateID_Burst); return true; }
	bool dGoombaPie::collisionCatA_PenguinMario(ActivePhysics *apThis, ActivePhysics *apOther){ doStateChange(&StateID_Burst); return true; }
	bool dGoombaPie::collisionCat14_YoshiFire(ActivePhysics *apThis, ActivePhysics *apOther){ doStateChange(&StateID_DieSmoke); return true; }
	bool dGoombaPie::collisionCat1_Fireball_E_Explosion(ActivePhysics *apThis, ActivePhysics *apOther) { doStateChange(&StateID_DieSmoke); return true; }

	// These handle the ice crap
	void dGoombaPie::_vf148() {
		dEn_c::_vf148();
		doStateChange(&StateID_Burst);
	}
	void dGoombaPie::_vf14C() {
		dEn_c::_vf14C();
		doStateChange(&StateID_Burst);
	}

	DoSomethingCool goombIceBlock;

	extern "C" void sub_80024C20(void);
	extern "C" void __destroy_arr(void*, void(*)(void), int, int);

	bool dGoombaPie::CreateIceActors()
	{
	    struct DoSomethingCool goombIceBlock = { 0, this->pos, {2.5, 2.5, 2.5}, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
	    this->frzMgr.Create_ICEACTORs( (void*)&goombIceBlock, 1 );
	    __destroy_arr( (void*)&goombIceBlock, sub_80024C20, 0x3C, 1 );
	    return true;
	}

	void dGoombaPie::addScoreWhenHit(void *other) {}


int dGoombaPie::onCreate() {

	// Model creation	
	allocator.link(-1, GameHeaps[0], 0, 0x20);

	this->resFile.data = getResource("pumpkin", "g3d/model.brres");
	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("Pumpkin");
	bodyModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&bodyModel, 0);

	mdl = this->resFile.GetResMdl("FX_Pumpkin");
	burstModel.setup(mdl, &allocator, 0x224, 1, 0);
	SetupTextures_Enemy(&burstModel, 0);

	allocator.unlink();


	// Other shit
	isBursting = false;
	this->scale = (Vec){0.39, 0.39, 0.39};

	ActivePhysics::Info HitMeBaby;

	HitMeBaby.xDistToCenter = 0.0;
	HitMeBaby.yDistToCenter = 12.0;

	HitMeBaby.xDistToEdge = 8.0;
	HitMeBaby.yDistToEdge = 14.0;		

	HitMeBaby.category1 = 0x3;
	HitMeBaby.category2 = 0x0;
	HitMeBaby.bitfield1 = 0x01;
	HitMeBaby.bitfield2 = 0x820A0;
	HitMeBaby.unkShort1C = 0;
	HitMeBaby.callback = &pieCollisionCallback;

	this->aPhysics.initWithStruct(this, &HitMeBaby);
	this->aPhysics.addToList();


	// Remember to follow a goomba
	if ((settings & 0xF) == 0) {
		Goomber = (dStageActor_c*)create(ProfileId::EN_KURIBO, 0, &pos, &rot, 0); }
	else {
		Goomber = (dStageActor_c*)create(ProfileId::EN_PATA_KURIBO, 0, &pos, &rot, 0); }
	// State Changers
	doStateChange(&StateID_Follow);

	this->onExecute();
	return true;
}

int dGoombaPie::onDelete() {
	return true;
}

int dGoombaPie::onExecute() {
	acState.execute();
	this->pos = Goomber->pos;
	this->rot = Goomber->rot;
	return true;
}

int dGoombaPie::onDraw() {
	matrix.translation(pos.x, pos.y + 4.0, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	if (isBursting) {
		burstModel.setDrawMatrix(matrix);
		burstModel.setScale(&scale);
		burstModel.calcWorld(false);
		burstModel.scheduleForDrawing();
	} else {
		bodyModel.setDrawMatrix(matrix);
		bodyModel.setScale(&scale);
		bodyModel.calcWorld(false);
		bodyModel.scheduleForDrawing();
	}

	return true;
}



///////////////
// Follow State
///////////////
	void dGoombaPie::beginState_Follow() { }
	void dGoombaPie::executeState_Follow() { }
	void dGoombaPie::endState_Follow() { }

///////////////
// Burst State
///////////////
	void dGoombaPie::beginState_Burst() { 
		this->timer = 0; 
		isBursting = true;
		this->removeMyActivePhysics();
		SpawnEffect("Wm_ob_eggbreak_yw", 0, &pos, &(S16Vec){0,0,0}, &(Vec){2.0, 2.0, 2.0});
	}
	void dGoombaPie::executeState_Burst() { 
		this->Delete(1);
	}
	void dGoombaPie::endState_Burst() { }

//
// processed\../src/exceptionHandler.cpp
//

#include "game.h"
#include "fileload.h"
#include "nsmbwVer.h"

#define GAME_NAME "NSMBWer+ 1.2.2 (DIRTY)"
const bool dsisrFun = false;
const bool gprFun = false;

u32 srr0;
const u32 dlcode = 0x80D26040;

struct OSContext
{
    u32 gpr[32];
    u32 cr;
    u32 lr;
    u32 ctr;
    u32 xer;
    double fpr[32];
    u8 unknown0[8];
    u32 srr[2];
    u8 unknown1[2];
    u16 flags;
    u32 gqr[8];
    u8 unknown2[4];
    float fppr[32];
};

/*inline bool GetBit(u32 num, char m)
{
    char n = 31 - m;
    return ((num >> n) & 1);
}
void ShowMainInfo(void * _osContext, u32 dsisr, u32 dar)
{
    void* osContext = _osContext;
    //osContext += 0x198;
    osContext = (void *)(((char *)osContext) + 0x198);
    srr0 = *(u32 *)(osContext);
    //osContext += 0x4;
    osContext = (void *)(((char *)osContext) + 0x4);
    u32 srr1 = *(u32 *)(osContext);

    nw4r::db::Exception_Printf_("SRR0:    %08X\n\n", srr0);

    if (srr1Fun)
    {
        //SRR1 fun.
        //Read 16-31
        char * enabled = "enabled.";
        char * disabled = "disabled.";
        nw4r::db::Exception_Printf_("External interrupt %s\n", (GetBit(srr1, 16) ? enabled : disabled));
        nw4r::db::Exception_Printf_("Privilege level: %s\n", (GetBit(srr1, 17) ? "user" : "supervisor"));
        nw4r::db::Exception_Printf_("Floating-point %s\n", (GetBit(srr1, 18) ? enabled : disabled));
        nw4r::db::Exception_Printf_("Machine check %s\n", (GetBit(srr1, 19) ? enabled : disabled));
        //
        nw4r::db::Exception_Printf_("Single-step trace %s\n", (GetBit(srr1, 21) ? enabled : disabled));
        nw4r::db::Exception_Printf_("Branch trace %s\n", (GetBit(srr1, 22) ? enabled : disabled));
        //
        //
        nw4r::db::Exception_Printf_("Exception prefix: %s\n", (GetBit(srr1, 25) ? "0xFFF....." : "0x000....."));
        nw4r::db::Exception_Printf_("Instruction address translation %s\n", (GetBit(srr1, 26) ? enabled : disabled));
        nw4r::db::Exception_Printf_("Data address translation %s\n", (GetBit(srr1, 27) ? enabled : disabled));
        //
        nw4r::db::Exception_Printf_("Process is %s (performance)\n", (GetBit(srr1, 29) ? "marked" : "not marked"));
        nw4r::db::Exception_Printf_("Exception is %s\n", (GetBit(srr1, 30) ? "recoverable" : "not recoverable"));
        nw4r::db::Exception_Printf_("%s endian mode\n\n", (GetBit(srr1, 31) ? "Little" : "Big"));
    }

    if (dsisrFun)
    {
        //DSISR fun.
        if (GetBit(dsisr, 0)) nw4r::db::Exception_Printf_("Crashed by load/store instruction\n");
        if (GetBit(dsisr, 1)) nw4r::db::Exception_Printf_("Attempted access translation not found\n");
        if (GetBit(dsisr, 4)) nw4r::db::Exception_Printf_("A memory access in not permitted\n");
        if (GetBit(dsisr, 5)) nw4r::db::Exception_Printf_("Store/load instruction performed at a bad address\n");
        nw4r::db::Exception_Printf_("Crashed by %s instruction\n", (GetBit(dsisr, 6) ? "store" : "load"));
        if (GetBit(dsisr, 9)) nw4r::db::Exception_Printf_("DABR match occurs\n");
        if (GetBit(dsisr, 11)) nw4r::db::Exception_Printf_("Instruction is eciwx or ecowx\n");
        nw4r::db::Exception_Printf_("\n");
    }
}*/
char *GetRegionAndVersion()
{
	NSMBWVer version = getNsmbwVer();
	switch(version)
	{
		case pal:
			return "PALv1";
		case pal2:
			return "PALv2";
		case ntsc:
			return "NTSCv1";
		case ntsc2:
			return "NTSCv2";
		case jpn:
			return "JPNv1";
		case jpn2:
			return "JPNv2";
		case kor:
			return "KOR";
		case twn:
			return "TWN";
		default:
			return "UNKNOWN";
	}
}
char *GetErrorDescription(u16 OSError)
{
    char *desc[] =
        {
            "SYSTEM RESET",
            "MACHINE CHECK",
            "DSI", "ISI",
            "EXTERNAL INTERRUPT",
            "ALIGNMENT",
            "PROGRAM",
            "FLOATING POINT",
            "DECREMENTER",
            "SYSTEM CALL",
            "TRACE",
            "PERFORMANCE MONITOR",
            "BREAKPOINT",
            "SYSTEM INTERRUPT",
            "THERMAL INTERRUPT",
            "PROTECTION",
            "FPE"};
    return desc[OSError];
}
void PrintContext(u16 OSError, void *_osContext, u32 _dsisr, u32 _dar)
{
    OSContext *osContext = (OSContext *)_osContext;
    nw4r::db::Exception_Printf_("Whoops! " GAME_NAME " has crashed - %s\n\nPlease send the information below to the mod creator\nYou can scroll through this report using the D-Pad.\n[%s]\n", GetErrorDescription(OSError), GetRegionAndVersion());
    nw4r::db::Exception_Printf_("SRR0: %08X | DSISR: %08X | DAR: %08X\n", osContext->srr[0]);

    if (gprFun)
    {
        int i = 0;
        do
        {
            nw4r::db::Exception_Printf_("R%02d:%08X  R%02d:%08X  R%02d:%08X\n", i, osContext->gpr[i], i + 0xB, osContext->gpr[i + 0xB], i + 0x16, osContext->gpr[i + 0x16]);
            i++;
        } while (i < 10);
        nw4r::db::Exception_Printf_("R%02d:%08X  R%02d:%08X\n\n", 10, osContext->gpr[10], 0x15, osContext->gpr[0x15]);
    }

    //Stack trace
    //nw4r::db::Exception_Printf_("\nException info trace (most recent on top):\n");
    int i = 0;
    u32 *stackPointer = (u32 *)((char *)nw4r::db::sException + 0x33C);
    do
    {
        if (stackPointer == 0 || (u32)stackPointer == 0xFFFFFFFF)
            break;

        nw4r::db::Exception_Printf_("%08X", stackPointer[1]);
        if (stackPointer[1] >= dlcode)
        {
            nw4r::db::Exception_Printf_(" - %08X NewerASM", stackPointer[1] - dlcode);
        }
        nw4r::db::Exception_Printf_("\n");

        i++;
        stackPointer = (u32 *)*stackPointer;
    } while (i < 0x10);
    //while (true);
}
//
// processed\../src/actors.cpp
//

#include <actors.h>
#include "nsmbwVer.h"

// Get the appropriate ID based on game version
Actors translateActorID(Actors id)
{
	NSMBWVer version = getNsmbwVer();
	switch(version)
	{
		case pal:
		case pal2:
		case ntsc:
		case ntsc2:
		case jpn:
		case jpn2:
		default: // unknown
			return adjustID(id);
			break;
		case kor:
		case twn:
			return id;
			break;
	}
}

Actors adjustID(Actors id)
{
	if(id > 703)
		return Actors(id - 2);
	if(id == 702 || id == 703) // wtf
		return Actors(id + 2);
	
	return id; // Actor is below id 702
}

//
// processed\../src/nsmbwVer.cpp
//

#include "nsmbwVer.h"
#include <game.h>

NSMBWVer getNsmbwVer()
{	
	u32 checkVer = *((u32*)0x800CF6CC);
	u32 checkKrTw;
	
	switch(checkVer)
	{
		case 0x40820030:
			return pal;
			break;
		case 0x40820038:
			return pal2;
			break;
		case 0x48000465:
			return ntsc;
			break;
		case 0x2c030000:
			return ntsc2;
			break;
		case 0x480000b4:
			return jpn;
			break;
		case 0x4082000c:
			return jpn2;
			break;
		case 0x38a00001:
			checkKrTw = *((u32*)0x80004238);
			if(checkKrTw == 0x6021c8e0) return kor;
			if(checkKrTw == 0x6021ace0) return twn;
			break;
	}
	return pal; // To appease the compiler warning gods
}
//
// processed\../src/unusedActorSprites.cpp
//

#include <game.h>
#include <profile.h>

const char* WaterliftFileList [] = {"lift_han_wood", NULL};
extern "C" dActor_c *dWaterLiftBuild();
const SpriteData WaterliftSpawnerSpriteData = { ProfileId::WATER_LIFT, 0, 0, 0 , 0, 0x10, 0x10, 0, 0, 0, 0, 8};
Profile WaterliftSpawnerProfile(&dWaterLiftBuild, SpriteId::WATER_LIFT, &WaterliftSpawnerSpriteData, ProfileId::WATER_LIFT, ProfileId::EN_KERONPA, "WATER_LIFT", WaterliftFileList, 2);
//
// processed\../src/worldmapManager.cpp
//

#include <game.h>
#include <common.h>
#include <profile.h>

//map manager actor, do whatever you want with it

int spawnMapManager() {
    dActor_c* worldmapManager = (dActor_c*)fBase_c::searchByProfileId(ProfileId::WM_MANAGER);
	if(!worldmapManager) {
		dActor_c::create(WM_MANAGER, 0, 0, 0);
	}
	return 0;
}

class dWMManager_c : public dActor_c {
public:
	static dActor_c* build();
	static dWMManager_c *instance;

	int onCreate();
};

dWMManager_c *dWMManager_c::instance = 0;

const char* WMManagerNameList[] = {0};
Profile WMManagerProfile(&dWMManager_c::build, ProfileId::WM_MANAGER, NULL, ProfileId::WM_SINKSHIP, ProfileId::WM_MANAGER, "WM_MANAGER", WMManagerNameList);

dActor_c* dWMManager_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(dWMManager_c));
	dWMManager_c *c = new(buffer) dWMManager_c;

	instance = c;
	return c;
}

int dWMManager_c::onCreate() {
	//grab save file
	SaveFile *file = GetSaveFile();
	SaveBlock *block = file->GetBlock(file->header.current_file);
	//check for the new bit
    if (!(block->bitfield & SAVE_BIT_NSMBWERPLUS)) {
		dStockItem_c *stockItem = (dStockItem_c*)searchByProfileId(ProfileId::STOCK_ITEM);
		//set new_powerups based off old ones
        for (int i = 0; i < 7; i++) {
			if (block->new_powerups_available[i] == 0) { //don't set if we've already got stuff in new_powerups
				block->new_powerups_available[i] = block->powerups_available[i];
				stockItem->newCounts[i] = block->new_powerups_available[i];
			}
        }
		//set our new bit
        block->bitfield |= SAVE_BIT_NSMBWERPLUS;
    }
	return true;
}
//
// processed\../src/starcoinmenu.cpp
//

#include <game.h>
#include <common.h>
#include <profile.h>
#include <sfx.h>

class dCollectionCoin_c : public dBase_c {
	public:
	u8 unk[0x420-sizeof(dBase_c)];
	dStateWrapper_c<dCollectionCoin_c> state;
	USING_STATES(dCollectionCoin_c);
	REF_NINTENDO_STATE(ExitAnimeEndWait);
};

extern "C" void CollectionCoinNextWorld(int dCoinCollection);
extern "C" void CollectionCoinPreviousWorld(int dCoinCollection);

static const int secretCode[] = {
	WPAD_UP,WPAD_UP,WPAD_DOWN,WPAD_DOWN,
	WPAD_LEFT,WPAD_RIGHT,WPAD_LEFT,WPAD_RIGHT,
	WPAD_ONE,WPAD_TWO,0
};
static const int secretCodeButtons = WPAD_UP|WPAD_DOWN|WPAD_LEFT|WPAD_RIGHT|WPAD_ONE|WPAD_TWO;
static int secretCodeIndex = 0;
static int minusCount = 0;
extern bool enableHardMode;
extern bool enableDebugMode;
extern u8 isReplayEnabled;

void addReplayAndHardMode(dCollectionCoin_c* self) {
	int nowPressed = Remocon_GetPressed(GetActiveRemocon());

	if ((GetActiveRemocon()->heldButtons == 0x810) && (nowPressed & 0x810)) {
		if (!enableHardMode) {
			enableHardMode = true;
			OSReport("Hard Mode enabled!\n");
			MapSoundPlayer(SoundRelatedClass, SE_VOC_MA_CS_COURSE_IN_HARD, 1);
		} else {
			enableHardMode = false;
			OSReport("Hard Mode disabled!\n");
		}
		return;
	}
	if (nowPressed & secretCodeButtons) {
		int nextKey = secretCode[secretCodeIndex];
		if (nowPressed & nextKey) {
			secretCodeIndex++;
			if (secretCode[secretCodeIndex] == 0) {
				secretCodeIndex = 0;
				if (isReplayEnabled != 100) {
					isReplayEnabled = 100;
					MapSoundPlayer(SoundRelatedClass, SE_VOC_MA_CS_COURSE_IN, 1);
					OSReport("Replay Recording enabled!\n");
				} else {
					isReplayEnabled = 0;
					OSReport("Replay Recording disabled!\n");
				}
			}
			return;
		} else {
			secretCodeIndex = 0;
		}
	}
	if (nowPressed & WPAD_MINUS) {
		minusCount++;
		if (minusCount >= 16) {
			minusCount = 0;

			enableDebugMode = !enableDebugMode;

			if (enableDebugMode) {
				MapSoundPlayer(SoundRelatedClass, SE_VOC_MA_GET_PRIZE, 1);
				OSReport("CollisionDebug enabled!\n");
			} else {
				OSReport("CollisionDebug disabled!\n");
			}
		}
	} else if (nowPressed & WPAD_RIGHT) {
		CollectionCoinNextWorld((int)self);
	} else if (nowPressed & WPAD_LEFT) {
		CollectionCoinPreviousWorld((int)self);
	} else if (nowPressed & WPAD_ONE) {
		self->state.setState(&dCollectionCoin_c::StateID_ExitAnimeEndWait);
	}
}
//
// processed\../src/worldmapScripts.cpp
//

#include <common.h>

typedef struct ScriptCommand {
    u32 type;
    u32 argument;
} ScriptCommand;


ScriptCommand Z_default_clr[] = {
    {140, 0},
    {115, 0},
    {128, 0},
    {0, 30},
    {114, 0},
    {158, 0},
    {159, 0},
    {115, 0},
    {60, 0},
    {2, 0},
    {112, 0},
    {153, 10},
    {151, 0},
    {113, 0},
    {153, 60},
    {152, 0},
    {153, 30},
    {96, 0},
    {97, 0},
    {98, 0},
    {4, 0},
    {155, 0},
    {156, 0},
    {80, 0},
    {111, 0},
    {150, 0},
    {83, 0},
    {109, 0},
    {129, 0},
    {130, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand Z_default_fail[] = {
    {0, 1},
    {141, 0},
    {128, 0},
    {0, 30},
    {135, 0},
    {4, 0},
    {113, 0},
    {155, 0},
    {80, 0},
    {129, 0},
    {130, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand Z_enemy_clr[] = {
    {161, 0},
    {0, 1},
    {141, 0},
    {128, 0},
    {110, 1},
    {162, 1},
    {82, 30},
    {89, 0},
    {90, 0},
    {4, 0},
    {92, 0},
    {113, 0},
    {155, 0},
    {130, 0},
    {166, 30},
    {80, 0},
    {129, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand Z_enemy_fail[] = {
    {164, 0},
    {0, 1},
    {141, 0},
    {128, 0},
    {110, 2},
    {0, 30},
    {55, 0},
    {11, 0},
    {4, 0},
    {113, 0},
    {155, 0},
    {166, 30},
    {80, 0},
    {129, 0},
    {130, 0},
    {164, 1},
    {141, 0},
    {5, 0},
};

ScriptCommand Z_toride_in[] = {
    {128, 0},
    {114, 0},
    {136, 0},
    {0, 10},
    {49, 0},
    {15, 0},
    {10, 0},
    {16, 0},
    {0, 5},
    {118, 0},
    {0, 20},
    {58, 0},
    {8, 5},
    {12, 0},
    {5, 0},
};

ScriptCommand Z_toride_clr[] = {
    {0, 2},
    {114, 0},
    {128, 0},
    {50, 0},
    {0, 30},
    {13, 0},
    {10, 1},
    {95, 0},
    {130, 0},
    {115, 0},
    {5, 0},
};

ScriptCommand Z_toride_fail[] = {
    {0, 2},
    {114, 0},
    {128, 0},
    {50, 0},
    {0, 30},
    {14, 0},
    {0, 20},
    {11, 1},
    {59, 0},
    {16, 0},
    {130, 0},
    {115, 0},
    {129, 0},
    {5, 0},
};

ScriptCommand Z_toride_fail2[] = {
    {0, 2},
    {114, 0},
    {128, 0},
    {50, 0},
    {0, 30},
    {14, 0},
    {0, 20},
    {11, 1},
    {130, 0},
    {115, 0},
    {129, 0},
    {5, 0},
};

ScriptCommand Z_castle_in[] = {
    {128, 0},
    {114, 0},
    {136, 0},
    {0, 10},
    {51, 0},
    {19, 0},
    {10, 0},
    {20, 0},
    {8, 5},
    {12, 0},
    {5, 0},
};

ScriptCommand Z_castle_clr[] = {
    {0, 2},
    {114, 0},
    {128, 0},
    {52, 0},
    {0, 30},
    {17, 0},
    {10, 1},
    {0, 60},
    {78, 0},
    {168, 0},
    {95, 0},
    {130, 0},
    {115, 0},
    {5, 0},
};

ScriptCommand Z_castle_fail[] = {
    {0, 2},
    {114, 0},
    {128, 0},
    {52, 0},
    {0, 30},
    {18, 0},
    {0, 20},
    {11, 1},
    {20, 0},
    {130, 0},
    {115, 0},
    {129, 0},
    {5, 0},
};

ScriptCommand Z_castle_fail2[] = {
    {0, 2},
    {114, 0},
    {128, 0},
    {52, 0},
    {0, 30},
    {18, 0},
    {0, 20},
    {11, 1},
    {130, 0},
    {115, 0},
    {129, 0},
    {5, 0},
};

ScriptCommand Z_ghost_in[] = {
    {128, 0},
    {114, 0},
    {136, 0},
    {0, 10},
    {53, 0},
    {21, 0},
    {10, 0},
    {23, 0},
    {137, 0},
    {8, 5},
    {12, 0},
    {5, 0},
};

ScriptCommand Z_ghost_clr[] = {
    {0, 2},
    {114, 0},
    {128, 0},
    {54, 0},
    {0, 30},
    {21, 0},
    {10, 1},
    {95, 0},
    {0, 60},
    {130, 0},
    {115, 0},
    {5, 0},
};

ScriptCommand Z_ghost_fail[] = {
    {0, 2},
    {114, 0},
    {128, 0},
    {54, 0},
    {0, 30},
    {22, 0},
    {0, 20},
    {11, 1},
    {139, 0},
    {24, 0},
    {130, 0},
    {115, 0},
    {129, 0},
    {5, 0},
};

ScriptCommand Z_ghost_fail2[] = {
    {0, 2},
    {114, 0},
    {128, 0},
    {54, 0},
    {0, 30},
    {22, 0},
    {0, 20},
    {11, 1},
    {25, 0},
    {130, 0},
    {115, 0},
    {129, 0},
    {5, 0},
};

ScriptCommand Z_cannon[] = {
    {0, 60},
    {26, 0},
    {27, 0},
    {28, 0},
    {0, 60},
    {29, 0},
    {30, 0},
    {65, 0},
    {5, 0},
};

ScriptCommand script_0x11[] = {
    {0, 60},
    {31, 0},
    {32, 0},
    {33, 0},
    {34, 0},
    {5, 0},
};

ScriptCommand Z_dokan[] = {
    {128, 0},
    {0, 10},
    {37, 0},
    {92, 0},
    {130, 0},
    {129, 0},
    {5, 0},
};

ScriptCommand Z_dokan_warp[] = {
    {0, 2},
    {128, 0},
    {0, 10},
    {8, 5},
    {38, 0},
    {5, 0},
};

ScriptCommand Z_dokan_start[] = {
    {0, 30},
    {36, 0},
    {130, 0},
    {5, 0},
};

ScriptCommand Z_W_Walking_in[] = {
    {0, 2},
    {140, 0},
    {128, 0},
    {0, 30},
    {40, 0},
    {41, 0},
    {0, 30},
    {42, 0},
    {43, 0},
    {64, 0},
    {84, 0},
    {113, 0},
    {155, 0},
    {81, 0},
    {92, 0},
    {80, 0},
    {79, 1},
    {109, 0},
    {129, 0},
    {130, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand Z_W_Walking_in_Normal[] = {
    {0, 2},
    {141, 0},
    {128, 0},
    {0, 30},
    {64, 0},
    {81, 0},
    {84, 0},
    {113, 0},
    {155, 0},
    {92, 0},
    {80, 0},
    {79, 1},
    {109, 0},
    {129, 0},
    {130, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand Z_W_Flying_in[] = {
    {0, 2},
    {140, 0},
    {128, 0},
    {0, 30},
    {40, 0},
    {41, 1},
    {0, 30},
    {42, 0},
    {43, 0},
    {64, 0},
    {113, 0},
    {81, 0},
    {84, 0},
    {155, 0},
    {92, 0},
    {80, 0},
    {79, 0},
    {129, 0},
    {130, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand Z_W_Cannon_in[] = {
    {0, 2},
    {140, 0},
    {128, 0},
    {0, 30},
    {40, 0},
    {41, 0},
    {0, 30},
    {42, 0},
    {43, 0},
    {66, 0},
    {81, 0},
    {84, 0},
    {113, 0},
    {155, 0},
    {0, 30},
    {79, 1},
    {109, 0},
    {129, 0},
    {130, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand Z_W_Cannon_in_Normal[] = {
    {0, 2},
    {141, 0},
    {128, 0},
    {0, 30},
    {66, 0},
    {84, 0},
    {113, 0},
    {155, 0},
    {165, 0},
    {109, 0},
    {129, 0},
    {130, 0},
    {5, 0},
};

ScriptCommand script_0x1a[] = {
    {0, 2},
    {140, 0},
    {128, 0},
    {44, 0},
    {0, 30},
    {50, 0},
    {45, 0},
    {0, 30},
    {114, 0},
    {13, 0},
    {10, 1},
    {95, 0},
    {130, 0},
    {115, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand script_0x1b[] = {
    {140, 0},
    {114, 0},
    {128, 0},
    {52, 0},
    {46, 0},
    {47, 0},
    {17, 0},
    {10, 1},
    {95, 1},
    {130, 0},
    {48, 2},
    {111, 0},
    {116, 5},
    {6, 0},
    {5, 0},
};

ScriptCommand Z_wSign_koopaCastle_in[] = {
    {140, 0},
    {114, 0},
    {128, 0},
    {52, 0},
    {46, 0},
    {47, 0},
    {0, 30},
    {67, 0},
    {17, 0},
    {10, 1},
    {92, 0},
    {95, 1},
    {130, 0},
    {115, 0},
    {0, 10},
    {69, 0},
    {70, 0},
    {68, 0},
    {71, 0},
    {92, 0},
    {0, 30},
    {3, 0},
    {129, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand script_0x1d[] = {
    {0, 120},
    {9, 0},
    {0, 60},
    {8, 0},
    {0, 30},
    {0, 60},
    {9, 0},
    {0, 60},
    {8, 0},
    {5, 0},
};

ScriptCommand Z_view_world[] = {
    {92, 0},
    {126, 0},
    {134, 0},
    {56, 0},
    {5, 0},
};

ScriptCommand Z_course_in[] = {
    {128, 0},
    {136, 0},
    {57, 0},
    {0, 30},
    {8, 5},
    {12, 0},
    {5, 0},
};

ScriptCommand Z_kinoko_out[] = {
    {128, 0},
    {0, 30},
    {60, 0},
    {5, 0},
};

ScriptCommand Z_airship_course_in[] = {
    {128, 0},
    {114, 0},
    {136, 0},
    {61, 0},
    {149, 0},
    {148, 0},
    {0, 30},
    {8, 5},
    {12, 0},
    {5, 0},
};

ScriptCommand Z_airship_course_out[] = {
    {0, 1},
    {141, 0},
    {114, 0},
    {128, 0},
    {127, 0},
    {0, 30},
    {62, 0},
    {11, 2},
    {130, 0},
    {115, 0},
    {129, 0},
    {5, 0},
};

ScriptCommand Z_start_kinoko_in[] = {
    {0, 30},
    {5, 0},
};

ScriptCommand script_0x24[] = {
    {140, 0},
    {114, 0},
    {164, 0},
    {128, 0},
    {0, 30},
    {62, 0},
    {11, 2},
    {130, 0},
    {0, 30},
    {63, 0},
    {48, 2},
    {111, 0},
    {116, 5},
    {6, 0},
    {5, 0},
};

ScriptCommand script_0x25[] = {
    {140, 0},
    {114, 0},
    {128, 0},
    {158, 0},
    {130, 0},
    {0, 30},
    {48, 2},
    {111, 0},
    {116, 5},
    {6, 0},
    {5, 0},
};

ScriptCommand Z_null[] = {
    {80, 0},
    {113, 0},
    {155, 0},
    {157, 0},
    {141, 0},
    {129, 0},
    {5, 0},
};

ScriptCommand Z_antlion[] = {
    {126, 0},
    {114, 0},
    {128, 0},
    {72, 0},
    {73, 0},
    {75, 0},
    {74, 0},
    {129, 0},
    {115, 0},
    {5, 0},
};

ScriptCommand Z_killer[] = {
    {114, 0},
    {128, 0},
    {76, 0},
    {86, 0},
    {8, 5},
    {77, 0},
    {5, 0},
};

ScriptCommand Z_start_battle[] = {
    {114, 0},
    {128, 0},
    {163, 0},
    {136, 0},
    {91, 0},
    {86, 0},
    {8, 5},
    {87, 0},
    {5, 0},
};

ScriptCommand Z_Switch[] = {
    {128, 0},
    {92, 0},
    {94, 0},
    {147, 0},
    {167, 0},
    {129, 0},
    {130, 0},
    {5, 0},
};

ScriptCommand Z_KoopaCastleAppear[] = {
    {140, 0},
    {114, 0},
    {128, 0},
    {0, 30},
    {99, 0},
    {100, 0},
    {115, 0},
    {101, 0},
    {92, 0},
    {130, 1},
    {0, 30},
    {102, 0},
    {0, 20},
    {108, 2},
    {0, 60},
    {104, 0},
    {103, 0},
    {108, 1},
    {0, 30},
    {105, 0},
    {131, 0},
    {3, 0},
    {0, 60},
    {106, 0},
    {107, 0},
    {129, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand Z_KinopioStart[] = {
    {0, 60},
    {113, 0},
    {5, 0},
};

ScriptCommand script_0x2d[] = {
    {0, 2},
    {128, 0},
    {121, 30},
    {119, 0},
    {121, 30},
    {59, 0},
    {121, 30},
    {120, 0},
    {64, 0},
    {84, 0},
    {113, 0},
    {155, 0},
    {92, 0},
    {80, 0},
    {79, 1},
    {109, 0},
    {129, 0},
    {130, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand script_0x2e[] = {
    {0, 2},
    {128, 0},
    {121, 30},
    {119, 0},
    {121, 30},
    {59, 0},
    {121, 30},
    {120, 0},
    {66, 0},
    {84, 0},
    {113, 0},
    {155, 0},
    {92, 0},
    {80, 0},
    {79, 1},
    {109, 0},
    {129, 0},
    {130, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand Z_Pause_Menu[] = {
    {154, 1},
    {0, 2},
    {92, 0},
    {134, 0},
    {114, 0},
    {123, 0},
    {124, 0},
    {122, 0},
    {130, 0},
    {115, 0},
    {154, 0},
    {5, 0},
};

ScriptCommand Z_airship_clear[] = {
    {140, 0},
    {114, 0},
    {128, 0},
    {127, 0},
    {0, 30},
    {62, 0},
    {11, 3},
    {130, 0},
    {115, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand Z_Stock_Menu[] = {
    {154, 1},
    {0, 2},
    {92, 0},
    {134, 0},
    {114, 0},
    {123, 0},
    {132, 0},
    {122, 0},
    {130, 0},
    {115, 0},
    {154, 0},
    {5, 0},
};

ScriptCommand Z_WorldSelect_Menu[] = {
    {154, 1},
    {0, 2},
    {92, 0},
    {134, 0},
    {114, 0},
    {123, 0},
    {133, 0},
    {122, 0},
    {130, 0},
    {115, 0},
    {154, 0},
    {5, 0},
};

ScriptCommand Z_antlion_star[] = {
    {126, 0},
    {114, 0},
    {128, 0},
    {72, 0},
    {73, 0},
    {143, 0},
    {142, 0},
    {74, 0},
    {144, 0},
    {129, 0},
    {115, 0},
    {5, 0},
};

ScriptCommand Z_GameStart[] = {
    {160, 0},
    {140, 0},
    {128, 0},
    {0, 0},
    {40, 0},
    {41, 0},
    {0, 30},
    {42, 0},
    {43, 0},
    {145, 0},
    {146, 0},
    {92, 0},
    {84, 0},
    {81, 0},
    {109, 0},
    {129, 0},
    {130, 0},
    {141, 0},
    {5, 0},
};

ScriptCommand *world_map_scripts_table[] = {
    Z_default_clr,
    Z_default_fail,
    Z_enemy_clr,
    Z_enemy_fail,
    Z_toride_in,
    Z_toride_clr,
    Z_toride_fail,
    Z_toride_fail2,
    Z_castle_in,
    Z_castle_clr,
    Z_castle_fail,
    Z_castle_fail2,
    Z_ghost_in,
    Z_ghost_clr,
    Z_ghost_fail,
    Z_ghost_fail2,
    Z_cannon,
    script_0x11,
    Z_dokan,
    Z_dokan_warp,
    Z_dokan_start,
    Z_W_Walking_in,
    Z_W_Walking_in_Normal,
    Z_W_Flying_in,
    Z_W_Cannon_in,
    Z_W_Cannon_in_Normal,
    script_0x1a,
    script_0x1b,
    Z_wSign_koopaCastle_in,
    script_0x1d,
    Z_view_world,
    Z_course_in,
    Z_kinoko_out,
    Z_airship_course_in,
    Z_airship_course_out,
    Z_start_kinoko_in,
    script_0x24,
    script_0x25,
    Z_null,
    Z_antlion,
    Z_killer,
    Z_start_battle,
    Z_Switch,
    Z_KoopaCastleAppear,
    Z_KinopioStart,
    script_0x2d,
    script_0x2e,
    Z_Pause_Menu,
    Z_airship_clear,
    Z_Stock_Menu,
    Z_WorldSelect_Menu,
    Z_antlion_star,
    Z_GameStart,
};
//
// processed\../src/waterGeyser.cpp
//

#include <common.h>
#include <game.h>
#include <g3dhax.h>
#include <sfx.h>
#include <profile.h>
#include "sandPillar.h"


const char* WaterGeyserArcNameList [] = {
	"water_geyser",
	NULL
};

const u8 WaterGeyserRiseDelayList[] = {
	125,	// 0
	123,	// 1
	121,	// 2
	124,	// 3
	118,	// 4
	112,	// 5
	109,	// 6
	113,	// 7
	110,	// 8
	107,	// 9
	104,	// 10
	104,	// 11
	101,	// 12
	97,		// 13
	94,		// 14
	90		// 15+
};

u8 lastPillarEffectType[] = {0, 0, 0, 0};

char* pillarEffect[] = {
	"Wm_mr_sprisesmoke",
	"Wm_mr_foot_water", // Wm_en_cmnwatertail, Wm_en_cmnwater, Wm_mr_foot_water
};

class daWaterGeyser_c : public daSandPillar_c {
	enum Mode {
		TimeControlled,
		EventControlled,
	};

	int onCreate();
	int onDelete();
	int onExecute();
	int onDraw();

	void bindAnimSrt_and_setUpdateRate(const char* name, m3d::mdl_c* mdl, m3d::anmTexSrt_c* animTexSrt, float rate);
	void executeSrtAnimations();
	bool areAllSrtAnimationsDone();

	mHeapAllocator_c allocator;
	nw4r::g3d::ResFile resFile;

	m3d::mdl_c model, modelTop, modelBehind;
	m3d::anmTexSrt_c anmTexSrt, anmTexSrtTop, anmTexSrtBehind;

	mMtx matrixTop, matrixBehind;

	mEf::es2 effect;
	int height, topHeight;
	Vec topScale;

	float topY, bottomY, totalHeight;
	u8 initialRiseDelay, riseDelay;
	u16 riseTime;
	float risePerFrame;

	int timer;
	daPlBase_c* players[4];
	float effectSize;
	Vec soundPos;

	Mode mode;

	u8 lastEvState;
	u8 newEvState;
	u8 offState;
	u64 triggeringEventID;
	bool invert, multiUse;

	nw4r::snd::SoundHandle handle; // Sound Handle

	bool ranOnce;

	StandOnTopCollider standOnTopCollider;
	ActivePhysics topAP;

	void updateModelMatrices();

	void spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void playerCollision(ActivePhysics *apThis, ActivePhysics *apOther);
	void yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther);

	bool collisionCat3_StarPower(ActivePhysics *apThis, ActivePhysics *apOther) { return false; }
	bool collisionCat9_RollingObject(ActivePhysics *apThis, ActivePhysics *apOther) { return false; }

	void doFunsuiStuffWithPlayers(bool force);
	void setSoundVolume();
	// void spawnWaterDrops();

	USING_STATES(daWaterGeyser_c);
	DECLARE_STATE(UpSignal);
	DECLARE_STATE(GoUp);
	DECLARE_STATE(Stabilize);
	DECLARE_STATE(WaitUp);
	DECLARE_STATE(GoDown);
	DECLARE_STATE(WaitDown);
	DECLARE_STATE(InitialWait);

	bool checkForEventTrigger(u8 lookForState);

	public: static dActor_c *build();
};

dActor_c *daWaterGeyser_c::build() {
	void *buffer = AllocFromGameHeap1(sizeof(daWaterGeyser_c));
	return new(buffer) daWaterGeyser_c;
}

const SpriteData WaterGeyserSpriteData = { ProfileId::WaterGeyser, 8, -14, 0, 0, 0x100, 0x100, 0, 0, 0, 0, 0x10 };
Profile WaterGeyserProfile(&daWaterGeyser_c::build, SpriteId::WaterGeyser, &WaterGeyserSpriteData, ProfileId::WaterGeyser, ProfileId::WaterGeyser, "WaterGeyser", WaterGeyserArcNameList, 0);

///////////////////////
// Externs and States
///////////////////////
CREATE_STATE(daWaterGeyser_c, UpSignal);
CREATE_STATE(daWaterGeyser_c, GoUp);
CREATE_STATE(daWaterGeyser_c, Stabilize);
CREATE_STATE(daWaterGeyser_c, WaitUp);
CREATE_STATE(daWaterGeyser_c, GoDown);
CREATE_STATE(daWaterGeyser_c, WaitDown);
CREATE_STATE(daWaterGeyser_c, InitialWait);

extern "C" int FUN_808027f0(daSandPillar_c * actor, daPlBase_c * player); // Returns 1 if player is in Funsui state, 0 otherwise (?)
// extern "C" void FUN_808028e0(daSandPillar_c * actor, daPlBase_c * player); // Tf is this
extern "C" uint FUN_80802d30(daSandPillar_c * actor, daPlBase_c * player); // Release Funsui for one player
// extern "C" void FUN_80802b40(daSandPillar_c *param_1); // Release Funsui (+ weird sand pillar stuff)

void daWaterGeyser_c::bindAnimSrt_and_setUpdateRate(const char* name, m3d::mdl_c* mdl, m3d::anmTexSrt_c* animTexSrt, float rate) {
	nw4r::g3d::ResAnmTexSrt animTexSrtRes = this->resFile.GetResAnmTexSrt(name);
	animTexSrt->bindEntry(mdl, animTexSrtRes, 0, 1);
	animTexSrt->bindEntry(mdl, animTexSrtRes, 1, 1);
	animTexSrt->bindEntry(mdl, animTexSrtRes, 2, 1);
	animTexSrt->setUpdateRate(rate);
	animTexSrt->setCurrentFrame(0.0);
	mdl->bindAnim(animTexSrt);
}

////////////////////////
// Collision Functions
////////////////////////
void daWaterGeyser_c::spriteCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
	daWaterGeyser_c *self = (daWaterGeyser_c*)apThis->owner;
	dEn_c *other = (dEn_c*)apOther->owner;

	if (other->stageActorType == other->EntityType) {
		if (self->aPhysics.left() <= other->aPhysics.left() && other->aPhysics.right() <= self->aPhysics.right()) {
			if (other->y_speed_inc >= 0.0) return;

			SpawnEffect("Wm_en_cmnwater", 0, &other->pos, &(S16Vec){0, 0, 0}, &(Vec){0.5, 0.5, 0.5});
			other->speed.y = 2.0;
		}
	}
}

void daWaterGeyser_c::playerCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
	daWaterGeyser_c *self = (daWaterGeyser_c*)apThis->owner;
	dAcPy_c *player = (dAcPy_c*)apOther->owner;

	int iVar2;
	if (iVar2 = FUN_808027f0(self, player), iVar2 != 0) {
		player->setFunsui();
		// FUN_808028e0(self, player);
		for (int i = 0; i < 4; i++) {
			daPlBase_c *p = GetPlayerOrYoshi(i);
			if (p != NULL && p == player && self->players[i] == NULL) {
				self->players[i] = p;
				lastPillarEffectType[i] = 1;
				break;
			}
		}
	}
}

void daWaterGeyser_c::yoshiCollision(ActivePhysics *apThis, ActivePhysics *apOther) {
	return playerCollision(apThis, apOther);
}

static void WaterGeyserPhysAboveCB1(daWaterGeyser_c *one, dStageActor_c *two) { }

static void WaterGeyserPhysBelowCB1(daWaterGeyser_c *one, dStageActor_c *two) { }

static void WaterGeyserPhysAdjCB1(daWaterGeyser_c *one, dStageActor_c *two, bool unkMaybeNotBool) { }

static bool WaterGeyserPhysAboveCB2(daWaterGeyser_c *one, dStageActor_c *two) {
	return (one->pos_delta.y > 0.0f);
}

static bool WaterGeyserPhysBelowCB2(daWaterGeyser_c *one, dStageActor_c *two) {
	return (one->pos_delta.y < 0.0f);
}

static bool WaterGeyserPhysAdjCB2(daWaterGeyser_c *one, dStageActor_c *two, bool unkMaybeNotBool) {
	return false;
}

void WaterGeyserTopCallback(ActivePhysics *apThis, ActivePhysics *apOther) {
	if (apOther->owner->stageActorType != dStageActor_c::PlayerType && apOther->owner->stageActorType != dStageActor_c::YoshiType) return;
	daPlBase_c *player = (daPlBase_c*)apOther->owner;

	if (!player->collMgr.isOnTopOfTile()) return;

	player->footnote_type = daPlBase_c::FOOTNOTE_WATER;
}

int daWaterGeyser_c::onCreate() {
	if(!this->ranOnce) {
		this->ranOnce = true;
		return false;
	}

	for (int i = 0; i < 4; i++) {
		this->players[i] = NULL;
	}

	int color = this->settings >> 20 & 0xF;
	float width = 0.25 + ((this->settings >> 16 & 0xF) * 0.25);
	if (width == 0.25) width = 1.0;
	u8 heightSetting = this->settings >> 8 & 0xFF;
	this->height = heightSetting + 6;
	this->topHeight = height * 15.5 - 4; // 15.5 seems to be the magic number here

	this->effectSize = width * 2.0;

	this->mode = (this->eventId1 >> 3 & 0x1) == 1 ? EventControlled : TimeControlled;

	char eventNum;
	switch (this->mode) {
		case EventControlled:
			eventNum = (int)this->settings & 0xFF;
			this->triggeringEventID = (u64)1 << (eventNum - 1);
			this->invert = (this->eventId1 >> 2) & 0x1;
			this->lastEvState = (int)(!this->invert);

			this->multiUse = (this->eventId1 >> 7) & 0x1;
			break;

		case TimeControlled:
			this->riseTime = (this->eventId1 >> 4 & 0xF) * 60;
			if (this->riseTime == 0) this->riseTime = 360;
			break;
	}

	this->initialRiseDelay = (this->eventId2 >> 4 & 0xF) * 10;
	this->riseDelay = (this->eventId2 & 0xF) + 30;
	if (this->riseDelay == 30) this->riseDelay = WaterGeyserRiseDelayList[min<u8>(heightSetting, 15)];

	allocator.link(-1, GameHeaps[0], 0, 0x20);

	char resName[16];
	getSpriteTexResName(resName, color);
	this->resFile.data = getResource("water_geyser", resName);


	nw4r::g3d::ResMdl mdl = this->resFile.GetResMdl("water_geyser");
	model.setup(mdl, &allocator, 0x224, 1, 0);

	nw4r::g3d::ResAnmTexSrt anmTexSrtRes = this->resFile.GetResAnmTexSrt("water_geyser");
	anmTexSrt.setup(mdl, anmTexSrtRes, &allocator, 0, 3);
	anmTexSrt.bindEntry(&model, anmTexSrtRes, 0, 1);
	anmTexSrt.bindEntry(&model, anmTexSrtRes, 1, 1);
	anmTexSrt.bindEntry(&model, anmTexSrtRes, 2, 1);
	anmTexSrt.setCurrentFrame(0.0);
	this->model.bindAnim(&anmTexSrt);


	nw4r::g3d::ResMdl mdlTop = this->resFile.GetResMdl("water_geyser_top");
	modelTop.setup(mdlTop, &allocator, 0x224, 1, 0);

	nw4r::g3d::ResAnmTexSrt anmTexSrtResTop = this->resFile.GetResAnmTexSrt("water_geyser_top");
	anmTexSrtTop.setup(mdlTop, anmTexSrtResTop, &allocator, 0, 3);
	anmTexSrtTop.bindEntry(&modelTop, anmTexSrtResTop, 0, 1);
	anmTexSrtTop.bindEntry(&modelTop, anmTexSrtResTop, 1, 1);
	anmTexSrtTop.bindEntry(&modelTop, anmTexSrtResTop, 2, 1);
	anmTexSrtTop.setCurrentFrame(0.0);
	this->modelTop.bindAnim(&anmTexSrtTop);


	nw4r::g3d::ResMdl mdlBehind = this->resFile.GetResMdl("water_geyser_behind");
	modelBehind.setup(mdlBehind, &allocator, 0x224, 1, 0);

	nw4r::g3d::ResAnmTexSrt anmTexSrtResBehind = this->resFile.GetResAnmTexSrt("water_geyser_behind");
	anmTexSrtBehind.setup(mdlBehind, anmTexSrtResBehind, &allocator, 0, 3);
	anmTexSrtBehind.bindEntry(&modelBehind, anmTexSrtResBehind, 0, 1);
	anmTexSrtBehind.bindEntry(&modelBehind, anmTexSrtResBehind, 1, 1);
	anmTexSrtBehind.bindEntry(&modelBehind, anmTexSrtResBehind, 2, 1);
	anmTexSrtBehind.setCurrentFrame(0.0);
	this->modelBehind.bindAnim(&anmTexSrtBehind);


	allocator.unlink();

	// Stuff I do understand

	this->scale = (Vec){width, height * 0.1, 1.0};
	this->topScale = (Vec){width, 1.0, 1.0};

	this->rot.x = 0; // X is vertical axis
	this->rot.y = 0; // Y is horizontal axis
	this->rot.z = 0; // Z is ... an axis >.>

	this->pos.z = 0.0;

	this->speed.x = 0.0;
	this->speed.y = 0.0;

	float w = 3.25 * 16 * width * 0.75;

	ActivePhysics::Info aPhysicsInfo;
	aPhysicsInfo.xDistToCenter = 0.0;
	aPhysicsInfo.yDistToCenter = 0.0;
	aPhysicsInfo.xDistToEdge = 2 * 16 * width;
	aPhysicsInfo.yDistToEdge = this->topHeight;
	aPhysicsInfo.category1 = 0x3;
	aPhysicsInfo.category2 = 0x16;
	aPhysicsInfo.bitfield1 = 0x2D;
	aPhysicsInfo.bitfield2 = 0x0;
	aPhysicsInfo.unkShort1C = 0x0;
	aPhysicsInfo.callback = &dEn_c::collisionCallback;

	this->aPhysics.initWithStruct(this, &aPhysicsInfo);


	standOnTopCollider.init(this, 0, 0, this->topHeight + 4, w + 2, -w - 2, this->rot.z, 1);
	standOnTopCollider.type = 0;
	standOnTopCollider._47 = 0; // SandPillar is 0xC
	standOnTopCollider.flags = 0;

	ActivePhysics::Info topAPInfo;
	topAPInfo.xDistToCenter = 0.0;
	topAPInfo.yDistToCenter = this->topHeight + 4;
	topAPInfo.xDistToEdge = w;
	topAPInfo.yDistToEdge = 2;
	topAPInfo.category1 = 0x3;
	topAPInfo.category2 = 0x16;
	topAPInfo.bitfield1 = 0x2D;
	topAPInfo.bitfield2 = 0x0;
	topAPInfo.unkShort1C = 0x0;
	topAPInfo.callback = &WaterGeyserTopCallback;

	this->topAP.initWithStruct(this, &topAPInfo);


	this->topY = this->pos.y;
	this->totalHeight = this->height * 16;
	this->bottomY = this->pos.y - this->totalHeight;

	this->pos.y = this->bottomY;

	this->soundPos = (Vec){this->pos.x, this->pos.y + this->topHeight + 16.0, this->pos.z};

	this->risePerFrame = (this->totalHeight / this->riseDelay);

	switch (this->mode) {
		case TimeControlled:
			if (this->initialRiseDelay > 0) doStateChange(&StateID_InitialWait);
			else doStateChange(&StateID_UpSignal);
			break;

		case EventControlled:
			if (this->invert) {
				if (this->initialRiseDelay > 0) doStateChange(&StateID_InitialWait);
				else doStateChange(&StateID_UpSignal);
			}
			else doStateChange(&StateID_WaitDown);
			break;
	}

	this->onExecute();
	return true;
}

int daWaterGeyser_c::onDelete() {
	this->standOnTopCollider.removeFromList();
	this->topAP.removeFromList();
	if (this->handle.Exists()) this->handle.Stop(0);
	return true;
}

int daWaterGeyser_c::onExecute() {
	acState.execute();
	updateModelMatrices();

	modelBehind._vf1C();
	anmTexSrtBehind.process();

	model._vf1C();
	anmTexSrt.process();

	modelTop._vf1C();
	anmTexSrtTop.process();

	standOnTopCollider.update();

	return true;
}

int daWaterGeyser_c::onDraw() {
	modelBehind.scheduleForDrawing();
	model.scheduleForDrawing();
	modelTop.scheduleForDrawing();
	return true;
}

void daWaterGeyser_c::updateModelMatrices() {
	// This won't work with wrap because I'm lazy.
	matrixBehind.translation(pos.x, pos.y, pos.z);
	matrixBehind.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	modelBehind.setDrawMatrix(matrixBehind);
	modelBehind.setScale(&scale);
	modelBehind.calcWorld(false);


	matrix.translation(pos.x, pos.y, pos.z);
	matrix.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	model.setDrawMatrix(matrix);
	model.setScale(&scale);
	model.calcWorld(false);


	matrixTop.translation(pos.x, pos.y + this->topHeight, pos.z + 1.0);
	matrixTop.applyRotationYXZ(&rot.x, &rot.y, &rot.z);

	modelTop.setDrawMatrix(matrixTop);
	modelTop.setScale(&topScale);
	modelTop.calcWorld(false);
}

void daWaterGeyser_c::executeSrtAnimations() {
	if (this->anmTexSrt.isEntryAnimationDone(0)) {
		this->anmTexSrt.setCurrentFrame(0.0);
	}
	if (this->anmTexSrtTop.isEntryAnimationDone(0)) {
		this->anmTexSrtTop.setCurrentFrame(0.0);
	}
	if (this->anmTexSrtBehind.isEntryAnimationDone(0)) {
		this->anmTexSrtBehind.setCurrentFrame(0.0);
	}
}

bool daWaterGeyser_c::areAllSrtAnimationsDone() {
	return this->anmTexSrt.isEntryAnimationDone(0) && this->anmTexSrtTop.isEntryAnimationDone(0) && this->anmTexSrtBehind.isEntryAnimationDone(0);
}

void daWaterGeyser_c::doFunsuiStuffWithPlayers(bool force = false) {
	for (int i = 0; i < 4; i++) {
		daPlBase_c *p = this->players[i];
		if (p == NULL) continue;

		if (
			p->aPhysics.right() < this->aPhysics.left() ||
			this->aPhysics.right() < p->aPhysics.left() ||
			p->aPhysics.bottom() > this->aPhysics.top() ||
			this->aPhysics.bottom() > p->aPhysics.top()
		) {
				this->players[i] = NULL;
				FUN_80802d30(this, p);

				if (this->aPhysics.top() <= p->aPhysics.top()) p->speed.y = 5.0;
		}
		else {
			p->speed.y = 2.0;
		}
	}
}

void daWaterGeyser_c::setSoundVolume() {
	setSoundDistance(&this->handle, this->soundPos, 0.75, 1.0, 750.0);
}

// void daWaterGeyser_c::spawnWaterDrops() {
// 	int w = ((int)(this->topAP.info.xDistToEdge / 12)) * 12;

// 	for (int i = -w; i <= w; i += 12) {
// 		Vec efxPos = { this->pos.x + i, this->pos.y + this->topAP.info.yDistToCenter, this->pos.z };
// 		SpawnEffect("", 0, &efxPos, &(S16Vec){0x8000, 0, 0}, &(Vec){this->effectSize, this->effectSize, this->effectSize}); // TODO: find a good effect
// 	}
// }

#define ACTIVATE	1
#define DEACTIVATE	0

bool daWaterGeyser_c::checkForEventTrigger(u8 lookForState) {
	bool eventTriggered = false;

	this->newEvState = 0;
	if (dFlagMgr_c::instance->flags & this->triggeringEventID) this->newEvState = 1;

	if (this->newEvState == this->lastEvState) return false;

	if (this->newEvState == lookForState) {
		this->offState = (this->newEvState == 1) ? 1 : 0;
		eventTriggered = true;
	}

	else this->offState = (this->newEvState == 1) ? 0 : 1;

	this->lastEvState = this->newEvState;

	return eventTriggered;
}

///////////////
// Up Signal State
///////////////
void daWaterGeyser_c::beginState_UpSignal() {
	this->timer = 0;
	SpawnEffect("Wm_en_cmnwater", 0, &this->soundPos, &(S16Vec){0, 0, 0}, &(Vec){this->effectSize, this->effectSize, this->effectSize});
	playSoundDistance(&this->handle, this->soundPos, SE_PLY_SPLASH_OUT, 1.5, 1.0, 750.0);
	playSoundDistance(&this->handle, this->soundPos, SE_BOSS_WENDY_WATER_UP, 0.75, 1.0, 750.0);
}
void daWaterGeyser_c::executeState_UpSignal() {
	if (this->timer >= 30) return doStateChange(&StateID_GoUp);
	setSoundVolume();
	this->timer++;
}
void daWaterGeyser_c::endState_UpSignal() { }

///////////////
// Go Up State
///////////////
void daWaterGeyser_c::beginState_GoUp() {
	this->bindAnimSrt_and_setUpdateRate("water_geyser", &this->model, &this->anmTexSrt, 1.0);
	this->bindAnimSrt_and_setUpdateRate("water_geyser_behind", &this->modelBehind, &this->anmTexSrtBehind, 1.0);
	this->bindAnimSrt_and_setUpdateRate("water_geyser_top", &this->modelTop, &this->anmTexSrtTop, 1.0);

	this->standOnTopCollider.addToList();
	this->topAP.addToList();
	this->aPhysics.addToList();
	this->pos.y = this->bottomY;
	this->timer = 0;
}
void daWaterGeyser_c::executeState_GoUp() {
	this->executeSrtAnimations();
	// this->spawnWaterDrops();

	if (this->timer >= this->riseDelay) return doStateChange(&StateID_Stabilize);
	this->pos.y += this->risePerFrame;
	this->timer++;

	this->doFunsuiStuffWithPlayers();
	setSoundVolume();
}
void daWaterGeyser_c::endState_GoUp() { }

///////////////
// Stabilize State
///////////////
void daWaterGeyser_c::beginState_Stabilize() {
	this->pos.y = this->topY;
	this->timer = 0;
}
void daWaterGeyser_c::executeState_Stabilize() {
	this->executeSrtAnimations();
	// this->spawnWaterDrops();

	if (this->timer >= 150) return doStateChange(&StateID_WaitUp);
	this->pos.y = this->topY + sin(((float)this->timer / 150.0) * 2.0 * M_PI) * 8.0;
	this->timer++;

	this->doFunsuiStuffWithPlayers();
	setSoundVolume();
}
void daWaterGeyser_c::endState_Stabilize() {
	this->pos.y = this->topY;
}

///////////////
// Wait Up State
///////////////
void daWaterGeyser_c::beginState_WaitUp() {
	this->timer = 0;
}
void daWaterGeyser_c::executeState_WaitUp() {
	this->executeSrtAnimations();
	// this->spawnWaterDrops();

	switch (this->mode) {
		case TimeControlled:
			if (this->timer >= this->riseTime) return doStateChange(&StateID_GoDown);
			this->timer++;
			break;

		case EventControlled:
			if (this->checkForEventTrigger(this->invert ? ACTIVATE : DEACTIVATE)) {
				return doStateChange(&StateID_GoDown);
			}
			break;
	}


	this->doFunsuiStuffWithPlayers();
	setSoundVolume();
}
void daWaterGeyser_c::endState_WaitUp() { }

///////////////
// Go Down State
///////////////
void daWaterGeyser_c::beginState_GoDown() {
	this->bindAnimSrt_and_setUpdateRate("water_geyser_end", &this->model, &this->anmTexSrt, 1.0);
	this->bindAnimSrt_and_setUpdateRate("water_geyser_behind_end", &this->modelBehind, &this->anmTexSrtBehind, 1.0);
	this->bindAnimSrt_and_setUpdateRate("water_geyser_top_end", &this->modelTop, &this->anmTexSrtTop, 1.0);

	if (this->handle.Exists()) this->handle.Stop((int)this->anmTexSrt.getFrameForEntry(0));
}
void daWaterGeyser_c::executeState_GoDown() {
	if (this->areAllSrtAnimationsDone()) {
		return doStateChange(&StateID_WaitDown);
	}

	this->doFunsuiStuffWithPlayers();
}
void daWaterGeyser_c::endState_GoDown() {
	this->aPhysics.removeFromList();
	this->standOnTopCollider.removeFromList();
	this->topAP.removeFromList();
	this->doFunsuiStuffWithPlayers(true);
	// FUN_80802b40(this);
	this->pos.y = this->bottomY;
}

///////////////
// Wait Down State
///////////////
void daWaterGeyser_c::beginState_WaitDown() {
	this->doFunsuiStuffWithPlayers(true);
	this->timer = 0;
}
void daWaterGeyser_c::executeState_WaitDown() {
	switch (this->mode) {
			case TimeControlled:
				if (this->timer >= this->riseDelay) return doStateChange(&StateID_UpSignal);
				this->timer++;
				break;

			case EventControlled:
				if (this->checkForEventTrigger(this->invert ? DEACTIVATE : ACTIVATE)) {
					if (this->initialRiseDelay > 0) doStateChange(&StateID_InitialWait);
					else doStateChange(&StateID_UpSignal);
				}
				break;
		}
}
void daWaterGeyser_c::endState_WaitDown() { }

///////////////
// Initial Wait State
///////////////
void daWaterGeyser_c::beginState_InitialWait() {
	this->timer = 0;
}
void daWaterGeyser_c::executeState_InitialWait() {
	if (this->timer >= this->initialRiseDelay) return doStateChange(&StateID_UpSignal);
	this->timer++;
}
void daWaterGeyser_c::endState_InitialWait() { }



//////////////////////////////////////////////////////////////////
// Sand Pillar Related Stuff
//////////////////////////////////////////////////////////////////

extern "C" void FUN_8008fba0(int playerNum, mEf::levelEffect_c *effect, char *effName, uint creatorId, Vec *pos, S16Vec *rot, Vec *scale); // Funsui particle effect
extern "C" void FUN_808025b0(ActivePhysics *apThis, ActivePhysics *apOther); // Sand pillar collision callback

void replaceSandPillarParticles(int playerNum, mEf::levelEffect_c *effect, char *effName, uint creatorId, Vec *pos, S16Vec *rot, Vec *scale) {
	char *newEffName = pillarEffect[lastPillarEffectType[playerNum]];
	return FUN_8008fba0(playerNum, effect, newEffName, creatorId, pos, rot, scale);
}

void newSandPillarCallback(ActivePhysics *apThis, ActivePhysics *apOther) {
	if (apOther->owner->stageActorType == apOther->owner->PlayerType) {
		int playerNum = apOther->owner->which_player;
		lastPillarEffectType[playerNum] = 0;
	}
	return FUN_808025b0(apThis, apOther);
}

//
// processed\../src/newSfx.cpp
//

#include <game.h>
#include <sfx.h>
#include "music.h"
#include "fileload.h"

const char* SFXNameList [] = {
	"original",				// 1999, DON'T USE THIS ONE
	// add more sfx here	// 2000
	NULL
};

int currentSFX = -1;
u32 *currentPtr = 0;

extern void loadFileAtIndex(u32 *filePtr, u32 fileLength, u32* whereToPatch);

// static FileHandle handle;
extern u32* GetCurrentPC();


extern "C" u32 NewSFXTable[];
extern "C" u32 NewSFXIndexes;

void loadAllSFXs() {
	u32 currentIdx = (u32)&NewSFXIndexes;

	for(int sfxIndex = 0; sfxIndex < (sizeof(SFXNameList) - 1) / sizeof(SFXNameList[0]); sfxIndex++) {
		FileHandle handle;

		char nameWithSound[80] = "";
		snprintf(nameWithSound, 79, "/Sound/stream/sfx/%s.rwav", SFXNameList[sfxIndex]);

		u32 filePtr = (u32)LoadFile(&handle, nameWithSound);

		NewSFXTable[sfxIndex] = currentIdx;
		loadFileAtIndex((u32*)filePtr, handle.length, (u32*)currentIdx);
		currentIdx += handle.length;
		currentIdx += (currentIdx % 0x10);
		FreeFile(&handle);
	}
}

int hijackSFX(int SFXNum) {
	int nameIndex = SFXNum - 1999;
	if(currentSFX == nameIndex) {
		return 189;
	}

	currentPtr = (u32*)NewSFXTable[nameIndex];
	currentSFX = nameIndex;

	return 189;
}

static nw4r::snd::StrmSoundHandle yoshiHandle;

void fuckingYoshiStuff() {
	PlaySoundWithFunctionB4(SoundRelatedClass, &yoshiHandle, 189, 1);
}

