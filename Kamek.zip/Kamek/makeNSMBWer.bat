@ECHO OFF
cd /d "%~dp0"
py -3 makeGame.py NSMBWerProject.yaml
pause